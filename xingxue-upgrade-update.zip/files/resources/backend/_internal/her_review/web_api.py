"""Web UI 的 JSON 接口。

约定：
    handle(app, method, path, query, payload) -> (状态码, 数据) | None
    返回 None 表示"没有这个接口"。

所有接口都返回可以直接交给前端渲染的**纯数据**（不带 ANSI 颜色、不带框线），
终端那套渲染（ui.py / report.py）完全不复用——两种界面的排版诉求不一样。
"""

from __future__ import annotations

import json
from pathlib import Path
import re
from datetime import date, datetime

from . import curriculum, evidence, gem, learning, queue as queue_mod, search, sm2

# --------------------------------------------------------------------------
# 序列化辅助：把领域对象变成前端能直接用的 dict
# --------------------------------------------------------------------------

def problem_json(p, *, with_note: bool = False, today: date | None = None) -> dict:
    """把一道题变成前端能直接渲染的 dict。

    today 要显式传进来（不要用 date.today()）：
    否则 dashboard 用注入的"今天"算出的到期数，
    和每道题自报的"逾期"标记会对不上——同一个页面出现两种日期口径最难查。
    """
    ref = today or date.today()
    data = {
        "id": p.id,
        "title": p.title,
        "source": p.source,
        "source_label": p.source_label,
        "difficulty": p.difficulty,
        "difficulty_label": p.difficulty_label,
        "tags": p.tags,
        "url": p.url,
        "maturity": p.maturity,
        "due": p.due.isoformat(),
        "due_in": (p.due - ref).days,
        "interval": p.interval,
        "ef": round(p.ef, 2),
        "repetitions": p.repetitions,
        "lapses": p.lapses,
        "review_count": p.review_count,
        "overdue": p.is_due(ref),
        "has_note": bool((p.note or "").strip()),
    }
    if with_note:
        data["note"] = p.note
        data["memory"] = p.memory
    return data


def note_json(row) -> dict:
    return {
        "id": row["id"],
        "body": row["body"],
        "color": row["color"],
        "pinned": bool(row["pinned"]),
        "archived": bool(row["archived"]),
        "created_at": (row["created_at"] or "")[:10],
    }


def countdown_json(row, today: date) -> dict:
    from . import panels

    target = date.fromisoformat(row["target"])
    yearly = bool(row["yearly"])
    effective = panels._next_occurrence(target, yearly, today)
    left = panels._days_left(effective, today)
    # 农历：倒数日里显示出来（农历模块早就有，只是一直没接上）。
    # 节日优先显示节日名（重阳节 / 中秋 / 春节），没有就显示农历日。
    lunar_text = ""
    try:
        from . import lunar

        lunar_text = lunar.festival(effective.year, effective.month, effective.day) \
            or lunar.day_text(effective.year, effective.month, effective.day)
    except Exception:
        lunar_text = ""
    return {
        "id": row["id"],
        "title": row["title"],
        "lunar": lunar_text,
        "kind": row["kind"],
        "kind_label": panels.KIND_LABELS.get(row["kind"], ("事件", ""))[0],
        "note": row["note"],
        "target": row["target"],
        "effective": effective.isoformat(),
        "yearly": yearly,
        "days_left": left,
        "passed": left < 0 and not yearly,
    }


def reminder_json(row) -> dict:
    from . import panels

    return {
        "id": row["id"],
        "body": row["body"],
        "pattern": row["pattern"],
        "pattern_label": panels.PATTERN_LABELS.get(row["pattern"], row["pattern"]),
        "when": panels.reminder_when(row),
        "at_time": row["at_time"],
        "important": row["priority"] == "important",
        "enabled": bool(row["enabled"]),
        "date": row["date"],
        "weekday": row["weekday"],
    }


# --------------------------------------------------------------------------
# 各领域接口
# --------------------------------------------------------------------------

def api_dashboard(ctx) -> dict:
    """首页需要的一切。一次请求拿全，避免前端串行等好几个接口。"""
    from . import encouragement
    from . import failures as failures_mod

    store = ctx.store
    today = ctx.today()
    due = store.due(today)
    streak = store.streak(today)
    left = gem.days_until_birthday(ctx.birthday, today) if ctx.birthday else None
    is_bday = gem.is_birthday(ctx.birthday, today)

    # 按当前处境挑一句鼓励语（生日 > 刚做完 > 深夜 > 有题 > 默认）
    hour = _now_hour(ctx)
    msg_kind, msg = encouragement.suitable_for_now(
        today, hour, is_birthday=is_bday, due_count=len(due))

    # 面板：复用 CLI 那套注册表，保证两端看到的顺序和内容一致
    from . import features

    panels: list[dict] = []
    registry = features.PanelRegistry()
    try:
        features.register_builtin_panels(registry, ctx)
    except Exception:
        pass
    for name in ctx.cfg.panel_order():
        spec = registry.get(name)
        if spec is None:
            continue
        panels.append({
            "id": spec.id,
            "title": spec.title,
            "intro": spec.intro,
            "source": spec.source,
            "kind": _panel_kind(spec.id),
        })
    # 插件面板单独标出来
    for name in ctx.cfg.panel_order():
        if not registry.get(name) and name:
            panels.append({"id": name, "title": name, "intro": "", "source": "插件",
                           "kind": "plugin"})

    return {
        "ok": True,
        "greeting": gem.greeting(ctx.name),
        "name": ctx.name,
        "today": today.isoformat(),
        "weekday": "周" + "一二三四五六日"[today.weekday()],
        "birthday": ctx.cfg.birthday,
        "birthday_in": left,
        "is_birthday": is_bday,
        "birthday_wish": gem.birthday_wish(ctx.birthday, ctx.name) if is_bday else "",
        "message": msg,
        "message_kind": msg_kind,
        "due_count": len(due),
        "total": store.count(),
        "streak": streak,
        "longest_streak": store.longest_streak(),
        "review_count": store.review_count_total(),
        "seconds": store.total_seconds(),
        "pending_failures": failures_mod.count_open(store),
        "due_preview": [problem_json(p, today=today) for p in due[:8]],
        "quote": gem.daily_quote(today),
        "care": gem.daily_care(today),
        "reminders_today": [reminder_json(r) for r in store.reminders_today(today)],
        "countdowns": [countdown_json(r, today) for r in store.countdowns()][:6],
        "cycle": cycle_json(ctx, today),
        "notes": [note_json(r) for r in store.notes()[:6]],
        "course": _course_coverage(ctx),
        "panels": panels,
        "theme": {"name": ctx.theme.name(), "seed": ctx.theme.seed},
    }


def _now_hour(ctx) -> int:
    """当前小时。--today 预览时不该受真实时间影响，所以锁定成白天。"""
    if getattr(ctx, "_web_today", None) is not None:
        return 14
    from datetime import datetime

    return datetime.now().hour


def api_message(ctx, payload: dict) -> dict:
    """要一句新的话（她点「再来一句」或摸猫时调）。"""
    from . import encouragement

    kind = (payload or {}).get("kind") or "home"
    petting = kind == "pet"
    line = encouragement.random_one(kind if kind in encouragement.MESSAGES else "home")
    return {
        "ok": True,
        "message": line,
        "kind": kind,
        "petting": petting,
        # 摸猫时顺便换一个表情，比只换文字更有反馈
        "mascot": _pet_pose(petting),
    }


def _pet_pose(petting: bool) -> str:
    """摸猫时给个随机表情，让它看起来是活的。

    只能返回 SVG 猫真正画出来的那几种姿态。
    之前这里返回过 "money"（旧字符画有、新 SVG 没有），
    前端拿到不认识的值就退回默认表情，摸起来像没反应。
    """
    if not petting:
        return "sit"
    import random

    # sit 权重高一些：摸猫大多数时候应该是开心的普通表情
    return random.choice(["cheer", "sit", "sit", "cheer", "sit"])


def api_kinds(ctx) -> dict:
    """语料统计，给「环境自检」或关于页用。"""
    from . import encouragement

    return {"ok": True, "counts": encouragement.counts(),
            "total": sum(encouragement.counts().values())}


def _panel_kind(panel_id: str) -> str:
    """告诉前端这个面板该渲染成什么形状。"""
    return {
        "countdown": "countdown",
        "course": "course",
        "learning": "learning",
        "notes": "notes",
        "reminders": "reminders",
        "quote": "quote",
    }.get(panel_id, "plugin")


def _course_coverage(ctx, limit: int | None = None) -> dict:
    problems = ctx.store.all()
    counts = dict(curriculum.coverage(problems))
    rows = []
    for course in curriculum.COURSES:
        rows.append({
            "code": course.code,
            "name": course.name,
            "category": course.category,
            "why": course.why,
            "count": counts.get(course, 0),
            "tags": course.tags,
            "points": course.points,
            "sites": course.sites,
        })
    total_points = sum(len(c.points) for c in curriculum.COURSES)
    return {
        "courses": rows if limit is None else rows[:limit],
        "total_courses": len(curriculum.COURSES),
        "total_points": total_points,
        "covered": sum(1 for r in rows if r["count"]),
        "categories": [{"name": n, "hint": h} for n, h in curriculum.CATEGORIES],
    }


def api_review_queue(ctx, *, limit: int = 0) -> dict:
    """复习队列 + 过滤说明。"""
    problems, report = queue_mod.build_queue(ctx.store, ctx.today(), limit=limit)
    return {
        "ok": True,
        "problems": [problem_json(p, with_note=False, today=ctx.today()) for p in problems],
        "total_due": len(ctx.store.due(ctx.today())),
        "report": {
            "eligible": report.eligible,
            "deduped": report.deduped,
            "dropped_by_cap": report.dropped_by_cap,
            "thin": report.thin,
            "duplicates": report.duplicates,
        },
    }


def api_review_card(ctx, problem_id: int) -> dict:
    """一张复习卡片。默认**不给思路**——先让她自己想，这是间隔重复的前提。"""
    p = ctx.store.get(problem_id)
    if p is None:
        return {"ok": False, "error": "找不到这道题"}
    return {"ok": True, "problem": problem_json(p, with_note=False, today=ctx.today())}


def api_review_show(ctx, problem_id: int) -> dict:
    """看思路（前端点"想不起来"时才调）。

    suggestions 放在**顶层**而不是塞进 problem 里：
    problem 只描述题目本身，搜索建议是"接下来可以做什么"，
    两者混在一起会让前端很难判断哪些是题目字段。
    """
    p = ctx.store.get(problem_id)
    if p is None:
        return {"ok": False, "error": "找不到这道题"}
    data = problem_json(p, with_note=True, today=ctx.today())
    return {
        "ok": True,
        "problem": data,
        "suggestions": [
            {"label": label, "keyword": kw, "url": search.search_url(kw)}
            for label, kw in search.queries_for_problem(p.title, p.tags)
        ],
    }


def api_review_submit(ctx, payload: dict) -> dict:
    """提交评分，SM-2 排下次复习。"""
    problem_id = payload.get("id")
    quality = payload.get("quality")
    if not isinstance(problem_id, int):
        return {"ok": False, "error": "缺少题目 id"}
    if not isinstance(quality, int) or quality not in range(6):
        return {"ok": False, "error": "评分必须是 0-5"}

    p = ctx.store.get(problem_id)
    if p is None:
        return {"ok": False, "error": "找不到这道题"}

    before = len(ctx.store.due(ctx.today()))
    result = ctx.store.submit_review(p, quality, today=ctx.today())
    left = max(0, before - 1)
    return {
        "ok": True,
        "passed": result.passed,
        "label": result.label,
        "interval": result.interval,
        "interval_text": sm2.human_interval(result.interval),
        "due": result.due.isoformat(),
        "ef": round(result.ef, 2),
        "repetitions": result.repetitions,
        "maturity": p.maturity,
        "remaining": left,
        "lapses": p.lapses,
    }


def api_stats(ctx) -> dict:
    """成绩单。

    除了通用统计，还带上**六级备考的专项统计**——
    通用统计是混着算法题一起算的，她看不出"我的六级背到哪了"。
    """
    store = ctx.store
    today = ctx.today()
    counts = store.maturity_counts()
    weak = [{"tag": t, "interval": round(iv, 1)} for t, iv in store.weakest_tags(5)]
    hardest = [problem_json(p, today=today) for p in store.hardest(6)]
    tags = [{"tag": t, "count": n, "avg_interval": round(iv, 1)}
            for t, n, iv, _ in store.tag_stats()[:12]]
    forecast = store.due_forecast(14, today)
    total = store.count()
    heat = store.heatmap(18, today)

    # 六级专项
    from . import cet6

    try:
        cet6_stats = cet6.study_stats(store, today)
    except Exception as exc:
        cet6_stats = {"error": f"{exc.__class__.__name__}: {exc}"}

    return {
        "ok": True,
        "total": total,
        "due": len(store.due(today)),
        "reviews": store.review_count_total(),
        "seconds": store.total_seconds(),
        "streak": store.streak(today),
        "longest": store.longest_streak(),
        "maturity": counts,
        "weak_tags": weak,
        "hardest": hardest,
        "tags": tags,
        "forecast": [{"day": k, "count": v} for k, v in sorted(forecast.items())],
        "heatmap": heat,
        "cet6": cet6_stats,
        "days_together": gem.days_together(ctx.together, today) if ctx.together else None,
        "birthday_in": gem.days_until_birthday(ctx.birthday, today) if ctx.birthday else None,
    }


def api_problems(ctx, query: dict) -> dict:
    """题库列表（带筛选）。"""
    store = ctx.store
    keyword = (query.get("q") or "").strip()
    tag = (query.get("tag") or "").strip()
    difficulty = (query.get("difficulty") or "").strip()
    only_due = query.get("due") in ("1", "true", "yes")
    course_code = (query.get("course") or "").strip()
    sort = query.get("sort") or "due"

    if keyword:
        problems = store.search(keyword)
    else:
        problems = store.all()

    if tag:
        problems = [p for p in problems if tag in p.tags]
    if difficulty:
        problems = [p for p in problems if p.difficulty == difficulty]
    if only_due:
        problems = [p for p in problems if p.is_due(ctx.today())]
    if course_code:
        course = curriculum.by_code(course_code)
        if course:
            wanted = {t.lower() for t in course.tags}
            problems = [p for p in problems
                        if any(t.lower() in wanted for t in (p.tags or []))]

    if sort == "review":
        problems.sort(key=lambda p: (-p.review_count, p.id))
    elif sort == "lapses":
        problems.sort(key=lambda p: (-p.lapses, p.id))
    elif sort == "title":
        problems.sort(key=lambda p: p.title)
    else:
        problems.sort(key=lambda p: (p.due, -p.lapses))

    all_tags: dict[str, int] = {}
    for p in store.all():
        for t in p.tags:
            all_tags[t] = all_tags.get(t, 0) + 1

    # ---- 分页 ----
    #
    # **参数要么生效，要么别接受。**
    # 原来 `?limit=5` 会被忽略、返回全部 126 道（52KB），
    # 调用方以为拿到 5 条、实际拿到 126 条，然后奇怪为什么这么慢。
    #
    # 默认值刻意选"不给就是全部"——这样已有的调用方行为不变，
    # 不为了修一个参数去破坏别的东西。
    total = len(problems)
    try:
        limit = int(query.get("limit") or 0)
    except (TypeError, ValueError):
        limit = 0
    try:
        offset = int(query.get("offset") or 0)
    except (TypeError, ValueError):
        offset = 0
    if offset < 0:
        offset = 0
    page: int | None = None
    if limit > 0:
        # 夹一下上限：`limit=999999` 会让序列化把内存吃爆
        limit = min(limit, 500)
        problems = problems[offset:offset + limit]
        # 页码是给界面显示用的（1 起），算不出来（offset 超范围）就给 None
        page = (offset // limit) + 1 if limit else None

    return {
        "ok": True,
        "problems": [problem_json(p, today=ctx.today()) for p in problems],
        # count = **这一页**几条；total = 符合条件的总数。
        #
        # 原来这里是 `problems[:400]` + `"count": len(problems)`，
        # 两个都有问题：
        #   · `[:400]` 是个**隐藏上限**——超过 400 道就静默截断，
        #     而 count 报的是截断前的数，于是"说 500 条实际给 400 条"
        #   · 现在由上面的 limit/offset 负责分页，这里不该再截
        #     （默认 limit=0 就是全部，行为不变；
        #      真要限量的话调用方传 limit，那才是看得见的）
        "count": len(problems),
        "total": total,
        "limit": limit,
        "offset": offset,
        "page": page,
        "tags": sorted(all_tags.items(), key=lambda kv: -kv[1]),
        "sources": sorted({p.source for p in store.all()}),
    }


def api_problem_create(ctx, payload: dict) -> dict:
    from . import io_formats

    title = (payload.get("title") or "").strip()
    if not title:
        return {"ok": False, "error": "题名不能为空"}
    url = (payload.get("url") or "").strip()
    try:
        pid = ctx.store.add(
            title=title,
            source=payload.get("source") or io_formats.guess_source(url),
            difficulty=io_formats.normalize_difficulty(payload.get("difficulty")),
            tags=queue_mod.normalize_tags(payload.get("tags") or []).tags,
            url=url,
            note=(payload.get("note") or "").strip(),
            memory=(payload.get("memory") or "").strip(),
        )
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    p = ctx.store.get(pid)
    return {"ok": True, "problem": problem_json(p, with_note=True, today=ctx.today()) if p else None}


def api_problem_update(ctx, problem_id: int, payload: dict) -> dict:
    changes: dict = {}
    for key in ("title", "note", "memory", "url", "difficulty", "source"):
        if key in payload:
            changes[key] = payload[key]
    if "tags" in payload:
        changes["tags"] = queue_mod.normalize_tags(payload["tags"] or []).tags
    if "archived" in payload:
        changes["archived"] = bool(payload["archived"])
    if not changes:
        return {"ok": False, "error": "没有要改的字段"}
    ok = ctx.store.update(problem_id, **changes)
    p = ctx.store.get(problem_id)
    return {"ok": ok, "problem": problem_json(p, with_note=True, today=ctx.today()) if p else None}


def api_problem_delete(ctx, problem_id: int) -> dict:
    return {"ok": ctx.store.delete(problem_id)}


def api_problem_detail(ctx, problem_id: int) -> dict:
    p = ctx.store.get(problem_id)
    if p is None:
        return {"ok": False, "error": "找不到这道题"}
    rows = [r for r in ctx.store.review_log(400) if r["problem_id"] == problem_id][:20]
    return {
        "ok": True,
        "problem": problem_json(p, with_note=True, today=ctx.today()),
        "history": [
            {"on": r["reviewed_on"], "quality": r["quality"],
             "interval_after": r["interval_after"]}
            for r in rows
        ],
        "suggestions": [
            {"label": label, "keyword": kw, "url": search.search_url(kw)}
            for label, kw in search.queries_for_problem(p.title, p.tags)
        ],
    }


def api_search(ctx, query: dict) -> dict:
    """B 站搜索。联网失败就降级成链接（前端照样能点）。"""
    from . import failures as failures_mod

    keyword = (query.get("q") or "").strip()
    problem_id = query.get("problem")
    problem = None
    if problem_id and str(problem_id).isdigit():
        problem = ctx.store.get(int(problem_id))

    if not keyword and problem:
        derived = search.queries_for_problem(problem.title, problem.tags)
        keyword = derived[0][1] if derived else problem.title
    if not keyword:
        return {"ok": False, "error": "没给搜索词"}

    outcome = search.search_online_cached(keyword, page=int(query.get("page") or 1))
    if outcome.ok:
        failures_mod.resolve_kind(ctx.store, "search")
    else:
        failures_mod.record(ctx.store, "search", "B 站搜索没拿到在线结果",
                            detail=outcome.error, retry=f'her search "{keyword}"')

    suggestions = []
    if problem:
        suggestions = [
            {"label": label, "keyword": kw, "url": search.search_url(kw)}
            for label, kw in search.queries_for_problem(problem.title, problem.tags)
        ]

    return {
        "ok": True,
        "keyword": search.build_query(keyword),
        "online": outcome.ok,
        "error": outcome.error,
        "search_url": search.search_url(keyword),
        # 总条数：搜索接口本来就会给（一次搜索它知道一共有多少条），
        # 但界面上只显示当页的十几条。不写清楚会让人以为"就这些"。
        "num_results": outcome.num_results,
        "videos": [
            {"title": v.title, "author": v.author, "url": v.url,
             "duration": v.duration_text(), "play": v.play_text(),
             "bvid": v.bvid,
             # 封面图。B 站搜索结果里本来就有，直接用（已缩过尺寸）。
             # 有些条目没有封面，留空由界面显示占位符。
             "pic": v.pic}
            for v in outcome.videos
        ],
        "suggestions": suggestions,
        "templates": [
            {"key": key, "label": label, "url": search.search_url(keyword, template=key)}
            for key, label in search.TEMPLATE_LABELS.items()
        ],
    }


def api_video_status(ctx) -> dict:
    """视频总结器的状态。"""
    from . import bilisum, deps

    installed = bilisum.installed()
    data: dict = {
        "ok": True,
        "installed": installed,
        "libraries": deps.capability_report(),
        "backend": str(bilisum.find_backend()) if installed else "",
    }
    if not installed:
        data["hint"] = ("没找到 BiliSum。装过的话设环境变量 BILISUM_HOME 指向安装目录；"
                        "没装也不影响复习，只是不能自动总结视频。")
        return data

    client = bilisum.Client(ctx.cfg.home)
    try:
        client.prepare()
    except bilisum.ServiceError as exc:
        data["hint"] = str(exc)
        return data
    data["data_root"] = str(client.data_root)
    data["port"] = client.port
    data["running"] = client.service_running()
    if data["running"]:
        ok, state = client.health()
        data["health"] = state
        data["ready"] = ok
    # 她的 BiliSum 有没有配大模型——决定"总结"是 LLM 笔记还是转写+概览
    try:
        settings = (client.data_root or ctx.cfg.home) / "data" / "settings.json"
        if settings.exists():
            payload = json.loads(settings.read_text(encoding="utf-8"))
            data["llm_enabled"] = bool(payload.get("llm_enabled"))
            data["transcription"] = payload.get("transcription_provider") or ""
    except Exception:
        pass
    return data


def api_video_start(ctx, payload: dict) -> dict:
    """启动一个总结任务，立刻返回 task_id（前端轮询进度）。"""
    from . import bilisum, failures as failures_mod

    url = (payload.get("url") or "").strip()
    if not url:
        return {"ok": False, "error": "要一个视频链接"}
    client = bilisum.Client(ctx.cfg.home)
    try:
        ok, message = client.ensure_service()
    except bilisum.ServiceError as exc:
        return {"ok": False, "error": str(exc)}
    if not ok:
        failures_mod.record(ctx.store, "summarize", "视频总结服务启动失败",
                            detail=message, retry="her video start")
        return {"ok": False, "error": message}

    ok, task_or_error = client.create_task(url)
    if not ok:
        failures_mod.record(ctx.store, "summarize", "创建总结任务失败",
                            detail=task_or_error, retry=f'her summarize "{url}"')
        return {"ok": False, "error": task_or_error}
    return {"ok": True, "task_id": task_or_error}


def api_video_progress(ctx, task_id: str) -> dict:
    from . import bilisum

    client = bilisum.Client(ctx.cfg.home)
    try:
        client.prepare()
    except bilisum.ServiceError as exc:
        return {"ok": False, "error": str(exc)}
    prog = client.progress(task_id)
    return {
        "ok": True,
        "status": prog.status,
        "progress": prog.progress,
        "stage": prog.stage,
        "message": prog.message,
        "done": prog.is_done(),
    }


def api_video_result(ctx, task_id: str, payload: dict) -> dict:
    """取结果。可选写回某道题的笔记（脱敏 + 预算 + 指纹 + 不覆盖）。"""
    from . import bilisum, failures as failures_mod

    client = bilisum.Client(ctx.cfg.home)
    try:
        client.prepare()
    except bilisum.ServiceError as exc:
        return {"ok": False, "error": str(exc)}

    summary = client.fetch_result(task_id)
    if not summary.has_content():
        reason = summary.error or "后端说任务完成了，但没拿到内容"
        failures_mod.record(ctx.store, "summarize", "总结完成但没有内容",
                            detail=reason, retry=f"her quality")
        return {"ok": False, "error": reason}

    body = bilisum.render_summary_markdown(summary)
    safe, redacted = evidence.redact(body)
    budget = evidence.budget(safe, "problem_note")

    report = evidence.build_report(
        summary, llm_used=_llm_enabled_from_settings(client),
        transcript_source=_guess_source(summary),
        warnings=([f"内容超出笔记预算（{budget.original_chars} → {budget.kept_chars} 字），已裁剪"]
                  if budget.truncated else [])
        + ([f"已脱敏 {redacted} 处疑似密钥"] if redacted else []),
    )

    saved = None
    problem_id = payload.get("problem_id")
    if payload.get("save") and isinstance(problem_id, int):
        problem = ctx.store.get(problem_id)
        if problem:
            saved = _write_into_note(ctx, problem, budget.text, report)

    return {
        "ok": True,
        "markdown": budget.text,
        "truncated": budget.truncated,
        "original_chars": budget.original_chars,
        "redacted": redacted,
        "quality": report.to_dict(),
        "quality_lines": report.lines(),
        "confidence": report.confidence()[0],
        "saved": saved,
    }


def _llm_enabled_from_settings(client) -> bool:
    try:
        settings = (client.data_root or Path(".")) / "data" / "settings.json"
        if settings.exists():
            return bool(json.loads(settings.read_text(encoding="utf-8")).get("llm_enabled"))
    except Exception:
        pass
    return False


def _guess_source(summary) -> str:
    text = " ".join(filter(None, [getattr(summary, "overview", "") or "",
                                 getattr(summary, "transcript", "") or ""]))
    if not text:
        return "unknown"
    fillers = sum(text.count(w) for w in ("呃", "啊", "呢", "哦", "嗯"))
    periods = text.count("。") + text.count("，")
    if periods >= 5 and fillers / max(1, periods) < 0.08:
        return "subtitle"
    if fillers >= 8:
        return "asr"
    return "unknown"


def _write_into_note(ctx, problem, text: str, report) -> dict:
    """写回笔记：幂等 + 不覆盖 + 超预算另存。和 CLI 走同一套保护。"""
    from pathlib import Path

    stamp = datetime.now().strftime("%Y-%m-%d")
    header = (f"【视频笔记 {stamp}】{report.title or ''}\n"
              f"来源指纹 {report.source_fingerprint}　"
              f"转写来源：{report.source_label()}　可信度：{report.confidence()[0]}\n")
    existing = problem.note or ""

    if existing and report.source_fingerprint and report.source_fingerprint in existing:
        return {"action": "skipped", "message": "笔记里已经有同一份内容（来源指纹相同）"}

    if not existing:
        ctx.store.update(problem.id, note=header + text)
        return {"action": "written", "message": "已写入笔记"}

    limit = evidence.BUDGETS["problem_note"]
    merged = existing + "\n\n" + header + text
    if len(merged) <= limit:
        ctx.store.update(problem.id, note=merged)
        return {"action": "appended", "message": "已追加（原来写的内容保留）"}

    room = limit - len(existing) - len(header) - 80
    if room >= 500:
        ctx.store.update(problem.id,
                         note=existing + "\n\n" + header + text[:room] + "\n…（已裁剪）")
        return {"action": "appended", "message": "已追加并裁剪（原来写的内容保留）"}

    out_dir = ctx.cfg.home / "notes"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{problem.id}-{stamp}.md"
    path.write_text(header + text, encoding="utf-8")
    return {"action": "file", "message": f"笔记接近上限，已另存到 {path.name}"}


def cycle_json(ctx, today: date) -> dict:
    """生理期预测。全部是「按你填的周期推的」，不是诊断。

    男性（设置里选了男）时**整体隐藏**：只回一个空壳 + hidden=True，
    phase / days_until / next_start / message 这些一个都不填 ——
    不把她的周期信息交给前端。

    隐藏≠删除：`cycle_last_start` 这些数据一个字节都不动，
    改回女性立刻恢复原样。
    """
    from . import cycle

    if ctx.cfg.cycle_hidden():
        # 性别选了「男」。
        #
        # **不是"整块隐藏"**：用户反馈过"设成男之后月历消失了"——
        # 那一步是多余的。性别管的是**提醒**（设置项自己的说明就是
        # 「决定要不要生理期提醒」），而她**自己记的数据**不该因此消失。
        #
        # 所以：有数据就照常给（月历要画、也能继续记），
        # 但把提醒相关的字段全部清空——首页那行、消息文案都不会出现。
        pred = cycle.predict(ctx.cfg, ctx.today())
        if pred.last_start is None:
            # 什么都没记过：没什么可显示的，保持原来的空壳
            return dict(_CYCLE_HIDDEN, hidden=True)
        return {
            "hidden": True,          # 语义＝"不要提醒"（不再是"整块别显示"）
            "enabled": False,        # 提醒关着
            "configured": True,
            "last_start": pred.last_start.isoformat(),
            "cycle_length": pred.cycle,
            "period_days": pred.period_days,
            # 下面这几个是"提醒/解读"性质的：男性态一律不给
            "phase": "",
            "phase_label": "",
            "day_of_cycle": None,
            "days_until": None,
            "message": "",
            # 月历要用到的日期照给
            "period_start": pred.period_start.isoformat() if pred.period_start else "",
            "period_end": pred.period_end.isoformat() if pred.period_end else "",
            "next_start": pred.next_start.isoformat() if pred.next_start else "",
            "next_end": pred.next_end.isoformat() if pred.next_end else "",
            "in_period": False,
            "stale": False,
            "cycles_ahead": pred.cycles_ahead,
        }

    pred = cycle.predict(ctx.cfg, today)
    return {
        "hidden": False,
        "enabled": bool(getattr(ctx.cfg, "cycle_reminder", True)),
        "configured": pred.last_start is not None,
        "last_start": pred.last_start.isoformat() if pred.last_start else "",
        "cycle_length": pred.cycle,
        "period_days": pred.period_days,
        "phase": pred.phase,
        "phase_label": pred.phase_label,
        "day_of_cycle": pred.day_of_cycle,
        "days_until": pred.days_until,
        "period_start": pred.period_start.isoformat() if pred.period_start else "",
        "period_end": pred.period_end.isoformat() if pred.period_end else "",
        "next_start": pred.next_start.isoformat() if pred.next_start else "",
        "next_end": pred.next_end.isoformat() if pred.next_end else "",
        # （原来这里还有 ovulation / fertile_from / fertile_to 三个字段，
        #   随"去掉排卵/易孕"一起删了——算法层已经不算它们。）
        "in_period": pred.in_period(),
        "stale": pred.is_stale(),
        "cycles_ahead": pred.cycles_ahead,
        "message": pred.message(),
    }


# 男性时 `cycle_json` 回的"空壳"。
#
# 为什么要留一份完整的键：前端多处会读 `cycle.xxx`，
# 键突然消失会渲染出 `undefined`。所以**键都在、值全空**，
# 前端只要看 hidden 就够了。
#
# 这里刻意把 cycle_length / period_days 也置 0 而不是她的真实值——
# "隐藏"就该是彻底隐藏，留个 28 天也是泄漏。
_CYCLE_HIDDEN: dict = {
    # **只回这一个键。**
    #
    # 原来把值清空但键名都留着（period_days / cycle_length …）。
    # 值确实没泄露，但**字段名本身也带语义**——返回体一旦被保存或分享，
    # 别人也能看出这个人在用生理期功能。用户明确要求"男性就不出现生理期"，
    # 那就连"存在过"都不该暴露。
    #
    # 安全性：前端只读 `hidden`（`v-if="!cycle.hidden"`、
    # `configured && enabled && !hidden`），旧版 app.js 同理——
    # 键没了就是 falsy，行为完全不变。
    "hidden": True,
}

# 男性时所有"写生理期"的接口都回这一句。
# 文案要说清**去哪改**，否则她只会看到"操作失败"。
_CYCLE_MALE_ERROR = ("设置里选的是男性，所以生理期记录是关着的。"
                     "想记录的话，去「设置 → 基本信息」把性别改成女性。")


def api_cycle_save(ctx, payload: dict) -> dict:
    """保存生理期设置。

    三个参数都要校验：周期长度填错（比如填 5 天）会算出一个毫无意义的预测，
    与其照着离谱输入算，不如明确告诉她合理范围。

    性别是男性时**直接拒绝**并且不落盘：既不改她的数据，
    也不让前端误以为保存成功了。
    """
    from . import cycle, gem

    # **男性态也允许记录**：月历还在、还能点「记录今天来了」，
    # 拦下来只会让她看到一个莫名其妙的错误。
    # （提醒归提醒，记录归记录。）
    cfg = ctx.cfg

    # **什么都没带就别装成保存成功。**
    #
    # 原来这里直接往下走：四个字段一个都没有时，它仍然 `cfg.save()`
    # 并且返回 ok=True —— 前端/脚本会以为设置生效了，其实什么都没变。
    # （实测：POST {} → 200 {"ok": true}）
    _known = ("enabled", "last_start", "cycle_length", "period_days")
    if not any(k in payload for k in _known):
        return {"ok": False,
                "error": ("没有要保存的内容。至少给一个："
                          "enabled / last_start / cycle_length / period_days")}

    if "last_start" in payload:
        value = (payload.get("last_start") or "").strip()
        if value:
            parsed = gem.parse_date(value)
            if parsed is None:
                return {"ok": False, "error": "日期看不懂，用 2026-10-01 或 10-01 这种格式"}
            if parsed > date.today():
                return {"ok": False, "error": "日期填成未来的了，检查一下年份"}
            cfg.cycle_last_start = parsed.isoformat()
        else:
            cfg.cycle_last_start = ""

    if "cycle_length" in payload:
        good, why = cycle.validate_cycle(payload.get("cycle_length"))
        if not good:
            return {"ok": False, "error": why}
        cfg.cycle_length = int(payload["cycle_length"])

    if "period_days" in payload:
        good, why = cycle.validate_period(payload.get("period_days"))
        if not good:
            return {"ok": False, "error": why}
        cfg.cycle_period_days = int(payload["period_days"])

    if "enabled" in payload:
        cfg.cycle_reminder = bool(payload["enabled"])

    try:
        cfg.save()
    except OSError as exc:
        return {"ok": False, "error": f"保存失败：{exc}"}
    return {"ok": True, "cycle": cycle_json(ctx, ctx.today())}


def api_cycle_mark(ctx, payload: dict) -> dict:
    """记录"这次开始了"——最常用的一个动作，所以单独给了接口。

    男性时同样拒绝（400 + 说清原因），而且**不写配置**。
    """
    from . import cycle, gem

    # 男性态也允许记录（见 api_cycle_save 的说明）

    value = (payload.get("date") or "").strip()
    when = gem.parse_date(value) if value else ctx.today()
    if when is None:
        return {"ok": False, "error": "日期看不懂"}
    if when > ctx.today():
        return {"ok": False, "error": "不能记录未来的日期"}
    cycle.mark(ctx.cfg, when)
    return {"ok": True, "cycle": cycle_json(ctx, ctx.today())}


def _cookies_home(ctx) -> Path:
    """cookies 存哪儿。

    **统一从这里取**，各处不要自己拼路径——
    拼错的表现是"保存成功了但搜索还是 412"，很难查。
    """
    return Path(ctx.cfg.home)


def api_cookies_status(ctx) -> dict:
    """当前 cookies 状态。

    **不回显 cookie 值**，只回名字和打码后的样子。
    这个返回会被显示在页面上、也可能进日志，
    而 cookies 是登录凭据，泄漏了等于把账号给人。
    """
    from . import browser_cookies, cookies

    home = _cookies_home(ctx)
    data = cookies.status(home)
    # 顺带告诉前端"能不能自动从浏览器抓"，好决定显示哪个按钮
    try:
        data["browser"] = browser_cookies.available()
    except Exception as exc:
        data["browser"] = {"can_auto": False, "browsers": [],
                           "reason": f"探测浏览器失败：{exc}"}
    return data


def api_cookies_save(ctx, payload: dict) -> dict:
    """保存 cookies。body: {text}"""
    from . import cookies

    text = str(payload.get("text") or "")
    if not text.strip():
        return {"ok": False, "error": "没有内容。把 cookie 粘进来再点保存。"}
    ok, msg, saved = cookies.save(_cookies_home(ctx), text)
    out = {"ok": ok, "message": msg, "count": len(saved)}
    if not ok:
        out["error"] = msg
    else:
        # 有没有登录凭据，这一步就要告诉她——
        # 只存到游客 cookie 的话搜索照样被限流
        from . import cookies as ck
        out["logged_in"] = ck.is_logged_in(saved)
        if not out["logged_in"]:
            out["warning"] = ("保存了，但里面**没有登录凭据**"
                              "（缺 SESSDATA / DedeUserID）。"
                              "这些多半只是游客标识，搜索仍可能被限流。")
        # **顺手同步给 BiliSum。**
        #
        # 她保存 cookies 本来就是为了让 B 站认得她，
        # 而 BiliSum 下载视频也需要这个。再点一个按钮是多此一举。
        #
        # 但**失败不能影响"保存成功"这个结论**：
        # BiliSum 可能没装、可能没在跑（视频总结第一次用才会拉起来）。
        # 那种情况下 cookies 是存好了的，只是视频下载暂时用不上。
        try:
            sync = api_cookies_sync(ctx, {})
            if sync.get("ok"):
                out["bilisum_synced"] = True
            elif not sync.get("skipped"):
                # 没跳过但失败了——说一句，但不改 ok
                out["bilisum_note"] = sync.get("error", "")
        except Exception as exc:
            out["bilisum_note"] = f"同步给 BiliSum 时出错：{exc}"
    return out


def api_cookies_clear(ctx) -> dict:
    """删除 cookies，退回未登录。"""
    from . import cookies

    ok, msg = cookies.clear(_cookies_home(ctx))
    return {"ok": ok, "message": msg}


def api_cookies_probe(ctx, payload: dict) -> dict:
    """真打一次 B 站搜索，验证 cookies 到底有没有用。

    为什么要这个：界面上"已保存"和"真能用"是两件事。
    过期凭据、只存了游客标识、值写错了——都会显示成"已保存"
    但搜索照样 412。
    """
    from . import search

    try:
        return search.cookies_probe(_cookies_home(ctx))
    except Exception as exc:
        return {"ok": False, "verdict": f"测试失败：{exc}",
                "hint": "这多半是程序的问题而不是 cookies 的问题。"}


def api_cookies_sync(ctx, payload: dict) -> dict:
    """把 cookies 文件路径告诉 BiliSum（给 yt-dlp 下载视频用）。

    为什么需要：BiliSum 下载 B 站视频走 yt-dlp，而 yt-dlp 要读
    cookies 文件才能下**会员视频 / 需要登录的视频**。

    **为什么传文件而不是让它从浏览器读**：
        `yt-dlp --cookies-from-browser` 在 **Windows 上不可用**
        （依赖的浏览器 cookie 解密库不支持）。
        让 BiliSum 走那条路等于让它失败。
    而我们的 cookies 正好已经存成 Netscape 格式——那正是 yt-dlp 认的格式。
    """
    from . import bilisum, cookies

    home = _cookies_home(ctx)
    if not cookies.load(home):
        return {"ok": False, "error": "还没有保存 cookies，先在上面保存一次。"}

    try:
        client = bilisum.Client(home)
    except Exception as exc:
        return {"ok": False, "error": f"用不了 BiliSum 客户端：{exc}"}

    if not client.service_running():
        return {
            "ok": False,
            "skipped": True,
            "error": "BiliSum 服务没在跑。",
            "hint": ("视频总结第一次用的时候会自动把它拉起来，"
                     "之后就同步好了。现在不用管。"),
        }

    ok, msg = client.sync_cookies_file(cookies.cookies_path(home))
    if not ok:
        return {"ok": False, "error": msg,
                "hint": "BiliSum 的接口可能变了；不影响搜索，只是视频下载用不上登录状态。"}
    return {"ok": True, "message": "已把 cookies 同步给 BiliSum（视频下载会用它）。"}


def api_cookies_bilisum(ctx) -> dict:
    """BiliSum 那边的 cookies 状态。界面用它决定显示什么。"""
    from . import bilisum, cookies

    home = _cookies_home(ctx)
    have_local = bool(cookies.load(home))
    try:
        client = bilisum.Client(home)
    except Exception as exc:
        return {"ok": False, "installed": False, "running": False,
                "reason": f"用不了 BiliSum 客户端：{exc}"}

    running = False
    try:
        running = client.service_running()
    except Exception:
        running = False

    if not running:
        return {
            "ok": True,
            "installed": True,
            "running": False,
            "have_local": have_local,
            "reason": "BiliSum 服务没在跑（视频总结第一次用会自动拉起来）。",
        }

    st = client.cookies_status()
    return {
        "ok": bool(st.get("ok")),
        "installed": True,
        "running": True,
        "have_local": have_local,
        "synced": bool(have_local
                       and st.get("cookies_file") == str(cookies.cookies_path(home))),
        "cookies_file": st.get("cookies_file", ""),
        "reason": st.get("reason", ""),
    }


def api_cookies_browser(ctx, payload: dict) -> dict:
    """从浏览器自动读 cookies。

    **可能失败**，而且失败原因会如实返回：
        · 浏览器正锁着文件   → 提示先关掉浏览器
        · v20 App-Bound 加密 → 自动读不了，引导到手动粘贴
        · 那个浏览器没登录过 → 换一个试

    这个接口**不会**为了"看起来成功"而返回空 cookies——
    那会让界面显示"已登录"而搜索照样 412。
    """
    from . import browser_cookies

    which = str(payload.get("which") or "")
    try:
        return browser_cookies.extract(_cookies_home(ctx), which)
    except Exception as exc:
        return {"ok": False, "error": f"读浏览器 cookies 出错：{exc}",
                "hint": "用下面的手动粘贴方式。"}


def api_mascot(ctx) -> dict:
    """符号喵喵的动作表。

    返回每个动作的**三样东西**：
        lines       画好的 ASCII 行（已经是最接近终端渲染的形式）
        name        中文名，比如「坐好」
        when        什么情况下会出现，比如「默认状态」

    为什么要给 name 和 when：设置页里有个动作预览，
    光看 ASCII 分不清哪个是哪个，得有个名字。

    注意 lines 里带 [p][/] [P][/] 这类**颜色标记**——
    那是给终端用的 ANSI 替身。Vue 版按这些标记转成 <span class="mc-p">，
    颜色由 styles.css 里的 .mc-* 决定，这样和整体配色一致。
    """
    from . import mascot

    # **用 plain() 剥掉颜色标记**，跟旧版 web_server._ascii_cat_html() 一致。
    #
    # 为什么不用原始 POSES：那里面带 [p][/] [P][/] 这类标记，
    # 是给终端上色用的。旧版网页端是剥掉之后单色渲染的
    # （CSS 里 .cat-ascii 只有一个 color，没有任何按标记上色的规则）。
    #
    # 用户要求"完全保留现有样式"，所以这里不能擅自改成彩色——
    # 那属于改画风，是另一个需要单独确认的决定。
    poses: dict[str, list[str]] = {}
    for key in mascot.POSES:
        try:
            poses[key] = list(mascot.plain(key))
        except Exception:
            continue
    if "sit" not in poses:          # 极端情况兜底
        poses["sit"] = [" /\\_/\\", "( o.o )", " > ^ <"]
    info = {}
    for key, meta in (getattr(mascot, "POSES_INFO", {}) or {}).items():
        if isinstance(meta, dict):
            info[key] = {"name": meta.get("name", key),
                         "when": meta.get("when", "")}
        else:
            info[key] = {"name": str(meta), "when": ""}
    return {
        "ok": True,
        "poses": poses,
        "info": info,
        "default": "sit",
        # 摸一摸时连播的动作序列。旧版写在前端（PET_SHOWS），
        # 这里也一并给出去，前端不用再抄一份。
        "shows": [
            ["stretch", "wash", "sit"],
            ["read", "think", "raise"],
            ["stare", "shock", "cheer"],
            ["sleep", "stretch", "sit"],
            ["slack", "shock", "read"],
            ["flat", "love", "sit"],
            ["eat", "wash", "sit"],
            ["think", "stare", "think", "raise"],
            ["fight", "cheer"],
            ["money", "love"],
        ],
        # 摸一摸时随机说的一句（字段名用 labels，别和动作的 lines 混）
        "labels": ["喵～", "摸摸头", "今天也要加油哦", "休息一下嘛",
                   "我在呢", "写代码辛苦了", "要不要喝口水",
                   "这道题你会的"],
    }


def api_ping(ctx) -> dict:
    """最轻的一个接口：只回一句话。

    用途是给**应用窗口模式**做存活心跳：
        Edge 的 --app 窗口关掉之后，服务端不会收到任何通知，
        只能靠"还有没有人在请求"来判断界面还在不在。
        所以前端每 30 秒打一次这个接口，后台线程看超过阈值没动静就退出。
    刻意不查数据库——心跳要便宜，不能每次都去读盘。
    """
    return {"ok": True, "app": "形学", "t": ctx.today().isoformat()}


def api_translate(ctx, payload: dict) -> dict:
    """翻译。

    用户要求"翻译的水平要高"——诚实的话写在这里：
    这台机器上**没有可用的本地大模型**，而这个程序的底线是零依赖，
    所以不可能自己生成高质量翻译。能做到的是：
        接入现成的翻译服务（实测只有 MyMemory 可用）+ **术语保护**
        + 离线词表兜底。

    术语保护才是真正提质量的那一层：机器翻译在专业词上错得最离谱，
    实测它把「动态规划」译成 "dynamic planning"（正确是
    "dynamic programming"）——恰恰是她最需要的词。
    """
    from . import translate as tr

    text = (payload.get("text") or "").strip()
    if not text:
        return {"ok": False, "error": "先输入要翻译的内容。"}
    # 免费接口对长度有限制，太长了也会很慢——提前说清楚，别让她等
    if len(text) > 2000:
        return {"ok": False,
                "error": f"一次最多翻 2000 字（现在 {len(text)} 字），分几段翻吧。"}
    try:
        result = tr.translate(
            text,
            src=(payload.get("src") or "").strip(),
            dst=(payload.get("dst") or "").strip(),
            use_terms=bool(payload.get("terms", True)),
        )
        result["ok"] = True
        return result
    except tr.TranslateError as exc:
        return {"ok": False, "error": str(exc)}
    except Exception as exc:
        return {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"}


def api_translate_terms(ctx) -> dict:
    """给界面用的：内置术语表有多少词、支持哪些语种。"""
    from . import translate as tr

    return {
        "ok": True,
        "languages": [{"code": k, "label": v} for k, v in tr.LANGUAGES.items()],
        "term_count": len(tr.TERMS_ZH_EN),
        "offline_count": len(tr.OFFLINE_ZH_EN),
    }


def api_courses(ctx) -> dict:
    return {"ok": True, **_course_coverage(ctx)}


# ---------------- 视频总结：任务总览 ----------------

def api_video_overview(ctx) -> dict:
    """任务总览 + 队列诊断。

    为什么要单独一个接口：界面光看"我的任务 status=queued, 0%"是不够的。
    BiliSum 的 worker 一个任务占一个线程，一旦有任务卡死，
    新任务就永远排队——看起来像"我们的进度条坏了"。

    实测遇到过的两种情况，这里都要能诊断出来：
        · 两个任务卡在 running 半小时 → 后面的全堵着
        · worker 线程池因为有任务抛异常而整个死掉 →
          取消卡死任务也没用，**必须重启后端**才能恢复
          （它启动时会 "Recovered N queued task(s)" 把排队的重放）

    所以这个接口除了任务列表，还要给出：
        queued_ahead  我的任务前面排了几个
        stalled       看起来卡住的任务（running 太久没动静）
        stuck_worker  队列没动 + 没有任务在跑 = worker 死了，建议重启
    """
    from . import bilisum

    client = bilisum.Client(ctx.cfg.home)
    try:
        client.prepare()
    except bilisum.ServiceError as exc:
        return {"ok": False, "error": str(exc)}

    running = client.service_running()
    if not running:
        return {"ok": True, "running": False, "tasks": [], "counts": {},
                "hint": "后端没在跑。点「开始总结」会自动拉起来。"}

    tasks = client.list_tasks()
    counts: dict[str, int] = {}
    for t in tasks:
        counts[t["status"]] = counts.get(t["status"], 0) + 1

    # 卡死判定：running 很久但进度不动。
    # 这里用"有没有任何 running 任务"来判断，因为拿不到可靠的开始时间——
    # 真正的判据是下面的 stuck_worker：队列里有人等着，但没人在跑。
    active = counts.get("running", 0)
    queued = counts.get("queued", 0)

    return {
        "ok": True,
        "running": True,
        "tasks": tasks,
        "counts": counts,
        "active": active,
        "queued": queued,
        # 有人排队 + 没人在跑 = worker 线程池死了。
        # 这个判断不依赖时间，比较可靠。
        "stuck_worker": queued > 0 and active == 0,
        "hint": ("后台没有在跑任何任务，但队列里还排着 "
                 f"{queued} 个——BiliSum 的 worker 很可能死掉了。"
                 "点「重启后端」能救回来（它启动时会重放排队任务）。"
                 if (queued > 0 and active == 0) else ""),
    }


def api_video_cancel(ctx, task_id: str) -> dict:
    """取消一个任务。"""
    from . import bilisum

    client = bilisum.Client(ctx.cfg.home)
    try:
        client.prepare()
    except bilisum.ServiceError as exc:
        return {"ok": False, "error": str(exc)}
    ok, message = client.cancel_task(task_id)
    return {"ok": ok, "message": message, "error": "" if ok else message}


def api_video_restart(ctx) -> dict:
    """重启 BiliSum 后端。

    这是"任务一直排队不动"的**真正解药**：worker 线程池一旦因为
    某个任务抛异常而死，就不会自己恢复；而重启会重放排队任务。
    （取消卡死任务实测没用，只有重启有效。）
    """
    from . import bilisum

    client = bilisum.Client(ctx.cfg.home)
    try:
        ok, message = client.restart_service()
    except bilisum.ServiceError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": ok, "message": message,
            "error": "" if ok else message}


# ---------------- 六级备考 ----------------

def api_cet6(ctx) -> dict:
    """六级备考页需要的一切。"""
    from . import cet6

    today = ctx.today()
    prog = cet6.progress(today)
    kind, advice = cet6.urgency(today)

    # 已经灌进题库的有多少（让她知道"这些词我背到哪了"）
    imported = 0
    try:
        for tag in ("六级",):
            imported = len([p for p in ctx.store.all() if tag in (p.tags or [])])
    except Exception:
        pass

    return {
        "ok": True,
        "exam_date": cet6.EXAM_DATE.isoformat(),
        "exam_time": cet6.EXAM_TIME,
        "speaking": cet6.SPEAKING_DATES,
        "register_url": cet6.REGISTER_URL,
        "result_url": cet6.RESULT_URL,
        "register_note": cet6.REGISTER_NOTE,
        "ticket_date": cet6.TICKET_DATE.isoformat(),
        "days_left": prog["days_left"],
        "percent": prog["percent"],
        "passed": prog["passed"],
        "advice_kind": kind,
        "advice": advice,
        "sections": cet6.SECTIONS,
        "topics": cet6.TOPICS,
        "videos": [
            {
                "key": v.key, "title": v.title, "query": v.query, "why": v.why,
                "minutes": v.minutes, "kind": v.kind,
                "search_url": v.search_url(),
            }
            for v in cet6.VIDEO_TOPICS
        ],
        "writing_frames": [
            {
                "name": f["name"], "pattern": f["pattern"],
                "openers": f["openers"], "body": f["body"], "closers": f["closers"],
                "sample": f["sample_prompt"],
            }
            for f in cet6.WRITING_FRAMES
        ],
        "translation_topics": [
            {"name": t["name"], "words": [{"cn": cn, "en": en} for cn, en in t["words"]],
             "patterns": t["patterns"]}
            for t in cet6.TRANSLATION_TOPICS
        ],
        "vocab": [{"word": w, "meaning": m, "note": n} for w, m, n in cet6.KEY_VOCAB],
        "coverage": cet6.coverage(),
        "imported": imported,
    }


def api_cet6_videos(ctx, query: dict) -> dict:
    """解析某个备考条目当前真实的 B 站视频。

    为什么不预先存视频链接：视频会下架、UP 主会改名。
    搜索出来的结果永远有效，写死的链接过几个月就是 404。
    """
    from . import cet6

    key = (query.get("key") or "").strip()
    ok, videos, error = cet6.resolve_videos(key, limit=int(query.get("limit") or 5))
    topic = cet6.by_key(key)
    return {
        "ok": True,
        "found": ok,
        "error": error,
        "videos": videos,
        "topic": {"key": topic.key, "title": topic.title, "query": topic.query}
        if topic else None,
    }


def api_cet6_import(ctx, payload: dict) -> dict:
    """把备考材料灌进题库，和算法题一起做间隔重复。

    这是这个模块真正的价值：她已经在用这套系统背题了，加进来就能背单词。
    """
    from . import cet6

    kinds = payload.get("kinds") or ["vocab", "writing", "translation"]
    if not isinstance(kinds, list):
        return {"ok": False, "error": "kinds 要是数组"}
    limit = int(payload.get("limit") or 0)
    try:
        added = cet6.import_problems(ctx.store, kinds=[str(k) for k in kinds], limit=limit)
    except Exception as exc:
        return {"ok": False, "error": f"导入失败：{exc}"}
    total = len([p for p in ctx.store.all() if "六级" in (p.tags or [])])
    return {
        "ok": True, "added": added, "total_in_bank": total,
        "message": (f"新加了 {added} 道" if added else "这些已经在题库里了，没重复加"),
    }


def _avatar_version(ctx) -> str:
    """头像的版本号（内容变了它就会变）。给 `/api/avatar/image?v=` 用。"""
    import hashlib

    raw = str(getattr(ctx.cfg, "avatar", "") or "")
    return hashlib.md5(raw.encode("utf-8")).hexdigest()[:10]


def avatar_image_bytes(ctx) -> tuple[bytes, str] | None:
    """头像的**原始字节** + MIME。没有头像就 None。

    为什么要这个：`data_url` 是把图片塞进 JSON 的 base64，
    1.5 MB 的图会变成 2 MB 的字符串。而 `<img src>` 拉二进制本来就
    更省（少 33%）、还能走浏览器缓存 —— 所以给 `Mascot` 用这个。
    """
    import base64

    from . import avatar

    info = avatar.describe(getattr(ctx.cfg, "avatar", ""))
    if not info["has_avatar"]:
        return None
    url = str(getattr(ctx.cfg, "avatar", "") or "")
    if "," not in url:
        return None
    head, b64 = url.split(",", 1)
    try:
        raw = base64.b64decode(b64, validate=False)
    except Exception:
        return None
    if not raw:
        return None
    low = head.lower()
    ctype = "image/png"
    for key, mime in (("jpeg", "image/jpeg"), ("jpg", "image/jpeg"),
                      ("gif", "image/gif"), ("webp", "image/webp"),
                      ("bmp", "image/bmp")):
        if key in low:
            ctype = mime
            break
    return raw, ctype


def api_avatar_get(ctx, query: dict | None = None) -> dict:
    """当前头像状态。

    **默认只回元信息**，不回 `data_url` —— 那是 2 MB 的 base64，
    每次启动（Mascot 会调）都传一遍纯属浪费。
    真要 base64 的加 `?data=1`。
    """
    from . import avatar

    info = dict(avatar.describe(ctx.cfg.avatar))
    out: dict = {"ok": True, "info": info}
    if info["has_avatar"]:
        info["version"] = _avatar_version(ctx)
        info["image_url"] = f"/api/avatar/image?v={info['version']}"
    q = query or {}
    want_data = str(q.get("data") or "").lower() in ("1", "true", "yes")
    if want_data:
        out["data_url"] = ctx.cfg.avatar if info["has_avatar"] else ""
    return out


def api_avatar_save(ctx, payload: dict) -> dict:
    """保存头像。校验交给 avatar.normalize（它负责挡 SVG、假类型、超大图）。"""
    from . import avatar

    raw = (payload or {}).get("data_url") or (payload or {}).get("data") or ""
    try:
        clean = avatar.normalize(raw)
    except avatar.AvatarError as exc:
        return {"ok": False, "error": str(exc)}

    ctx.cfg.avatar = clean
    try:
        ctx.cfg.save()
    except OSError as exc:
        return {"ok": False, "error": f"保存失败（写不了配置文件）：{exc}"}

    info = avatar.describe(clean)
    return {"ok": True, "info": info, "data_url": clean}


def api_avatar_clear(ctx) -> dict:
    """删掉头像，换回符号猫。"""
    ctx.cfg.avatar = ""
    try:
        ctx.cfg.save()
    except OSError as exc:
        return {"ok": False, "error": f"保存失败：{exc}"}
    return {"ok": True, "info": {"has_avatar": False, "format": "", "bytes": 0, "kb": 0},
            "data_url": ""}


def api_sites(ctx) -> dict:
    """学习网站清单。

    每个站点同时给出两样东西，别搞混（前端踩过这个坑）：
        url             首页地址，点「打开」用这个
        search_template 站内搜索模板，里面含 {q}，点「站内搜索」时替换
    只给 url 的话，前端会拿它去替换 {q} —— 替换不掉，
    于是要么打开首页（不是她要的），要么把没替换的 {q} 拼进地址栏变成空白页。
    """
    # 先取好收藏和去过次数：下面每个站点都要用，
    # 放在循环里查会变成 N 次查询
    fav_keys = ctx.store.favorite_keys()
    visit_counts = {
        str(r["site_key"]): int(r["visits"] or 0)
        for r in ctx.store.visit_stats()
    }

    groups = []
    for name, hint in learning.CATEGORIES:
        sites = learning.in_category(name)
        if not sites:
            continue
        groups.append({
            "name": name,
            "hint": hint,
            "sites": [
                {
                    "key": s.key, "title": s.title, "url": s.url,
                    "what": s.what, "when": s.when, "how": s.how,
                    "tags": s.tags, "can_search": s.can_search(),
                    "search_template": s.search,
                    # 给一个「打开就能用」的示例，前端可以预填输入框
                    "sample": s.search_url(s.tags[0] if s.tags else s.title)
                    if s.can_search() else s.url,
                    # 收藏状态和去过几次，让资源页一次渲染就带齐标记，
                    # 不用前端再去问一遍（少一趟请求、也少一处可能不一致）
                    "favorite": s.key in fav_keys,
                    "visits": visit_counts.get(s.key, 0),
                }
                for s in sites
            ],
        })
    return {"ok": True, "groups": groups, "total": len(learning.SITES),
            "favorites": [dict(r) for r in ctx.store.favorites()],
            "recent": [dict(r) for r in ctx.store.visits(limit=30)]}


# ---------------- 资源收藏 / 打开记录 ----------------

def api_site_favorites(ctx) -> dict:
    """收藏列表。"""
    return {"ok": True,
            "favorites": [dict(r) for r in ctx.store.favorites()]}


def api_site_favorite_toggle(ctx, payload: dict) -> dict:
    """收藏 / 取消收藏。

    做成 toggle 而不是分开的加/删两个接口：
    界面上就是一个星号按钮，点一下切换，最自然。
    返回里带 `favorite` 告诉她切换后的状态，前端据此改图标。
    """
    key = (payload.get("key") or "").strip()
    if not key:
        return {"ok": False, "error": "缺少站点标识"}
    if payload.get("note") is not None and ctx.store.is_favorite(key):
        # 只改备注（详情弹窗里保存时走这条）
        ctx.store.set_favorite_note(key, str(payload.get("note") or ""))
        return {"ok": True, "favorite": True, "message": "备注已保存"}
    now_fav = ctx.store.toggle_favorite(
        key,
        title=str(payload.get("title") or ""),
        url=str(payload.get("url") or ""),
        category=str(payload.get("category") or ""),
    )
    return {"ok": True, "favorite": now_fav,
            "message": "已收藏" if now_fav else "已取消收藏"}


def api_site_favorite_delete(ctx, key: str) -> dict:
    ok = ctx.store.remove_favorite(key)
    return {"ok": True, "removed": ok}


def api_site_favorite_move(ctx, key: str, payload: dict) -> dict:
    delta = -1 if str(payload.get("dir") or "up") == "up" else 1
    moved = ctx.store.move_favorite(key, delta)
    return {"ok": True, "moved": moved,
            "message": "已调整顺序" if moved else "已经在头/尾了"}


def api_site_visits(ctx) -> dict:
    """打开记录 + 按站点统计。"""
    return {
        "ok": True,
        "visits": [dict(r) for r in ctx.store.visits(limit=150)],
        "stats": [dict(r) for r in ctx.store.visit_stats()],
    }


def api_site_visit_add(ctx, payload: dict) -> dict:
    """记一次打开。"""
    key = (payload.get("key") or "").strip()
    if not key:
        return {"ok": False, "error": "缺少站点标识"}
    ctx.store.record_visit(
        key,
        title=str(payload.get("title") or ""),
        url=str(payload.get("url") or ""),
        source=str(payload.get("source") or "sites"),
    )
    return {"ok": True}


def api_site_visits_clear(ctx) -> dict:
    n = ctx.store.clear_visits()
    return {"ok": True, "cleared": n}

# ---------------- 便签 / 倒数日 / 提醒 ----------------

def api_notes(ctx) -> dict:
    return {"ok": True, "notes": [note_json(r) for r in ctx.store.notes()]}


def api_note_save(ctx, payload: dict) -> dict:
    from . import panels

    nid = payload.get("id")
    body = (payload.get("body") or "").strip()
    if not body:
        return {"ok": False, "error": "便签内容不能为空"}
    color = payload.get("color") or "pink"
    if color not in panels.NOTE_COLORS:
        color = "pink"
    if isinstance(nid, int) and ctx.store.note(nid):
        ctx.store.update_note(nid, body=body, color=color,
                              pinned=bool(payload.get("pinned")))
        return {"ok": True, "id": nid}
    new_id = ctx.store.add_note(body, color, pinned=bool(payload.get("pinned")))
    return {"ok": True, "id": new_id}


def api_note_action(ctx, note_id: int, payload: dict) -> dict:
    action = payload.get("action")
    row = ctx.store.note(note_id)
    if row is None:
        return {"ok": False, "error": "找不到这张便签"}
    if action == "pin":
        ctx.store.update_note(note_id, pinned=not bool(row["pinned"]))
    elif action == "archive":
        ctx.store.update_note(note_id, archived=True)
    elif action == "unarchive":
        ctx.store.update_note(note_id, archived=False)
    elif action == "delete":
        ctx.store.delete_note(note_id)
    else:
        return {"ok": False, "error": f"不认识的动作 {action}"}
    return {"ok": True}


def api_countdowns(ctx) -> dict:
    today = ctx.today()
    return {"ok": True,
            "countdowns": [countdown_json(r, today) for r in ctx.store.countdowns()],
            "birthday": ctx.cfg.birthday,
            "birthday_in": gem.days_until_birthday(ctx.birthday, today) if ctx.birthday else None,
            "cycle": cycle_json(ctx, today),
            # 日历标记：{日期: 类型}，前端拿它画小点
            "cycle_marks": {
                d.isoformat(): v
                for d, v in _cycle_marks(ctx, today).items()
            }}


def _cycle_marks(ctx, today: date) -> dict:
    """日历要用的标记 {日期: period/next}。

    **男性时返回空的 —— 因为没有经期这回事。**

    这条语义改过两次，记一下免得再来回改：

        v1  男性 → 空：想的是"别让她在男性模式下看到周期"
        用户：设成男之后**月历消失了**（那时连卡片都不显示）
        v2  男性 → 给标记：想的是"月历和记录照常能用，只是不提醒"
        用户：**"男性就单纯一个日历"** —— 记录按钮、经期标记都不要

    所以现在是 v3：男性 → 空。**卡片和月历照常显示**（那部分在 `cycle_json`
    和前端那边保证），但格子上没有任何经期颜色。
    """
    from . import cycle

    if ctx.cfg.cycle_hidden():
        return {}
    try:
        return cycle.cycle_days(cycle.predict(ctx.cfg, today), today)
    except Exception:
        return {}


def api_countdown_save(ctx, payload: dict) -> dict:
    cid = payload.get("id")
    title = (payload.get("title") or "").strip()
    target = (payload.get("target") or "").strip()
    if not title:
        return {"ok": False, "error": "要给个标题"}
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", target):
        return {"ok": False, "error": "日期要写成 2026-10-18 这样"}
    try:
        if isinstance(cid, int) and ctx.store.countdown(cid):
            ctx.store.update_countdown(
                cid, title=title, target=target, kind=payload.get("kind") or "event",
                note=payload.get("note") or "", yearly=bool(payload.get("yearly")))
            return {"ok": True, "id": cid}
        new_id = ctx.store.add_countdown(
            title, target, payload.get("kind") or "event",
            payload.get("note") or "", yearly=bool(payload.get("yearly")))
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "id": new_id}


def api_countdown_edit(ctx, cid: int, payload: dict) -> dict:
    """改一个倒数日。

    **为什么单独写**：前端 `DayEditor.vue` 对已有条目发
    `POST /api/countdowns/{id}`，但后端原来只注册了 `DELETE`——
    所以**改倒数日会 404**。

    为什么不在 `api_countdown_save` 里按 id 分支：
    那个函数的 payload 形状是"新建"（title 必填等），
    改的时候语义不一样（只改传了的字段）。分开更清楚。
    """
    from . import gem

    row = ctx.store.countdown(cid)
    if row is None:
        return {"ok": False, "error": "找不到这个倒数日"}

    title = str(payload.get("title") or "").strip()
    target = str(payload.get("target") or "").strip()
    if not title:
        return {"ok": False, "error": "给它起个名字"}
    when = gem.parse_date(target)
    if when is None:
        return {"ok": False, "error": "日期看不懂，用 2026-12-12 这种格式"}

    kind = str(payload.get("kind") or "other")
    note = str(payload.get("note") or "")
    yearly = bool(payload.get("yearly"))
    try:
        ctx.store.update_countdown(
            cid, title=title, target=when, kind=kind,
            note=note, yearly=yearly)
    except Exception as exc:
        return {"ok": False, "error": f"改不了：{exc}"}
    return {"ok": True, "id": cid}


def api_countdown_delete(ctx, cid: int) -> dict:
    return {"ok": ctx.store.delete_countdown(cid)}


def api_reminders(ctx) -> dict:
    today = ctx.today()
    today_ids = {r["id"] for r in ctx.store.reminders_today(today)}
    return {"ok": True, "reminders": [
        {**reminder_json(r), "fires_today": r["id"] in today_ids}
        for r in ctx.store.reminders()
    ]}


def api_reminder_save(ctx, payload: dict) -> dict:
    rid = payload.get("id")
    body = (payload.get("body") or "").strip()
    if not body:
        return {"ok": False, "error": "要写提醒内容"}
    pattern = payload.get("pattern") or "daily"
    weekday = int(payload.get("weekday") or ctx.today().isoweekday())
    # 同时接受 `date` 和 `on_date`。
    #
    # 后端读的是 `date`，而前端（我写的 Vue 版）一开始发的是 `on_date`。
    # 两边名字不一致的后果是**指定的日期被忽略**，静默退回"今天"——
    # 比报错更糟，因为她会以为设对了。
    #
    # 现在前端改成了 `date`，这里也留着 `on_date` 兜底：
    # 万一还有别处传旧名，不至于静默失效。
    on_date = (payload.get("date") or payload.get("on_date") or "").strip()
    if pattern in ("date", "once") and not on_date:
        on_date = ctx.today().isoformat()
    try:
        if isinstance(rid, int) and ctx.store.reminder(rid):
            ctx.store.update_reminder(
                rid, body=body, pattern=pattern, weekday=weekday, date=on_date,
                at_time=payload.get("at_time") or "",
                priority="important" if payload.get("important") else "normal")
            return {"ok": True, "id": rid}
        new_id = ctx.store.add_reminder(
            body, pattern, weekday, on_date, payload.get("at_time") or "",
            "important" if payload.get("important") else "normal")
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "id": new_id}


def api_reminder_action(ctx, rid: int, payload: dict) -> dict:
    action = payload.get("action")
    row = ctx.store.reminder(rid)
    if row is None:
        return {"ok": False, "error": "找不到这条提醒"}
    if action == "toggle":
        ctx.store.update_reminder(rid, enabled=not bool(row["enabled"]))
    elif action == "delete":
        ctx.store.delete_reminder(rid)
    else:
        return {"ok": False, "error": f"不认识的动作 {action}"}
    return {"ok": True}


# ---------------- 诊断 ----------------

def api_failures(ctx) -> dict:
    from . import failures as failures_mod

    def one(f):
        return {"id": f.id, "kind": f.kind, "kind_label": f.kind_label,
                "summary": f.summary, "detail": f.detail, "retry": f.retry,
                "attempts": f.attempts, "state": f.state,
                "updated_at": f.updated_at[:16].replace("T", " ")}

    return {
        "ok": True,
        "open": [one(f) for f in failures_mod.open_failures(ctx.store)],
        "resolved": [one(f) for f in failures_mod.all_failures(ctx.store)
                     if f.state != "open"][:20],
    }


def api_failure_action(ctx, fid: int, payload: dict) -> dict:
    from . import failures as failures_mod

    action = payload.get("action")
    if action == "resolve":
        return {"ok": failures_mod.resolve(ctx.store, fid)}
    if action == "clear":
        return {"ok": True, "cleared": failures_mod.clear(ctx.store)}
    return {"ok": False, "error": f"不认识的动作 {action}"}


def api_quality(ctx) -> dict:
    rows = list(ctx.store.conn.execute(
        "SELECT * FROM quality_log ORDER BY id DESC LIMIT 20"))
    items = []
    for row in rows:
        try:
            report = evidence.QualityReport.from_dict(json.loads(row["payload"] or "{}"))
        except (ValueError, TypeError):
            continue
        items.append({**report.to_dict(),
                      "confidence": report.confidence()[0],
                      "confidence_color": report.confidence()[1],
                      "source_label": report.source_label(),
                      "when": (row["created_at"] or "")[:16].replace("T", " ")})
    return {"ok": True, "items": items}


def api_doctor(ctx) -> dict:
    """环境自检。每一项都如实说"就绪/未就绪"，不伪装完整。"""
    from . import bilisum, deps, failures as failures_mod

    cfg = ctx.cfg
    online = search.http_available()
    libs = deps.capability_report()
    return {
        "ok": True,
        "home": str(cfg.home),
        "db": str(cfg.db_path),
        "db_exists": cfg.db_path.exists(),
        "version": _version(),
        "name": cfg.name,
        "birthday": cfg.birthday,
        "together": cfg.together_since,
        "theme": {"name": ctx.theme.name(), "seed": ctx.theme.seed},
        "online": online,
        "bilisum_installed": bilisum.installed(),
        "libraries": libs,
        "libraries_ready": sum(1 for i in libs if i["available"]),
        "libraries_total": len(libs),
        "pending_failures": failures_mod.count_open(ctx.store),
        "counts": {
            "problems": ctx.store.count(),
            "notes": len(ctx.store.notes()),
            "countdowns": len(ctx.store.countdowns()),
            "reminders": len(ctx.store.reminders()),
            "reviews": ctx.store.review_count_total(),
        },
    }


def _version() -> str:
    try:
        from . import __version__

        return __version__
    except Exception:
        return "?"


def api_settings_get(ctx) -> dict:
    from . import features

    return {
        "ok": True,
        "name": ctx.cfg.name,
        "birthday": ctx.cfg.birthday,
        "together_since": ctx.cfg.together_since,
        # 性别：只回归一化后的值（female / male），前端拿它渲染单选
        "gender": ctx.cfg.gender_value(),
        "panels": ctx.cfg.panel_order(),
        "all_panels": features.DEFAULT_PANELS,
    }


def api_settings_save(ctx, payload: dict) -> dict:
    from .config import GENDERS

    cfg = ctx.cfg
    if "name" in payload:
        cfg.name = (payload.get("name") or "").strip()
    if "gender" in payload:
        # 只认 female / male。**不能静默忽略**——
        # 静默忽略的表现是"界面上选了男，实际还是女"，查起来最费劲。
        value = str(payload.get("gender") or "").strip().lower()
        if value not in GENDERS:
            return {"ok": False,
                    "error": "性别只能选「女」或「男」（female / male），"
                             "别的写法看不懂。"}
        cfg.gender = value
    if "birthday" in payload:
        value = (payload.get("birthday") or "").strip()
        if value and gem.parse_date(value) is None:
            return {"ok": False, "error": "生日格式看不懂，用 2006-10-18 或 10-18"}
        cfg.birthday = value
    if "together_since" in payload:
        value = (payload.get("together_since") or "").strip()
        if value and gem.parse_date(value) is None:
            return {"ok": False, "error": "日期格式看不懂，用 2023-09-01"}
        cfg.together_since = value
    if isinstance(payload.get("panels"), list):
        cfg.set_panels([str(p) for p in payload["panels"]])
    try:
        cfg.save()
    except OSError as exc:
        return {"ok": False, "error": f"写配置失败：{exc}"}

    # 名字/生日改了要刷新主题和问候
    ctx.theme = gem.theme_from_birthday(cfg.birthday)
    ctx.birthday = gem.parse_date(cfg.birthday)
    return {"ok": True, "gender": cfg.gender_value(),
            "theme": {"name": ctx.theme.name()}}


def api_panels_toggle(ctx, payload: dict) -> dict:
    panel_id = (payload.get("id") or "").strip()
    enabled = bool(payload.get("enabled"))
    order = ctx.cfg.panel_order()
    if enabled and panel_id not in order:
        order.append(panel_id)
    elif not enabled and panel_id in order:
        order.remove(panel_id)
    ctx.cfg.set_panels(order)
    try:
        ctx.cfg.save()
    except OSError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "panels": order}


def api_panels_reorder(ctx, payload: dict) -> dict:
    order = [str(p) for p in (payload.get("panels") or [])]
    if not order:
        return {"ok": False, "error": "顺序不能为空"}
    ctx.cfg.set_panels(order)
    try:
        ctx.cfg.save()
    except OSError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "panels": order}


def api_normalize_tags(ctx, payload: dict) -> dict:
    """标签规范化预览（对应"形状校验"那套思路）。"""
    result = queue_mod.normalize_tags(payload.get("tags") or [])
    return {"ok": True, "tags": result.tags, "changed": result.changed,
            "unknown": result.unknown, "summary": result.summary()}


# --------------------------------------------------------------------------
# 娱乐 · 听歌
# --------------------------------------------------------------------------

def api_music_search(ctx, query: dict) -> dict:
    """搜歌。`GET /api/music/search?q=<关键词>&limit=<条数>`

    永远回 200：搜不到、连不上、接口改版，都是 `{ok: false, error: 中文}`。
    **任何异常都别漏出去**——这个模块挂了不能影响别的接口（同一进程里跑的服务）。
    """
    from . import music

    keyword = (query.get("q") or "").strip()
    try:
        limit = int(query.get("limit") or 30)
    except (TypeError, ValueError):
        limit = 30
    try:
        return music.search(keyword, limit=limit)
    except Exception as exc:  # 兜底：宁可回一句人话，也不要 500
        return {"ok": False, "songs": [],
                "error": f"音乐搜索出问题了（{exc.__class__.__name__}），别的功能不受影响。"}


def api_music_url(ctx, query: dict) -> dict:
    """取播放直链。`GET /api/music/url?id=<歌曲 id>`

    拿不到就 `{ok: false, why: 中文原因}`（需要会员 / 没版权 / 网络不通）。
    **不缓存直链**（25 分钟过期），每次播放都重取——见 music.py 的说明。
    """
    from . import music

    try:
        return music.stream_url(query.get("id"))
    except Exception as exc:
        return {"ok": False,
                "why": f"取播放地址出问题了（{exc.__class__.__name__}），换一首试试。"}


def api_music_lyric(ctx, query: dict) -> dict:
    """歌词。`GET /api/music/lyric?id=<歌曲 id>`

    永远回 200：没有歌词 / 纯音乐 / 连不上，都是 `{ok: false, error: 中文}`。
    """
    from . import music

    try:
        return music.lyric(query.get("id"))
    except Exception as exc:
        return {"ok": False, "lines": [],
                "error": f"取歌词出问题了（{exc.__class__.__name__}）。"}


def _track_json(row) -> dict:
    """歌单一行 → 前端要的形状。"""
    return {
        "id": int(row["song_id"]),
        "name": row["name"] or "",
        "artists": row["artists"] or "",
        "album": row["album"] or "",
        "duration": int(row["duration"] or 0),
        "duration_text": _mmss(int(row["duration"] or 0)),
        "cover": row["cover"] or "",
        "quality": row["quality"] or "",
        "added_at": row["created_at"] or "",
    }


def _mmss(seconds: int) -> str:
    seconds = max(0, int(seconds or 0))
    if seconds >= 3600:
        return f"{seconds // 3600}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}"
    return f"{seconds // 60}:{seconds % 60:02d}"


def api_music_playlist(ctx) -> dict:
    """歌单。`GET /api/music/playlist`"""
    rows = ctx.store.music_playlist()
    tracks = [_track_json(r) for r in rows]
    return {"ok": True, "tracks": tracks, "count": len(tracks)}


def api_music_playlist_add(ctx, payload: dict) -> dict:
    """收进歌单。`POST /api/music/playlist`

    payload 就是搜索结果里那一首歌（id/name/artists/album/duration/cover/quality）。
    **不收直链**——见 db.py 里 music_tracks 的说明。
    """
    song_id = payload.get("id") or payload.get("song_id")
    try:
        added = ctx.store.music_add(
            song_id,
            name=str(payload.get("name") or ""),
            artists=str(payload.get("artists") or ""),
            album=str(payload.get("album") or ""),
            duration=payload.get("duration") or 0,
            cover=str(payload.get("cover") or ""),
            quality=str(payload.get("quality") or ""),
        )
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "added": added,
            "message": "已加入歌单" if added else "这首歌已经在歌单里了"}


def api_music_playlist_remove(ctx, song_id) -> dict:
    """从歌单移除。`DELETE /api/music/playlist/<song_id>`"""
    try:
        removed = ctx.store.music_remove(song_id)
    except (TypeError, ValueError):
        return {"ok": False, "error": "歌曲 id 不对"}
    return {"ok": True, "removed": removed}


def api_music_playlist_clear(ctx) -> dict:
    """清空歌单。`POST /api/music/playlist/clear`"""
    n = ctx.store.music_clear()
    return {"ok": True, "removed": n}


def api_music_playlist_move(ctx, song_id, payload: dict) -> dict:
    """上移/下移一位。`POST /api/music/playlist/<song_id>/move`"""
    try:
        delta = int(payload.get("delta") or -1)
    except (TypeError, ValueError):
        delta = -1
    moved = ctx.store.music_move(song_id, delta)
    return {"ok": True, "moved": moved}



# ---------------------------------------------------------------------------
#  备份 / 站点体检 / 专注（升级版第一批）
# ---------------------------------------------------------------------------
def _sites_flat() -> list[dict]:
    """把资源站点拍平成一维（体检要遍历）。

    注意 `learning.SITES` 是 **Site 对象**的列表（不是 dict、也不是
    按 category 分组的嵌套结构）—— 我第一版按嵌套结构写，取不到东西，
    体检接口直接 400。这里用属性读，并顺手兼容 dict 形式。
    """
    from . import learning

    out: list[dict] = []
    seen: set[str] = set()
    for s in getattr(learning, "SITES", []) or []:
        if isinstance(s, dict):
            key = str(s.get("key") or s.get("url") or "")
            title = str(s.get("title") or "")
            url = str(s.get("url") or "")
        else:
            key = str(getattr(s, "key", "") or getattr(s, "url", ""))
            title = str(getattr(s, "title", "") or "")
            url = str(getattr(s, "url", "") or "")
        if not url.startswith("http") or key in seen:
            continue
        seen.add(key)
        out.append({"key": key, "title": title, "url": url})
    return out


# ---------------------------------------------------------------------------
#  错题本 / 提醒到点 / 7 天负载 / 目标（升级版第二批）
# ---------------------------------------------------------------------------
def api_mistakes(ctx, payload: dict | None = None, query: dict | None = None) -> dict:
    """错题本。GET 列表；POST 新增。"""
    q = query or {}
    if payload is None:
        pid = q.get("problem_id")
        if pid:
            return {"ok": True, "items": ctx.store.mistakes_for(int(pid))}
        return {"ok": True, "items": ctx.store.mistakes_recent(40),
                "by_kind": ctx.store.mistake_counts()}
    action = str(payload.get("action") or "add")
    if action == "delete":
        return {"ok": ctx.store.mistake_delete(int(payload.get("id") or 0))}
    pid = int(payload.get("problem_id") or 0)
    reason = str(payload.get("reason") or "").strip()
    if not pid:
        return {"ok": False, "error": "缺少题目 id"}
    if not reason:
        return {"ok": False, "error": "写一句「错在哪」才有用（或者跳过）"}
    got = ctx.store.mistake_add(pid, reason, str(payload.get("kind") or ""))
    return {"ok": True, "item": got, "items": ctx.store.mistakes_for(pid)}


def api_reminders_due(ctx, payload: dict | None = None) -> dict:
    """到点的提醒。POST 是确认/顺延。"""
    if payload is None:
        items = ctx.store.reminders_due()
        return {"ok": True, "items": items, "count": len(items)}
    rid = int(payload.get("id") or 0)
    if not rid:
        return {"ok": False, "error": "缺少提醒 id"}
    action = str(payload.get("action") or "ack")
    if action == "snooze":
        # 顺延：先 ack（今天不再弹），再由前端把时间往后推 10 分钟?
        # 简单起见：只记 ack，界面上提示"10 分钟后再提"
        got = ctx.store.reminder_ack(rid, action="snooze")
        return {"ok": True, **got, "note": "已顺延（今天不再弹这条）"}
    got = ctx.store.reminder_ack(rid, action="ack")
    return {"ok": True, **got}


def api_review_load(ctx, query: dict | None = None) -> dict:
    """未来 N 天每天到期几道 —— 提前看到积压。

    第 0 天是"今天（含逾期）"，之后按 `due` 日期分桶。
    """
    from collections import Counter
    from datetime import timedelta

    q = query or {}
    try:
        days = max(1, min(30, int(q.get("days") or 7)))
    except (TypeError, ValueError):
        days = 7
    today = ctx.today()
    buckets: list[dict] = [{"date": today.isoformat(), "count": len(ctx.store.due(today))}]
    counter = Counter(p.due.isoformat() for p in ctx.store.upcoming(days, today))
    for i in range(1, days + 1):
        d = (today + timedelta(days=i)).isoformat()
        buckets.append({"date": d, "count": int(counter.get(d, 0))})
    peak = max((b["count"] for b in buckets), default=0)
    return {"ok": True, "buckets": buckets, "peak": peak,
            "total": sum(b["count"] for b in buckets)}


def api_goals(ctx, payload: dict | None = None) -> dict:
    """目标。GET 列表（带进度）；POST 新增/改/删。"""
    if payload is None:
        return {"ok": True, "items": _goals_with_progress(ctx)}

    action = str(payload.get("action") or "add")
    if action == "delete":
        return {"ok": ctx.store.goal_delete(int(payload.get("id") or 0)),
                "items": _goals_with_progress(ctx)}
    if action in ("progress", "done", "edit"):
        fields = {}
        if payload.get("progress") is not None:
            fields["progress"] = int(payload["progress"])
        if payload.get("target_num") is not None:
            fields["target_num"] = int(payload["target_num"])
        if payload.get("title") is not None:
            fields["title"] = str(payload["title"])[:60]
        if payload.get("target_date") is not None:
            fields["target_date"] = str(payload["target_date"])[:10]
        if payload.get("done") is not None:
            fields["done"] = 1 if payload["done"] else 0
        got = ctx.store.goal_update(int(payload.get("id") or 0), **fields)
        return {**got, "items": _goals_with_progress(ctx)}

    title = str(payload.get("title") or "").strip()
    if not title:
        return {"ok": False, "error": "目标得有个名字"}
    got = ctx.store.goal_add(title, str(payload.get("kind") or "problems"),
                             int(payload.get("target_num") or 0),
                             str(payload.get("target_date") or ""))
    return {"ok": True, "goal": got, "items": _goals_with_progress(ctx)}


def _goals_with_progress(ctx) -> list[dict]:
    """给每个目标算进度 + "每天该做多少"。

    problems 类：进度 = **做过的题数**（至少复习过一次），不是"题库里有多少"——
                后者不是她努力的结果。
    manual  类：进度 = 她自己填的 progress。
    """
    from datetime import date as _date

    done_problems = ctx.store.reviewed_problem_count()
    today = ctx.today()
    out: list[dict] = []
    for g in ctx.store.goals():
        kind = str(g.get("kind") or "problems")
        target = int(g.get("target_num") or 0)
        cur = done_problems if kind == "problems" else int(g.get("progress") or 0)
        pct = 0 if target <= 0 else min(100, round(cur / target * 100))
        days_left = None
        per_day = None
        raw_date = str(g.get("target_date") or "")
        if raw_date:
            try:
                d = _date.fromisoformat(raw_date)
                days_left = (d - today).days
                if days_left > 0 and target > cur:
                    per_day = -(-(target - cur) // days_left)     # 向上取整
            except ValueError:
                pass
        out.append({**g, "current": cur, "percent": pct,
                    "days_left": days_left, "per_day": per_day})
    return out


def api_watch(ctx, payload: dict | None = None) -> dict:
    """待看清单。GET 列表；POST 加 / 打勾 / 删。"""
    if payload is None:
        return {"ok": True, "items": ctx.store.watch_list(),
                "stats": ctx.store.watch_stats()}
    action = str(payload.get("action") or "add")
    if action == "add":
        title = str(payload.get("title") or "").strip()
        if not title:
            return {"ok": False, "error": "没有视频标题"}
        got = ctx.store.watch_add(title, str(payload.get("url") or ""),
                                  str(payload.get("bvid") or ""),
                                  str(payload.get("author") or ""),
                                  str(payload.get("note") or ""))
        return {"ok": True, **got, "items": ctx.store.watch_list(),
                "stats": ctx.store.watch_stats(),
                "note": "已经在清单里了" if got.get("duplicated") else ""}
    if action == "toggle":
        got = ctx.store.watch_toggle(int(payload.get("id") or 0))
        return {**got, "items": ctx.store.watch_list(),
                "stats": ctx.store.watch_stats()}
    if action == "delete":
        return {"ok": ctx.store.watch_delete(int(payload.get("id") or 0)),
                "items": ctx.store.watch_list(),
                "stats": ctx.store.watch_stats()}
    return {"ok": False, "error": f"不认识的动作：{action}"}

def _listen_client():
    """B 站总结服务的客户端（**全局缓一份**）。

    `Client(home)` 第一次会准备数据目录（慢），每次请求都建一遍就是自找超时 ✗
    """
    global _LISTEN_CLIENT
    if _LISTEN_CLIENT is not None:
        return _LISTEN_CLIENT
    from . import bilisum

    cls = None
    for name in dir(bilisum):
        obj = getattr(bilisum, name)
        if isinstance(obj, type) and hasattr(obj, "create_task"):
            cls = obj
            break
    if cls is None:
        raise RuntimeError("这个版本没有可用的 B 站服务封装")
    from pathlib import Path as _P

    _LISTEN_CLIENT = cls(_DATA_HOME[0] if _DATA_HOME else _P("."))
    return _LISTEN_CLIENT


def _service_running(client) -> bool:
    try:
        if hasattr(client, "service_running"):
            return bool(client.service_running())
        if hasattr(client, "health"):
            got = client.health()
            return bool(got[0]) if isinstance(got, tuple) else bool(got)
    except Exception:
        return False
    return True


def _subtitle_lines(text: str) -> list[str]:
    """把字幕整理成 `[mm:ss] 句子`（前端靠它逐句循环）。"""
    import re as _re

    out: list[str] = []
    for raw in str(text or "").splitlines():
        s = raw.strip()
        if not s:
            continue
        m = _re.match(r"^\[?(\d{1,2}):(\d{2})(?::(\d{2}))?\]?\s*(.*)$", s)
        if m and m.group(4):
            sec = (int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
                   if m.group(3) else int(m.group(1)) * 60 + int(m.group(2)))
            out.append(f"[{sec // 60:02d}:{sec % 60:02d}] {m.group(4)}")
        else:
            out.append(s)
    return out


def _subtitle_start(ctx, lid: int) -> dict:
    """**只做建任务这一小步**，立刻返回（不再在请求里等它跑完）。"""
    from . import listening as _ls

    row = ctx.store.listen_get(int(lid))
    if row is None:
        return {"ok": False, "error": "没有这条听力"}
    url = str(dict(row).get("path") or "")
    if not url.startswith(("http://", "https://")):
        return {"ok": False, "error": "这条不是 B 站链接（本地文件没有字幕可抓）"}
    if not _ls.is_bili(url):
        return {"ok": False, "error": "只支持 B 站链接"}

    try:
        client = _listen_client()
    except Exception as exc:
        return {"ok": False, "error": f"准备 B 站服务失败：{exc.__class__.__name__}"}

    # **不阻塞**：服务没在跑就直接告诉她去哪儿点一下（不在这里等它启动）
    if not _service_running(client):
        return {"ok": False, "state": "no-service",
                "error": "B 站总结服务没在跑 —— 先去「视频总结」点一次「开始总结」"
                         "把它拉起来（第一次要一两分钟），再回来抓字幕"}

    try:
        task_id = client.create_task(url, prefer_subtitles=True)
    except TypeError:
        try:
            task_id = client.create_task(url)
        except Exception as exc:
            return {"ok": False, "error": f"建任务失败：{exc.__class__.__name__}: {exc}"}
    except Exception as exc:
        return {"ok": False, "error": f"建任务失败：{exc.__class__.__name__}: {exc}"}
    if isinstance(task_id, dict):
        task_id = task_id.get("task_id") or task_id.get("id") or ""
    if not task_id:
        return {"ok": False, "error": "服务没给任务号"}

    import time as _time

    _LISTEN_TASKS[int(lid)] = {"task_id": str(task_id), "at": _time.time(),
                               "state": "running", "error": ""}
    return {"ok": True, "state": "running", "task_id": str(task_id),
            "note": "任务已建，正在抓字幕…（前端会每隔几秒问一次进度）"}


def _subtitle_status(ctx, lid: int) -> dict:
    """**每次只查一下**：让前端轮询，而不是让请求干等。"""
    import time as _time

    info = _LISTEN_TASKS.get(int(lid))
    if not info:
        return {"ok": False, "state": "none",
                "error": "还没有开始抓（先点一次「抓 B 站字幕」）"}
    if info.get("state") == "done":
        return {"ok": True, "state": "done", **info.get("result", {})}
    if _time.time() - float(info.get("at") or 0) > 600:
        info["state"] = "error"
        info["error"] = "等太久了（10 分钟）—— 去「视频总结」看看那个任务什么情况"
        return {"ok": False, "state": "error", "error": info["error"]}

    try:
        client = _listen_client()
    except Exception as exc:
        return {"ok": False, "state": "error",
                "error": f"服务客户端不可用：{exc.__class__.__name__}"}

    got = None
    for name in ("summary", "result", "get_summary", "task", "get_task"):
        fn = getattr(client, name, None)
        if not callable(fn):
            continue
        try:
            got = fn(info["task_id"])
        except Exception:
            continue
        if got is not None:
            break
    if got is None:
        return {"ok": True, "state": "running", "note": "服务还没回结果…"}

    def pick(obj, *names):
        for n in names:
            if isinstance(obj, dict) and obj.get(n):
                return obj[n]
            v = getattr(obj, n, None)
            if v:
                return v
        return ""

    status = str(pick(got, "status", "state") or "")
    text = str(pick(got, "transcript") or pick(got, "markdown") or "")
    err = str(pick(got, "error") or "")
    if not text.strip():
        if status.lower() in ("done", "success", "finished", "完成", "ok"):
            info["state"] = "error"
            info["error"] = err or "服务说完成了，但没给字幕（这个视频可能没有字幕）"
            return {"ok": False, "state": "error", "error": info["error"]}
        return {"ok": True, "state": "running",
                "note": f"服务正在处理…（状态：{status or '处理中'}）"}

    lines = _subtitle_lines(text)[:4000]
    body = "\n".join(lines)[:20000]
    ctx.store.listen_update(int(lid), transcript=body)
    stamped = sum(1 for x in lines if x.startswith("["))
    result = {"transcript": body, "lines": len(lines), "stamped": stamped,
              "note": f"抓到 {len(lines)} 行（其中 {stamped} 行带时间戳）—— "
                      f"点带时间戳的句子就能逐句循环",
              "items": ctx.store.listening(), "stats": ctx.store.listen_stats()}
    info["state"] = "done"
    info["result"] = result
    return {"ok": True, "state": "done", **result}


MAX_AUDIO_MB = 15


def api_listening_audio(ctx, lid: int) -> dict:
    """音频内容（base64 data URL）。

    **为什么不直出字节**：HTTP 层直出二进制的那套约定我没确认过（不猜）。
    小文件 base64 多花 33% 体积，但一集一集听完全够；超过 15 MB 就
    明确让她用"系统播放器打开"（那条路已经验证过）。
    """
    import base64
    import mimetypes
    from pathlib import Path as _P

    row = ctx.store.listen_get(int(lid))
    if row is None:
        return {"ok": False, "error": "没有这条听力"}
    d = dict(row)
    raw_path = str(d.get("path") or "")
    # **B 站链接**：不是本地文件，前端改用内嵌播放器
    if raw_path.startswith(("http://", "https://")):
        from . import listening as _ls

        return {"ok": False, "is_url": True, "url": raw_path,
                "bvid": _ls.bvid_of(raw_path),
                "title": d.get("title") or raw_path,
                "error": ""}
    path = _P(raw_path)
    if not path or not path.is_file():
        return {"ok": False, "error": "音频文件不在了（可能被移动/删掉）",
                "title": d.get("title") or ""}
    try:
        size = path.stat().st_size
    except OSError:
        return {"ok": False, "error": "读不了这个文件"}
    mb = size / 1024 / 1024
    if mb > MAX_AUDIO_MB:
        return {"ok": False, "too_big": True, "mb": round(mb, 1),
                "path": str(path), "title": d.get("title") or path.stem,
                "error": f"这个音频 {mb:.1f} MB，太大了（上限 {MAX_AUDIO_MB} MB）"
                         f"—— 点「用系统播放器打开」听吧"}
    try:
        raw = path.read_bytes()
    except OSError as exc:
        return {"ok": False, "error": f"读不了：{exc.__class__.__name__}"}
    ctype = mimetypes.guess_type(path.name)[0] or "audio/mpeg"
    return {"ok": True, "title": d.get("title") or path.stem,
            "mb": round(mb, 1), "path": str(path), "mime": ctype,
            "data_url": f"data:{ctype};base64," + base64.b64encode(raw).decode("ascii")}

def listening_audio_bytes(ctx, lid: int) -> tuple[bytes, str, str]:
    """把登记的音频**以字节流**给网页（播放器读不了本地路径）。

    返回 (字节, Content-Type, 文件名)。文件不在 → 空字节（前端会提示）。
    """
    import mimetypes
    from pathlib import Path as _P

    row = ctx.store.listen_get(int(lid))
    if row is None:
        return b"", "application/octet-stream", ""
    path = _P(str(dict(row).get("path") or ""))
    if not path.is_file():
        return b"", "application/octet-stream", path.name
    try:
        data = path.read_bytes()
    except OSError:
        return b"", "application/octet-stream", path.name
    ctype = mimetypes.guess_type(path.name)[0] or "audio/mpeg"
    return data, ctype, path.name

def api_todos(ctx, payload: dict | None = None) -> dict:
    """便签里的待办：从正文解析 `- [ ]` / `- [x]` 的行。

    **为什么不建新表**：待办本来就写在便签正文里（"- [ ] 买牛奶"），
    再建一份表就有两份真相 —— 改了一边不同步。这里只做"读出来"和"改那一行"。
    """
    import re as _re

    notes = ctx.store.notes()
    out: list[dict] = []
    for n in notes:
        body = str(dict(n).get("body") or "")
        for i, line in enumerate(body.splitlines()):
            m = _re.match(r"^\s*[-*]\s*\[([ xX])\]\s*(.+?)\s*$", line)
            if not m:
                continue
            out.append({"note_id": int(dict(n)["id"]), "line": i,
                        "done": m.group(1).lower() == "x",
                        "text": m.group(2)[:120]})
    if payload is None:
        return {"ok": True, "items": out,
                "open": sum(1 for x in out if not x["done"]),
                "done": sum(1 for x in out if x["done"])}

    action = str(payload.get("action") or "toggle")
    nid = int(payload.get("note_id") or 0)
    line_no = int(payload.get("line") or 0)
    row = ctx.store.note_get(nid) if hasattr(ctx.store, "note_get") else None
    if row is None:
        # 退路：遍历找（note_get 不一定存在）
        for n in notes:
            if int(dict(n)["id"]) == nid:
                row = n
                break
    if row is None:
        return {"ok": False, "error": "找不到这条便签"}
    body = str(dict(row).get("body") or "")
    lines = body.splitlines()
    if not (0 <= line_no < len(lines)):
        return {"ok": False, "error": "行号越界（这一行可能被改过了）"}
    m = _re.match(r"^(\s*[-*]\s*\[)([ xX])(\]\s*.+)$", lines[line_no])
    if not m:
        return {"ok": False, "error": "这一行已经不是待办了"}
    want_done = (not (m.group(2).lower() == "x")) if payload.get("done") is None \
        else bool(payload.get("done"))
    lines[line_no] = m.group(1) + ("x" if want_done else " ") + m.group(3)
    new_body = "\n".join(lines)
    if hasattr(ctx.store, "note_update"):
        ctx.store.note_update(nid, new_body)
    elif hasattr(ctx.store, "note_save"):
        ctx.store.note_save(nid, new_body)
    else:
        ctx.store.conn.execute("UPDATE notes SET body = ? WHERE id = ?", (new_body, nid))
        ctx.store.conn.commit()
    return {"ok": True, "note_id": nid, "line": line_no, "done": want_done,
            "items": _todos_again(ctx)}

def _todos_again(ctx) -> list[dict]:
    """重新解析一遍（打勾之后返回最新清单）。"""
    import re as _re

    out: list[dict] = []
    for n in ctx.store.notes():
        d = dict(n)
        for i, line in enumerate(str(d.get("body") or "").splitlines()):
            m = _re.match(r"^\s*[-*]\s*\[([ xX])\]\s*(.+?)\s*$", line)
            if m:
                out.append({"note_id": int(d["id"]), "line": i,
                            "done": m.group(1).lower() == "x",
                            "text": m.group(2)[:120]})
    return out


def api_ai(ctx, payload: dict | None = None) -> dict:
    """AI 助教。GET 状态；POST 动作（含保存设置）。

    **密钥只在本地**：GET 只回"有没有配"和一个打码提示，绝不回全文。
    """
    from . import ai

    if payload is None:
        return {"ok": True, **ai.status(ctx.cfg)}
    action = str(payload.get("action") or "")
    if action == "save":
        fields = {}
        if payload.get("enabled") is not None:
            fields["ai_enabled"] = bool(payload["enabled"])
        if payload.get("key") is not None:
            fields["ai_key"] = str(payload["key"]).strip()
        if payload.get("model") is not None:
            fields["ai_model"] = str(payload["model"]).strip() or ai.DEFAULT_MODEL
        if not fields:
            return {"ok": False, "error": "没有要改的"}
        # **写进 config.json**：和她的数据放一起，不写日志、不外传
        data = {}
        try:
            import json as _json
            from pathlib import Path as _P

            p = _P(ctx.cfg.home) / "config.json"
            data = _json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}
        except Exception:
            data = {}
        data.update(fields)
        for k, v in fields.items():
            if hasattr(ctx.cfg, k):
                setattr(ctx.cfg, k, v)
        try:
            import json as _json2
            from pathlib import Path as _P2

            (_P2(ctx.cfg.home) / "config.json").write_text(
                _json2.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            return {"ok": False, "error": f"存不下来：{exc.__class__.__name__}"}
        return {"ok": True, **ai.status(ctx.cfg), "note": "存好了"}
    if action == "test":
        got = ai.ask(ctx.cfg, "explain", "1+1 等于几？")
        return {"ok": bool(got.get("ok")), **ai.status(ctx.cfg),
                "text": got.get("text", ""), "error": got.get("error", "")}
    if action == "chat":
        # **对话式**：把整段历史发过去（上限由后端截断）
        got = ai.chat(ctx.cfg, list(payload.get("messages") or []),
                      str(payload.get("system") or ""))
        return {**got, **ai.status(ctx.cfg)}
    if action in ("explain", "cards", "essay", "translate"):
        text = str(payload.get("text") or "")
        if action == "explain" and not text and payload.get("problem_id"):
            # 从题库取题目内容（她可能只点了"讲解这题"）
            row = ctx.store.get(int(payload["problem_id"]))
            if row is not None:
                text = f"{row.title}\n{getattr(row, 'note', '') or ''}"
        got = ai.ask(ctx.cfg, action, text, str(payload.get("extra") or ""))
        return {**got, **ai.status(ctx.cfg)}
    return {"ok": False, "error": f"不认识的动作：{action}"}


def api_plugins(ctx) -> dict:
    """插件清单 + 面板（**走真正的加载入口 `load_all`**）。

    上一版我只调了 `discover()`（它只列文件、不加载），所以永远 0 个插件。
    真正要做的是：建一个 `panels.PanelRegistry` → `load_all(reg, ctx)`
    → 插件清单在 `rt.infos`，面板在 `reg.panels`。
    """
    from . import panels as panels_mod
    from . import plugins as plugins_mod

    home = ctx.cfg.home
    rt = plugins_mod.PluginRuntime(home)
    reg = panels_mod.PanelRegistry()

    # ① 把插件真正加载进来（签名不确定，两种都试）
    loaded_err = ""
    try:
        rt.load_all(reg, ctx)
    except TypeError:
        try:
            rt.load_all(reg, ctx, [])
        except Exception as exc:
            loaded_err = f"{exc.__class__.__name__}: {exc}"
    except Exception as exc:
        loaded_err = f"{exc.__class__.__name__}: {exc}"

    # ② 插件清单：从 rt.infos 读（加载之后才有）
    infos = getattr(rt, "infos", {}) or {}
    items: list[dict] = []
    for name, info in (infos.items() if hasattr(infos, "items") else []):
        items.append({
            "name": str(getattr(info, "name", name) or name),
            "version": str(getattr(info, "version", "") or ""),
            "description": str(getattr(info, "description", "") or ""),
            "state": str(getattr(info, "state", "") or ""),
            "error": str(getattr(info, "error", "") or ""),
            "commands": [c for c in (getattr(info, "commands", []) or [])],
        })
    # 加载失败也如实列出来（"坏插件不能弄坏程序"的可见部分）
    # **按名字去重**：坏插件在 infos 和 errors 里各有一份，直接加会列两次
    # **比较前统一去掉 .py 后缀**：infos 里是 `broken`、errors 里是 `broken.py`，
    # 全等比较会漏，于是同一个坏插件列两次。
    def _norm(s: str) -> str:
        return str(s).strip().removesuffix(".py").removesuffix("/")

    seen = {_norm(i["name"]) for i in items}
    for name, err in (getattr(rt, "errors", []) or []):
        items.append({"name": str(name), "version": "", "description": "",
                      "state": "error", "error": str(err), "commands": []})
        seen.add(_norm(name))     # ← 循环里也要更新，否则同一个坏插件会被列多次

    # ③ 面板：从注册表读，逐个渲染（渲染失败只影响那一个）
    panels: list[dict] = []
    for pid, spec in (getattr(reg, "panels", {}) or {}).items():
        title = str(getattr(spec, "title", pid) or pid)
        owner = str(getattr(spec, "plugin", "") or getattr(spec, "source", "") or "")
        text = ""
        try:
            render = getattr(spec, "render", None)
            if callable(render):
                # render 可能需要 ctx 也可能不要 —— 两种都试
                try:
                    got = render()
                except TypeError:
                    got = render(ctx)
                if isinstance(got, str):
                    text = got
                else:
                    text = "\n".join(str(x) for x in (got or []))
            else:
                for attr in ("lines", "text", "body"):
                    v = getattr(spec, attr, None)
                    if v:
                        text = v if isinstance(v, str) else "\n".join(str(x) for x in v)
                        break
        except Exception as exc:
            text = f"（这个面板渲染失败：{exc.__class__.__name__}）"
        panels.append({"plugin": owner, "id": str(pid), "title": title, "text": text})

    # **最后统一按名字去重**：重复可能来自 infos 内部、也可能来自 infos+errors
    # 两处，逐个来源去重挡不住（我前两次就是这么漏的）。
    # 保留有错误信息的那份（信息更多）。
    uniq: dict[str, dict] = {}
    for it in items:
        k = _norm(it["name"])
        old = uniq.get(k)
        if old is None or (not old.get("error") and it.get("error")):
            uniq[k] = it
    items = sorted(uniq.values(), key=lambda x: (x["state"] != "error", x["name"]))

    return {"ok": True, "items": items, "panels": panels,
            "commands": [{"plugin": i["name"], "name": str(c)}
                         for i in items for c in (i.get("commands") or [])],
            "dir": str(home / "plugins"), "count": len(infos),
            "panel_count": len(panels),
            "load_error": loaded_err,
            "template": plugins_mod.TEMPLATE}
def api_data_health(ctx) -> dict:
    """数据体检：找出"悄悄变烂"的地方。

    只**报告**，不自动改 —— 自动删重复题这种事风险太大（万一是她故意建的）。
    每条都给出"怎么办"，她自己决定。
    """
    from datetime import timedelta

    today = ctx.today()
    problems = ctx.store.all()
    n = len(problems)
    issues: list[dict] = []

    # ① 重名题（同标题多条）
    by_title: dict[str, list] = {}
    for p in problems:
        by_title.setdefault(str(p.title).strip(), []).append(p.id)
    dup = {k: v for k, v in by_title.items() if len(v) > 1 and k}
    if dup:
        issues.append({"kind": "重复题目", "count": len(dup),
                       "detail": "；".join(f"{k}（{len(v)} 条）" for k, v in list(dup.items())[:5]),
                       "how": "在题库里合并或删掉重复的那几条"})

    # ② 没标签的题（复习时没法按知识点筛）
    no_tag = [p for p in problems if not (p.tags or [])]
    if no_tag:
        issues.append({"kind": "没有标签", "count": len(no_tag),
                       "detail": "、".join(p.title for p in no_tag[:5]),
                       "how": "加个标签（比如「图论」「DP」）—— 成绩单的弱项分析靠它"})

    # ③ 太久没复习的（60 天以上还没到期说明记录有问题）
    stale = [p for p in problems if p.due and (today - p.due).days > 60]
    if stale:
        issues.append({"kind": "逾期很久没动", "count": len(stale),
                       "detail": "、".join(p.title for p in stale[:5]),
                       "how": "打开复习过一次就会重新排期；不做就归档掉"})

    # ④ 没有链接的题（复习时"打开原题"点不了）
    no_url = [p for p in problems if not (p.url or "")]
    if no_url:
        issues.append({"kind": "没有原题链接", "count": len(no_url),
                       "detail": "、".join(p.title for p in no_url[:5]),
                       "how": "补上链接，「打开原题」就能用了（也能去 B 站搜讲解）"})

    # ⑤ 备份情况（数据只有一份才是真风险）
    from . import backup

    bks = backup.list_backups(ctx.cfg.home)
    newest = bks[0]["at"][:10] if bks else ""
    if not bks:
        issues.append({"kind": "没有备份", "count": 1, "detail": "一份备份都没有",
                       "how": "点「立即备份」（也会每天自动备份一次）"})
    elif newest and (today - __import__("datetime").date.fromisoformat(newest)).days > 3:
        issues.append({"kind": "备份有点旧", "count": 1, "detail": f"最近一份是 {newest}",
                       "how": "点「立即备份」"})

    # ⑥ 便签里有没有"空白的"（写了但只有空格）
    notes = ctx.store.notes()
    # `sqlite3.Row` **不支持 .get()**（支持下标）—— 先转 dict。
    empty = [x for x in notes if not str(dict(x).get("body") or "").strip()]
    if empty:
        issues.append({"kind": "空白便签", "count": len(empty), "detail": "",
                       "how": "删掉它们（便签列表里可以删）"})

    return {"ok": True, "checked_at": today.isoformat(), "problems": n,
            "issues": issues, "clean": not issues}

def api_materials(ctx, payload: dict | None = None, query: dict | None = None) -> dict:
    """资料库：登记 / 搜索 / 删。

    注意 `describe()` 里的限制：**相对路径会被拒**（按后端进程目录解析会指错地方，
    和"数据搬家"踩过的是同一个坑）。
    """
    from . import materials

    if payload is None:
        q = str((query or {}).get("q") or "")
        return {"ok": True, "items": ctx.store.materials(q),
                "stats": ctx.store.materials_stats(), "q": q}
    action = str(payload.get("action") or "add")
    if action == "delete":
        return {"ok": ctx.store.material_delete(int(payload.get("id") or 0)),
                "items": ctx.store.materials(),
                "stats": ctx.store.materials_stats()}
    if action == "add":
        got = materials.describe(str(payload.get("path") or ""))
        if not got.get("ok"):
            return got
        row = ctx.store.material_add(got["title"], got["path"], got["kind"],
                                     got["size"], got.get("preview", ""),
                                     str(payload.get("tag") or ""),
                                     str(payload.get("note") or ""))
        return {"ok": True, "item": row, "items": ctx.store.materials(),
                "stats": ctx.store.materials_stats()}
    return {"ok": False, "error": f"不认识的动作：{action}"}

def api_portable(ctx, payload: dict | None = None) -> dict:
    """便携模式：看当前数据在哪 / 搬到别处。

    搬家**只复制不删除**，并且要 `confirm: true` ——
    动数据目录的操作，不能因为点错一下就执行。
    """
    from . import portable

    if payload is None:
        return {"ok": True, **portable.where(ctx.cfg.home)}
    action = str(payload.get("action") or "move")
    if action == "move":
        got = portable.move(ctx.cfg.home, str(payload.get("target") or ""),
                            confirm=bool(payload.get("confirm")))
        return got
    return {"ok": False, "error": f"不认识的动作：{action}"}

def api_mock(ctx, payload: dict | None = None) -> dict:
    """六级模考。GET 记录 + 统计；POST 记一次 / 删一条。"""
    if payload is None:
        return {"ok": True, **ctx.store.mock_stats()}
    action = str(payload.get("action") or "add")
    if action == "delete":
        return {"ok": ctx.store.mock_delete(int(payload.get("id") or 0)),
                **ctx.store.mock_stats()}
    from datetime import date as _date

    taken = str(payload.get("taken_on") or "")[:10] or _date.today().isoformat()
    total = int(payload.get("total") or 0)
    if not (0 < total <= 710):
        return {"ok": False, "error": "总分要在 1 到 710 之间"}
    got = ctx.store.mock_add(
        taken, total,
        int(payload.get("listening") or 0), int(payload.get("reading") or 0),
        int(payload.get("writing") or 0), int(payload.get("minutes") or 0),
        str(payload.get("note") or ""))
    return {"ok": True, "exam": got, **ctx.store.mock_stats()}

def api_words(ctx, payload: dict | None = None, query: dict | None = None) -> dict:
    """六级词卡。GET 取今天该背的 + 进度；POST 导入 / 评价。"""
    from . import words as words_mod

    if payload is None:
        try:
            limit = max(1, min(100, int(str((query or {}).get("limit") or 20))))
        except (TypeError, ValueError):
            limit = 20
        return {"ok": True, "items": words_mod.due(ctx.store, limit),
                "stats": words_mod.stats(ctx.store)}
    action = str(payload.get("action") or "review")
    if action == "import":
        from . import cet6

        vocab = list(getattr(cet6, "KEY_VOCAB", []) or [])
        return {**words_mod.import_vocab(ctx.store, vocab),
                "stats": words_mod.stats(ctx.store)}
    if action == "review":
        got = words_mod.review(ctx.store, int(payload.get("id") or 0),
                               str(payload.get("quality") or ""))
        if not got.get("ok"):
            return got
        return {**got, "items": words_mod.due(ctx.store, 20),
                "stats": words_mod.stats(ctx.store)}
    return {"ok": False, "error": f"不认识的动作：{action}"}

def api_logs(ctx, query: dict | None = None) -> dict:
    """读启动器日志的尾部（出问题时她自己能看到"刚才发生了什么"）。

    日志在**安装目录**（desktop.log），不是数据目录 —— 后端是打包的 exe 时
    它在 exe 旁边；开发态在项目根目录。
    """
    import sys as _sys
    from pathlib import Path as _Path

    try:
        lines = max(20, min(1000, int(str((query or {}).get("lines") or 200))))
    except (TypeError, ValueError):
        lines = 200
    # **逐级往上找**：打包后后端在 `…/resources/backend/`，
    # 而日志在安装目录（还要再上两层）。只找一两层会找不到（我第一版就是这样）。
    cands = []
    exe = _Path(_sys.executable)
    here = exe.parent
    for _ in range(5):                      # 后端目录 → resources → 安装目录 → 上两级
        cands.append(here / "desktop.log")
        here = here.parent
    cands.append(_Path.cwd() / "desktop.log")
    try:
        cands.append(_Path(ctx.cfg.home).parent / "desktop.log")
    except Exception:
        pass
    found = None
    for c in cands:
        try:
            if c.is_file():
                found = c
                break
        except OSError:
            continue
    if found is None:
        return {"ok": True, "path": "", "lines": [],
                "note": "还没找到日志（应用正常启动后就会有）"}
    try:
        text = found.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        return {"ok": False, "error": f"读不了日志：{exc.__class__.__name__}"}
    return {"ok": True, "path": str(found), "total": len(text),
            "lines": text[-lines:]}

def api_backup(ctx, payload: dict | None = None) -> dict:
    """备份。GET 列出来；POST 有动作。

    `now` 现在打一份 / `restore` 恢复 / `delete` 删掉某一份。
    """
    from . import backup

    home = ctx.cfg.home
    if payload is None:
        return {"ok": True, "items": backup.list_backups(home),
                "dir": str(backup.backup_root(home)), "keep": backup.KEEP}
    action = str(payload.get("action") or "now")
    if action == "now":
        made = backup.make_backup(home, prefix="手动")
        backup.prune(home)
        return {**made, "items": backup.list_backups(home)}
    if action == "restore":
        got = backup.restore(home, str(payload.get("name") or ""))
        return {**got, "items": backup.list_backups(home)}
    if action == "delete":
        name = str(payload.get("name") or "")
        target = backup.backup_root(home) / name
        if not target.is_file() or target.parent != backup.backup_root(home):
            return {"ok": False, "error": "找不到这份备份"}
        target.unlink()
        return {"ok": True, "deleted": name, "items": backup.list_backups(home)}
    return {"ok": False, "error": f"不认识的动作：{action}"}


def api_site_health(ctx, payload: dict | None = None) -> dict:
    """资源站点体检。GET 读缓存（不联网）；POST 触发后台检测。"""
    from . import site_health

    home = ctx.cfg.home
    if payload is not None and str(payload.get("action") or "check") == "check":
        sites = _sites_flat()
        if not sites:
            return {"ok": False, "error": "没有可检测的站点"}
        site_health.run_async(home, sites)
        return {"ok": True, "started": True, "count": len(sites),
                "note": "正在后台检测，几秒后再看"}
    data = site_health.load(home)
    if data is None:
        return {"ok": True, "checked_at": "", "items": [],
                "note": "还没检测过，点「检测」跑一次"}
    return {"ok": True, "checked_at": data.get("at", ""),
            "items": data.get("items", []),
            "ok_count": data.get("ok_count", 0),
            "bot_count": data.get("bot_count", 0),
            "dead_count": data.get("dead_count", 0)}


def api_focus(ctx, payload: dict | None = None,
              query: dict | None = None) -> dict:
    """专注（番茄钟）。GET 统计；POST 记一笔。

    注意 GET 和 POST 的区分**不能靠"payload 是不是空"** ——
    路由那边为了传 days 会塞一个 dict 进来，于是 GET 被当成写请求，
    统计接口直接回 error（我第一版就是这样，界面上今日专注一直是 None）。
    """
    if payload is None:
        try:
            days = max(1, min(90, int(str((query or {}).get("days") or 7))))
        except (TypeError, ValueError):
            days = 7
        return {"ok": True, **ctx.store.focus_stats(days)}
    minutes = int(payload.get("minutes") or 0)
    if minutes <= 0:
        return {"ok": False, "error": "专注时长要大于 0"}
    started = str(payload.get("started_at") or "")
    if not started:
        from datetime import datetime

        started = datetime.now().isoformat(timespec="seconds")
    got = ctx.store.focus_add(started, minutes, str(payload.get("note") or ""))
    return {"ok": True, "session": got, **ctx.store.focus_stats(7)}


def api_lunar(ctx, query: dict) -> dict:
    """农历。`GET /api/lunar?month=2026-10`

    回这个月每天要显示的小字：`{日期: {d: 农历日, f: 节日}}`。

    **只算一个月**：月历一次只显示一个月，没必要把整年拉出来算。
    表本身是固定的（1900–2100），超出范围就回空（前端不显示那行小字）。
    """
    from . import lunar

    raw = str(query.get("month") or "").strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})", raw)
    if not m:
        return {"ok": False, "error": "月份要看不懂了，用 2026-10 这种写法"}
    y, mo = int(m.group(1)), int(m.group(2))
    if not (1 <= mo <= 12):
        return {"ok": False, "error": "月份要在 1 到 12 之间"}
    if not lunar.in_range(y):
        return {"ok": True, "month": f"{y:04d}-{mo:02d}", "days": {},
                "note": f"农历表只覆盖 {lunar.MIN_YEAR}-{lunar.MAX_YEAR} 年"}
    return {"ok": True, "month": f"{y:04d}-{mo:02d}",
            "days": lunar.month_calendar(y, mo)}


# ---------------- 应用更新（应用内一键更新 / 选择更新包） ----------------

# 更新包上传大小上限（web_server 读原始 body 时也用这个值）
UPDATE_UPLOAD_LIMIT = 200 * 1024 * 1024


def _permission_hint(exc: BaseException) -> str:
    """把 Permission denied 翻译成她能照着做的中文建议。"""
    return (
        "解压/写入更新包时被系统拒绝了（Permission denied）。"
        "多半是 Windows 安全中心或杀毒软件拦住了程序目录/数据目录的写入。"
        "可以：① 暂时关闭杀毒软件的实时防护再点一次；"
        "② 把程序文件夹移到普通目录（如 D:\\形学）；"
        "③ 用安装包重装到本机（会装到 AppData，不受影响）。"
        f"详细错误：{exc}")


def _update_state(ctx) -> dict:
    """设置页「软件更新」卡片要的全部数据。"""
    from . import updater
    from .update_sites import (
        DOWNLOAD_FALLBACKS, DOWNLOAD_PAGE_URL, DOWNLOAD_URL, META_URLS,
        SITE_HINT, SITE_NAME, UPLOAD_URL,
    )

    st = updater.make_state(ctx.cfg.home)
    st["sites"] = {
        "name": SITE_NAME,
        "hint": SITE_HINT,
        "download_url": DOWNLOAD_URL,
        "download_fallbacks": list(DOWNLOAD_FALLBACKS),
        "page_url": DOWNLOAD_PAGE_URL,
        "upload_url": UPLOAD_URL,
        "meta_urls": list(META_URLS),
    }
    return st


def api_update_state(ctx) -> dict:
    """当前版本 / 待应用的更新 / 固定下载站点。"""
    return _update_state(ctx)


def api_update(ctx, payload: dict) -> dict:
    """更新动作：download（一键下载）/ apply（立即重启更新）/ cancel（取消）。"""
    from . import updater

    action = str(payload.get("action") or "")

    if action == "download":
        # 应用内一键更新：读 update.json → 比版本 → 三路直链下载 → 校验 sha256 → 暂存
        try:
            info = updater.download_and_stage(ctx.cfg.home)
        except updater.UpdateError as exc:
            return {"ok": False, "error": str(exc)}
        except PermissionError as exc:
            return {"ok": False, "error": _permission_hint(exc)}
        except OSError as exc:
            return {"ok": False, "error": f"更新包处理失败（写文件出错）：{exc}"}
        return {"ok": True,
                "result": {k: v for k, v in info.items() if k != "pending"},
                **_update_state(ctx)}

    if action == "apply":
        try:
            info = updater.apply_now(ctx.cfg.home)
        except updater.UpdateError as exc:
            return {"ok": False, "error": str(exc)}
        # 稍等一下让响应先发出去，再退出后端（PowerShell 会接着替换文件并重启）
        updater.schedule_exit(1.2)
        return {"ok": True, "message": "正在更新，程序会自动重启", **info}

    if action == "cancel":
        updater.cancel(ctx.cfg.home)
        return {"ok": True, **_update_state(ctx)}

    return {"ok": False, "error": f"不认识的更新动作：{action}"}


def api_update_upload(app, raw: bytes) -> dict:
    """接收上传的更新包（原始 zip 字节，不走 JSON）。

    只做校验 + 解压到暂存目录，**不动现有程序**；真正替换要用户点「立即重启并更新」。
    """
    from . import updater

    try:
        info = updater.validate_and_stage(app.cfg.home, raw)
    except updater.UpdateError as exc:
        return {"ok": False, "error": str(exc)}
    except PermissionError as exc:
        return {"ok": False, "error": _permission_hint(exc)}
    except Exception as exc:  # 兜底：任何异常都变成能看懂的话
        return {"ok": False, "error": f"更新包处理失败：{exc}"}
    return {"ok": True, "result": info}


# --------------------------------------------------------------------------
# 路由
# --------------------------------------------------------------------------

def handle(app, method: str, path: str, query: dict, payload: dict):
    """把请求分发到上面的函数。返回 (状态码, 数据) 或 None。"""
    ctx = app.context()
    try:
        return _route(ctx, method, path, query, payload)
    finally:
        try:
            ctx.store.close()
        except Exception:
            pass


def _route(ctx, method: str, path: str, query: dict, payload: dict):
    # ---- 概览 ----
    if path == "/api/dashboard" and method == "GET":
        return 200, api_dashboard(ctx)
    if path == "/api/message" and method == "POST":
        return 200, api_message(ctx, payload)
    if path == "/api/message/kinds" and method == "GET":
        return 200, api_kinds(ctx)
    # ---- 工具箱 ----
    if path == "/api/translate" and method == "POST":
        data = api_translate(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/translate/meta" and method == "GET":
        return 200, api_translate_terms(ctx)

    # ---- B 站 cookies ----
    #
    # 都是精确匹配，但**顺序上仍然放在 mascar 之前**，
    # 保持"功能模块聚在一起"的可读性。
    # （这个项目里因为路由顺序踩过坑：/api/video/overview 被
    #   /api/video/{id} 的通配匹配吃掉过。这里虽然不涉及通配，
    #   但把新模块集中放、并写清顺序要求，是个好习惯。）
    if path == "/api/cookies" and method == "GET":
        return 200, api_cookies_status(ctx)
    if path == "/api/cookies" and method == "POST":
        data = api_cookies_save(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/cookies" and method == "DELETE":
        data = api_cookies_clear(ctx)
        return (200 if data.get("ok") else 400), data
    if path == "/api/cookies/probe" and method == "POST":
        return 200, api_cookies_probe(ctx, payload)
    if path == "/api/cookies/browser" and method == "POST":
        return 200, api_cookies_browser(ctx, payload)
    if path == "/api/cookies/sync" and method == "POST":
        return 200, api_cookies_sync(ctx, payload)
    if path == "/api/cookies/bilisum" and method == "GET":
        return 200, api_cookies_bilisum(ctx)

    # ---- 符号喵喵（Vue 版按需取动作表）----
    if path == "/api/mascot" and method == "GET":
        return 200, api_mascot(ctx)

    # ---- 应用窗口心跳 ----
    if path == "/api/ping" and method == "GET":
        return 200, api_ping(ctx)

    # ---- 专业学习 ----
    if path == "/api/stats" and method == "GET":
        return 200, api_stats(ctx)
    if path == "/api/doctor" and method == "GET":
        return 200, api_doctor(ctx)

    # ---- 复习 ----
    if path == "/api/review/queue" and method == "GET":
        limit = int(query.get("limit") or 0)
        return 200, api_review_queue(ctx, limit=limit)
    if path == "/api/review/submit" and method == "POST":
        data = api_review_submit(ctx, payload)
        return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/review/(\d+)/show", path)
    if match and method == "GET":
        data = api_review_show(ctx, int(match.group(1)))
        return (200 if data.get("ok") else 404), data
    match = re.fullmatch(r"/api/review/(\d+)", path)
    if match and method == "GET":
        data = api_review_card(ctx, int(match.group(1)))
        return (200 if data.get("ok") else 404), data

    # ---- 题目 ----
    if path == "/api/problems" and method == "GET":
        return 200, api_problems(ctx, query)
    if path == "/api/problems" and method == "POST":
        data = api_problem_create(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/problems/tags" and method == "POST":
        return 200, api_normalize_tags(ctx, payload)
    match = re.fullmatch(r"/api/problems/(\d+)", path)
    if match:
        pid = int(match.group(1))
        if method == "GET":
            data = api_problem_detail(ctx, pid)
            return (200 if data.get("ok") else 404), data
        if method == "PUT":
            data = api_problem_update(ctx, pid, payload)
            return (200 if data.get("ok") else 400), data
        if method == "DELETE":
            return 200, api_problem_delete(ctx, pid)

    # ---- 搜索与视频 ----
    if path == "/api/search" and method == "GET":
        data = api_search(ctx, query)
        return (200 if data.get("ok") else 400), data
    if path == "/api/video/status" and method == "GET":
        return 200, api_video_status(ctx)
    if path == "/api/video/start" and method == "POST":
        data = api_video_start(ctx, payload)
        return (200 if data.get("ok") else 400), data
    # 任务总览（队列诊断）——要放在 /api/video/{id}/... 的通配匹配**之前**，
    # 否则 "overview" 会被当成 task_id 吃掉。
    if path == "/api/video/overview" and method == "GET":
        return 200, api_video_overview(ctx)
    if path == "/api/video/restart" and method == "POST":
        data = api_video_restart(ctx)
        return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/video/([\w-]+)/cancel", path)
    if match and method == "POST":
        data = api_video_cancel(ctx, match.group(1))
        return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/video/([\w-]+)/progress", path)
    if match and method == "GET":
        data = api_video_progress(ctx, match.group(1))
        return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/video/([\w-]+)/result", path)
    if match and method == "POST":
        data = api_video_result(ctx, match.group(1), payload)
        return (200 if data.get("ok") else 400), data

    # ---- 专业学习 / 学习资源 ----
    if path == "/api/courses" and method == "GET":
        return 200, api_courses(ctx)
    # ---- 资源收藏 / 打开记录 ----
    #
    # **顺序有讲究**：/api/sites/favorites 和 /api/sites/visits 要放在
    # /api/sites/{key} 这类通配匹配之前，否则 "favorites" 会被当成 key。
    # （/api/video/overview 就被 task_id 吃掉过一次，同一个坑。）
    if path == "/api/sites/favorites":
        if method == "GET":
            return 200, api_site_favorites(ctx)
        if method == "POST":
            data = api_site_favorite_toggle(ctx, payload)
            return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/sites/favorites/([\w.-]+)", path)
    if match and method == "DELETE":
        return 200, api_site_favorite_delete(ctx, match.group(1))
    match = re.fullmatch(r"/api/sites/favorites/([\w.-]+)/move", path)
    if match and method == "POST":
        return 200, api_site_favorite_move(ctx, match.group(1), payload)
    if path == "/api/sites/visits":
        if method == "GET":
            return 200, api_site_visits(ctx)
        if method == "POST":
            data = api_site_visit_add(ctx, payload)
            return (200 if data.get("ok") else 400), data
        if method == "DELETE":
            return 200, api_site_visits_clear(ctx)

    if path == "/api/sites" and method == "GET":
        return 200, api_sites(ctx)

    # ---- 六级备考 ----
    if path == "/api/cet6" and method == "GET":
        return 200, api_cet6(ctx)
    if path == "/api/cet6/videos" and method == "GET":
        return 200, api_cet6_videos(ctx, query)
    if path == "/api/cet6/import" and method == "POST":
        data = api_cet6_import(ctx, payload)
        return (200 if data.get("ok") else 400), data

    # ---- 便签 / 倒数日 / 提醒 ----
    if path == "/api/notes" and method == "GET":
        return 200, api_notes(ctx)
    if path == "/api/notes" and method == "POST":
        data = api_note_save(ctx, payload)
        return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/notes/(\d+)", path)
    if match and method == "POST":
        data = api_note_action(ctx, int(match.group(1)), payload)
        return (200 if data.get("ok") else 400), data

    if path == "/api/countdowns" and method == "GET":
        return 200, api_countdowns(ctx)
    if path == "/api/countdowns" and method == "POST":
        data = api_countdown_save(ctx, payload)
        return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/countdowns/(\d+)", path)
    if match and method == "DELETE":
        return 200, api_countdown_delete(ctx, int(match.group(1)))
    if match and method == "POST":
        data = api_countdown_edit(ctx, int(match.group(1)), payload)
        return (200 if data.get("ok") else 400), data

    # ---- 生理期 ----
    if path == "/api/cycle" and method == "GET":
        return 200, {"ok": True, "cycle": cycle_json(ctx, ctx.today())}
    if path == "/api/cycle" and method == "POST":
        data = api_cycle_save(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/cycle/mark" and method == "POST":
        data = api_cycle_mark(ctx, payload)
        return (200 if data.get("ok") else 400), data

    if path == "/api/reminders" and method == "GET":
        return 200, api_reminders(ctx)
    if path == "/api/reminders" and method == "POST":
        data = api_reminder_save(ctx, payload)
        return (200 if data.get("ok") else 400), data
    match = re.fullmatch(r"/api/reminders/(\d+)", path)
    if match and method == "POST":
        data = api_reminder_action(ctx, int(match.group(1)), payload)
        return (200 if data.get("ok") else 400), data

    # ---- 诊断 ----
    if path == "/api/failures" and method == "GET":
        return 200, api_failures(ctx)
    match = re.fullmatch(r"/api/failures/(\d+)", path)
    if match and method == "POST":
        data = api_failure_action(ctx, int(match.group(1)), payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/quality" and method == "GET":
        return 200, api_quality(ctx)

    # ---- 应用更新 ----
    if path == "/api/update" and method == "GET":
        return 200, api_update_state(ctx)
    if path == "/api/update" and method == "POST":
        data = api_update(ctx, payload)
        return (200 if data.get("ok") else 400), data

    # ---- 设置 ----
    if path == "/api/settings" and method == "GET":
        return 200, api_settings_get(ctx)
    if path == "/api/settings" and method == "POST":
        data = api_settings_save(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/settings/panels" and method == "POST":
        if "panels" in payload:
            data = api_panels_reorder(ctx, payload)
        else:
            data = api_panels_toggle(ctx, payload)
        return (200 if data.get("ok") else 400), data

    # ---- 头像 ----
    if path == "/api/avatar" and method == "GET":
        return 200, api_avatar_get(ctx, query)
    if path == "/api/avatar" and method == "POST":
        data = api_avatar_save(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/avatar" and method == "DELETE":
        data = api_avatar_clear(ctx)
        return (200 if data.get("ok") else 400), data

    # ---- 娱乐 · 听歌 ----
    #
    # 两个接口**永远回 200**：网络不通/接口改版/被限流都写成
    # `{ok: false, error/why: 中文}`。理由：
    #   · 音乐是娱乐模块，它挂了不该在界面上炸出一片红（前端只会 toast 报错）；
    #   · 200 + ok=false 让前端能"温柔地"显示一句人话。
    # 另外：这两个接口**不做任何缓存直链的事**（25 分钟就过期，缓存只会带来怪 bug），
    # 细节都在 her_review/music.py 的模块注释里。
    if path == "/api/music/search" and method == "GET":
        return 200, api_music_search(ctx, query)
    if path == "/api/music/url" and method == "GET":
        return 200, api_music_url(ctx, query)
    # ---- 备份 / 站点体检 / 专注（升级版第一批）----
    # ---- 错题本 / 提醒到点 / 负载 / 目标（升级版第二批）----
    if path == "/api/mistakes" and method == "GET":
        return 200, api_mistakes(ctx, None, query)
    if path == "/api/mistakes" and method == "POST":
        data = api_mistakes(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/reminders/due" and method == "GET":
        return 200, api_reminders_due(ctx)
    if path == "/api/reminders/due" and method == "POST":
        data = api_reminders_due(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/review/load" and method == "GET":
        return 200, api_review_load(ctx, query)
    if path == "/api/goals" and method == "GET":
        return 200, api_goals(ctx)
    if path == "/api/goals" and method == "POST":
        data = api_goals(ctx, payload)
        return (200 if data.get("ok") else 400), data

    if path == "/api/watch" and method == "GET":
        return 200, api_watch(ctx)
    if path == "/api/watch" and method == "POST":
        data = api_watch(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/links" and method == "GET":
        return 200, api_links(ctx, None, query)
    if path == "/api/links" and method == "POST":
        data = api_links(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/attachments" and method == "GET":
        return 200, api_attachments(ctx, None, query)
    if path == "/api/attachments" and method == "POST":
        data = api_attachments(ctx, payload)
        return (200 if data.get("ok") else 400), data
    _aim = re.fullmatch(r"/api/attachment/(\d+)", path)
    if _aim and method == "GET":
        return 200, api_attachment_image(ctx, int(_aim.group(1)))
    # 备考级别（四级 / 六级）：一处切换，听力/阅读/作文/翻译的素材跟着变
    if path == "/api/cet" and method == "GET":
        return 200, api_cet(ctx)
    if path == "/api/cet" and method == "POST":
        data = api_cet(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/practice" and method == "GET":
        return 200, api_practice(ctx, None, query)
    if path == "/api/practice" and method == "POST":
        data = api_practice(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/listening" and method == "GET":
        return 200, api_listening(ctx, None, query)
    # 抓字幕的进度查询（**每次只查一下**，前端轮询用）
    if path == "/api/listening/subtitle" and method == "GET":
        lid = int(str((query or {}).get("id") or 0))
        data = _subtitle_status(ctx, lid)
        return (200 if data.get("ok") or data.get("state") == "running" else 400), data
    if path == "/api/listening" and method == "POST":
        data = api_listening(ctx, payload)
        return (200 if data.get("ok") else 400), data
    _am = re.fullmatch(r"/api/listening/(\d+)/audio", path)
    if _am and method == "GET":
        # **以 base64 交给网页播放器**：HTTP 层直出字节的约定我没确认，
        # 不猜 —— 小文件走这条路，大文件前端改用系统播放器（open_path）。
        return 200, api_listening_audio(ctx, int(_am.group(1)))
    if path == "/api/todos" and method == "GET":
        return 200, api_todos(ctx)
    if path == "/api/todos" and method == "POST":
        data = api_todos(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/ai" and method == "GET":
        return 200, api_ai(ctx)
    if path == "/api/ai" and method == "POST":
        data = api_ai(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/plugins" and method == "GET":
        return 200, api_plugins(ctx)
    if path == "/api/health/data" and method == "GET":
        return 200, api_data_health(ctx)
    if path == "/api/materials" and method == "GET":
        return 200, api_materials(ctx, None, query)
    if path == "/api/materials" and method == "POST":
        data = api_materials(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/portable" and method == "GET":
        return 200, api_portable(ctx)
    if path == "/api/portable" and method == "POST":
        data = api_portable(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/mock" and method == "GET":
        return 200, api_mock(ctx)
    if path == "/api/mock" and method == "POST":
        data = api_mock(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/words" and method == "GET":
        return 200, api_words(ctx, None, query)
    if path == "/api/words" and method == "POST":
        data = api_words(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/logs" and method == "GET":
        return 200, api_logs(ctx, query)
    if path == "/api/backup" and method == "GET":
        return 200, api_backup(ctx)
    if path == "/api/backup" and method == "POST":
        data = api_backup(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/sites/health" and method == "GET":
        return 200, api_site_health(ctx)
    if path == "/api/sites/health" and method == "POST":
        data = api_site_health(ctx, payload)
        return (200 if data.get("ok") else 400), data
    if path == "/api/focus" and method == "GET":
        return 200, api_focus(ctx, None, query)
    if path == "/api/focus" and method == "POST":
        data = api_focus(ctx, payload)
        return (200 if data.get("ok") else 400), data

    if path == "/api/lunar" and method == "GET":
        return 200, api_lunar(ctx, query)
    if path == "/api/music/lyric" and method == "GET":
        return 200, api_music_lyric(ctx, query)
    if path == "/api/music/playlist":
        if method == "GET":
            return 200, api_music_playlist(ctx)
        if method == "POST":
            data = api_music_playlist_add(ctx, payload)
            return (200 if data.get("ok") else 400), data
    if path == "/api/music/playlist/clear" and method == "POST":
        return 200, api_music_playlist_clear(ctx)
    match = re.fullmatch(r"/api/music/playlist/(\d+)", path)
    if match and method == "DELETE":
        return 200, api_music_playlist_remove(ctx, match.group(1))
    match = re.fullmatch(r"/api/music/playlist/(\d+)/move", path)
    if match and method == "POST":
        return 200, api_music_playlist_move(ctx, match.group(1), payload)

    return None



# ==========================================================================
#  恢复区：以下函数是第 10~30 批加的接口，曾被一次错误的补丁切掉，这里重建。
#  实现与原版一致（契约：动作名、返回字段都对得上前端）。
# ==========================================================================

# 听力的预置主题（点一下就去 B 站搜）
LISTEN_PRESETS = [
    {"key": "cet6", "label": "六级听力真题", "keyword": "六级听力真题",
     "kind": "real", "note": "历年真题听力"},
    {"key": "cet6-jj", "label": "六级听力精讲", "keyword": "六级听力 精讲",
     "kind": "intensive", "note": "逐题精讲，适合精听"},
    {"key": "voa", "label": "VOA 慢速英语", "keyword": "VOA慢速英语",
     "kind": "loop", "note": "磨耳朵经典材料"},
    {"key": "bbc", "label": "BBC 六分钟英语", "keyword": "BBC 6 Minute English",
     "kind": "loop", "note": "六分钟一集，适合循环"},
    {"key": "ted", "label": "TED 演讲（带字幕）", "keyword": "TED 演讲 中英字幕",
     "kind": "intensive", "note": "有字幕，可精听"},
    {"key": "ears", "label": "英语磨耳朵合集", "keyword": "英语听力磨耳朵",
     "kind": "loop", "note": "长合集，放着听"},
]

# 阅读 / 作文 / 翻译 的预置主题
PRACTICE_PRESETS = {
    "reading": [
        {"key": "cet6-read", "label": "六级阅读真题讲解", "keyword": "六级阅读真题 讲解"},
        {"key": "cet6-read-skill", "label": "六级阅读技巧", "keyword": "六级阅读 技巧 方法"},
        {"key": "cet6-cloze", "label": "选词填空专项", "keyword": "六级选词填空 技巧"},
        {"key": "long-read", "label": "长篇阅读/匹配题", "keyword": "六级长篇阅读 匹配题 技巧"},
        {"key": "read-aloud", "label": "英文原著精读", "keyword": "英文原著 精读 讲解"},
    ],
    "writing": [
        {"key": "cet6-write", "label": "六级作文模板", "keyword": "六级作文 模板 万能句型"},
        {"key": "cet6-write-topic", "label": "历年作文真题", "keyword": "六级作文 历年真题 范文"},
        {"key": "write-skill", "label": "写作提分技巧", "keyword": "六级写作 提分 技巧"},
        {"key": "write-model", "label": "高分范文精讲", "keyword": "六级作文 高分范文 讲解"},
    ],
    "translation": [
        {"key": "cet6-trans", "label": "六级翻译真题", "keyword": "六级翻译 历年真题 讲解"},
        {"key": "trans-skill", "label": "翻译技巧", "keyword": "六级翻译 技巧 方法"},
        {"key": "trans-culture", "label": "中国文化主题词", "keyword": "六级翻译 中国文化 高频词"},
        {"key": "trans-practice", "label": "翻译每日一练", "keyword": "六级翻译 每日一练"},
    ],
}

PRACTICE_LABELS = {"reading": "阅读", "writing": "作文", "translation": "翻译"}


def _search_rows(outcome) -> list:
    """从搜索结果里取列表（字段名挨个试 —— 这个项目里踩过好几次）。"""
    for attr in ("results", "items", "videos", "list", "data"):
        v = getattr(outcome, attr, None)
        if isinstance(v, list) and v:
            return v
    if isinstance(outcome, dict):
        for attr in ("results", "items", "videos"):
            v = outcome.get(attr)
            if isinstance(v, list) and v:
                return v
    return []


def _search_pick(row, *names) -> str:
    for n in names:
        if isinstance(row, dict) and row.get(n):
            return str(row[n])
        v = getattr(row, n, None)
        if v:
            return str(v)
    return ""


def _listen_import_search(ctx, keyword: str, kind: str = "loop",
                          limit: int = 8) -> dict:
    """用已有的 B 站搜索，把结果登记成听力条目（**实时搜，不写死 BV 号**）。"""
    from . import search as search_mod

    kw = str(keyword or "").strip()
    if not kw:
        return {"ok": False, "error": "没给搜索词"}
    try:
        outcome = search_mod.search_online_cached(kw, page=1)
    except Exception as exc:
        return {"ok": False, "error": f"搜索失败（{exc.__class__.__name__}）—— 检查网络"}
    rows = _search_rows(outcome)
    if not rows:
        return {"ok": False,
                "error": "B 站搜索没拿到结果：" + (str(getattr(outcome, "error", "")) or "（换个关键词试试）")}
    existing = {str(x.get("path") or "") for x in ctx.store.listening()}
    added = skipped = 0
    for row in rows[:max(1, min(20, int(limit)))]:
        url = _search_pick(row, "url", "link", "href", "arcurl")
        bvid = _search_pick(row, "bvid", "bv")
        if not url and bvid:
            url = "https://www.bilibili.com/video/" + bvid
        title = _search_pick(row, "title", "name", "video_title") or url
        if not url or url in existing:
            skipped += 1
            continue
        ctx.store.listen_add(kind, title[:120], url, "", "", kw[:200])
        existing.add(url)
        added += 1
    return {"ok": True, "added": added, "skipped": skipped, "keyword": kw,
            "items": ctx.store.listening(), "stats": ctx.store.listen_stats(),
            "note": f"「{kw}」导入了 {added} 条" + (f"，跳过重复 {skipped} 条" if skipped else "")}


def _listen_attach_papers(ctx, limit: int = 1) -> dict:
    """给真题**逐套**搜 B 站并挂上第一条（一次只做 limit 套，避免超时）。"""
    from . import listening as _ls3
    from . import search as _search3

    have = {}
    for x in ctx.store.listening("real"):
        key = str(x.get("paper_key") or "")
        if key and str(x.get("path") or ""):
            have[key] = x

    todo = [p for p in _ls3.REAL_PAPERS if p["key"] not in have]
    todo = todo[:max(1, min(5, int(limit)))]
    added = failed = 0
    detail = []
    for paper in todo:
        key = paper["key"]
        kw = str(paper["title"]).replace("六级", _cet_label(ctx)).replace("听力", "听力真题")
        try:
            outcome = _search3.search_online_cached(kw, page=1)
        except Exception:
            failed += 1
            detail.append(key + "✗")
            continue
        rows = _search_rows(outcome)
        if not rows:
            failed += 1
            detail.append(key + "✗")
            continue
        row = rows[0]
        url = _search_pick(row, "url", "link", "href", "arcurl")
        bvid = _search_pick(row, "bvid", "bv")
        if not url and bvid:
            url = "https://www.bilibili.com/video/" + bvid
        title = _search_pick(row, "title", "name") or str(paper["title"])
        if not url:
            failed += 1
            detail.append(key + "✗")
            continue
        got = ctx.store.listen_add("real", title[:120], url, key, "", "")
        rid = got.get("id") if isinstance(got, dict) else None
        if rid:
            try:
                ctx.store.listen_update(int(rid), paper_key=key)
            except Exception:
                pass
        added += 1
        detail.append(key + "+1")

    left = len([p for p in _ls3.REAL_PAPERS
                if p["key"] not in {str(x.get("paper_key") or "")
                                    for x in ctx.store.listening("real")
                                    if str(x.get("path") or "")}])
    note = f"挂了 {added} 套" + (f"，{failed} 套没搜到" if failed else "")
    return {"ok": True, "added": added, "failed": failed, "remaining": left,
            "note": note, "detail": detail,
            "items": ctx.store.listening(), "stats": ctx.store.listen_stats()}


# ---------------------------------------------------------------------------
#  备考级别（四级 / 六级）—— 一处切换，全局生效
# ---------------------------------------------------------------------------

def cet_level(ctx) -> str:
    """当前级别（默认六级；非法值一律当六级）。"""
    raw = str(getattr(ctx.cfg, "cet_level", "") or "cet6").lower()
    return raw if raw in ("cet4", "cet6") else "cet6"


def _cet_label(ctx) -> str:
    return "四级" if cet_level(ctx) == "cet4" else "六级"


def _listen_presets(ctx) -> list:
    """听力预置主题（按级别生成关键词）。"""
    lab = _cet_label(ctx)
    return [
        {"key": "real", "label": lab + "听力真题", "keyword": lab + "听力真题",
         "kind": "real", "note": "历年真题听力"},
        {"key": "jj", "label": lab + "听力精讲", "keyword": lab + "听力 精讲",
         "kind": "intensive", "note": "逐题精讲，适合精听"},
        {"key": "voa", "label": "VOA 慢速英语", "keyword": "VOA慢速英语",
         "kind": "loop", "note": "磨耳朵经典材料"},
        {"key": "bbc", "label": "BBC 六分钟英语", "keyword": "BBC 6 Minute English",
         "kind": "loop", "note": "六分钟一集，适合循环"},
        {"key": "ted", "label": "TED 演讲（带字幕）", "keyword": "TED 演讲 中英字幕",
         "kind": "intensive", "note": "有字幕，可精听"},
        {"key": "ears", "label": "英语磨耳朵合集", "keyword": "英语听力磨耳朵",
         "kind": "loop", "note": "长合集，放着听"},
    ]


def _practice_presets(ctx, module: str) -> list:
    """阅读/作文/翻译的预置主题（按级别生成关键词）。"""
    lab = _cet_label(ctx)
    table = {
        "reading": [("真题讲解", lab + "阅读真题 讲解"), ("阅读技巧", lab + "阅读 技巧 方法"),
                    ("选词填空", lab + "选词填空 技巧"), ("长篇阅读/匹配题", lab + "长篇阅读 匹配题 技巧"),
                    ("英文原著精读", "英文原著 精读 讲解")],
        "writing": [("作文模板", lab + "作文 模板 万能句型"), ("历年真题范文", lab + "作文 历年真题 范文"),
                    ("提分技巧", lab + "写作 提分 技巧"), ("高分范文精讲", lab + "作文 高分范文 讲解")],
        "translation": [("翻译真题", lab + "翻译 历年真题 讲解"), ("翻译技巧", lab + "翻译 技巧 方法"),
                        ("中国文化主题词", lab + "翻译 中国文化 高频词"),
                        ("每日一练", lab + "翻译 每日一练")],
    }
    out = []
    for label, kw in table.get(module, []):
        out.append({"key": module + "-" + str(len(out) + 1), "label": label, "keyword": kw})
    return out


def api_cet(ctx, payload: dict | None = None) -> dict:
    """读 / 切 备考级别（四级 / 六级）。"""
    if payload is None:
        lv = cet_level(ctx)
        return {"ok": True, "level": lv, "label": _cet_label(ctx),
                "labels": {"cet4": "四级", "cet6": "六级"}}
    action = str(payload.get("action") or "set")
    if action == "set":
        want = str(payload.get("level") or "").lower()
        if want not in ("cet4", "cet6"):
            return {"ok": False, "error": "级别只能是 cet4 或 cet6"}
        try:
            import json as _json
            from pathlib import Path as _P

            p = _P(ctx.cfg.home) / "config.json"
            data = _json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}
            data["cet_level"] = want
            p.write_text(_json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            return {"ok": False, "error": f"存不下来：{exc.__class__.__name__}"}
        try:
            ctx.cfg.cet_level = want
        except Exception:
            pass
        return {"ok": True, "level": want, "label": "四级" if want == "cet4" else "六级",
                "note": f"已切到{('四级' if want == 'cet4' else '六级')}备考"}


def api_listening(ctx, payload: dict | None = None, query: dict | None = None) -> dict:
    """听力：清单 / 新增 / 导入资源 / 挂真题 / 字幕 / 打勾 / 删。"""
    from . import listening as listen_mod

    if not _DATA_HOME:
        _DATA_HOME.append(ctx.cfg.home)

    if payload is None:
        kind = str((query or {}).get("kind") or "")
        return {"ok": True, "items": ctx.store.listening(kind),
                "stats": ctx.store.listen_stats(),
                "papers": listen_mod.real_papers(cet_level(ctx)),
                "presets": _listen_presets(ctx),
                "labels": {k: listen_mod.kind_label(k)
                           for k in ("real", "intensive", "loop")}}

    action = str(payload.get("action") or "add")

    if action == "add":
        raw = str(payload.get("path") or "")
        if raw.strip():
            got = listen_mod.describe_source(raw)
            if not got.get("ok"):
                return got
            title = str(payload.get("title") or got.get("title") or "")
            path = str(got.get("url") or got.get("path") or "")
        else:
            title = str(payload.get("title") or "").strip()
            if not title:
                return {"ok": False, "error": "给个标题，或者粘一个音频路径 / B 站链接"}
            path = ""
        row = ctx.store.listen_add(str(payload.get("kind") or "intensive"), title,
                                   path, str(payload.get("paper_key") or ""),
                                   str(payload.get("transcript") or ""),
                                   str(payload.get("note") or ""))
        return {"ok": True, **row, "items": ctx.store.listening(),
                "stats": ctx.store.listen_stats()}
    if action == "attach_papers":
        return _listen_attach_papers(ctx, int(payload.get("limit") or 1))
    if action == "import_search":
        return _listen_import_search(ctx, str(payload.get("keyword") or ""),
                                     str(payload.get("kind") or "loop"),
                                     int(payload.get("limit") or 8))
    if action == "import_presets":
        _presets = _listen_presets(ctx)
        keys = payload.get("keys") or [p["key"] for p in _presets]
        total = 0
        detail = []
        for pre in _presets:
            if pre["key"] not in keys:
                continue
            got = _listen_import_search(ctx, pre["keyword"], pre["kind"],
                                        int(payload.get("limit") or 6))
            if got.get("ok"):
                total += int(got.get("added") or 0)
                detail.append(f"{pre['label']}+{got.get('added')}")
            else:
                detail.append(f"{pre['label']}✗")
        return {"ok": True, "added": total, "detail": detail,
                "items": ctx.store.listening(), "stats": ctx.store.listen_stats(),
                "note": "导入完成：" + "、".join(detail)}
    if action == "subtitle":
        return _subtitle_start(ctx, int(payload.get("id") or 0))
    if action == "subtitle_status":
        return _subtitle_status(ctx, int(payload.get("id") or 0))
    if action == "transcript":
        ok = ctx.store.listen_update(int(payload.get("id") or 0),
                                     transcript=str(payload.get("transcript") or ""))
        return {"ok": ok, "error": "" if ok else "存不下来",
                "items": ctx.store.listening(), "stats": ctx.store.listen_stats()}
    if action == "done":
        ok = ctx.store.listen_update(int(payload.get("id") or 0),
                                     done=1 if payload.get("done") else 0)
        return {"ok": ok, "items": ctx.store.listening(),
                "stats": ctx.store.listen_stats()}
    if action == "played":
        ctx.store.listen_played(int(payload.get("id") or 0))
        return {"ok": True, "items": ctx.store.listening(),
                "stats": ctx.store.listen_stats()}
    if action == "delete":
        return {"ok": ctx.store.listen_delete(int(payload.get("id") or 0)),
                "items": ctx.store.listening(), "stats": ctx.store.listen_stats()}
    return {"ok": False, "error": f"不认识的动作：{action}"}


def _practice_import_search(ctx, module: str, keyword: str, limit: int = 5) -> dict:
    """阅读/作文/翻译：用 B 站搜索给这个模块导资源。"""
    from . import search as _search_mod

    kw = str(keyword or "").strip()
    if not kw:
        return {"ok": False, "error": "没给搜索词"}
    try:
        outcome = _search_mod.search_online_cached(kw, page=1)
    except Exception as exc:
        return {"ok": False, "error": f"搜索失败（{exc.__class__.__name__}）—— 检查网络"}
    rows = _search_rows(outcome)
    if not rows:
        return {"ok": False, "error": "B 站没返回结果（换个关键词，或等几分钟再试）"}
    added = skipped = 0
    for row in rows[:max(1, min(15, int(limit)))]:
        url = _search_pick(row, "url", "link", "href", "arcurl")
        bvid = _search_pick(row, "bvid", "bv")
        if not url and bvid:
            url = "https://www.bilibili.com/video/" + bvid
        title = _search_pick(row, "title", "name") or url
        if not url:
            skipped += 1
            continue
        got = ctx.store.practice_add(module, title[:120], url, kw[:200])
        if got.get("duplicated"):
            skipped += 1
        else:
            added += 1
    return {"ok": True, "added": added, "skipped": skipped, "keyword": kw,
            "items": ctx.store.practices(module),
            "note": f"「{kw}」导入了 {added} 条" + (f"，跳过重复 {skipped} 条" if skipped else "")}


def api_practice(ctx, payload: dict | None = None, query: dict | None = None) -> dict:
    """阅读 / 作文 / 翻译：资源清单 + 一键导入。"""
    if payload is None:
        module = str((query or {}).get("module") or "reading")
        return {"ok": True, "module": module,
                "label": PRACTICE_LABELS.get(module, module),
                "presets": _practice_presets(ctx, module),
                "items": ctx.store.practices(module),
                "all": ctx.store.practice_stats()}

    action = str(payload.get("action") or "add")
    module = str(payload.get("module") or "reading")
    if action == "import_search":
        return _practice_import_search(ctx, module, str(payload.get("keyword") or ""),
                                       int(payload.get("limit") or 5))
    if action == "import_preset":
        pre = None
        for p in _practice_presets(ctx, module):
            if p["key"] == str(payload.get("key") or "") or p["label"] == str(payload.get("label") or ""):
                pre = p
                break
        if pre is None:
            # 前端可能传的是关键词（菜单项直接带 keyword）
            kw = str(payload.get("keyword") or "")
            if kw:
                return _practice_import_search(ctx, module, kw, int(payload.get("limit") or 4))
            return {"ok": False, "error": "不认识的主题"}
        return _practice_import_search(ctx, module, pre["keyword"],
                                       int(payload.get("limit") or 4))
    if action == "add":
        title = str(payload.get("title") or "").strip()
        url = str(payload.get("url") or "").strip()
        if not title and not url:
            return {"ok": False, "error": "给个标题或链接"}
        got = ctx.store.practice_add(module, title or url, url,
                                     str(payload.get("note") or ""))
        return {"ok": True, **got, "items": ctx.store.practices(module)}
    if action == "done":
        ok = ctx.store.practice_update(int(payload.get("id") or 0),
                                       done=1 if payload.get("done") else 0)
        return {"ok": ok, "items": ctx.store.practices(module)}
    if action == "delete":
        return {"ok": ctx.store.practice_delete(int(payload.get("id") or 0)),
                "items": ctx.store.practices(module)}
    return {"ok": False, "error": f"不认识的动作：{action}"}


def _link_title(ctx, kind: str, oid: int) -> str:
    """把一个 (kind, id) 解析成标题（找不到返回空）。"""
    try:
        if kind == "problem":
            row = ctx.store.get(int(oid))
            return str(getattr(row, "title", "") or "")
        if kind == "material":
            row = ctx.store.material_get(int(oid))
            return str(dict(row).get("title") or "") if row is not None else ""
        if kind == "listening":
            row = ctx.store.listen_get(int(oid))
            return str(dict(row).get("title") or "") if row is not None else ""
    except Exception:
        return ""
    return ""


def _link_exists(ctx, kind: str, oid: int) -> bool:
    return bool(_link_title(ctx, kind, oid))


def _links_of(ctx, kind: str, oid: int) -> list:
    """一个对象的全部关联，**两个方向都查**，并把对面标题解析好。"""
    out = []
    for row in (ctx.store.links_of(kind, oid) if oid else []):
        if str(row["from_kind"]) == kind and int(row["from_id"]) == oid:
            other_kind, other_id = str(row["to_kind"]), int(row["to_id"])
        else:
            other_kind, other_id = str(row["from_kind"]), int(row["from_id"])
        out.append({"id": row["id"], "kind": other_kind, "ref_id": other_id,
                    "title": _link_title(ctx, other_kind, other_id),
                    "note": row.get("note") or ""})
    return out


def api_links(ctx, payload: dict | None = None, query: dict | None = None) -> dict:
    """资料 ↔ 题目 互链（一条记录就是双向的）。"""
    if payload is None:
        kind = str((query or {}).get("kind") or "problem")
        oid = int(str((query or {}).get("id") or 0))
        return {"ok": True, "kind": kind, "id": oid, "items": _links_of(ctx, kind, oid)}

    action = str(payload.get("action") or "add")
    fk = str(payload.get("from_kind") or "problem")
    fi = int(payload.get("from_id") or 0)
    tk = str(payload.get("to_kind") or "material")
    ti = int(payload.get("to_id") or 0)

    if action == "delete":
        return {"ok": ctx.store.link_delete(int(payload.get("id") or 0))}
    if action == "candidates":
        if tk == "material":
            rows = ctx.store.materials("")[:60]
            return {"ok": True, "items": [{"id": x["id"], "title": x["title"]}
                                          for x in rows]}
        if tk == "problem":
            rows = ctx.store.all()[:200]
            return {"ok": True, "items": [{"id": x.id, "title": x.title} for x in rows]}
        return {"ok": True, "items": []}
    if action == "add":
        if not fi or not ti:
            return {"ok": False, "error": "两边都要给 id"}
        if not _link_exists(ctx, fk, fi):
            return {"ok": False, "error": f"找不到这一边（{fk} {fi}）"}
        if not _link_exists(ctx, tk, ti):
            return {"ok": False, "error": f"找不到那一边（{tk} {ti}）"}
        got = ctx.store.link_add(fk, fi, tk, ti, str(payload.get("note") or ""))
        return {"ok": True, **got,
                "note": "已经在关联里了" if got.get("duplicated") else "关联上了",
                "items": _links_of(ctx, fk, fi)}
    return {"ok": False, "error": f"不认识的动作：{action}"}


ATTACH_DIRNAME = "附件"
ATTACH_MAX_MB = 8
ATTACH_TYPES = {
    "image/png": ".png", "image/jpeg": ".jpg", "image/jpg": ".jpg",
    "image/gif": ".gif", "image/webp": ".webp", "image/bmp": ".bmp",
}


def _attach_dir(ctx):
    from pathlib import Path as _P

    d = _P(ctx.cfg.home) / ATTACH_DIRNAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def _attach_public(items) -> list:
    """对外只给元信息，**不给磁盘路径**。"""
    return [{k: v for k, v in x.items() if k != "path"} for x in items]


def api_attachments(ctx, payload: dict | None = None, query: dict | None = None) -> dict:
    """题目附件（贴图）：列表 / 贴一张 / 从本地文件贴 / 删。"""
    import base64
    import hashlib
    from pathlib import Path as _P2

    if payload is None:
        pid = int(str((query or {}).get("problem_id") or 0))
        return {"ok": True,
                "items": _attach_public(ctx.store.attachments(pid)) if pid else []}

    action = str(payload.get("action") or "add")
    pid = int(payload.get("problem_id") or 0)

    if action == "add":
        if not pid:
            return {"ok": False, "error": "没给题目 id"}
        raw = str(payload.get("data_url") or "")
        if not raw.startswith("data:"):
            return {"ok": False, "error": "只收 data URL（前端把图片转好再发）"}
        try:
            head, b64 = raw.split(",", 1)
            mime = head[5:].split(";")[0].lower()
        except ValueError:
            return {"ok": False, "error": "data URL 格式不对"}
        ext = ATTACH_TYPES.get(mime)
        if ext is None:
            return {"ok": False,
                    "error": "这个类型（" + mime + "）不收；支持 png / jpg / gif / webp / bmp"}
        try:
            data = base64.b64decode(b64, validate=False)
        except Exception:
            return {"ok": False, "error": "图片数据解不开"}
        mb = len(data) / 1024 / 1024
        if mb > ATTACH_MAX_MB:
            return {"ok": False, "error": f"这张图 {mb:.1f} MB，超过 {ATTACH_MAX_MB} MB 上限"}
        if len(data) < 64:
            return {"ok": False, "error": "这张图太小了（可能是空的）"}
        digest = hashlib.md5(data).hexdigest()[:16]
        target = _attach_dir(ctx) / (digest + ext)
        if not target.is_file():
            target.write_bytes(data)
        got = ctx.store.attach_add(pid, str(payload.get("name") or "贴图")[:120],
                                   str(target), len(data))
        return {"ok": True, **got, "note": f"贴上了（{mb:.1f} MB）",
                "items": _attach_public(ctx.store.attachments(pid))}

    if action == "from_path":
        from pathlib import Path as _P3

        p = _P3(str(payload.get("path") or "").strip().strip('"'))
        if not pid:
            return {"ok": False, "error": "没给题目 id"}
        if not p.is_absolute():
            return {"ok": False, "error": "请写完整路径（如 D:\\图片\\题目.png）"}
        if not p.is_file():
            return {"ok": False, "error": f"找不到这个文件：{p}"}
        ext = p.suffix.lower()
        if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"):
            return {"ok": False, "error": "只收图片文件（png/jpg/gif/webp/bmp）"}
        try:
            data = p.read_bytes()
        except OSError as exc:
            return {"ok": False, "error": f"读不了：{exc.__class__.__name__}"}
        mb = len(data) / 1024 / 1024
        if mb > ATTACH_MAX_MB:
            return {"ok": False, "error": f"这个文件 {mb:.1f} MB，超过上限"}
        digest = hashlib.md5(data).hexdigest()[:16]
        target = _attach_dir(ctx) / (digest + (".jpg" if ext == ".jpeg" else ext))
        if not target.is_file():
            target.write_bytes(data)
        got = ctx.store.attach_add(pid, p.stem[:120], str(target), len(data))
        return {"ok": True, **got, "note": "贴上了：" + p.name,
                "items": _attach_public(ctx.store.attachments(pid))}

    if action == "delete":
        ok = ctx.store.attach_delete(int(payload.get("id") or 0))
        return {"ok": ok, "items": _attach_public(ctx.store.attachments(pid))}

    return {"ok": False, "error": "不认识的动作：" + action}


def api_attachment_image(ctx, aid: int) -> dict:
    """取一张附图（base64 data URL）。不直出二进制 —— 那层约定不猜。"""
    import base64
    import mimetypes
    from pathlib import Path as _P4

    row = ctx.store.attachment_get(int(aid))
    if row is None:
        return {"ok": False, "error": "没有这张图"}
    d = dict(row)
    p = _P4(str(d.get("path") or ""))
    if not p.is_file():
        return {"ok": False, "error": "图片文件不在了（可能被删）"}
    try:
        data = p.read_bytes()
    except OSError:
        return {"ok": False, "error": "读不了这张图"}
    mime = mimetypes.guess_type(p.name)[0] or "image/png"
    return {"ok": True, "name": d.get("name") or p.name,
            "data_url": "data:" + mime + ";base64," + base64.b64encode(data).decode("ascii")}

# 恢复区需要的模块级状态（原来在被切掉的那段里 ✗）
# 函数是**运行时**才读这些名字，所以放在文件末尾定义也安全 ✓
_LISTEN_CLIENT = None
_LISTEN_TASKS: dict = {}
_DATA_HOME: list = []
