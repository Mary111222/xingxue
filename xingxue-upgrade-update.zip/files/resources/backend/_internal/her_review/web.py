"""启动图形界面（供启动器调用，也支持 python -m her_review.web）。

用法：
    python -m her_review.web              # 用默认数据目录，自动开浏览器
    python -m her_review.web --port 4000  # 指定端口
    python -m her_review.web --no-open    # 不自动开浏览器
"""

from __future__ import annotations

import argparse
import sys
import threading
from pathlib import Path


def _activate_local_libs() -> None:
    """把程序目录下的 .pylibs 加进 sys.path。

    为什么界面入口也必须做这一步：
        .pylibs 原来只在 `python -m her_review` 的入口（__main__.py）里激活，
        而界面走的是 `python -m her_review.web` —— 于是双击启动时
        增强库一个都没生效：搜索不走 httpx、没有缓存，
        但"环境自检"页又会把没生效的库报成"不可用"，看着像装坏了。
        两个入口都要激活，口径才一致。

    刻意不 import 包内任何模块：走最小依赖路径，
    哪怕 her_review 里别的文件坏了，这一步也不该受影响。
    """
    try:
        target = Path(__file__).resolve().parent.parent / ".pylibs"
        if target.is_dir():
            entry = str(target)
            if entry not in sys.path:
                sys.path.insert(0, entry)
    except Exception:
        pass


_activate_local_libs()

# **全局启用 IPv4 优先**：这台机器的 IPv6 连不通，
# 不走这一步的话每个外网请求都要先等 IPv6 超时（实测 20~30 秒 vs 0.3 秒）。
# 放在入口是为了覆盖站点体检、封面抓取、B 站接口……所有网络请求。
from .net import prefer_ipv4

prefer_ipv4()
from . import ui, web_server  # noqa: E402



def _daily_backup(home) -> None:
    """每天首次启动自动备份一份。

    放在**后台线程**里跑：备份要压 zip，不能拖慢启动 ——
    她的要求是"双击到能用"在一秒上下。
    备份失败**不能影响启动**，所以整段吞掉异常。
    """
    try:
        from . import backup

        got = backup.maybe_daily(Path(home))
        if got and got.get("ok"):
            print("  [备份] 今天已自动备份：" + str(got.get("name")))
    except Exception:
        pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="xingxue-web", description="形学 · 图形界面（普通浏览器窗口）")
    parser.add_argument("--home", type=Path, default=None,
                        help="数据目录（默认读 her.local.json）")
    parser.add_argument("--port", type=int, default=None, help="端口（被占用会自动换）")
    parser.add_argument("--no-open", action="store_true", help="不要自动打开浏览器")
    parser.add_argument("--today", default=None, help="把今天假定成某一天（YYYY-MM-DD）")
    parser.add_argument("--quiet", action="store_true", help="不打印启动横幅")
    args = parser.parse_args(argv)

    # 每天首次启动自动备份一份（后台线程；失败也不影响启动）
    threading.Thread(target=_daily_backup, args=(args.home,), daemon=True).start()

    # Windows 控制台默认不是 UTF-8，中文横幅会变乱码
    ui.configure_stdio()

    today = None
    if args.today:
        from . import gem

        today = gem.parse_date(args.today)
        if today is None:
            print(f"日期看不懂：{args.today}")
            return 2

    try:
        web_server.serve(args.home, port=args.port, open_browser=not args.no_open,
                         today=today, quiet=args.quiet)
    except RuntimeError as exc:
        print(f"\n  启动失败：{exc}\n")
        return 1
    except OSError as exc:
        print(f"\n  端口被占用或没有权限：{exc}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
