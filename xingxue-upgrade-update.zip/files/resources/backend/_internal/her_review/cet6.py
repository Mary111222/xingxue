"""六级备考（CET-6）。

考试信息来自官方通知（2026 年下半年全国大学英语四、六级考试报名工作启动）：
    - 笔试：**2026 年 12 月 12 日 15:00-17:25**（六级）
    - 口试：2026 年 11 月 21-22 日
    - 报名：CET 全国网上报名系统 cet-bm.neea.edu.cn
    - 准考证：笔试 12 月 1 日 9 时起可打印
    - 不提供纸质成绩单，电子成绩报告单在中国教育考试网下载

设计上刻意做了三件"诚实"的事，因为这个模块最容易变成假资料合集：

    1. **不硬编 B 站视频链接**。视频会被下架、UP 主会改名，
       写死的链接过几个月就是一堆 404。这里存的是**搜索词**——
       搜索永远有效，而且能搜到最新最好的那个视频。
       真正的直链由 `resolve_videos()` 在联网时解析出来。
    2. **真题只收录能确证的题型与公开考点**（写作题目、翻译主题、
       高频词），不编造"某年真题原文"——编出来的东西她会当成真的去背。
       要完整历年套卷，给的是可核验的公开渠道。
    3. **词汇表标了来源**（四六级考试大纲词汇），不假装是"内部押题"。

和程序其它部分的衔接：
    单词、写作模板、翻译表达都是**适合间隔重复**的材料，
    可以用 `import_problems()` 直接灌进题库，和算法题一起复习——
    这是这个模块真正的价值：她已经在用这套系统背题了，加进来就能背单词。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

# 官方考试日期（2026 年下半年）
EXAM_DATE = date(2026, 12, 12)
EXAM_TIME = "15:00-17:25"
SPEAKING_DATES = "11 月 21-22 日"
REGISTER_URL = "https://cet-bm.neea.edu.cn/"
RESULT_URL = "https://www.neea.edu.cn/"
# 报名与准考证的时间点（来自同一份官方通知）
REGISTER_NOTE = "报名、缴费、打印准考证都在 cet-bm.neea.edu.cn（12 月 1 日 9 时起可打印笔试准考证）"
TICKET_DATE = date(2026, 12, 1)

# 六级笔试卷面结构（总分 710，425 分通过）
SECTIONS: list[dict] = [
    {
        "name": "写作",
        "ratio": "15%",
        "score": 106.5,
        "minutes": 30,
        "order": "第一步（先写作文，写完才发听力卷）",
        "tips": [
            "背 3 个万能框架就够：现象分析 / 观点对比 / 图表描述——历年题目基本都落在这三类",
            "开头第一句要长且没语法错，阅卷老师看的就是前两句",
            "字数 150-200，写到 160-180 最稳；少了扣分，多了容易出错",
        ],
    },
    {
        "name": "听力",
        "ratio": "35%",
        "score": 248.5,
        "minutes": 30,
        "order": "第二步（含长对话 8 题 + 篇章 7 题 + 讲座 10 题）",
        "tips": [
            "讲座题（占比最高）念的是学术语速，靠的是**预读选项**猜话题，不是听清每个词",
            "听到与选项同义替换的词就是答案位置，原词照搬的往往是干扰项",
            "不会的题立刻放过，纠结一道会丢后面三道",
        ],
    },
    {
        "name": "阅读",
        "ratio": "35%",
        "score": 248.5,
        "minutes": 40,
        "order": "第三步（选词填空 10 题 + 长篇匹配 10 题 + 仔细阅读 10 题）",
        "tips": [
            "**先做仔细阅读**（分值最高），再做长篇匹配，选词填空放最后（最难且最不值）",
            "选词填空先按词性把 15 个词分类，再按空位语法需求挑——比按意思猜准得多",
            "长篇匹配找数字、大写专有名词、极端词，这些最好定位",
        ],
    },
    {
        "name": "翻译",
        "ratio": "15%",
        "score": 106.5,
        "minutes": 30,
        "order": "第四步（汉译英段落，主题多为中国文化 / 社会发展）",
        "tips": [
            "宁可写简单句写对，不要写复杂句写错——语法错了直接降档",
            "不会的词用解释法绕过去（「丝绸之路」不会写就 the ancient road between China and the West）",
            "常考主题词要提前背：传统文化、经济发展、科技创新、教育公平",
        ],
    },
]

# 知识板块：每个板块的复习重点与常见坑
TOPICS: list[dict] = [
    {
        "key": "vocab",
        "name": "词汇",
        "weight": "地基，直接影响其它四项",
        "points": [
            "六级核心词汇约 5500 词，其中**高频 1500 词**覆盖真题绝大多数考点",
            "优先背动词和形容词：它们决定你能不能读懂长难句",
            "熟词僻义比生词更容易丢分（如 address 除了「地址」还有「处理/演讲」）",
            "词根词缀能救命，但只对认词有用，写作时别硬造",
        ],
        "mistakes": [
            "只背单词书不做真题 → 认识的词放到句子里还是读不懂",
            "从 A 背到 Z → 永远停在 abandon",
            "只看中文意思，不看例句搭配 → 写作时用不出来",
        ],
    },
    {
        "key": "listening",
        "name": "听力",
        "weight": "35%，最容易短期提分",
        "points": [
            "讲座（Lecture）占 10 题，是分值大头，必须专门练",
            "同义替换是命题核心：选项很少照抄原文",
            "信号词后面常出答案：however / in fact / the key point is / research shows",
        ],
        "mistakes": [
            "试图听懂每个词 → 跟不上语速",
            "不做预读直接听 → 不知道要抓什么",
            "错了就重听一遍原速 → 应该对照原文精听",
        ],
    },
    {
        "key": "reading",
        "name": "阅读",
        "weight": "35%，时间最紧",
        "points": [
            "仔细阅读：题干关键词回原文定位，答案一般在定位句本身或下一句",
            "长篇匹配：先扫题干里的专有名词和数字，再回文章找",
            "选词填空：先判词性，再判单复数/时态，最后才是意思",
        ],
        "mistakes": [
            "按顺序做 → 选词填空耗掉 15 分钟，仔细阅读没时间",
            "凭印象选 → 六级阅读的干扰项都「读起来很对」",
            "过度推理 → 答案一定能在原文找到依据",
        ],
    },
    {
        "key": "writing",
        "name": "写作",
        "weight": "15%，投入产出比最高",
        "points": [
            "背 3 个框架 + 10 个高级句式，够应付所有题目",
            "连接词要显式（Firstly / Moreover / In conclusion），阅卷是按点给分",
            "替换低级词：important → crucial，think → hold the view that",
        ],
        "mistakes": [
            "临场构思 → 考场只有 30 分钟，必须提前有模板",
            "堆砌长难句 → 错一处不如写对三句",
            "不检查单复数与主谓一致 → 这是最常见的扣分点",
        ],
    },
    {
        "key": "translation",
        "name": "翻译",
        "weight": "15%，主题集中",
        "points": [
            "历年主题高度集中在中国文化与社会发展，常考词要成组背",
            "长句拆成短句：中文一句话可能对应英文三句",
            "被动语态在说明性内容里更自然（was built / is regarded as）",
        ],
        "mistakes": [
            "逐字直译 → 中式英语",
            "遇到不会的词就空着 → 用解释法绕过去，写出来就有分",
            "忽略时态 → 讲历史用过去时，讲现状用现在时",
        ],
    },
]


# --------------------------------------------------------------------------
# B 站学习资源
# --------------------------------------------------------------------------

@dataclass
class VideoTopic:
    """一条备考视频条目。

    data 里刻意**只存搜索词**（query），不存具体视频链接：
    链接会失效，搜索词不会。联网时可以用 resolve() 解析出当前最好的几个视频。
    """
    key: str
    title: str
    query: str                  # B 站搜索词
    why: str                    # 这个要解决什么
    minutes: str = ""           # 建议单次投入时长
    kind: str = "system"        # system 系统课 / drill 专项 / skill 技巧 / vocab 词汇

    def search_url(self, template: str = "https://search.bilibili.com/all?keyword={q}") -> str:
        from urllib.parse import quote

        return template.replace("{q}", quote(self.query))


VIDEO_TOPICS: list[VideoTopic] = [
    VideoTopic(
        key="cet6-full",
        title="六级全程系统课",
        query="英语六级 全程班 系统课",
        why="从题型讲到技巧的完整一套。适合先过一遍建立全局观，别一上来就刷题。",
        minutes="每次 40-60 分钟",
        kind="system",
    ),
    VideoTopic(
        key="cet6-listening",
        title="六级听力专项（讲座题为主）",
        query="英语六级 听力 讲座 技巧",
        why="讲座占听力 10 题、是分值大头，也最难。这一项练好了听力就能上一个档。",
        minutes="每次 30 分钟 + 精听一篇",
        kind="drill",
    ),
    VideoTopic(
        key="cet6-reading",
        title="六级阅读技巧（仔细阅读 / 匹配 / 选词）",
        query="英语六级 阅读 技巧 仔细阅读",
        why="阅读 35% 且时间最紧。学的是「先做哪篇、怎么定位」，不是多读。",
        minutes="每次 40 分钟",
        kind="skill",
    ),
    VideoTopic(
        key="cet6-writing",
        title="六级作文模板与万能句式",
        query="英语六级 作文 模板 万能句型",
        why="写作投入产出比最高：背 3 个框架 + 10 个句式，30 分钟就能用上。",
        minutes="每次 30 分钟，背完就默写一遍",
        kind="skill",
    ),
    VideoTopic(
        key="cet6-translation",
        title="六级翻译常考主题（中国文化 / 社会发展）",
        query="英语六级 翻译 技巧 中国文化",
        why="翻译主题高度集中，把常考词成组背下来，考场直接能用。",
        minutes="每次 30 分钟",
        kind="skill",
    ),
    VideoTopic(
        key="cet6-vocab",
        title="六级高频词汇（1500 词 / 词根词缀）",
        query="英语六级 高频词汇 1500 词根词缀",
        why="词汇是所有题型的地基。跟一套讲词根词缀的，比干背单词书效率高。",
        minutes="每天 20-30 分钟，配合本程序的复习队列",
        kind="vocab",
    ),
    VideoTopic(
        key="cet6-past",
        title="历年真题逐套精讲（2023-2026）",
        query="英语六级 真题 精讲 2025",
        why="真题是最好的模拟卷。听讲解比自己闷头做更能发现错因。",
        minutes="每周一套，做完立刻看讲解",
        kind="drill",
    ),
    VideoTopic(
        key="cet6-grammar",
        title="六级语法补漏（长难句 / 从句 / 非谓语）",
        query="英语六级 语法 长难句 分析",
        why="阅读读不懂、翻译写不出，很多时候不是词汇量问题，是句子结构拆不开。",
        minutes="每次 25 分钟",
        kind="skill",
    ),
    VideoTopic(
        key="cet6-plan",
        title="六级 3 个月备考规划",
        query="英语六级 备考规划 三个月 时间安排",
        why="先看别人怎么排时间，再按自己的课表改一版——比想到哪学到哪强。",
        minutes="看一次，然后写自己的计划",
        kind="system",
    ),
    VideoTopic(
        key="cet6-paper",
        title="六级考场流程与答题顺序",
        query="英语六级 考试流程 答题顺序 时间分配",
        why="考场是先写作文再听力、答题卡要收两次。提前知道流程能少慌一半。",
        minutes="看一次即可",
        kind="skill",
    ),
]


# --------------------------------------------------------------------------
# 真题备考材料（公开题型 / 公开考点，非逐字真题）
# --------------------------------------------------------------------------

@dataclass
class Item:
    """一条备考题目。可以直接灌进题库做间隔重复。"""
    kind: str           # writing / translation / vocab / listening / reading
    prompt: str         # 题目或词条
    answer: str         # 参考思路 / 释义
    note: str = ""      # 关键点（会写进题库的 note）
    tags: list[str] = field(default_factory=list)
    source: str = ""


# 写作：历年真题的**题型**（六级的作文题目类型高度稳定，这三类覆盖绝大多数）
WRITING_FRAMES: list[dict] = [
    {
        "name": "现象分析型",
        "pattern": "开头描述现象 → 分析原因（2-3 条）→ 给出建议/展望",
        "openers": [
            "In recent years, there has been a growing concern over ...",
            "It is widely acknowledged that ... has become increasingly common among college students.",
            "Nowadays, ... has sparked heated discussion on campus.",
        ],
        "body": [
            "Several factors can account for this phenomenon. To begin with, ...",
            "What's more, ... plays an equally important role.",
            "Another contributing factor is that ...",
        ],
        "closers": [
            "In light of the above, it is high time that we took effective measures to ...",
            "Only by doing so can we ... in the long run.",
        ],
        "sample_prompt": "Directions: Write an essay on the impact of short videos on college students' study habits.",
    },
    {
        "name": "观点对比型",
        "pattern": "引出争议 → 一方观点 → 另一方观点 → 我的立场（重要：必须有明确立场）",
        "openers": [
            "When it comes to ..., opinions vary from person to person.",
            "There is a heated debate over whether ...",
        ],
        "body": [
            "Those who advocate ... argue that ...",
            "Nevertheless, others hold the opposite view, maintaining that ...",
            "From my perspective, the former/latter view is more reasonable, because ...",
        ],
        "closers": [
            "Taking all these factors into consideration, we may reasonably draw the conclusion that ...",
        ],
        "sample_prompt": "Directions: Some students prefer online courses while others favor traditional classrooms. What is your opinion?",
    },
    {
        "name": "图表/引言型",
        "pattern": "描述图表或引用原句 → 解释含义 → 举例论证 → 总结",
        "openers": [
            "As is vividly depicted in the chart, ... witnessed a remarkable change.",
            "The saying \"...\" reminds us that ...",
        ],
        "body": [
            "This trend can be attributed to ...",
            "A case in point is that ...",
        ],
        "closers": [
            "In conclusion, the chart/saying conveys a simple yet profound truth: ...",
        ],
        "sample_prompt": "Directions: Write an essay based on the saying \"Well begun is half done.\"",
    },
]

# 翻译：历年常考主题与对应表达（这些是公开的高频考点，可以放心背）
TRANSLATION_TOPICS: list[dict] = [
    {
        "name": "传统文化",
        "words": [
            ("四大发明", "the four great inventions of ancient China"),
            ("丝绸之路", "the Silk Road"),
            ("儒家思想", "Confucianism"),
            ("书法", "calligraphy"),
            ("剪纸", "paper-cutting"),
            ("京剧", "Peking Opera"),
            ("二十四节气", "the 24 solar terms"),
            ("中秋节", "the Mid-Autumn Festival"),
            ("团圆", "reunion"),
            ("传承", "pass down / inherit"),
        ],
        "patterns": [
            "……已有两千多年历史 → ... dates back more than 2,000 years",
            "……被联合国列为世界文化遗产 → ... was listed as a UNESCO World Cultural Heritage site",
            "……象征着…… → ... symbolizes ...",
        ],
    },
    {
        "name": "经济社会发展",
        "words": [
            ("改革开放", "the reform and opening-up policy"),
            ("脱贫攻坚", "poverty alleviation"),
            ("城镇化", "urbanization"),
            ("高铁", "high-speed rail"),
            ("电子商务", "e-commerce"),
            ("移动支付", "mobile payment"),
            ("共同富裕", "common prosperity"),
            ("可持续发展", "sustainable development"),
        ],
        "patterns": [
            "随着……的发展 → With the development of ...",
            "……取得了显著进步 → ... has made remarkable progress",
            "……极大地改变了人们的生活 → ... has greatly changed people's lives",
        ],
    },
    {
        "name": "科技创新",
        "words": [
            ("人工智能", "artificial intelligence"),
            ("航天事业", "the space industry"),
            ("量子计算", "quantum computing"),
            ("5G 技术", "5G technology"),
            ("创新驱动", "innovation-driven"),
            ("自主研发", "independent research and development"),
        ],
        "patterns": [
            "……走在世界前列 → ... ranks among the world's leaders in ...",
            "……被广泛应用于…… → ... is widely applied in ...",
        ],
    },
    {
        "name": "教育与社会",
        "words": [
            ("义务教育", "compulsory education"),
            ("素质教育", "quality-oriented education"),
            ("终身学习", "lifelong learning"),
            ("志愿者", "volunteer"),
            ("老龄化", "aging population"),
            ("社会保障", "social security"),
        ],
        "patterns": [
            "越来越多人意识到…… → An increasing number of people are aware that ...",
            "……对……至关重要 → ... is of vital importance to ...",
        ],
    },
]

# 高频词汇：带**词根/搭配**的精讲版（不是干巴巴的单词表）
# 选词标准：六级真题里反复出现、且容易"认得但用不出"的词
KEY_VOCAB: list[tuple[str, str, str]] = [
    ("address", "v. 处理，解决；演讲　n. 地址",
     "熟词僻义典型。真题里 address the issue（解决问题）出现频率远高于「地址」。"),
    ("appreciate", "v. 感激；理解，意识到；增值",
     "除「感激」外还有 appreciate the difference（意识到差别），阅读里常考。"),
    ("approach", "n. 方法，途径　v. 接近；着手处理",
     "a new approach to doing sth（注意 to 后面是 doing），写作万能词。"),
    ("assume", "v. 假定，认为；承担（责任）",
     "assume responsibility（承担责任）是翻译高频。"),
    ("attribute", "v. 把……归因于（to）　n. 属性",
     "attribute A to B 是因果类阅读的核心动词。"),
    ("capacity", "n. 能力；容量；职位",
     "the capacity to do sth；与 ability 的区别是它更强调「承载力」。"),
    ("commit", "v. 承诺；犯（错/罪）；投入",
     "be committed to doing（致力于），to 是介词。"),
    ("compensate", "v. 补偿，弥补（for）",
     "compensate for the loss，翻译里表「弥补」就用它。"),
    ("comprehensive", "adj. 全面的，综合的",
     "a comprehensive reform（综合改革），写作高级替换 overall。"),
    ("consequence", "n. 结果，后果",
     "as a consequence of；注意它偏「不好的结果」，好事用 result。"),
    ("considerable", "adj. 相当大的",
     "与 considerate（体贴的）只差一个字母，是经典易混。"),
    ("contribute", "v. 贡献；促成（to）；投稿",
     "contribute to 既可以接好事也可以接坏事（导致），看语境。"),
    ("crucial", "adj. 至关重要的",
     "替换 important 的首选，比 significant 更常用在六级作文里。"),
    ("decline", "v./n. 下降；婉拒",
     "图表作文描述下降必用；decline an invitation 是「婉拒」。"),
    ("demonstrate", "v. 证明；演示；示威",
     "demonstrate that... 比 show that... 高级，作文可直接换。"),
    ("derive", "v. 获得（from）；起源于",
     "derive pleasure from reading（从阅读中获得乐趣）。"),
    ("distinguish", "v. 区分（between / from）",
     "distinguish A from B；distinguished（杰出的）是同根形容词。"),
    ("dominate", "v. 支配，主导",
     "科技类阅读高频，如 dominate the market。"),
    ("eliminate", "v. 消除，排除",
     "eliminate poverty（消除贫困），翻译高频。"),
    ("emphasize", "v. 强调",
     "写作里替掉 stress / highlight，注意名词是 emphasis（on）。"),
    ("enhance", "v. 提高，增强",
     "enhance efficiency / awareness，六级作文万能动词。"),
    ("essential", "adj. 必不可少的（to / for）",
     "be essential to，比 necessary 语气强。"),
    ("exaggerate", "v. 夸大",
     "阅读态度题里表示「作者认为某说法过头了」。"),
    ("facilitate", "v. 促进，使便利",
     "facilitate communication，正式文体常用。"),
    ("fluctuate", "v. 波动",
     "图表作文描述「有升有降」就用它，比 go up and down 专业。"),
    ("fundamental", "adj. 根本的，基础的",
     "a fundamental change；名词 fundamental（基本原理）。"),
    ("generate", "v. 产生，生成",
     "generate income / electricity，科技类高频。"),
    ("guarantee", "v./n. 保证",
     "guarantee 后面接 that 从句或名词，不能接 to do。"),
    ("implement", "v. 实施，执行",
     "implement a policy（实施政策），翻译高频。"),
    ("implication", "n. 影响，含义",
     "阅读题里 the implication of... 指「隐含的影响/意味」。"),
    ("inevitable", "adj. 不可避免的",
     "it is inevitable that...，作文万能句式。"),
    ("initiative", "n. 倡议；主动性",
     "take the initiative to do（主动做），名词也可指「新方案」。"),
    ("integrate", "v. 整合，融入（into / with）",
     "integrate A into B，社会类话题高频。"),
    ("maintain", "v. 维持；坚持认为",
     "maintain that... 在阅读里常表示「（作者）坚持认为」。"),
    ("negotiate", "v. 谈判，协商",
     "negotiate with sb about sth。"),
    ("obstacle", "n. 障碍",
     "overcome obstacles（克服障碍），写作加分词。"),
    ("perspective", "n. 视角，观点",
     "from the perspective of（从……角度），作文高级表达。"),
    ("phenomenon", "n. 现象（复数 phenomena）",
     "现象分析型作文的题眼，复数拼写常被考。"),
    ("priority", "n. 优先事项",
     "give priority to（优先考虑），翻译与作文通用。"),
    ("profound", "adj. 深远的，深刻的",
     "a profound impact（深远影响），比 big 高级得多。"),
    ("promote", "v. 促进；晋升；推销",
     "promote economic growth，一个词覆盖多个考点。"),
    ("reluctant", "adj. 不情愿的",
     "be reluctant to do，态度题关键词。"),
    ("reveal", "v. 揭示，显示",
     "研究类阅读高频：The study reveals that...。"),
    ("significant", "adj. 重要的；显著的",
     "图表作文说「显著变化」就用它，别用 obvious。"),
    ("substantial", "adj. 大量的；实质的",
     "a substantial increase，替换 big 的正式说法。"),
    ("sufficient", "adj. 充足的",
     "sufficient evidence；反义是 insufficient。"),
    ("sustain", "v. 维持；支撑；遭受",
     "sustainable development 就是从它来的。"),
    ("tackle", "v. 处理，解决",
     "tackle the problem，跟 address 同义可互换。"),
    ("transform", "v. 彻底改变",
     "比 change 强，transform A into B。"),
    ("undermine", "v. 削弱，损害",
     "undermine confidence，阅读里常表负面影响。"),
]


# --------------------------------------------------------------------------
# 查与用
# --------------------------------------------------------------------------

def days_left(today: date) -> int:
    return (EXAM_DATE - today).days


def progress(today: date, start: date | None = None) -> dict:
    """备考进度：还剩几天、已过百分比。

    start 默认按"考试前 100 天"算起，这样进度条有意义（不会一开始就 90%）。
    """
    left = days_left(today)
    begin = start or date(EXAM_DATE.year, EXAM_DATE.month, EXAM_DATE.day)
    if start is None:
        # 默认从考试前 100 天开始算
        from datetime import timedelta

        begin = EXAM_DATE - timedelta(days=100)
    total = max(1, (EXAM_DATE - begin).days)
    done = max(0, min(total, (today - begin).days))
    return {
        "days_left": left,
        "started": today >= begin,
        "percent": round(done / total * 100),
        "begin": begin.isoformat(),
        "exam": EXAM_DATE.isoformat(),
        "passed": left < 0,
    }


def urgency(today: date) -> tuple[str, str]:
    """给一句符合当前阶段的建议：(级别, 话)。

    不同阶段该干的事不一样——剩三个月和剩一周，策略完全不同。
    直接说"加油"没有意义。
    """
    left = days_left(today)
    if left < 0:
        return "done", "考试已经过去了。成绩出来记得回来更新一下。"
    if left == 0:
        return "today", "就是今天。证件、耳机、2B 铅笔、黑色签字笔——都带齐了吗？"
    if left <= 7:
        return "sprint", "最后一周：别学新东西了，把真题错题过一遍，背熟作文框架。"
    if left <= 21:
        return "sprint", "剩三周：每周两套真题掐时间做，作文和翻译必须动笔写。"
    if left <= 45:
        return "steady", "一个多月：专项突破听力讲座和仔细阅读，这两项最拉分。"
    if left <= 90:
        return "steady", "还有两个多月：先背高频词，再上真题，别一开始就刷套卷。"
    return "early", "时间还宽裕：先把词汇和语法地基打牢，后面会轻松很多。"


def videos(kind: str = "") -> list[VideoTopic]:
    if not kind:
        return list(VIDEO_TOPICS)
    return [v for v in VIDEO_TOPICS if v.kind == kind]


def by_key(key: str) -> VideoTopic | None:
    for v in VIDEO_TOPICS:
        if v.key == key:
            return v
    return None


def resolve_videos(key: str, limit: int = 5) -> tuple[bool, list[dict], str]:
    """联网解析某个条目当前最好的几个 B 站视频。

    为什么不预先存链接：视频会下架、UP 主会改名。
    搜索出来的结果永远是最新的，写死的链接过几个月就是 404。
    """
    from . import search

    topic = by_key(key)
    if topic is None:
        return False, [], f"没有这个条目：{key}"
    outcome = search.search_online(topic.query)
    if not outcome.ok:
        return False, [], outcome.error or "搜索失败"
    out = []
    for v in outcome.videos[:limit]:
        out.append({
            "title": v.title, "author": v.author, "url": v.url,
            "duration": v.duration_text(), "play": v.play_text(),
            "bvid": v.bvid,
        })
    return True, out, ""


def vocab_items(limit: int = 0) -> list[Item]:
    """把高频词变成可以直接灌进题库的题目。"""
    items = []
    for word, meaning, note in (KEY_VOCAB if not limit else KEY_VOCAB[:limit]):
        items.append(Item(
            kind="vocab",
            prompt=f"{word}",
            answer=meaning,
            note=note,
            tags=["六级", "词汇"],
            source="六级核心词汇",
        ))
    return items


def writing_items() -> list[Item]:
    """写作框架变成题目（题型是固定的，背框架就能用）。"""
    items = []
    for frame in WRITING_FRAMES:
        body = "\n".join(
            ["【结构】" + frame["pattern"], "", "【开头可用】"]
            + ["· " + s for s in frame["openers"]]
            + ["", "【主体可用】"] + ["· " + s for s in frame["body"]]
            + ["", "【结尾可用】"] + ["· " + s for s in frame["closers"]]
        )
        items.append(Item(
            kind="writing",
            prompt=f"六级作文框架：{frame['name']}",
            answer=body,
            note=f"例：{frame['sample_prompt']}",
            tags=["六级", "写作"],
            source="六级写作题型（公开题型，非逐字真题）",
        ))
    return items


def translation_items() -> list[Item]:
    """翻译常考主题词变成题目。"""
    items = []
    for topic in TRANSLATION_TOPICS:
        words = "\n".join(f"· {cn} → {en}" for cn, en in topic["words"])
        patterns = "\n".join("· " + p for p in topic["patterns"])
        items.append(Item(
            kind="translation",
            prompt=f"六级翻译常考词：{topic['name']}",
            answer=f"【词汇】\n{words}\n\n【句式】\n{patterns}",
            note=f"{topic['name']}是历年翻译的高频主题，这些词成组背。",
            tags=["六级", "翻译", topic["name"]],
            source="六级翻译常考主题（公开考点）",
        ))
    return items


def all_items() -> list[Item]:
    return vocab_items() + writing_items() + translation_items()


def import_problems(store, kinds: list[str] | None = None,
                    limit: int = 0) -> int:
    """把备考材料灌进题库，和算法题一起做间隔重复。

    返回新增了几道。**已经存在的标题会跳过**（不会重复加），
    所以她可以反复跑这条命令来补新内容。
    """
    want = set(kinds or ["vocab", "writing", "translation"])
    items: list[Item] = []
    if "vocab" in want:
        items += vocab_items(limit)
    if "writing" in want:
        items += writing_items()
    if "translation" in want:
        items += translation_items()

    existing = {p.title.strip().lower() for p in store.all(include_archived=True)}
    payload = []
    for item in items:
        title = item.prompt.strip()
        if title.lower() in existing:
            continue
        existing.add(title.lower())
        payload.append({
            "title": title,
            "source": "other",
            "difficulty": "medium",
            "tags": item.tags,
            "url": "",
            "note": item.note + (f"\n\n{item.answer}" if item.answer else ""),
        })
    if not payload:
        return 0
    store.add_many(payload)
    return len(payload)


def coverage() -> dict:
    return {
        "video_topics": len(VIDEO_TOPICS),
        "vocab": len(KEY_VOCAB),
        "writing_frames": len(WRITING_FRAMES),
        "translation_topics": len(TRANSLATION_TOPICS),
        "translation_words": sum(len(t["words"]) for t in TRANSLATION_TOPICS),
        "sections": len(SECTIONS),
        "topics": len(TOPICS),
    }


# --------------------------------------------------------------------------
# 复习情况统计（给成绩单用）
# --------------------------------------------------------------------------

def study_stats(store, today: date) -> dict:
    """六级备考的复习情况。返回给界面直接渲染的一张表。

    为什么单独做这份统计：
        题库首页那些数字（待复习/已掌握）是**混着算法题一起算的**——
        她看不出"我的六级背到哪了"。六级和算法题混在一个进度里，
        既不知道单词背了多少，也不知道还剩多少没背。

    统计口径：
        全部       题库里带「六级」标签的题（= 导入过的备考材料）
        已掌握     间隔 >= 30 天（SM-2 里算"已掌握"）
        进行中     复习过但还没到 30 天
        没开始     一次都没复习过
        今天要复习 今天到期的
        未来 7 天  接下来一周会到期的（提前知道压力）
    """
    problems = [p for p in store.all() if "六级" in (p.tags or [])]

    # 按子类拆分（词汇 / 写作 / 翻译），这样她能看出哪块落下了
    groups: dict[str, dict] = {}
    for p in problems:
        kind = "其他"
        for tag in p.tags or []:
            if tag in ("词汇", "写作", "翻译"):
                kind = tag
                break
        g = groups.setdefault(kind, {"total": 0, "done": 0, "mastered": 0,
                                     "due_today": 0, "interval_sum": 0.0})
        g["total"] += 1
        g["interval_sum"] += p.interval
        if p.review_count > 0:
            g["done"] += 1
        if p.maturity == "已掌握":
            g["mastered"] += 1
        if p.due <= today:
            g["due_today"] += 1

    rows = []
    for kind, g in groups.items():
        rows.append({
            "kind": kind,
            "total": g["total"],
            "done": g["done"],
            "mastered": g["mastered"],
            "due_today": g["due_today"],
            "avg_interval": round(g["interval_sum"] / max(1, g["total"]), 1),
            "percent": round(g["done"] / max(1, g["total"]) * 100),
        })
    # 词汇排最前，其余按数量降序——她最关心词汇
    order = {"词汇": 0, "写作": 1, "翻译": 2}
    rows.sort(key=lambda r: (order.get(r["kind"], 9), -r["total"]))

    reviewed = [p for p in problems if p.review_count > 0]
    due_today = [p for p in problems if p.due <= today]
    mastered = [p for p in problems if p.maturity == "已掌握"]

    # 掌握程度分布。
    # 为什么除了"已掌握"还要单列"复习中"：
    #   SM-2 里"已掌握"要求间隔 >= 30 天，得复习好几次才到得了。
    #   她前几周看成绩单会一直是"掌握 0%"，像是没进展——
    #   其实间隔从 1 天涨到 8 天已经是明显进步了。
    maturity: dict[str, int] = {"新题": 0, "学习中": 0, "复习中": 0, "已掌握": 0}
    for p in problems:
        maturity[p.maturity] = maturity.get(p.maturity, 0) + 1

    total_reviews = sum(p.review_count for p in problems)
    # 未来 7 天每天要复习几道
    from datetime import timedelta

    forecast = []
    for offset in range(7):
        day = today + timedelta(days=offset)
        # 逾期的一次性全算在 offset=0，否则它们会在未来每一天都出现
        count = sum(1 for p in problems
                    if (p.due - day).days == 0 or (offset == 0 and p.due < today))
        forecast.append({"offset": offset, "date": day.isoformat(), "count": count})

    return {
        "total": len(problems),
        "done": len(reviewed),
        "mastered": len(mastered),
        "not_started": len(problems) - len(reviewed),
        "due_today": len(due_today),
        "total_reviews": total_reviews,
        "avg_interval": round(
            sum(p.interval for p in problems) / max(1, len(problems)), 1),
        "progress_percent": round(len(reviewed) / max(1, len(problems)) * 100),
        "mastered_percent": round(len(mastered) / max(1, len(problems)) * 100),
        "maturity": maturity,
        "rows": rows,
        "forecast": forecast,
        "imported": len(problems),
        "available": len(all_items()),
    }


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from datetime import timedelta

    # 考试日期是官方公布的（2026-12-12）
    assert EXAM_DATE == date(2026, 12, 12), EXAM_DATE
    assert EXAM_DATE.weekday() == 5, "12 月 12 日应该是周六"

    # ---- 倒计时 ----
    assert days_left(date(2026, 12, 12)) == 0
    assert days_left(date(2026, 12, 1)) == 11
    assert days_left(date(2026, 12, 13)) == -1
    total = len(KEY_VOCAB) + len(WRITING_FRAMES) + len(TRANSLATION_TOPICS)

    # ---- 进度 ----
    p = progress(date(2026, 10, 4))
    assert p["days_left"] == 69, p
    assert 0 <= p["percent"] <= 100, p
    assert not p["passed"]
    # 考试当天 100%，考完标记 passed
    assert progress(EXAM_DATE)["percent"] == 100, progress(EXAM_DATE)
    assert progress(EXAM_DATE + timedelta(days=1))["passed"] is True
    # 很早就查也不该算出负数或超过 100
    early = progress(date(2020, 1, 1))
    assert 0 <= early["percent"] <= 100, early

    # ---- 阶段建议：不同时间给不同的话，且都不是空的 ----
    seen: dict[str, str] = {}
    for d in (400, 100, 60, 30, 10, 3, 0, -5):
        kind, line = urgency(EXAM_DATE - timedelta(days=d))
        assert line.strip(), f"{d} 天时没有建议"
        seen.setdefault(kind, line)
    # 至少覆盖早/稳/冲刺/当天/考完 这几档
    assert {"early", "steady", "sprint", "today", "done"} <= set(seen), seen
    # 同一天必须稳定（不能刷新一次换一句）
    d = EXAM_DATE - timedelta(days=30)
    assert urgency(d) == urgency(d)
    # 越接近考试建议越"紧"——不能出现"还剩 3 天，时间还宽裕"这种
    assert "宽裕" not in urgency(EXAM_DATE - timedelta(days=3))[1]
    assert "宽裕" in urgency(EXAM_DATE - timedelta(days=400))[1]

    # ---- 视频条目 ----
    assert len(VIDEO_TOPICS) >= 8, len(VIDEO_TOPICS)
    keys = [v.key for v in VIDEO_TOPICS]
    assert len(keys) == len(set(keys)), "key 有重复"
    for v in VIDEO_TOPICS:
        assert v.title.strip() and v.query.strip(), v
        assert v.why.strip(), f"{v.key} 没说为什么要看它"
        assert "{" not in v.query, "搜索词里不该有占位符"
        # 搜索链接必须能被搜索模块正常处理
        url = v.search_url()
        assert url.startswith("https://search.bilibili.com/all?keyword="), url
        assert "{" not in url and " " not in url, url
    # 按类型筛选
    assert videos("vocab") and all(v.kind == "vocab" for v in videos("vocab"))
    assert len(videos()) == len(VIDEO_TOPICS)
    assert by_key(VIDEO_TOPICS[0].key) is VIDEO_TOPICS[0]
    assert by_key("不存在的") is None

    # 解析未知条目要报错而不是抛异常
    ok, items, err = resolve_videos("不存在的")
    assert not ok and err and items == [], (ok, items, err)

    # ---- 卷面结构：比例加起来应该是 100% ----
    ratios = [int(s["ratio"].rstrip("%")) for s in SECTIONS]
    assert sum(ratios) == 100, f"卷面比例加起来是 {sum(ratios)}%"
    scores = sum(s["score"] for s in SECTIONS)
    assert abs(scores - 710) < 1, f"总分应该是 710，算出来 {scores}"
    for s in SECTIONS:
        assert s["tips"], f"{s['name']} 没有给建议"
        assert s["order"].strip(), f"{s['name']} 没说什么时候做"

    # ---- 知识板块 ----
    assert len(TOPICS) >= 5
    for t in TOPICS:
        assert t["points"] and t["mistakes"], f"{t['name']} 缺内容"

    # ---- 备考题目 ----
    items = all_items()
    assert len(items) >= 55, f"只有 {len(items)} 条"
    for it in items:
        assert it.prompt.strip(), it
        assert it.answer.strip(), f"{it.prompt} 没有参考答案"
        assert it.tags, f"{it.prompt} 没有标签"
        assert "六级" in it.tags, it.tags
    # 三类都要有
    kinds = {i.kind for i in items}
    assert {"vocab", "writing", "translation"} <= kinds, kinds

    # 词汇条目：必须带词性和关键点（不能只是一个单词配一个中文）
    vocabs = vocab_items()
    assert len(vocabs) == len(KEY_VOCAB)
    for v in vocabs:
        assert v.note.strip(), f"{v.prompt} 没有关键点说明"
        assert len(v.answer) > 3, v.answer
    # 词条不能重复
    words = [v.prompt for v in vocabs]
    assert len(words) == len(set(words)), "有重复单词"

    # limit 参数
    assert len(vocab_items(5)) == 5

    # 写作框架：三个框架的句式都要有
    for frame in WRITING_FRAMES:
        assert frame["openers"] and frame["body"] and frame["closers"], frame["name"]
        assert frame["sample_prompt"].strip(), frame["name"]

    # 翻译主题：词汇和句式都要有
    for t in TRANSLATION_TOPICS:
        assert t["words"] and t["patterns"], t["name"]
        for cn, en in t["words"]:
            assert cn.strip() and en.strip(), t["name"]
            # 英文不该还是中文（写错了会很尴尬）
            assert not any("\u4e00" <= ch <= "\u9fff" for ch in en), f"{cn} 的英文里混了中文：{en}"

    # ---- 覆盖统计 ----
    cov = coverage()
    assert cov["video_topics"] == len(VIDEO_TOPICS)
    assert cov["vocab"] == len(KEY_VOCAB)
    assert cov["sections"] == 4

    # ---- 灌进题库（用内存库，不碰她的数据）----
    from .db import Store

    store = Store(":memory:")
    try:
        before = store.count()
        n = import_problems(store, ["vocab", "writing"])
        assert n == len(KEY_VOCAB) + len(WRITING_FRAMES), n
        assert store.count() == before + n
        # 再跑一次不该重复加（幂等）
        again = import_problems(store, ["vocab", "writing"])
        assert again == 0, f"第二次应该加 0 条，实际 {again}"
        # 加进去的题要能正常取出来、带得上标签和思路
        got = store.search("address")
        assert got, "灌进去以后搜不到"
        row = got[0]
        assert row.note.strip(), "note 是空的"
        assert "六级" in row.tags, row.tags
        # 只加翻译
        n2 = import_problems(store, ["translation"])
        assert n2 == len(TRANSLATION_TOPICS), n2
    finally:
        store.close()

    print(f"cet6 selftest: 全部断言通过 ✓"
          f"（{cov['video_topics']} 个视频主题 / {cov['vocab']} 个高频词 / "
          f"{cov['writing_frames']} 个作文框架 / {cov['translation_topics']} 类翻译主题）")


if __name__ == "__main__":
    _selftest()
