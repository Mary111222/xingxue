"""网络小工具：**优先 IPv4**。

## 为什么需要它（实测数据）

这台机器的 DNS 会给 B 站返回 IPv6 地址，而 **IPv6 实际连不通**：

    IPv6 直连 api.bilibili.com → TCP TimeoutError（20~30 秒才放弃）
    IPv4 直连同一台          → DNS 65ms + TCP 45ms + TLS 80ms + TTFB 134ms = 0.33 秒

**差 100 倍。** Python 默认按系统顺序解析（IPv6 排在前面）→ 每个请求都先
等 IPv6 超时 → 在界面上就是"搜索很慢 + 空结果"（和登录无关）。

## 做法

把 `socket.getaddrinfo` 包一层，只保留 IPv4 结果。**只影响本进程**，
不改系统设置、不动 hosts。

    XINGXUE_IPV4=0  → 关掉（万一以后 IPv6 修好了）
    默认（不设或 =1）→ 启用

## 边界

解析不出 IPv4 时**退回原行为**（不把本来能用的请求弄坏）。
纯 IPv6 主机本来就连不上，包一层只会让它更早报错 —— 那是更快，不是更糟。
"""
from __future__ import annotations

import os
import socket

_orig_getaddrinfo = socket.getaddrinfo
_installed = False


def _v4_only(host, port, family=0, type=0, proto=0, flags=0):
    """只解析 IPv4；拿不到就退回原行为（安全兜底）。"""
    try:
        got = _orig_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)
        if got:
            return got
    except OSError:
        pass
    return _orig_getaddrinfo(host, port, family, type, proto, flags)


def prefer_ipv4() -> bool:
    """装上「优先 IPv4」。重复调用无副作用。返回是否装上。"""
    global _installed
    if os.environ.get("XINGXUE_IPV4", "1").strip().lower() in ("0", "false", "no"):
        return False
    if not _installed:
        socket.getaddrinfo = _v4_only
        _installed = True
    return True


def _selftest() -> None:
    import time

    assert prefer_ipv4()
    t0 = time.time()
    ips = socket.getaddrinfo("api.bilibili.com", 443)
    dt = time.time() - t0
    families = {x[0].name for x in ips}
    print(f"  api.bilibili.com 解析 {dt * 1000:.0f}ms，地址族 {families}")
    assert families <= {"AF_INET"}, f"还混着 IPv6：{families}"
    t0 = time.time()
    s = socket.create_connection(("api.bilibili.com", 443), timeout=6)
    print(f"  TCP 连接 {time.time() - t0:.2f}s ✓")
    s.close()
    print("net selftest: 通过 ✓")


if __name__ == "__main__":
    _selftest()
