"""B 站登录 cookies 的管理。

## 为什么需要这个

B 站的搜索接口对**未登录请求**限流非常严——表现就是 HTTP 412。
之前 `search.py` 里已经修过一个类似问题（缺 `Origin` 头），但那个修完
仍然会时不时 412，因为**根本没带登录信息**。

带上登录后的 cookies，请求在 B 站看来就是"一个登录用户在搜"，
不再是可疑的脚本流量。

## 设计要点

**① cookies 是一个文件，不是一个变量**

    数据目录/cookies/bilibili.txt

这一点是**刻意的**：文件可以被看到、被编辑、被删除、被备份。
出问题时她能自己去看看里面是什么；换电脑时跟着数据目录一起走。
做成"存在配置里的一个字符串"就做不到这些。

**② 两种格式都收**

    · Cookie 头格式：`SESSDATA=xxx; bili_jct=yyy; DedeUserID=123`
      这是从浏览器 DevTools 里直接复制出来的样子
    · Netscape 格式（cookies.txt）：
      制表符分隔的 7 列，浏览器插件导出的就是这个

为什么要都收：让**她**用哪种都行。要求她转换格式是无谓的门槛。

**③ 只认关键的几个名字，但不过滤掉别的**

判断"有没有登录"要看关键 cookie（`SESSDATA` / `DedeUserID`）。
但请求时要**把拿到的全部带上**——B 站还要 `buvid3`、`bili_jct` 这些
来做风控识别，少一个都可能被判成异常流量。

**④ 绝不在日志/接口里回显 cookie 值**

这是登录凭据。`status()` 只回**名字**和是否有值，星号打码。
`describe()` 是给人看的，也只说"有哪些、关键的有没有"。
"""

from __future__ import annotations

import re
import time
from pathlib import Path

# 判断"登录了没有"看这几个。
# SESSDATA 是会话凭据；DedeUserID 是用户号（有它基本就说明登录过）。
KEY_COOKIES = ("SESSDATA", "DedeUserID", "bili_jct")

# 这几个有了能显著降低风控概率，但缺了不算"没登录"
HELPFUL_COOKIES = ("buvid3", "buvid4", "b_nut", "sid", "bili_ticket")

FILENAME = "bilibili.txt"

# cookie 名的合法形态。用来从任意文本里把 key=value 挑出来。
_NAME = re.compile(r"[A-Za-z_][\w]*")
# Netscape 格式：domain \t flag \t path \t secure \t expiry \t name \t value
_NETSCAPE_COLS = 7


def cookies_dir(home: Path) -> Path:
    """cookies 放哪个目录。"""
    return Path(home) / "cookies"


def cookies_path(home: Path) -> Path:
    """cookies 文件路径。"""
    return cookies_dir(home) / FILENAME


# --------------------------------------------------------------------------
#  解析
# --------------------------------------------------------------------------

def _parse_netscape_line(line: str) -> tuple[str, str] | None:
    """解析一行 Netscape cookies.txt。不是这个格式就返回 None。"""
    if line.startswith("#") or not line.strip():
        return None
    cols = line.split("\t")
    if len(cols) < _NETSCAPE_COLS:
        return None
    name, value = cols[5].strip(), cols[6].strip()
    if not name:
        return None
    return name, value


def parse(text: str) -> dict[str, str]:
    """从任意文本里解析出 cookies。

    三种输入都能吃：
        · `k=v; k2=v2`            一行或多行
        · Netscape cookies.txt    制表符分隔
        · 整个 HTTP 头（`Cookie: k=v; ...`）

    **为什么做得这么宽松**：她复制什么过来都可能。
    与其报"格式不对"让她去查，不如尽量认出来。
    认不出来的部分静默丢掉——总比整个失败好。
    """
    out: dict[str, str] = {}

    # 先试 Netscape 格式（整行整行地看）
    for line in text.splitlines():
        got = _parse_netscape_line(line)
        if got:
            out[got[0]] = got[1]

    # 再按 key=value 扫一遍（Cookie 头和 Netscape 都能被这个兜住）
    # 用分号/换行/制表符都当分隔，值取到下一个分隔符为止
    for m in re.finditer(
            r"(?:^|[;\s\t])([A-Za-z_][\w]*)\s*=\s*([^;\s\t\r\n]*)", text):
        name, value = m.group(1), m.group(2)
        # 空值不算（有些站点会发 k= 这种）
        if value:
            out.setdefault(name, value)

    # 去掉明显不是 cookie 的东西
    for junk in ("Cookie", "cookie", "path", "domain", "expires", "secure",
                 "HttpOnly", "TRUE", "FALSE"):
        out.pop(junk, None)
    return out


def is_logged_in(cookies: dict[str, str]) -> bool:
    """有没有登录信息。

    判据：`SESSDATA` 或 `DedeUserID` 至少有一个。
    只看 `buvid3` 之类的**不算登录**——那是游客标识，
    B 站对游客照样限流。
    """
    return any(cookies.get(k) for k in ("SESSDATA", "DedeUserID"))


def missing_key_cookies(cookies: dict[str, str]) -> list[str]:
    """缺了哪几个关键的。"""
    return [k for k in KEY_COOKIES if not cookies.get(k)]


def to_header(cookies: dict[str, str]) -> str:
    """拼成 Cookie 请求头的值。"""
    return "; ".join(f"{k}={v}" for k, v in cookies.items())


# --------------------------------------------------------------------------
#  读写
# --------------------------------------------------------------------------

def load(home: Path) -> dict[str, str]:
    """读 cookies。文件不存在或读不了就返回空 dict（**不抛异常**）。

    为什么容忍失败：这是"增强功能"，
    没有 cookies 时搜索仍然要能用（只是可能被限流）。
    在这里抛异常会把整个搜索拖垮。
    """
    p = cookies_path(home)
    if not p.is_file():
        return {}
    try:
        return parse(p.read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return {}


def save(home: Path, text: str) -> tuple[bool, str, dict[str, str]]:
    """把一段文本解析后存成 Netstape 格式。

    返回 (成功, 说明, 解析出的 cookies)。

    **存成 Netscape 格式**而不是原样保存：
        · 她的输入可能是任意格式，原样存着以后还要再解析一次
        · Netscape 是标准格式，别的工具（curl、yt-dlp）也认
        · 解析一次、存成规范形式，后面读的时候就简单了
    """
    cookies = parse(text)
    if not cookies:
        return False, "没能从这段内容里认出任何 cookie。", {}

    d = cookies_dir(home)
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return False, f"建不了目录 {d}：{exc}", {}

    lines = [
        "# Netscape HTTP Cookie File",
        "# 这个是「形学」保存的 B 站登录凭据。删掉它就会退回未登录状态。",
        "# 不要把这个文件发给别人——里面是登录凭据。",
        "",
    ]
    for name, value in sorted(cookies.items()):
        # domain  flag  path  secure  expiry  name  value
        lines.append(
            f".bilibili.com\tTRUE\t/\tTRUE\t0\t{name}\t{value}")
    try:
        cookies_path(home).write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError as exc:
        return False, f"写不了 {cookies_path(home)}：{exc}", {}

    return True, f"已保存 {len(cookies)} 个 cookie。", cookies


def clear(home: Path) -> tuple[bool, str]:
    """删掉 cookies（退回未登录）。"""
    p = cookies_path(home)
    if not p.is_file():
        return True, "本来就没有保存过 cookies。"
    try:
        p.unlink()
        return True, "已删除 cookies。"
    except OSError as exc:
        return False, f"删不掉 {p}：{exc}"


# --------------------------------------------------------------------------
#  请求头
# --------------------------------------------------------------------------

def bili_headers(home: Path, extra: dict[str, str] | None = None
                 ) -> dict[str, str]:
    """给 B 站请求用的请求头。**带 cookies**。

    这是唯一该用来构造 B 站请求头的入口——
    各个模块自己拼 headers 的话，早晚会漏掉 cookie 这一项
    （现在就是这样：`search.py` 里那份就没有）。

    `Origin` 那一条是必须的，缺了它无论有没有 cookie 都会被 412。
    这一点是之前踩出来的（见 search.py 里的长注释）。
    """
    from .search import _UA

    headers = {
        "User-Agent": _UA,
        "Referer": "https://www.bilibili.com/",
        "Origin": "https://www.bilibili.com",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9",
    }
    cookies = load(home)
    if cookies:
        headers["Cookie"] = to_header(cookies)
    if extra:
        headers.update(extra)
    return headers


# --------------------------------------------------------------------------
#  状态（给界面看）
# --------------------------------------------------------------------------

def _mask(value: str) -> str:
    """打码。**凭据不该在任何地方原样出现**。"""
    if not value:
        return ""
    if len(value) <= 6:
        return "*" * len(value)
    return value[:3] + "*" * min(12, len(value) - 5) + value[-2:]


def status(home: Path) -> dict:
    """cookies 的当前状态。给界面用。

    **只回名字和打码后的值**，不回完整 cookie——
    这个接口的返回会被写进日志、被显示在页面上，
    而 cookies 是登录凭据，泄漏了等于把账号给人。
    """
    p = cookies_path(home)
    cookies = load(home)
    info: dict = {
        "ok": True,
        "has_file": p.is_file(),
        "path": str(p),
        "count": len(cookies),
        "logged_in": is_logged_in(cookies),
        "missing": missing_key_cookies(cookies),
        # 有哪些 cookie（名字可以看，值不行）
        "names": sorted(cookies),
        "present": {k: True for k in cookies},
        "masked": {k: _mask(v) for k, v in cookies.items()
                   if k in KEY_COOKIES or k in HELPFUL_COOKIES},
    }
    if p.is_file():
        try:
            st = p.stat()
            info["saved_at"] = time.strftime(
                "%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime))
            info["size"] = st.st_size
        except OSError:
            pass
    # 页面要不要提示"建议登录"
    if not cookies:
        info["advice"] = ("还没保存 B 站 cookies。未登录搜索容易被限流"
                          "（HTTP 412），建议登录一次。")
    elif not is_logged_in(cookies):
        info["advice"] = ("保存了 cookies，但里面没有登录凭据"
                          "（缺 SESSDATA / DedeUserID）。"
                          "这些多半只是游客标识，仍会被限流。")
    else:
        info["advice"] = "已保存登录 cookies，搜索会带上登录信息。"
    return info


def describe(home: Path) -> str:
    """一句话说明当前状态（终端/日志用）。"""
    s = status(home)
    if not s["has_file"]:
        return "B 站 cookies：没有（未登录，搜索可能被限流）"
    if not s["logged_in"]:
        return (f"B 站 cookies：{s['count']} 个，但没有登录凭据"
                f"（缺 {'、'.join(s['missing'])}）")
    return f"B 站 cookies：{s['count']} 个，已登录"


# --------------------------------------------------------------------------
#  自检
# --------------------------------------------------------------------------

def _selftest() -> None:
    """把解析和状态这两块的边界都断言一遍。

    重点是**别把游客 cookies 当成登录**——
    如果判错了，界面会显示"已登录"但搜索照样 412，
    那种"看着好了其实没好"是最难查的。
    """
    # ① Cookie 头格式
    c = parse("SESSDATA=abc%2Cdef; bili_jct=xyz; DedeUserID=12345")
    assert c["SESSDATA"] == "abc%2Cdef", c
    assert c["bili_jct"] == "xyz", c
    assert c["DedeUserID"] == "12345", c
    assert is_logged_in(c), "有 SESSDATA 就该算登录"

    # ② Netscape 格式
    ns = ("# Netscape HTTP Cookie File\n"
          ".bilibili.com\tTRUE\t/\tTRUE\t0\tSESSDATA\tabc123\n"
          ".bilibili.com\tTRUE\t/\tTRUE\t0\tbuvid3\tBV1\n")
    c2 = parse(ns)
    assert c2.get("SESSDATA") == "abc123", c2
    assert c2.get("buvid3") == "BV1", c2
    assert is_logged_in(c2)
    # 注释行和表头不该被当成 cookie
    assert "Netscape" not in c2 and "HTTP" not in c2, c2

    # ③ 整个 HTTP 头
    c3 = parse("Cookie: SESSDATA=zzz; DedeUserID=9\r\nUser-Agent: x")
    assert c3.get("SESSDATA") == "zzz", c3
    assert "User-Agent" not in c3, c3

    # ④ **只有游客 cookie 时不算登录**（关键断言）
    guest = parse("buvid3=ABC; b_nut=123; sid=xyz")
    assert not is_logged_in(guest), "只有游客标识不算登录"
    assert missing_key_cookies(guest) == list(KEY_COOKIES), \
        missing_key_cookies(guest)

    # ⑤ 认不出东西时返回空，不抛
    assert parse("") == {}
    assert parse("随便一段中文，没有等号") == {}
    assert parse("=====") == {}

    # ⑥ 空值的 cookie 不算
    assert "k" not in parse("k=; j=1"), parse("k=; j=1")

    # ⑦ 打码不能泄漏原值
    m = _mask("SESSDATA_SECRET_VALUE")
    assert "SECRET" not in m, m
    assert m.startswith("SES") and m.endswith("UE"), m
    assert _mask("") == ""
    assert set(_mask("abc")) == {"*"}, _mask("abc")

    # ⑧ to_header 往返
    h = to_header({"a": "1", "b": "2"})
    assert parse(h) == {"a": "1", "b": "2"}, h

    print("  cookies selftest：全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()


