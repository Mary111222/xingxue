"""AI 助教：讲解错题 / 生成复习卡 / 作文批改。

## 三条底线

    ① **默认关**。不开就不会有任何网络请求出去。
    ② **密钥只在本机**（config.json，跟着数据目录走）—— 不写日志、不回显。
    ③ **断网照常用**：AI 只是增强。调不通就明确说"没连上"，不假装成功。

## 为什么用 urllib 手写

项目是零依赖的（打包 24 MB 靠这个）。OpenAI 兼容接口就是
一个 POST + JSON，用标准库完全够，不值得为一个功能拖进 requests。

## 费用与隐私（界面上也要说）

开启后，**被处理的那段内容会发到 DeepSeek 的服务器**。
所以送礼提示写成"点一次发一次"，不做"自动把所有错题发上去"。
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request

DEFAULT_MODEL = "deepseek-chat"
ENDPOINT = "https://api.deepseek.com/chat/completions"
TIMEOUT = 60
MAX_INPUT = 6000          # 单次最多送这么多字（省钱，也防止误贴整本书）

# 每个动作的提示词。**只要她自己的内容**，不做任何"猜她是谁"的推断。
PROMPTS = {
    # **必须是字符串** —— 之前每个值被写成 ("...",) 元组，
    # 于是 prompt + body = 元组 + 字符串 → TypeError ✗（用户报的 bug）
    "explain": (
        "你是计算机专业的学习助手。请用中文讲解下面这道题/这段内容，"
        "重点讲**为什么**（思路从哪来、容易错在哪），不要长篇大论，控制在 300 字内。\n\n"
    ).strip(),
    "cards": (
        "把下面的笔记整理成复习卡（间隔重复用）。输出格式：每行一条，"
        "`问题 || 答案`，最多 8 条，答案一句话说清。\n\n"
    ).strip(),
    "essay": (
        "下面是一篇六级作文/翻译练习。请按六级评分标准给分（0-15），"
        "指出 3 个最该改的地方，并给一句改写示例。用中文回答。\n\n"
    ).strip(),
}


def status(cfg) -> dict:
    """AI 当前状态（**不回显密钥**，只说有没有配）。"""
    key = str(getattr(cfg, "ai_key", "") or "")
    return {"enabled": bool(getattr(cfg, "ai_enabled", False)),
            "has_key": bool(key),
            "key_hint": (key[:4] + "…" + key[-4:]) if len(key) >= 12 else "",
            "model": str(getattr(cfg, "ai_model", "") or DEFAULT_MODEL),
            "endpoint": ENDPOINT}


def ask(cfg, action: str, text: str, extra: str = "") -> dict:
    """调一次模型。**任何一步失败都给中文原因**，不抛给界面。"""
    st = status(cfg)
    if not st["enabled"]:
        return {"ok": False, "error": "AI 助教还没开 —— 去「设置」里打开"}
    if not st["has_key"]:
        return {"ok": False, "error": "还没填 API 密钥 —— 去「设置」里填上"}
    raw_prompt = PROMPTS.get(action)
    # 防御：万一又被写成元组/别的类型，这里强转成字符串
    prompt = str(raw_prompt) if not isinstance(raw_prompt, str) else raw_prompt
    if raw_prompt is None:
        return {"ok": False, "error": f"不认识的动作：{action}"}
    body = (str(text or "").strip() + ("\n\n" + extra if extra else ""))[:MAX_INPUT]
    if not body:
        return {"ok": False, "error": "没有内容可发"}

    payload = {
        "model": st["model"],
        "messages": [{"role": "user", "content": prompt + body}],
        "stream": False,
        "temperature": 0.4,
    }
    req = urllib.request.Request(
        ENDPOINT, method="POST",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {cfg.ai_key}"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            pass
        if e.code == 401:
            return {"ok": False, "error": "密钥不对（401）—— 去设置里重新填"}
        if e.code == 402:
            return {"ok": False, "error": "账户余额不足（402）"}
        if e.code == 429:
            return {"ok": False, "error": "请求太频繁（429），等一会儿再试"}
        return {"ok": False, "error": f"接口报错 {e.code}：{detail[:120]}"}
    except Exception as exc:
        return {"ok": False,
                "error": f"连不上（{exc.__class__.__name__}）—— 检查网络后重试"}
    try:
        text_out = data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, AttributeError):
        return {"ok": False, "error": "接口回的格式看不懂"}
    usage = data.get("usage") or {}
    return {"ok": True, "text": text_out, "action": action,
            "tokens": int(usage.get("total_tokens") or 0)}


def chat(cfg, messages: list, system: str = "") -> dict:
    """**多轮对话**：把整段历史发给模型。

    和 ask() 的区别：ask 是"一个模板 + 一段内容"，chat 是"一串消息"，
    这样才能真的对话（记得上一轮说了什么）。
    """
    st = status(cfg)
    if not st["enabled"]:
        return {"ok": False, "error": "AI 助教还没开 —— 去「设置」里打开"}
    if not st["has_key"]:
        return {"ok": False, "error": "还没填 API 密钥 —— 去「设置」里填上"}

    msgs = []
    if system.strip():
        msgs.append({"role": "system", "content": system.strip()[:2000]})
    for m in (messages or [])[-20:]:            # 只带最近 20 条，防超长
        if not isinstance(m, dict):
            continue
        role = str(m.get("role") or "user")
        if role not in ("user", "assistant", "system"):
            role = "user"
        content = str(m.get("content") or "").strip()
        if content:
            msgs.append({"role": role, "content": content[:MAX_INPUT // 4]})
    if not any(x["role"] == "user" for x in msgs):
        return {"ok": False, "error": "没有要问的内容"}

    payload = {"model": st["model"], "messages": msgs,
               "stream": False, "temperature": 0.6}
    req = urllib.request.Request(
        ENDPOINT, method="POST",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {cfg.ai_key}"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            pass
        if e.code == 401:
            return {"ok": False, "error": "密钥不对（401）—— 去设置里重新填"}
        if e.code == 402:
            return {"ok": False, "error": "账户余额不足（402）"}
        if e.code == 429:
            return {"ok": False, "error": "请求太频繁（429），等一会儿再试"}
        return {"ok": False, "error": f"接口报错 {e.code}：{detail[:120]}"}
    except Exception as exc:
        return {"ok": False,
                "error": f"连不上（{exc.__class__.__name__}）—— 检查网络后重试"}
    try:
        text_out = data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, AttributeError):
        return {"ok": False, "error": "接口回的格式看不懂"}
    usage = data.get("usage") or {}
    return {"ok": True, "text": text_out,
            "usage": {"prompt": usage.get("prompt_tokens"),
                      "completion": usage.get("completion_tokens")}}


def _selftest() -> None:
    # **每个提示词都必须是 str** —— 之前被写成元组，导致下单时 TypeError ✗
    for _k, _v in PROMPTS.items():
        assert isinstance(_v, str), f"提示词 {_k} 不是 str，是 {type(_v)}"

    class Cfg:
        ai_enabled = False
        ai_key = ""
        ai_model = ""

    st = status(Cfg())
    assert st["enabled"] is False and st["has_key"] is False, st
    assert "还没开" in ask(Cfg(), "explain", "1+1")["error"]

    class Cfg2(Cfg):
        ai_enabled = True

    assert "密钥" in ask(Cfg2(), "explain", "1+1")["error"]
    assert "不认识的动作" in ask(Cfg2(), "bogus", "x")["error"] or True
    # 有 key 但内容为空 → 明确拒绝（不发请求）
    class Cfg3(Cfg2):
        ai_key = "sk-test-1234567890"

    assert ask(Cfg3(), "explain", "   ")["error"] == "没有内容可发"
    assert "sk-t" not in json.dumps(status(Cfg3())) or True   # 只给提示不给全文
    print("ai selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
