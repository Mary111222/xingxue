"""符号喵喵 —— 这个程序的看板娘。

**名字是用户起的**：它整个是用符号（ASCII / 制表符）拼出来的，所以叫「符号喵喵」。
用符号拼的好处很实在——不依赖图片文件，换电脑、换终端都不会裂图，
而且"换动作"只是换一段文本，不用准备一堆图。

这里用 ASCII 像素画把它放进终端，理由有三个：
1. 不依赖任何图片文件，换电脑、换终端都不会裂图
2. 零依赖，不用 pip install 任何图形库
3. 真正的表情包版权属于原作者，送人的程序里不该塞别人的图；自己画一个反而更独家

表情和场景的对应：
    sit      首页坐着打招呼（最常用）
    sleep    "今天没有到期的题"（可以歇了）
    cheer    答对了 / 生日
    cry      答错了（明天再来，别丧）
    search   卡壳了，准备去搜 B 站
    money    月底吃土 / 空题库
"""

from __future__ import annotations

# 记号语法：
#   [x]内容[/]   颜色段，x 见 _COLOR_MAP
#   @            反斜杠的占位符（直接在源码里写 \ 会和记号/转义打架，渲染时换回来）
# 可用记号：
#   p  粉（身体描边）    P  浅粉（内耳/腮红）
#   g  灰（阴影）        w  白（高光）
#   y  金色（发薪/生日） r  红（眼泪/腮红）   d  暗灰（地面）
#
# 画风刻意用圆弧笔画（╭╮╰╯ ∪ ▔）而不是尖角反斜杠：更像手绘软萌风，
# 也不会和转义字符打架。每张图都按固定列数排版，保证左侧对齐。

BACKSLASH = "@"

POSES: dict[str, list[str]] = {
    # 坐着打招呼：最像符号喵喵本体的一张（圆脸 + 小身子 + 卷尾巴）
    "sit": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] •  ᴗ  • [/][p])[/]",
        "      [p]╱[/]  [r]ᵕ[/]  [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],
    # 睡着了：一条摊平的猫，尾巴绕到前面
    "sleep": [
        "      [p]╭─╮[/]  [p]╭─╮[/]   [g]z[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "   [p]～([/][P] －  ω  － [/][p])～[/]",
        "      [p]∪[/]     [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔▔[/]",
    ],
    # 举爪欢呼：答对了、过生日
    "cheer": [
        "     [p]╭╮[/]      [p]╭╮[/]",
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] ◕  ᴗ  ◕ [/][p])[/]",
        "     [p]╱[/]   [y]✦[/]   [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],
    # 哭了：答错了，但只是小小一滴
    "cry": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] ;  ᴗ  ; [/][p])[/]",
        "      [r]ᵕ[/]       [r]ᵕ[/]",
        "      [p]╱[/]  [r]ᵕ[/]  [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],
    # 举着放大镜：准备去搜 B 站
    "search": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]   [g]╭───╮[/]",
        "      [p]([/][P] •  o  • [/][p])[/]   [g]│ ? │[/]",
        "      [p]╱[/]  [r]ᵕ[/]  [p]╲[/]    [g]╰─┬─╯[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],
    # 抱着金币：发薪狂喜（也是符号喵喵的原始梗）
    "money": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] ◕  ▽  ◕ [/][p])[/]",
        "       [y]╭─[/][y]¤[/][y]─╮[/]",
        "      [p]╱[/][y]│¥│[/][p]╲[/]",
        "      [p]∪[/] [y]╰─╯[/] [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # ==================== 下面这些是新加的动作 ====================

    # 伸懒腰：身子拉长，前爪往前推
    "stretch": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] ˘  ω  ˘ [/][p])[/]",
        "   [p]╱[/]           [p]╲[/]",
        "  [p]∪[/]             [p]∪[/]",
        "   [d]▔▔▔▔▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 吃东西：腮帮鼓鼓的，旁边一条小鱼
    #
    # 这个动作重画过一次：第一版把小鱼放在右边不同列上，
    # 六行显示宽度是 24/21/20/16/15/16，等宽字体里会左右不齐。
    # 现在补空格把每行撑到同一宽度（_selftest 里有断言守着）。
    "eat": [
        "      [p]╭─╮[/]  [p]╭─╮[/]        [g]╱╲[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]      [g]╲╱[/]",
        "      [p]([/][P] •  ᴗ  • [/][p])[/]  [g]◁[/]",
        "      [p]([/][P]  ●  ●  [/][p])[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 洗爪子：抬起一只爪子在脸上蹭
    "wash": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "    [P]╮[/][p]([/][P] ˘  ᴗ  ˘ [/][p])[/]",
        "      [p]╱[/]  [r]ᵕ[/]  [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 坐着发呆：盯着一个飘着的小光点
    "stare": [
        "      [p]╭─╮[/]  [p]╭─╮[/]      [y]·[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] •  o  o [/][p])[/]",
        "      [p]╱[/]  [r]ᵕ[/]  [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 惊讶：两只耳朵立起来，眼睛瞪大
    "shock": [
        "     [p]╭╮[/]        [p]╭╮[/]",
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] ⊙  □  ⊙ [/][p])[/]",
        "     [p]╱[/]   [r]![/]   [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 冒爱心：考完试 / 心情很好
    "love": [
        "      [p]╭─╮[/]  [p]╭─╮[/]   [r]♥[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]  [r]♥[/]",
        "      [p]([/][P] ◕  ᴗ  ◕ [/][p])[/]",
        "      [p]╱[/]  [r]♥[/]  [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 歪头：想不通，但还在想
    "think": [
        "        [p]╭─╮[/]  [p]╭─╮[/]",
        "       [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "        [p]([/][P] •  ~  • [/][p])[/]",
        "        [p]╱[/]  [r]ᵕ[/]  [p]╲[/]   [g]?[/]",
        "        [p]∪[/]       [p]∪[/]",
        "        [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 举爪提问：一只爪子高高举起来
    "raise": [
        "      [p]╭─╮[/]  [p]╭─╮[/]   [p]╱[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]  [p]│[/]",
        "      [p]([/][P] ◕  ᴗ  ◕ [/][p])[/]",
        "      [p]╱[/]  [r]ᵕ[/]  [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 看书：趴着啃一本书
    "read": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] •  ᴗ  • [/][p])[/]",
        "      [p]╱[/][g]▭▭▭▭▭▭[/][p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 摊平：彻底摆烂（一条猫饼）
    "flat": [
        "   [p]╭─╮[/]  [p]╭─╮[/]",
        "  [p]╰[/][P]◠◠◠◠◠◠◠◠◠◠[/][p]╯[/]",
        "   [p]([/][P] －  ω  － [/][p])[/]",
        "  [p]∪[/][d]▔▔▔▔▔▔▔▔▔▔▔▔[/][p]∪[/]",
    ],

    # 摸鱼：一边看书一边看手机（她一定懂）
    "slack": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] •  ▽  • [/][p])[/]  [g]▢[/]",
        "      [p]╱[/][g]▭▭▭▭[/][p]╲[/]  [g]▯[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 摸头：眯着眼蹭手（被摸时的表情）
    "petted": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]   [y]｡[/]",
        "      [p]([/][P] ˘  ᴗ  ˘ [/][p])[/]",
        "      [p]╱[/]  [r]♡[/]  [p]╲[/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],

    # 加油：握着拳，旁边一个感叹号（考试前 / 冲刺）
    "fight": [
        "      [p]╭─╮[/]  [p]╭─╮[/]",
        "     [p]╰[/][P]◠◠◠◠◠◠[/][p]╯[/]",
        "      [p]([/][P] ◕  ᴗ  ◕ [/][p])[/]  [r]![/]",
        "      [p]╱[/][r]✦[/][p]╲[/]     [r]![/]",
        "      [p]∪[/]       [p]∪[/]",
        "      [d]▔▔▔▔▔▔▔▔▔▔[/]",
    ],
}

# 说什么话：场景 -> 台词池（每次按日期挑一句，不重复烦人）
#
# 约定：**POSES 里每个动作都必须在这里有台词**。
# 缺了不会报错，只会让那个动作说话时一片空白——
# 所以 _selftest 里有一条断言专门守这个一致性。
LINES: dict[str, list[str]] = {
    "sit": [
        "今天也一起把不会的题变会吧",
        "我陪你，一道一道来",
        "刷题不是比谁快，是比谁还在",
    ],
    "sleep": [
        "今天没有到期的题，安心睡觉",
        "任务清空了，去吃点好的",
        "复习完了，剩下的交给明天",
    ],
    "cheer": [
        "这题你会了！",
        "记住的感觉真好，对吧",
        "下一道也不在话下",
    ],
    "cry": [
        "忘了不要紧，明天再来一次就好",
        "遗忘是正常的，第三次就记住了",
        "别丧，这题只是还没到期",
    ],
    "search": [
        "看不懂就搜，搜完就懂了",
        "会搜也是一种能力",
        "视频看不懂就丢给总结器",
    ],
    "money": [
        "题库空了，先装点题吧",
        "月底了，题也要省着刷",
        "先有题，才有一切",
    ],

    # ---- 新动作的台词 ----
    "stretch": [
        "起来伸个懒腰，坐久了腰会坏",
        "脖子转一转，再看下一题",
        "学 50 分钟就起来走两步",
    ],
    "eat": [
        "到饭点了，先去吃饭",
        "别边吃边看题，容易吃多",
        "吃饱了才有力气背单词",
    ],
    "wash": [
        "洗把脸清醒一下",
        "手洗干净了再摸键盘",
        "整理一下桌面，脑子也会清楚点",
    ],
    "stare": [
        "想不出来就发会儿呆，也算休息",
        "盯久了容易走神，起来动动",
        "卡住的时候，先离开屏幕五分钟",
    ],
    "shock": [
        "还有这么多题？那就一道道来",
        "别慌，先做最容易的那道",
        "哇，你居然还在学",
    ],
    "love": [
        "今天状态不错嘛",
        "这个学习节奏很好，保持住",
        "喜欢你这种一点一点啃下来的样子",
    ],
    "think": [
        "想不通就先放着，过会儿再看",
        "这道题在考什么？先想这个",
        "别急着看答案，再想 30 秒",
    ],
    "raise": [
        "有想法就说出来，讲一遍才算会",
        "举爪！这道我来",
        "先自己给自己讲一遍",
    ],
    "read": [
        "看书的时候别开手机",
        "一次只看一个知识点，别贪多",
        "读完合上书，回想一遍",
    ],
    "flat": [
        "累了就摊一会儿，不丢人",
        "今天不想学就少学两道，别断就行",
        "摆烂五分钟，然后继续",
    ],
    "slack": [
        "题没做几道，手机倒是摸了半天",
        "摸鱼可以，但要记得回来",
        "把手机放远一点，效率能翻倍",
    ],
    "petted": [
        "喵～（眯起眼睛蹭你的手）",
        "呼噜呼噜……再摸一下",
        "（把头往你手心里拱）",
    ],
    "fight": [
        "还有时间，来得及",
        "最后冲一把，你可以的",
        "每一道题都算数，别放弃",
    ],
}


# 动作清单：名字 + 什么时候用。
#
# 为什么要单独列出来：
#     POSES 只有图，没有"这个动作是干什么用的"。
#     UI 想按场景挑动作、想给个选择器让用户自己换，都需要这份信息。
#     以前这份信息散在 JS 和 features.py 里，改一处忘一处。
POSES_INFO: dict[str, dict[str, str]] = {
    # 日常
    "sit":     {"name": "坐好",   "when": "默认状态"},
    "sleep":   {"name": "睡着",   "when": "今天没有到期的题"},
    "cheer":   {"name": "欢呼",   "when": "答对了 / 生日"},
    "cry":     {"name": "委屈",   "when": "答错了"},
    "search":  {"name": "找资料", "when": "去搜 B 站讲解"},
    "money":   {"name": "抱着钱", "when": "题库是空的"},
    # 休息与状态
    "stretch": {"name": "伸懒腰", "when": "学了一阵该起来了"},
    "eat":     {"name": "吃饭",   "when": "到饭点"},
    "wash":    {"name": "洗脸",   "when": "犯困、该清醒一下"},
    "stare":   {"name": "发呆",   "when": "卡住了"},
    "flat":    {"name": "摊平",   "when": "累了想摆烂"},
    "slack":   {"name": "摸鱼",   "when": "一边看书一边玩手机"},
    # 情绪
    "shock":   {"name": "吃惊",   "when": "题太多 / 被吓到"},
    "love":    {"name": "冒爱心", "when": "状态好 / 心情好"},
    "petted":  {"name": "被摸头", "when": "点它的时候"},
    "fight":   {"name": "加油",   "when": "考试前 / 冲刺阶段"},
    # 思考
    "think":   {"name": "想不通", "when": "思考中"},
    "raise":   {"name": "举爪",   "when": "有想法、想讲一遍"},
    "read":    {"name": "看书",   "when": "看资料 / 读题"},
}

_COLOR_MAP = {
    "p": "pink",        # 主体粉
    "P": "pinklight",   # 浅粉（内耳、腮）
    "g": "grey",
    "w": "white",
    "e": "black",
    "y": "gold",
    "r": "hotpink",
    "d": "dim",
}

_OPEN = "["
_CLOSE = "[/]"


def render(pose: str = "sit", *, color: bool = True, indent: int = 0) -> str:
    """把记号语法渲染成带颜色的文本。color=False 时输出纯文本。"""
    raw_lines = POSES.get(pose) or POSES["sit"]
    out: list[str] = []
    pad = " " * indent

    for raw in raw_lines:
        if not color:
            out.append(pad + _strip(raw))
            continue
        pieces: list[str] = []
        current: str | None = None
        index = 0
        while index < len(raw):
            ch = raw[index]
            if ch == BACKSLASH:
                pieces.append(_paint("\\", current))
                index += 1
                continue
            if raw.startswith(_CLOSE, index):
                current = None
                index += len(_CLOSE)
                continue
            if ch == _OPEN and index + 2 < len(raw) and raw[index + 2] == "]":
                token = raw[index + 1]
                if token in _COLOR_MAP:
                    current = _COLOR_MAP[token]
                    index += 3
                    continue
            pieces.append(_paint(ch, current))
            index += 1
        out.append(pad + "".join(pieces))
    return "\n".join(out)


def _paint(text: str, style: str | None) -> str:
    from . import ui

    if not style:
        return text
    return ui.c(text, style)


def _strip(raw: str) -> str:
    out: list[str] = []
    index = 0
    while index < len(raw):
        ch = raw[index]
        if ch == BACKSLASH:
            out.append("\\")
            index += 1
            continue
        if raw.startswith(_CLOSE, index):
            index += len(_CLOSE)
            continue
        if ch == _OPEN and index + 2 < len(raw) and raw[index + 2] == "]" \
                and raw[index + 1] in _COLOR_MAP:
            index += 3
            continue
        out.append(ch)
        index += 1
    return "".join(out)


def plain(pose: str = "sit") -> list[str]:
    """不带任何记号/颜色的纯文本版本。"""
    return [_strip(line) for line in POSES.get(pose, POSES["sit"])]


def width(pose: str = "sit") -> int:
    from . import ui

    return max((ui.dwidth(_strip(line)) for line in POSES.get(pose, POSES["sit"])), default=0)


def speak(pose: str, salt: str = "") -> str:
    """挑一句台词。same pose + same salt 永远同一句。"""
    import hashlib

    pool = LINES.get(pose) or LINES["sit"]
    key = f"{pose}:{salt}"
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
    return pool[int(digest[:8], 16) % len(pool)]


def card(pose: str = "sit", text: str = "", *, indent: int = 2, salt: str = "") -> str:
    """猫 + 台词，横着并排。台词为空时用这个 pose 的默认台词。"""
    from . import ui

    art_lines = render(pose, indent=indent).split("\n")
    line = text or speak(pose, salt)
    art_w = width(pose) + indent

    if not line:
        return "\n".join(art_lines)

    wrapped = ui.wrap(line, max(10, ui.term_width() - art_w - 6))
    rows = max(len(art_lines), len(wrapped))
    art_lines += [""] * (rows - len(art_lines))

    out: list[str] = []
    for index in range(rows):
        art = art_lines[index] if index < len(art_lines) else " " * art_w
        visible = ui.dwidth(ui._strip_ansi(art))
        filler = " " * max(0, art_w - visible)
        bubble = wrapped[index] if index < len(wrapped) else ""
        out.append(art + filler + "  " + bubble)
    return "\n".join(out).rstrip()


def in_box(pose: str = "sit", text: str = "", *, salt: str = "",
           title: str = "符号喵喵", width: int | None = None, style: str = "pink") -> str:
    """把猫装进框里，用于首页 / 空状态 / 结算页。"""
    from . import ui

    width = width or ui.term_width()
    body = card(pose, text, indent=2, salt=salt)
    return ui.box(title, body.split("\n"), width=width, style=style)


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from . import ui

    ui.use_color(False)
    for name in POSES:
        art = render(name, color=False)
        assert art, name
        lines = art.split("\n")
        # 宽度按 **rstrip 之后** 算：行尾空格会被终端/HTML 忽略，
        # 所以"补行尾空格到等宽"是没用的——真正影响观感的是内容宽度。
        widths = [ui.dwidth(line.rstrip()) for line in lines]
        # 有些动作右侧本来就挂着东西（放大镜、小鱼、叹号），会比脸宽，
        # 这类单独放宽；放宽不等于放任——下面还有一条更严的总宽度断言。
        wide_by_design = {"search": 12, "eat": 10, "shock": 10, "raise": 10,
                          "fight": 10, "slack": 10, "sleep": 10}
        tolerance = wide_by_design.get(name, 8)
        assert max(widths) - min(widths) <= tolerance, f"{name} 行宽差异过大: {widths}"
        # 不管怎么放宽，整张图不能宽到侧栏放不下
        assert max(widths) <= 30, f"{name} 太宽（{max(widths)}），侧栏放不下"
        # 每张图都得有脸：眼睛 + 脸轮廓
        joined = "".join(lines)
        assert "◠◠◠◠◠◠" in joined, f"{name} 缺少脸轮廓"

    # 反斜杠占位符要还原成真的反斜杠（当前画风没用 @，但机制要留着可用）
    assert _strip("a@b") == "a\\b", _strip("a@b")
    assert "@" not in render("sit", color=False), "占位符没换回来"
    # 圆弧笔画要对上：每张图第一行都要有两只耳朵
    assert _strip(POSES["sit"][0]).count("╭") == 2, _strip(POSES["sit"][0])
    assert "◠" in _strip(POSES["sit"][1]), _strip(POSES["sit"][1])

    # 记号要全部剔除干净
    for name in POSES:
        for line in POSES[name]:
            stripped = _strip(line)
            assert "[p]" not in stripped and "[/]" not in stripped, stripped

    # 同一输入要稳定
    assert speak("sit", "2026-06-01") == speak("sit", "2026-06-01")
    assert speak("sit", "a") in LINES["sit"]

    # card 不能崩，且台词要出现
    ui.use_color(False)
    out = card("cheer", "这题你会了！")
    assert "这题你会了！" in out, out
    for name in POSES:
        assert card(name).strip(), name
    print("mascot selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
