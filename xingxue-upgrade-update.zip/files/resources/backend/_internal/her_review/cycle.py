"""生理期记录与预测。

用户要求："在日历那加一个生理期提醒，这一块你自行发挥"。
所以这里把"一个提醒"扩成了一套完整但克制的东西。

设计原则（这块最容易做过头，所以先定规矩）：

    1. **她主动记录，程序只做算术。** 不做"自动检测"、不猜、不诊断。
       程序只知道她填的日期和周期长度，然后照公式预测。
    2. **预测不是事实。** 界面上明确写"预计""大概"，
       并给出"推迟几天算正常"的范围——免得她按预测日期焦虑。
       周期会因考试、熬夜、压力变化，这是正常的，程序不该装作很准。
    3. **提醒可以关。** 默认开启，但一句话就能关掉。
       有些人不需要天天被提醒这件事。
    4. **数据只在本机。** 和题库、便签一样，写在她自己的数据目录里。

预测口径（都是公开的妇科常识，不是我自己编的）：
    下次经期   = 上次开始 + 周期长度
    排卵日     = 下次经期 - 14 天
    易孕期     = 排卵日前 5 天 ~ 排卵日后 1 天（共 7 天，精子可存活约 5 天）
    黄体期     = 排卵后到下次经期（固定约 14 天）

    这几个日期在不同人、不同月之间的波动可以很大，
    所以界面上会带上"按你填的周期推的"这句限定。
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

# 周期长度的合理范围。超出这个范围多半是填错了，
# 与其算出一个离谱的预测，不如直接问她。
MIN_CYCLE, MAX_CYCLE = 18, 60
MIN_PERIOD, MAX_PERIOD = 2, 12

# 默认值（中国女性的常见范围）
DEFAULT_CYCLE = 28
DEFAULT_PERIOD = 5

# **不计算排卵日，也不算易孕期**（用户要求去掉）。
#
# 原来这里是：
#     LUTEAL_DAYS = 14       ← 黄体期固定 14 天，拿它反推排卵日
#     FERTILE_BEFORE/AFTER   ← 易孕期 = 排卵前 5 天 ~ 后 1 天
#
# 去掉不只是"界面上不显示"，而是从**算法层**删掉，原因有两条：
#   ① 排卵日是按"黄体期恒为 14 天"反推的。个体差异很大，误差常有几天，
#      当知识点展示不如不展示。
#   ② 易孕期的推断**容易被当成避孕依据**——那是有实际风险的用途。
#      这个程序只做"帮你记住上次什么时候来的"，不该越界到那一步。
#
# 现在只剩两个概念：**经期**（实际记录）和**预计经期**（推算）。

# 推迟几天以内算正常（超过就提示"可以留意一下"，但不吓她）
NORMAL_DELAY = 7

PHASE_LABELS = {
    "period": "经期",
    "after": "经期刚结束",
    "luteal": "周期中",
    "waiting": "经期前",
    "unknown": "还没记录",
}


@dataclass
class Prediction:
    """一次预测的结果。所有日期都是"预计"，不是事实。

    字段命名刻意写清楚，因为这个模块最容易在语义上搞混：
        period_start / period_end     **当前这次**经期的开始与结束
        next_start / next_end         **下一次**经期的开始与结束
    第一版我把"当前经期结束"叫成了 next_end，结果日历上会把
    已经过去的经期标成下一次——名字含糊，代码就会用错。
    """
    last_start: date | None = None
    cycle: int = DEFAULT_CYCLE
    period_days: int = DEFAULT_PERIOD
    period_start: date | None = None
    period_end: date | None = None
    next_start: date | None = None
    next_end: date | None = None
    days_until: int | None = None      # 距下次经期还有几天（永远是正的，见 predict）
    late_days: int = 0                 # 保留字段：手工构造 Prediction 时可能用到
    cycles_ahead: int = 0              # 记录有多旧：自动推进了几轮
    phase: str = "unknown"
    phase_label: str = PHASE_LABELS["unknown"]
    day_of_cycle: int | None = None    # 现在是本周期的第几天

    def is_delayed(self) -> bool:
        return self.late_days > 0

    def is_notably_late(self) -> bool:
        return self.late_days > NORMAL_DELAY

    def is_stale(self) -> bool:
        """记录是不是太旧了（超过一个周期没更新）。

        为什么不直接说"你推迟了"：
            程序分不清"这个月晚了"和"忘记录入"。医学上判断推迟也要先排除
            记录遗漏，程序不该越过这一步替她下结论。
            所以旧记录只说"该更新了"，不说"你晚了"。
        """
        return self.cycles_ahead >= 2

    def in_period(self) -> bool:
        return self.phase == "period"

    def message(self) -> str:
        """一句适合放在首页的话。措辞刻意克制——不制造焦虑。"""
        if self.last_start is None:
            return "还没记录过。在「倒数日」页填一次上次的开始日期就行。"
        if self.phase == "period":
            left = (self.period_end - date.today()).days if self.period_end else 0
            return (f"经期第 {self.day_of_cycle} 天，大概还有 {max(0, left)} 天结束。"
                    f"多喝热水，别熬夜。")
        if self.is_stale():
            return (f"记录还是 {self.last_start.isoformat()} 那次的，"
                    f"已经过去 {self.cycles_ahead} 个周期了，预测会不准。"
                    f"在「倒数日」页更新一下日期吧。")
        if self.is_notably_late():
            return (f"按你填的周期算，已经推迟 {self.late_days} 天了。"
                    f"周期受考试、熬夜、压力影响会波动，"
                    f"如果连续几个月都这样，可以去看看医生。")
        if self.is_delayed():
            return f"比预计晚了 {self.late_days} 天，还在正常波动范围内，先别紧张。"
        # （这里原来有"易孕期内""预计今天是排卵日"两句文案，
        #   随排卵/易孕一起删掉了。）
        if self.phase == "waiting":
            return f"还有 {self.days_until} 天。可以提前在包里放一片。"
        return f"距下次预计还有 {self.days_until} 天。"


def predict(config, today: date) -> Prediction:
    """按她填的参数推算。还没记录过就返回一个空的 Prediction。"""
    raw = (getattr(config, "cycle_last_start", "") or "").strip()
    cycle = int(getattr(config, "cycle_length", 0) or DEFAULT_CYCLE)
    period_days = int(getattr(config, "cycle_period_days", 0) or DEFAULT_PERIOD)

    # 参数越界就直接用默认值，不要按离谱的输入算出更离谱的预测
    if not (MIN_CYCLE <= cycle <= MAX_CYCLE):
        cycle = DEFAULT_CYCLE
    if not (MIN_PERIOD <= period_days <= MAX_PERIOD):
        period_days = DEFAULT_PERIOD

    last = _parse(raw)
    if last is None:
        return Prediction(cycle=cycle, period_days=period_days)

    if last > today:
        # 填成未来了，多半是年份写错。不报错，但也不预测——只提示。
        return Prediction(last_start=last, cycle=cycle,
                          period_days=period_days, phase="unknown",
                          phase_label="日期填成了未来")

    # 找"当前这个周期"。
    #
    # 这里有个必须想清楚的问题（我前面绕了两圈才想明白）：
    #   "推迟"和"记录太旧"是同一件事的两种说法——
    #   程序没法知道她是"这个月晚了"还是"忘了记录"。
    #   如果无脑往后推进，推算出的下一轮永远在未来，"推迟"就永远不出现；
    #   如果不推进，两个月不开就会显示"推迟 60 天"，吓人且没意义。
    #
    # 采取的办法：**照常推进，但另外记录"这条记录有多旧"**。
    #   记录越旧，预测越不可信——所以超过一个周期就提示她更新，
    #   而不是替她断言"你推迟了"。
    #   （医学上判断推迟要先排除记录遗漏，程序不该越过这一步下结论。）
    start = last
    guard = 0
    while guard < 400:
        nxt = start + timedelta(days=cycle)
        if nxt > today:
            break                      # 今天还没到下一轮，当前周期就是它
        start = nxt
        guard += 1
    cycles_ahead = guard               # 自动推进了几轮

    next_start = start + timedelta(days=cycle)
    # 当前这次经期的结束（start 就是"当前周期"的开始）
    period_end = start + timedelta(days=period_days - 1)
    # 下一次经期的结束（日历上要把未来那次也标出来）
    next_end = next_start + timedelta(days=period_days - 1)
    day_of_cycle = (today - start).days + 1
    days_until = (next_start - today).days
    # 注意：days_until 永远是正的（因为推进到未来才停）。
    # 真正该提示的是"记录太旧、预测不可信"，不是"你推迟了"。
    late_days = 0

    # 判定当前处于哪个阶段（经期优先；不再有排卵/易孕这两个阶段）
    if start <= today <= period_end:
        phase = "period"
    elif today < start + timedelta(days=period_days + 3):
        phase = "after"
    elif days_until <= 5:
        phase = "waiting"
    else:
        phase = "luteal"

    return Prediction(
        last_start=last, cycle=cycle, period_days=period_days,
        period_start=start, period_end=period_end,
        next_start=next_start, next_end=next_end,
        days_until=days_until, late_days=late_days,
        phase=phase, phase_label=PHASE_LABELS.get(phase, phase),
        day_of_cycle=day_of_cycle, cycles_ahead=cycles_ahead,
    )


def mark(config, when: date, *, save: bool = True) -> None:
    """记录"这次开始了"。"""
    config.cycle_last_start = when.isoformat()
    if save:
        try:
            config.save()
        except OSError:
            pass


def _parse(text: str) -> date | None:
    from . import gem

    return gem.parse_date(text)


def cycle_days(pred: Prediction, today: date) -> dict[date, str]:
    """给日历用：{日期: 标记}。

    标记只有两种（月历上就按这两种上色）：

        period  实际记录下来的经期（含往前推的几轮，方便她核对）
        next    按周期推算的**预计**经期
    """
    out: dict[date, str] = {}
    if pred.last_start is None:
        return out

    # 把过去几个月的经期也标出来，方便她核对"上次是不是这几天"
    cursor = pred.last_start
    for _ in range(3):
        for i in range(pred.period_days):
            out[cursor + timedelta(days=i)] = "period"
        cursor = cursor - timedelta(days=pred.cycle)

    if pred.next_start:
        # 下次的经期是"预测"，用单独的颜色（和实际记录区分开）
        for i in range(pred.period_days):
            out[pred.next_start + timedelta(days=i)] = "next"
    return out


def validate_cycle(value) -> tuple[bool, str]:
    """校验周期长度。返回 (可以吗, 说明)。"""
    try:
        n = int(value)
    except (TypeError, ValueError):
        return False, "周期长度要填数字（天）"
    if not (MIN_CYCLE <= n <= MAX_CYCLE):
        return False, (f"周期长度一般在 {MIN_CYCLE}-{MAX_CYCLE} 天之间。"
                       f"填 {n} 天的话预测会不准——"
                       f"要么改成实际天数，要么先留空用默认的 {DEFAULT_CYCLE} 天。")
    return True, ""


def validate_period(value) -> tuple[bool, str]:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return False, "经期天数要填数字（天）"
    if not (MIN_PERIOD <= n <= MAX_PERIOD):
        return False, f"经期天数一般在 {MIN_PERIOD}-{MAX_PERIOD} 天之间"
    return True, ""


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from .config import Config

    # ---- 还没记录 ----
    cfg = Config()
    p = predict(cfg, date(2026, 10, 4))
    assert p.last_start is None
    assert p.phase == "unknown"
    assert p.message().strip()
    assert cycle_days(p, date(2026, 10, 4)) == {}

    # ---- 周期第 1 天 ----
    cfg = Config(cycle_last_start="2026-10-01", cycle_length=28, cycle_period_days=5)
    p = predict(cfg, date(2026, 10, 1))
    assert p.phase == "period", p.phase
    assert p.day_of_cycle == 1, p.day_of_cycle
    # 当前这次经期：10-01 开始，5 天 → 10-05 结束
    assert p.period_start == date(2026, 10, 1), p.period_start
    assert p.period_end == date(2026, 10, 5), p.period_end
    # 下一次经期：10-29 开始，11-02 结束
    assert p.next_start == date(2026, 10, 29), p.next_start
    assert p.next_end == date(2026, 11, 2), p.next_end
    assert p.days_until == 28
    assert p.late_days == 0

    # ---- 经期第 5 天还在经期 ----
    p = predict(cfg, date(2026, 10, 5))
    assert p.phase == "period", p.phase
    assert p.day_of_cycle == 5
    # 第 6 天就不算了
    assert predict(cfg, date(2026, 10, 6)).phase != "period"

    # ---- 排卵日 / 易孕期：**已经整体去掉**，这里的断言反过来守它 ----
    #
    # 这几条以前是"算出排卵日/易孕期"，现在改成"**不许再出现**"：
    # 一旦有人手滑把它们加回来（哪怕是复制粘贴），这里就会红。
    p = predict(cfg, date(2026, 10, 15))
    assert not hasattr(p, "ovulation"), "Prediction 不该再有 ovulation 字段"
    assert not hasattr(p, "fertile_from"), "Prediction 不该再有 fertile_from 字段"
    assert not hasattr(p, "fertile_to"), "Prediction 不该再有 fertile_to 字段"
    for d in (date(2026, 10, 9), date(2026, 10, 12), date(2026, 10, 15),
              date(2026, 10, 16)):
        assert predict(cfg, d).phase not in ("fertile", "ovulation"), d
    assert "排卵" not in predict(cfg, date(2026, 10, 15)).message()
    assert "易孕" not in predict(cfg, date(2026, 10, 15)).message()
    # 阶段标签里也不该再有这两个词
    assert not any("排卵" in v or "易孕" in v for v in PHASE_LABELS.values())

    # ---- 临近经期 ----
    p = predict(cfg, date(2026, 10, 26))
    assert p.phase == "waiting", p.phase
    assert p.days_until == 3, p.days_until
    assert "3 天" in p.message()

    # ---- 记录太旧：不说"你推迟了"，只说"该更新了" ----
    # 这是这个模块最重要的一个判断。程序分不清"这个月晚了"和"忘记录入"，
    # 所以旧记录只提示更新，不替她下"推迟"的结论。
    p = predict(cfg, date(2026, 12, 5))
    assert p.cycles_ahead >= 2, p.cycles_ahead
    assert p.is_stale(), f"12-05 距离 10-01 已经过了两轮，应该判为记录太旧"
    assert "更新" in p.message(), p.message()
    assert "推迟" not in p.message(), "别替她说'推迟了'——分不清是晚了还是忘了记"
    # days_until 永远是正的（推进到未来才停）
    assert p.days_until is not None and p.days_until > 0, p.days_until

    # 刚记录完一两轮内不算旧
    assert not predict(cfg, date(2026, 10, 20)).is_stale()
    assert not predict(cfg, date(2026, 10, 28)).is_stale()
    # 过了一轮但不到两轮，也还不算旧（一个月的容错是合理的）
    assert not predict(cfg, date(2026, 11, 10)).is_stale(), "不到两轮不该报旧"

    # ---- 推迟的文案单独测（手工构造，因为自动推进后 late_days 恒为 0）----
    manual = Prediction(last_start=date(2026, 10, 1), cycle=28, period_days=5,
                        period_start=date(2026, 10, 1), period_end=date(2026, 10, 5),
                        next_start=date(2026, 10, 29), next_end=date(2026, 11, 2),
                        days_until=-2, late_days=2, phase="luteal",
                        phase_label="黄体期", day_of_cycle=31)
    assert manual.is_delayed() and not manual.is_notably_late()
    assert "别紧张" in manual.message(), manual.message()
    manual2 = Prediction(last_start=date(2026, 10, 1), cycle=28, period_days=5,
                         days_until=-12, late_days=12, phase="luteal",
                         phase_label="黄体期", day_of_cycle=41)
    assert manual2.is_notably_late()
    assert "医生" in manual2.message(), manual2.message()

    # ---- 预计日过了但没到窗口 → 算推迟，而不是当成新一轮 ----
    # 10-01 + 28 = 10-29，窗口是 10-29~11-02
    p = predict(cfg, date(2026, 10, 28))
    assert p.days_until == 1 and p.late_days == 0, (p.days_until, p.late_days)
    # 10-30 落在窗口内 → 新周期已开始，day_of_cycle 从 10-29 起算
    p = predict(cfg, date(2026, 10, 30))
    assert p.day_of_cycle == 2, p.day_of_cycle
    assert p.phase == "period", p.phase
    assert p.late_days == 0, p.late_days

    # ---- 隔了两个月才打开：日号仍然要算对 ----
    # 上次记录 10-01，她在 12-05 打开，应该已经自动往后推了两轮
    p = predict(cfg, date(2026, 12, 5))
    # 10-01 → 10-29 → 11-26 → 12-24，所以 12-05 落在 11-26 那一轮里
    assert p.next_start == date(2026, 12, 24), p.next_start
    assert p.day_of_cycle == (date(2026, 12, 5) - date(2026, 11, 26)).days + 1, p.day_of_cycle
    assert p.cycle == 28

    # ---- 填成未来：不预测，也不报错 ----
    cfg2 = Config(cycle_last_start="2030-01-01", cycle_length=28)
    p2 = predict(cfg2, date(2026, 10, 4))
    assert p2.phase == "unknown"
    assert "未来" in p2.phase_label, p2.phase_label

    # ---- 参数越界要用默认值，不能照着离谱输入算 ----
    cfg3 = Config(cycle_last_start="2026-10-01", cycle_length=999,
                  cycle_period_days=99)
    p3 = predict(cfg3, date(2026, 10, 4))
    assert p3.cycle == DEFAULT_CYCLE, p3.cycle
    assert p3.period_days == DEFAULT_PERIOD, p3.period_days

    # ---- 校验函数 ----
    assert validate_cycle(28)[0] is True
    assert validate_cycle("28")[0] is True
    assert validate_cycle(5)[0] is False
    assert validate_cycle(999)[0] is False
    assert validate_cycle("abc")[0] is False
    assert validate_cycle(None)[0] is False
    assert "18-60" in validate_cycle(5)[1]
    assert validate_period(5)[0] is True
    assert validate_period(1)[0] is False
    assert validate_period(20)[0] is False

    # ---- 日历标记 ----
    cfg4 = Config(cycle_last_start="2026-10-01", cycle_length=28, cycle_period_days=5)
    p4 = predict(cfg4, date(2026, 10, 15))
    marks = cycle_days(p4, date(2026, 10, 15))
    assert marks.get(date(2026, 10, 1)) == "period"
    assert marks.get(date(2026, 10, 5)) == "period"
    assert marks.get(date(2026, 10, 29)) == "next"
    # **只有这两种**：排卵/易孕的标记不该再出现
    assert set(marks.values()) <= {"period", "next"}, sorted(set(marks.values()))
    assert marks.get(date(2026, 10, 15)) is None
    assert marks.get(date(2026, 10, 12)) is None
    # 过去的经期也要标（往前推两轮）
    assert marks.get(date(2026, 9, 3)) == "period"
    # 只返回日期，不返回别的类型
    assert all(isinstance(k, date) for k in marks)

    # ---- mark() 会写进配置 ----
    cfg5 = Config()
    mark(cfg5, date(2026, 10, 1), save=False)
    assert cfg5.cycle_last_start == "2026-10-01"
    assert predict(cfg5, date(2026, 10, 2)).phase == "period"

    # ---- 每种阶段的文案都不能是空的 ----
    for day in (1, 6, 12, 15, 25, 28, 35):
        q = predict(cfg, date(2026, 9, 30) + timedelta(days=day))
        assert q.message().strip(), f"第 {day} 天没有文案"
        assert q.phase_label.strip()

    print("cycle selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
