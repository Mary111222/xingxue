"""交互小工具：提问、暂停、按 ID 或关键词找一道题。

单独成模块是为了避免循环导入：
commands.py / commands_web.py / cli.py 都要用这些函数。
"""

from __future__ import annotations

import sys

from . import ui
from .db import Problem, Store


class InputClosed(Exception):
    """输入流结束了（管道读完 / 她按了 Ctrl+D）。

    为什么要专门定义一个异常：
        之前 ask() 在 EOF 时返回空串，于是 review 的 while 循环会
        把"空串"当成"无效输入"再问一次，而输入流已经关了 →
        **无限循环刷屏**。实测（管道喂入）180 秒都没退出。
        现在 EOF 会抛出来，由调用方决定"当作退出"还是别的处理。
    """


# pause() 不抛异常（暂停失败不该中断流程），但要留个标记让调用方能察觉
input_exhausted = False


def interactive() -> bool:
    """当前是不是"有人能看着屏幕回答"。

    判据是 **stdin 和 stdout 都连着终端**，两个都要：
        - stdout 被重定向（> file、管道给别人）→ 她看不到提示，问了也白问
        - stdin 不是终端（< file、喂管道）→ 没人能回答
    踩过的坑：只看 stdin.isatty() 不够。PowerShell 里
    `python x.py | Select-Object` 的 stdin 仍然是终端（管道在 PowerShell 层），
    于是程序会兴致勃勃地弹一个没人看得见的提示然后 EOF。
    """
    try:
        stdin_ok = sys.stdin is not None and sys.stdin.isatty()
        stdout_ok = sys.stdout is not None and sys.stdout.isatty()
        return bool(stdin_ok and stdout_ok)
    except (AttributeError, ValueError):
        return False


def ask_or(prompt: str, default: str = "") -> str:
    """需要交互时才问；非交互环境直接用默认值。

    适合"有默认值、问不问都行"的参数（比如初始化里的几个可选项）。
    """
    if not interactive():
        return default
    return ask(prompt, default)


def ask(prompt: str, default: str = "") -> str:
    """问一句。输入流结束会抛 InputClosed（调用方或入口必须处理）。"""
    suffix = f" [{default}]" if default else ""
    try:
        raw = input(f"{ui.c('?', 'hotpink')} {prompt}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt) as exc:
        print()
        raise InputClosed() from exc
    return raw or default


def ask_choice(prompt: str, valid: set[str], default: str = "") -> str:
    while True:
        raw = ask(prompt, default).lower()
        if raw in valid:
            return raw
        if not raw and default:
            return default
        ui.warn(f"请输入 {'/'.join(sorted(valid))}")


def pause(message: str = "回车继续") -> None:
    """等一个回车。非交互环境直接跳过（**不消费输入**）。

    两个坑都踩过：
        1. 如果只是 try/except 兜住 EOF，非交互环境下 input() 仍然会
           **把喂进来的内容吃掉**——比如管道喂的是 "q"，会被 pause 吃掉，
           后面的 ask 就只能拿到 EOF，本来正常的退出变成"失败"。
        2. 暂停失败不该让复习中断，所以这里不抛异常；
           但要留一个 input_exhausted 标记，调用方才知道"输入没了"，
           否则会一直空转（这正是之前无限刷屏 bug 的成因）。
    """
    global input_exhausted
    if not interactive():
        return
    try:
        input(ui.c(f"  {message}…", "grey"))
    except (EOFError, KeyboardInterrupt):
        print()
        input_exhausted = True


def reset_input_state() -> None:
    global input_exhausted
    input_exhausted = False


def input_is_exhausted() -> bool:
    return input_exhausted


def resolve(store: Store, token: str) -> Problem | None:
    """按 ID 或关键词找到一道题。"""
    token = (token or "").strip()
    if not token:
        return None
    if token.isdigit():
        return store.get(int(token))
    matches = store.search(token, include_archived=True)
    if not matches:
        return None
    if len(matches) == 1:
        return matches[0]
    # 多个结果时优先标题完全一致的
    for item in matches:
        if item.title == token:
            return item
    return matches[0]
