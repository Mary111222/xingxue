"""便携模式：数据目录搬家。

## 数据目录是怎么定的

启动器（Rust `backend.rs::resolve_data_home`）依次找：

    exe.parent/her.local.json
    exe.parent/resources/her.local.json
    项目根/her.local.json

读里面的 `{ "home": "…" }`，用环境变量 `HER_REVIEW_HOME` 传给后端。
所以"搬家"要做两件事：**把数据复制过去** + **把 her.local.json 指过去**。

## 不搬什么

`.app-window`（WebView2 的缓存，几百 MB）、`缓存/`、`备份/` 里的旧包 ——
它们是可再生的。搬过去只会让复制很慢，而且 WebView2 缓存换路径本来就该重建。
（`备份/` 保留：那是她的保险，万一新位置出问题还能退。）
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

# 这些是可再生的，不搬
SKIP_DIRS = {".app-window", "缓存", "__pycache__"}
SKIP_SUFFIX = {".log", ".pid"}


def exe_dir() -> Path:
    """安装目录（打包后 exe 所在；开发态是项目根）。"""
    exe = Path(sys.executable)
    here = exe.parent
    # 打包后：…/resources/backend/xingxue-backend.exe → 安装目录在上三层
    for up in (0, 1, 2, 3):
        cand = here
        for _ in range(up):
            cand = cand.parent
        if (cand / "xingxue.exe").is_file():
            return cand
    return here


def where(home: Path) -> dict:
    """当前状态：数据在哪、多大、配置文件在哪。"""
    home = Path(home)

    ed = exe_dir()
    conf = ed / "her.local.json"
    size = 0
    files = 0
    if home.is_dir():
        for p in home.rglob("*"):
            if p.is_file():
                size += p.stat().st_size
                files += 1
    return {"home": str(home), "exists": home.is_dir(),
            "files": files, "mb": round(size / 1024 / 1024, 1),
            "exe_dir": str(ed),
            "config_path": str(conf), "config_exists": conf.is_file(),
            "portable": conf.is_file()}


def _copy(src: Path, dst: Path) -> dict:
    """复制数据目录（跳过可再生的那些）。"""
    copied = 0
    skipped = 0
    dst.mkdir(parents=True, exist_ok=True)
    for item in sorted(src.iterdir()):
        if item.name in SKIP_DIRS:
            skipped += 1
            continue
        target = dst / item.name
        if item.is_dir():
            # 目录内部也过滤
            def _ignore(_dir, names):
                return [n for n in names if n in SKIP_DIRS]
            shutil.copytree(item, target, dirs_exist_ok=True, ignore=_ignore)
            copied += 1
        elif item.is_file():
            if item.suffix in SKIP_SUFFIX:
                skipped += 1
                continue
            shutil.copy2(item, target)
            copied += 1
    return {"copied": copied, "skipped": skipped}


def move(home: Path, target: str, confirm: bool = False) -> dict:
    """把数据复制到 `target`，并把 her.local.json 指过去。

    **默认只复制、不删除**（原目录留着）—— 搬家出问题时原数据还在。
    必须 `confirm=True` 才真的动手（界面上是二次确认）。
    """
    home = Path(home)
    if not confirm:
        return {"ok": False, "error": "这是要动数据目录的操作，需要确认"}
    raw = str(target).strip()
    if not raw:
        return {"ok": False, "error": "给个目标目录"}
    dst = Path(raw).expanduser()
    # **必须写完整路径**：相对路径会按后端进程的当前目录解析 ——
    # 打包后那是 resources/backend/，于是数据被搬到程序内部，
    # her.local.json 也会指到一个莫名其妙的地方。
    # （我自测时就是这么把指针指错的，幸好只复制不删除。）
    if not dst.is_absolute():
        return {"ok": False,
                "error": "请写完整路径（比如 D:\\形学数据）—— 相对路径会按程序目录解析"}
    try:
        dst = dst.resolve()
    except OSError:
        pass
    if dst == home.resolve():
        return {"ok": False, "error": "目标就是当前目录，不用搬"}
    if home.resolve() in dst.parents:
        return {"ok": False, "error": "目标不能放在当前数据目录里面（会自己套自己）"}
    if dst.is_dir() and any(dst.iterdir()):
        # 允许，但要说清楚（可能覆盖同名文件）
        pass
    try:
        got = _copy(home, dst)
    except OSError as exc:
        return {"ok": False, "error": f"复制失败：{exc.__class__.__name__}: {exc}"}

    # **先校验复制结果再改指针**：搬过去的东西里至少有 config.json 或
    # 数据库才算成功。不校验的话，复制不完整也会把程序指过去，
    # 表现是"打开之后数据全没了"（其实是没搬过去）。
    names = {x.name for x in dst.iterdir()} if dst.is_dir() else set()
    if not ({"config.json", "data.sqlite3"} & names):
        return {"ok": False,
                "error": f"复制到 {dst} 的东西里没有配置文件或数据库，"
                         f"先不改数据指针（原数据没动）"}

    ed = exe_dir()
    conf = ed / "her.local.json"
    try:
        conf.write_text(json.dumps({"home": str(dst)}, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    except OSError as exc:
        return {"ok": False,
                "error": f"数据复制好了，但写不了 {conf.name}（{exc.__class__.__name__}）"
                         f"—— 手工把 home 改成 {dst} 也行"}
    return {"ok": True, "from": str(home), "to": str(dst),
            "copied": got["copied"], "config": str(conf),
            "note": "**重启应用**才会用新目录。原来的数据没删，随时可以改回来。"}


def _selftest() -> None:
    import tempfile

    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as td:
        home = Path(td) / "src"
        home.mkdir()
        (home / "config.json").write_text('{"name":"测试"}', encoding="utf-8")
        (home / "data.sqlite3").write_bytes(b"x" * 100)
        (home / ".app-window").mkdir()
        (home / ".app-window" / "cache").write_bytes(b"y" * 5000)
        (home / "缓存").mkdir()
        (home / "缓存" / "x.json").write_text("{}", encoding="utf-8")

        assert where(home)["files"] >= 4, where(home)
        r = move(home, str(Path(td) / "dst"))
        assert not r["ok"] and "确认" in r["error"], r
        r = move(home, str(home))
        assert not r["ok"], r
        r = move(home, str(Path(td) / "dst"), confirm=True)
        assert r["ok"], r
        dst = Path(r["to"])
        assert (dst / "config.json").is_file(), "数据没复制过去"
        assert not (dst / ".app-window").exists(), "缓存不该搬"
        assert not (dst / "缓存").exists(), "缓存目录不该搬"
        print("portable selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
