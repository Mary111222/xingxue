"""证据层：来源指纹、输入预算、脱敏、质量记录。

这一层的想法借自 VeoStudyHub 的技术方案（"证据优先 Evidence-first"）：
**凡是引用外部内容的产出，都必须能回答三个问题**——
    1. 这份内容是从哪来的？（来源）
    2. 生成期间来源变了吗？（指纹复核）
    3. 进模型/进数据库的东西有没有超预算、有没有夹带密钥？（预算与脱敏）

对应到 her 这个程序：
    视频总结的结果会写进题目的 note，如果不做这几件事，会出现这些真实问题：
    - 视频被 UP 主重新上传过，笔记里的事实已经过时，但没人知道它对的是哪一版
    - 转写文本几万字，整段塞进数据库，note 字段膨胀到没法维护
    - BiliSum 的报错信息里可能带 API Key，跟着笔记一起存进去、一起导出给别人

所以这里提供四个小工具，都不依赖任何第三方库：
    fingerprint(text)      内容指纹（SHA-256，规范化后计算，避免空白差异导致漂移）
    budget(text, limit)    按预算裁剪，并返回"裁掉了多少"
    redact(text)           清掉密钥类片段（Bearer / api_key / 长随机串）
    QualityReport          记录一次生成的过滤/回退统计，好让她知道结果有多可信
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any


# --------------------------------------------------------------------------
# 指纹
# --------------------------------------------------------------------------

def normalize(text: str) -> str:
    """规范化：统一换行、去掉行尾空白、压缩连续空行。

    为什么要先规范化再算指纹：
        同一份内容经过一次 round-trip（存库再读出）可能多出/少掉一些空白，
        直接对原文算指纹会"看起来变了但实际没变"，导致误判来源变化。
    """
    if not text:
        return ""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = unicodedata.normalize("NFC", text)
    lines = [line.rstrip() for line in text.split("\n")]
    out: list[str] = []
    blank = 0
    for line in lines:
        if line:
            blank = 0
            out.append(line)
        else:
            blank += 1
            if blank <= 1:  # 连续空行压成一个
                out.append("")
    return "\n".join(out).strip()


def fingerprint(*parts: str) -> str:
    """给一段内容（或多段拼起来）算指纹。返回 16 位十六进制（够用且好读）。

    用 SHA-256 而不是 md5：这里不是防碰撞场景，只是保持一致性与"看上去可信"，
    但既然标准库都有，没理由用弱的。
    """
    payload = "\x1f".join(normalize(p) for p in parts if p is not None)
    if not payload:
        return ""
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return digest[:16]


def fingerprint_dict(data: dict) -> str:
    """给结构化数据算指纹。sort_keys 保证字段顺序变化不会造成指纹漂移。"""
    if not data:
        return ""
    try:
        payload = json.dumps(data, ensure_ascii=False, sort_keys=True, default=str)
    except (TypeError, ValueError):
        payload = str(data)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def looks_changed(old: str, new: str) -> bool:
    """两份内容算不算"变了"（按规范化后的指纹判断）。"""
    if not old or not new:
        return bool(old) != bool(new)
    return fingerprint(old) != fingerprint(new)


# --------------------------------------------------------------------------
# 输入预算
# --------------------------------------------------------------------------

# 各字段的字符预算。数字来自实测：中文技术视频的转写，
# 30 分钟左右大约 9000-15000 字，知识笔记通常 2000-5000 字。
# 定这些预算的目的不是省磁盘，而是不让单个字段无限膨胀到无法维护。
BUDGETS: dict[str, int] = {
    "transcript": 60000,   # 完整转写（长视频会很长，给足）
    "note": 20000,         # 知识笔记
    "overview": 8000,      # 口播概览
    "problem_note": 8000,  # 题目上挂的 note（她要天天看，不能太长）
    "memory": 500,         # 私人记忆
}


@dataclass
class BudgetResult:
    text: str
    original_chars: int = 0
    kept_chars: int = 0
    truncated: bool = False
    kind: str = ""

    def summary(self) -> str:
        if not self.truncated:
            return f"{self.kind} {self.kept_chars} 字（未超预算）"
        return (f"{self.kind} {self.original_chars} → {self.kept_chars} 字"
                f"（超预算，已按 {self.kind} 上限裁剪）")


def budget(text: str, kind: str = "note", *, limit: int | None = None) -> BudgetResult:
    """按预算裁剪文本。

    裁剪策略：优先在段落边界切，其次是句子边界，最后才硬切。
    直接按字符数硬切会把一句话劈成两半，读起来像坏数据。
    """
    text = text or ""
    cap = limit if limit is not None else BUDGETS.get(kind, 20000)
    original = len(text)
    if original <= cap:
        return BudgetResult(text=text, original_chars=original, kept_chars=original,
                            truncated=False, kind=kind)

    cut = text[:cap]
    # 1) 段落边界
    for mark in ("\n\n", "\n", "。", "！", "？", ". ", "；", ";"):
        position = cut.rfind(mark)
        if position > cap * 0.6:  # 别为了找边界砍掉一大半
            cut = cut[:position + len(mark)]
            break
    cut = cut.rstrip() + f"\n\n…（原文 {original} 字，超出 {kind} 预算已裁剪）"
    return BudgetResult(text=cut, original_chars=original, kept_chars=len(cut),
                        truncated=True, kind=kind)


# --------------------------------------------------------------------------
# 脱敏
# --------------------------------------------------------------------------

# 常见密钥形态。
#
# 顺序有讲究：**先按"值的形状"清，再用"键名 = 值"兜底**。
# 反过来（先跑 assign）会在值里留下 sk- 前缀那种尾巴，形成绕过路径。
# 用 (?<![A-Za-z0-9]) 而不是 \b：llm_api_key 里的下划线属于 word 字符，
# \b 在它前面不成立，会漏掉——这是实测踩过的。
_SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("bearer", re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{12,}")),
    ("sk_prefix", re.compile(r"(?<![A-Za-z0-9])sk-[A-Za-z0-9._\-]{12,}")),
    ("long_hex", re.compile(r"(?<![A-Za-z0-9])[A-Fa-f0-9]{32,}(?![A-Za-z0-9])")),
    # 兜底：任何 "key/token/secret/password = 某个不太短的值"
    ("assign", re.compile(
        r"(?i)(?<![A-Za-z0-9])(api[_-]?key|access[_-]?token|secret|password|passwd|pwd)"
        r"\s*[:=]\s*[\"']?([A-Za-z0-9._\-]{8,})")),
    ("url_token", re.compile(r"(?i)([?&](?:token|access_token|key|apikey)=)[^&\s]+")),
]

REDACTED = "[已脱敏]"


def redact(text: str) -> tuple[str, int]:
    """清掉疑似密钥的片段。返回 (处理后的文本, 清掉几处)。

    为什么必须要做：BiliSum 的报错、日志、以及它返回的 settings 片段里
    都可能带 API Key；这些文本一旦跟着视频笔记写进 note，
    再被 her export 导出、发给她同学，就等于把 Key 送出去了。
    """
    if not text:
        return text or "", 0
    count = 0

    def sub(pattern: re.Pattern[str], replacement, source: str) -> str:
        nonlocal count
        result, n = pattern.subn(replacement, source)
        count += n
        return result

    out = text
    for name, pattern in _SECRET_PATTERNS:
        if name == "bearer":
            out = sub(pattern, f"Bearer {REDACTED}", out)
        elif name == "assign":
            # 保留键名，只清值：这样日志还能看出"是哪个 Key 没配"
            out = sub(pattern, lambda m: f"{m.group(1)}={REDACTED}", out)
        elif name == "url_token":
            out = sub(pattern, lambda m: f"{m.group(1)}{REDACTED}", out)
        else:
            out = sub(pattern, REDACTED, out)
    return out, count


# --------------------------------------------------------------------------
# 质量报告
# --------------------------------------------------------------------------

@dataclass
class QualityReport:
    """一次生成的质量记录。

    存在的意义：AI 出来的东西**不该假装完整**。
    如果这次是靠 B 站字幕而不是 ASR、如果 LLM 没配置所以只有转写，
    这些都要如实写下来给她看，而不是产出一份看起来很完整实际没依据的笔记。
    """
    task_id: str = ""
    title: str = ""
    status: str = ""
    transcript_source: str = ""     # subtitle / asr / unknown
    transcript_chars: int = 0
    note_chars: int = 0
    overview_chars: int = 0
    has_note: bool = False
    has_overview: bool = False
    llm_used: bool = False
    degraded: list[str] = field(default_factory=list)   # 降级/回退原因
    warnings: list[str] = field(default_factory=list)
    source_fingerprint: str = ""
    generated_at: str = ""
    elapsed_seconds: float = 0.0

    def source_label(self) -> str:
        return {"subtitle": "B 站字幕", "asr": "语音识别（ASR）",
                "unknown": "未知"}.get(self.transcript_source, self.transcript_source or "未知")

    def confidence(self) -> tuple[str, str]:
        """给一个粗略的"可信度"判断：(等级, 颜色)。"""
        if self.has_note and self.llm_used and not self.degraded:
            return "高", "brightgreen"
        if self.has_note or self.has_overview:
            return "中", "gold"
        if self.transcript_chars:
            return "低（只有转写）", "orange"
        return "无内容", "red"

    def lines(self) -> list[str]:
        from . import ui

        level, color = self.confidence()
        out = [
            ui.c("视频      ", "grey") + (self.title or "（无标题）"),
            ui.c("可信度    ", "grey") + ui.c(level, color, "bold")
            + ui.c(f"    转写来源：{self.source_label()}", "grey"),
        ]
        detail = []
        if self.transcript_chars:
            detail.append(f"转写 {self.transcript_chars} 字")
        if self.note_chars:
            detail.append(f"笔记 {self.note_chars} 字")
        if self.overview_chars:
            detail.append(f"概览 {self.overview_chars} 字")
        if detail:
            out.append(ui.c("内容量    ", "grey") + ui.c("　".join(detail), "plum"))
        if self.elapsed_seconds:
            out.append(ui.c("耗时      ", "grey")
                       + ui.c(f"{self.elapsed_seconds:.0f} 秒", "grey"))
        if self.source_fingerprint:
            out.append(ui.c("来源指纹  ", "grey")
                       + ui.c(self.source_fingerprint, "plum")
                       + ui.c("   （内容变了这个值就变）", "grey"))
        if not self.llm_used:
            out.append(ui.c("说明      ", "grey")
                       + ui.c("这次没有用大模型（她的 BiliSum 里 llm_enabled=false），"
                              "产出的是转写 + 结构化概览", "gold"))
        for item in self.degraded:
            out.append(ui.c("降级      ", "grey") + ui.c(item, "gold"))
        for item in self.warnings:
            out.append(ui.c("注意      ", "grey") + ui.c(item, "orange"))
        return out

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "QualityReport":
        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        return cls(**{k: v for k, v in (data or {}).items() if k in known})


def build_report(summary: Any, *, task_id: str = "", elapsed: float = 0.0,
                 llm_used: bool = False, transcript_source: str = "",
                 degraded: list[str] | None = None,
                 warnings: list[str] | None = None) -> QualityReport:
    """从一次 BiliSum 的结果构造质量报告。"""
    note = getattr(summary, "markdown", "") or ""
    overview = getattr(summary, "overview", "") or ""
    transcript = getattr(summary, "transcript", "") or ""

    # 转写来源：BiliSum 优先用 B 站字幕，拿不到才走 ASR；
    # 从概览/笔记里能看出痕迹（字幕通常更干净、句子完整）
    source = transcript_source
    if not source:
        source = "unknown"

    report = QualityReport(
        task_id=task_id or getattr(summary, "task_id", ""),
        title=getattr(summary, "title", "") or "",
        status=getattr(summary, "status", "") or "",
        transcript_source=source,
        transcript_chars=len(transcript),
        note_chars=len(note),
        overview_chars=len(overview),
        has_note=bool(note.strip()),
        has_overview=bool(overview.strip()),
        llm_used=llm_used,
        degraded=list(degraded or []),
        warnings=list(warnings or []),
        source_fingerprint=fingerprint(note, overview, transcript),
        generated_at=datetime.now().isoformat(timespec="seconds"),
        elapsed_seconds=elapsed,
    )
    if not report.has_note and not report.has_overview:
        report.warnings.append("这次没拿到笔记也没拿到概览，只有转写")
    return report


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from . import ui

    ui.use_color(False)

    # ---- 指纹 ----
    assert fingerprint("你好") == fingerprint("你好"), "同样内容指纹要一致"
    assert fingerprint("你好") != fingerprint("你好啊"), "不同内容指纹要不同"
    assert fingerprint("a\r\nb") == fingerprint("a\nb"), "换行差异不该让指纹变"
    assert fingerprint("a  \nb") == fingerprint("a\nb"), "行尾空白不该让指纹变"
    assert fingerprint("a\n\n\n\nb") == fingerprint("a\n\nb"), "连续空行要压缩"
    assert fingerprint("") == ""
    assert len(fingerprint("x")) == 16
    assert not looks_changed("同一段话", "同一段话")
    assert looks_changed("旧的", "新的")
    assert looks_changed("", "有内容")
    assert fingerprint_dict({"b": 1, "a": 2}) == fingerprint_dict({"a": 2, "b": 1}), \
        "字段顺序不该影响指纹"

    # ---- 预算 ----
    short = budget("短文本", "note")
    assert not short.truncated and short.text == "短文本"
    long_text = "第一段。" * 200 + "\n\n" + "第二段。" * 200
    cut = budget(long_text, "note", limit=100)
    assert cut.truncated and len(cut.text) < len(long_text)
    assert "超出" in cut.text, "裁剪后要留一句说明"
    assert cut.original_chars == len(long_text)
    # 裁剪要切在句子/段落边界，不能把一句话劈开
    assert cut.text.startswith("第一段。"), cut.text[:40]
    # 默认预算走 BUDGETS
    assert budget("x", "memory", limit=1).kept_chars <= 30

    # ---- 脱敏 ----
    cases = [
        ("Authorization: Bearer abcdefghijklmnop1234", "bearer"),
        ("api_key=sk-abcdefghijklmnopqrstuvwxyz", "api"),
        ("llm_api_key: sk-proj-ABCDEFGHIJKLMNOP123456", "assign"),
        ("token: " + "a" * 40, "hex"),
        ("https://x.com/api?access_token=secret123456&page=1", "url"),
    ]
    for text, label in cases:
        cleaned, n = redact(text)
        assert n >= 1, f"{label} 应该被清掉：{text!r} -> {cleaned!r}"
        assert "secret123456" not in cleaned or label == "url", cleaned
    # 正常文本不该被误伤
    plain = "关键：用哈希表存已经见过的值，遍历时先查 target - x"
    assert redact(plain) == (plain, 0), redact(plain)
    # 普通的中文句子和短标识不该被清
    assert redact("her-review 2.0.0 版本") == ("her-review 2.0.0 版本", 0)

    # ---- 质量报告 ----
    class _FakeSummary:
        task_id = "t1"
        title = "单调栈讲解"
        status = "completed"
        markdown = "# 笔记\n\n内容"
        overview = "[00:00] 大家好"
        transcript = "转写内容" * 100

    rep = build_report(_FakeSummary(), llm_used=True, transcript_source="subtitle")
    assert rep.has_note and rep.has_overview
    assert rep.confidence()[0] == "高", rep.confidence()
    assert rep.source_label() == "B 站字幕"
    assert len(rep.source_fingerprint) == 16
    lines = rep.lines()
    assert any("可信度" in ui._strip_ansi(l) for l in lines)

    # 降级要反映在可信度和文案里
    rep2 = build_report(_FakeSummary(), llm_used=False,
                        degraded=["没有配置 LLM，产出转写 + 概览"])
    assert rep2.confidence()[0] == "中", rep2.confidence()
    assert any("降级" in ui._strip_ansi(l) for l in rep2.lines())

    # 空结果
    class _Empty:
        task_id = "t2"
        title = ""
        status = "failed"
        markdown = ""
        overview = ""
        transcript = ""

    rep3 = build_report(_Empty())
    assert rep3.confidence()[0] == "无内容"
    assert rep3.warnings, "空结果要留下警告"

    # 序列化往返
    again = QualityReport.from_dict(rep.to_dict())
    assert again.title == rep.title and again.note_chars == rep.note_chars

    print("evidence selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
