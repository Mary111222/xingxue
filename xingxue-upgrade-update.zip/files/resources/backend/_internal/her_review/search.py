"""刷题不会 → 搜 B 站 → 看视频 / 丢给视频总结器。

这个模块解决一件事：**复习卡壳的那一刻，从「不会」到「看懂」的距离要最短。**

设计原则：
1. 离线优先。搜不了网也要能用——纯 URL 拼装永远可用，`webbrowser` 直接打开。
2. 联网是加分项。能拿到真实搜索列表时，在终端里就能看到标题/UP 主/播放量，
   挑一个再打开，比盲开一个搜索结果页精确得多。
3. 和 BiliSum 打通。搜到的视频可以直接交给视频总结器出摘要 + 知识笔记，
   顺便把知识笔记写回这道题的 note 里——这是「学到的东西沉淀下来」。

B 站搜索接口说明：
    GET https://api.bilibili.com/x/web-interface/search/type
        ?search_type=video&keyword=<关键词>&page=<页码>
    需要先访问一次主站拿 buvid3 cookie，否则可能返回 -412（风控）。
    接口无官方保证，所以任何异常都降级为「直接打开搜索页」。
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.parse
import urllib.request

from . import wbi
from .net import prefer_ipv4

# **导入时就启用 IPv4 优先**：这台机器的 IPv6 连不通，
# 不这么做每个请求都要先等 IPv6 超时（实测 20~30 秒 vs 0.33 秒）。
prefer_ipv4()
import webbrowser
from dataclasses import dataclass, field
from pathlib import Path

from . import ui

SEARCH_PAGE = "https://search.bilibili.com/all?keyword={kw}"
SEARCH_PAGE_VIDEO = "https://search.bilibili.com/video?keyword={kw}"
API_SEARCH = "https://api.bilibili.com/x/web-interface/search/type"
# 搜索结果的缓存时长（秒）。装了 diskcache 才生效，没装就是每次都打网络。
# 10 分钟是权衡：够她反复点同一个知识点时不重复请求，又不会久到结果过时。
CACHE_TTL = 600.0
HOME = "https://www.bilibili.com/"

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

# 训练/算法类搜索的推荐前缀：直接搜 tag 太宽，加上这些词命中率高很多
QUERY_TEMPLATES = {
    "explain": "{kw} 讲解",
    "code": "{kw} 代码 手写",
    "interview": "{kw} 面试",
    "template": "{kw} 模板题",
    "crash": "{kw} 十分钟搞懂",
}

TEMPLATE_LABELS = {
    "explain": "讲解",
    "code": "手写代码",
    "interview": "面试角度",
    "template": "模板题",
    "crash": "速成",
}

# 常见算法/知识点的中文别名，让搜索命中率更高
ALIASES = {
    "dp": "动态规划",
    "dfs": "深度优先搜索",
    "bfs": "广度优先搜索",
    "bst": "二叉搜索树",
    "lru": "LRU 缓存",
    "trie": "字典树",
    "kmp": "KMP 算法",
    "bit": "树状数组",
    "segment tree": "线段树",
    "union-find": "并查集",
    "并查集": "并查集",
    "双指针": "双指针",
    "滑动窗口": "滑动窗口",
    "单调栈": "单调栈",
    "二分查找": "二分查找",
    "回溯": "回溯算法",
    "贪心": "贪心算法",
    "动态规划": "动态规划",
    "拓扑排序": "拓扑排序",
    "二叉树": "二叉树",
    "链表": "链表",
    "哈希表": "哈希表",
    "堆": "堆 优先队列",
    "位运算": "位运算",
    "图": "图论 基础",
    "字符串": "字符串算法",
    "数组": "数组 双指针",
    "分治": "分治算法",
    "设计": "数据结构设计题",
    "记忆化": "记忆化搜索",
}


# --------------------------------------------------------------------------
# 查询构造
# --------------------------------------------------------------------------

def expand(keyword: str) -> str:
    """把缩写/英文标签换成更容易搜到中文教程的说法。"""
    key = keyword.strip()
    return ALIASES.get(key.lower(), ALIASES.get(key, key))


def build_query(keyword: str, template: str | None = None, extra: str = "") -> str:
    """拼出真正丢给 B 站的搜索词。"""
    base = expand(keyword)
    if template and template in QUERY_TEMPLATES:
        base = QUERY_TEMPLATES[template].format(kw=base)
    if extra:
        base = f"{base} {extra}"
    return base.strip()


def search_url(keyword: str, template: str | None = None, video_only: bool = False) -> str:
    query = build_query(keyword, template)
    pattern = SEARCH_PAGE_VIDEO if video_only else SEARCH_PAGE
    return pattern.format(kw=urllib.parse.quote(query))


def queries_for_problem(title: str, tags: list[str], extra: str = "") -> list[tuple[str, str]]:
    """给一道题生成一组「该搜什么」的建议：(显示名, 搜索词)。

    顺序是有讲究的：先搜知识点（最可能找到好教程），再搜整题（找题解）。
    """
    out: list[tuple[str, str]] = []
    seen: set[str] = set()

    def push(label: str, kw: str) -> None:
        kw = build_query(kw, extra=extra)
        if kw and kw not in seen:
            seen.add(kw)
            out.append((label, kw))

    for tag in tags[:3]:
        push(f"知识点 · {tag}", tag)
    if tags:
        push("这题 + 讲解", f"{title} {tags[0]}")
    push("整题题解", title)
    if len(tags) >= 2:
        push("多知识点结合", " ".join(tags[:2]))
    return out


# --------------------------------------------------------------------------
# B 站接口（可能失败，失败就降级）
# --------------------------------------------------------------------------

@dataclass
class Video:
    title: str
    author: str
    bvid: str = ""
    url: str = ""
    duration: str = ""
    play: int = 0
    danmaku: int = 0
    description: str = ""
    pubdate: str = ""
    # 封面图地址。B 站搜索结果里本来就有（字段名 pic），
    # 而且带 @320w_200h 这种尺寸后缀——直接用就能拿到已经缩好的图，
    # 不用我们自己下原图再缩放。
    pic: str = ""

    def play_text(self) -> str:
        if self.play >= 10000:
            return f"{self.play / 10000:.1f}万"
        return str(self.play)

    def duration_text(self) -> str:
        """返回 M:SS 形式的时长。

        为什么要补零：B 站搜索接口返回的 duration 有时是 "7:5" 这种
        （秒的十位被截掉了，7:50 变成 7:5）。上游数据就是坏的，
        真实秒数拿不回来，但至少把格式统一成 "7:05"——
        原样显示成 "7:5" 会让人以为是我们算错了。
        """
        raw = str(self.duration or "").strip()
        if not raw:
            return ""
        if ":" in raw:
            parts = raw.split(":")
            if len(parts) == 2 and parts[1].isdigit():
                return f"{parts[0]}:{int(parts[1]):02d}"
            return raw
        try:
            total = int(raw)
        except ValueError:
            return raw
        if total >= 3600:
            return f"{total // 3600}:{total % 3600 // 60:02d}:{total % 60:02d}"
        return f"{total // 60}:{total % 60:02d}"


@dataclass
class SearchOutcome:
    ok: bool
    videos: list[Video] = field(default_factory=list)
    error: str = ""
    num_results: int = 0


def _strip_html(text: str) -> str:
    """B 站标题里带 <em class="keyword"> 高亮标签，去掉。"""
    out: list[str] = []
    skip = False
    for ch in text:
        if ch == "<":
            skip = True
        elif ch == ">":
            skip = False
        elif not skip:
            out.append(ch)
    return "".join(out).replace("&quot;", '"').replace("&amp;", "&")


def resolve_home(home: Path | str | None = None) -> Path:
    """找出数据目录（cookies 就存在里面）。

    为什么不要求调用方一定传：
        `search_online` 有 5 个调用点（cet6 / commands_web / web_api），
        全都要改签名的话改动面太大，而且漏一个就会静默地不带 cookies。
        所以**自己兜底解析**——传了就用传的，没传就按配置解析链找。

    解析链和命令行入口完全一致（显式指定 > 环境变量 > her.local.json > 默认），
    这一点很重要：不然界面读的 cookies 和命令行读的可能是两份。

    （为什么不能"假设她在项目目录下"：数据目录是可配置的，
      她的就是 `容齐芳的数据/`，写死会在换配置时静默失效。）
    """
    if home is not None:
        return Path(home)
    try:
        from . import config

        return config.resolve_and_load(None).home
    except Exception:
        # 解析不出来也不该让搜索崩掉——退回当前目录，
        # 结果是"没有 cookies"，搜索仍能跑（只是可能被限流）
        return Path(".")

def http_available() -> bool:
    """快速判断网络是否可用（3 秒超时，不阻塞）。

    带上 cookies 一起请求——B 站对未登录的首页请求有时也会插验证页，
    而那个页面不是 200，会被误判成"网络不通"。
    """
    from . import cookies

    try:
        req = urllib.request.Request(
            HOME, headers=cookies.bili_headers(resolve_home()))
        with urllib.request.urlopen(req, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False


def _normalize_pic(raw: object) -> str:
    """把封面图地址整理成能直接用的形式。

    三个坑，都会导致图片加载不出来——而且**不报错**，就是一片空白：
        · `//` 开头（协议相对）：浏览器在 https 页面下通常能猜对，
          但补成 https:// 最稳
        · `http://` 开头：https 页面加载 http 图片会被浏览器
          当成混合内容（mixed content）直接拦掉
        · 空值：有些条目本来就没图，留空让界面显示占位符
    """
    text = str(raw or "").strip()
    if not text:
        return ""
    if text.startswith("//"):
        return "https:" + text
    if text.startswith("http://"):
        return "https://" + text[len("http://"):]
    return text



def search_online(keyword: str, page: int = 1, timeout: int = 8,
                  home: Path | str | None = None) -> SearchOutcome:
    """调 B 站搜索接口拿真实结果。任何异常都返回 ok=False，由调用方降级。

    两处"增强库"在这里真正发挥作用（没装也照常工作）：
        httpx      装了就走连接复用 + 自动重试（deps.http_get_json 内部判断）
        diskcache  装了就把结果缓存 10 分钟——她反复点同一个知识点时不再打网络

    `home`：数据目录。用来读 B 站登录 cookies。不传就自己解析（见 resolve_home）。
    """
    from . import cookies, deps

    home = resolve_home(home)

    query = build_query(keyword)
    cache_key = f"bili-search:{query}:p{page}"

    # 命中缓存就直接返回，连网络都不碰
    cached = deps.cache_get(cache_key, ttl=CACHE_TTL)
    if isinstance(cached, dict) and cached.get("videos") is not None:
        videos = [
            Video(
                title=v.get("title", ""), author=v.get("author", ""),
                bvid=v.get("bvid", ""), url=v.get("url", ""),
                duration=v.get("duration", ""),          # 注意：duration 是字符串
                play=int(v.get("play") or 0),
                danmaku=int(v.get("danmaku") or 0),
                description=v.get("description", ""),
                pubdate=v.get("pubdate", ""),
                pic=v.get("pic", ""),
            )
            for v in cached["videos"]
        ]
        return SearchOutcome(True, videos=videos,
                             num_results=int(cached.get("num_results") or 0))

    # **Origin 这个头不能少**——它是 412 的一个根因。
    #
    # 实测（scripts/_diag_bili412.py）：
    #     只有 User-Agent                → HTTP 412
    #     UA + Referer                   → HTTP 412
    #     UA + Referer + **Origin**      → HTTP 200 ✓ 20 条结果
    # B 站的风控会把"没有 Origin 的跨站 JSON 请求"当成脚本流量挡掉。
    # 缺了它表现为：搜索**永远**失败，提示"被风控挡了，等几分钟再搜"——
    # 但等多久都没用，因为不是频率问题，是请求本身不像浏览器发的。
    #
    # **另一个根因是没带登录 cookies。** 有了 Origin 之后仍会时不时 412，
    # 因为 B 站对"未登录的搜索请求"限流更严。带上登录凭据之后
    # 在它看来就是"一个登录用户在搜"，不再算可疑流量。
    #
    # 所以这里**统一走 cookies.bili_headers()**，不再自己拼：
    # 各处自己拼 headers 的话，早晚会漏掉 cookie 这一项（之前就漏了）。
    headers = cookies.bili_headers(home, extra={
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9",
    })
    # 碰到 412 就退避重试。
    #
    # 实测：412 是**搜索接口独有的临时限流**，等一会儿自己恢复。
    #     视频详情 / 首页 / finger 都还是 200，只有 search/type 被挡；
    #     等 30 秒再试就 200 了（我连续测了十几次触发的）。
    # 退避 0.8s → 1.8s → 2.8s，最多 3 次——短时限流她完全感觉不到。
    params = {"search_type": "video", "keyword": query, "page": str(page)}
    ok = False
    payload: dict = {}
    error = ""
    last_status = 0
    for attempt in range(3):
        if attempt:
            time.sleep(0.8 + attempt)      # 0.8 → 1.8 → 2.8
        ok, payload, error = deps.http_get_json(
            API_SEARCH, headers=headers, params=params,
            timeout=float(timeout),
        )
        if ok:
            break
        # 只有"被限流"才值得重试；域名不通之类的重试也没用
        last_status = 0
        if "412" in str(error):
            last_status = 412
        elif "429" in str(error):
            last_status = 429
        if not last_status:
            break

    if not ok:
        # 错误信息要说清楚"是限流、等一会儿自己会好"，
        # 不要让她以为程序坏了。
        if last_status in (412, 429):
            return SearchOutcome(
                False,
                error=(f"B 站搜索接口临时限流了（HTTP {last_status}）。"
                       f"等半分钟左右自己会恢复——"
                       f"刚才连试了 3 次都没过，说明这次挡得比较紧。"
                       f"下面的搜索链接可以直接点开用。"),
            )
        return SearchOutcome(False, error=_friendly_error(error, home))

    if payload.get("code") != 0:
        return SearchOutcome(False, error=f"B 站接口 code={payload.get('code')} {payload.get('message', '')}")

    data = payload.get("data") or {}
    results = data.get("result") or []
    videos: list[Video] = []
    for item in results:
        if item.get("type") != "video":
            continue
        bvid = item.get("bvid", "")
        videos.append(
            Video(
                title=_strip_html(item.get("title", "")).strip(),
                author=item.get("author", ""),
                bvid=bvid,
                url=item.get("arcurl") or (f"https://www.bilibili.com/video/{bvid}" if bvid else ""),
                duration=item.get("duration", ""),
                play=int(item.get("play") or 0),
                danmaku=int(item.get("danmaku") or 0),
                description=_strip_html(item.get("description", "")).strip(),
                pubdate=str(item.get("pubdate") or ""),
                pic=_normalize_pic(item.get("pic", "")),
            )
        )

    # 写缓存（装没装 diskcache 都能调，没装时它就是个空操作）
    deps.cache_set(cache_key, {
        "videos": [
            {"title": v.title, "author": v.author, "bvid": v.bvid, "url": v.url,
             "duration": v.duration, "play": v.play, "danmaku": v.danmaku,
             "description": v.description, "pubdate": v.pubdate,
             "pic": v.pic}
            for v in videos
        ],
        "num_results": int(data.get("numResults") or 0),
    })

    return SearchOutcome(True, videos=videos, num_results=int(data.get("numResults") or 0))


def _friendly_error(raw: str, home: Path | str | None = None) -> str:
    """把底层网络错误翻译成她能看懂、**而且能照着做**的话。

    deps.http_get_json 在失败时给的是 "HTTP 412" 或 "ConnectError: ..." 这类，
    直接摆给她看没意义——她需要知道的是"要不要重试、还是去检查网络"。

    **412 要分情况说**（这是这次改的重点）：
        没登录 cookies        → "登录一次就能解决"，指向具体动作
        有 cookies 但没凭据   → 说明那些只是游客标识
        有登录 cookies        → 那才真是临时限流，"等一会儿"

    之前不管哪种情况都只说"等半分钟"——如果她没登录，
    等多久都不会好，这条提示等于误导。
    """
    text = (raw or "").strip()
    low = text.lower()
    if "412" in text:
        from . import cookies

        try:
            state = cookies.status(resolve_home(home))
        except Exception:
            state = {}
        if not state.get("logged_in"):
            if state.get("count"):
                return ("B 站搜索被限流（HTTP 412）。保存的 cookies 里"
                        "**没有登录凭据**（缺 SESSDATA / DedeUserID），"
                        "那些多半只是游客标识。去「搜 B 站」页登录一次"
                        "就能明显好转。")
            return ("B 站搜索被限流（HTTP 412）。**登录一次就能解决**——"
                    "未登录的搜索请求在 B 站那边限流严得多。"
                    "去「搜 B 站」页点「登录获取」。")
        return ("B 站搜索接口临时限流（HTTP 412）——"
                "程序已经自动重试过 3 次了，说明这次挡得比较紧。"
                "等半分钟再点一次搜索就好，下面的链接也能直接用。")
    if "timeout" in low or "timed out" in low:
        return "网络超时，检查一下网络再试"
    if "connect" in low or "unreachable" in low or "getaddrinfo" in low:
        return "连不上 B 站，检查一下网络"
    if text.startswith("HTTP 5"):
        return f"B 站服务器出错（{text}），过会儿再试"
    if "json" in low:
        return "接口返回的不是 JSON（可能被风控）"
    return text or "搜索失败"


# --------------------------------------------------------------------------
# 打开 / 展示
# --------------------------------------------------------------------------


def cookies_probe(home: Path | str | None = None, timeout: int = 10) -> dict:
    """用当前 cookies 打一次真实搜索，看**到底能不能用**。

    为什么需要这个：
        界面上显示"已保存 8 个 cookie"不等于它们有效——
        可能是过期的、可能值对不上、可能只有游客标识。
        **只有真打一次才知道。**

    返回：
        ok           请求本身成功了吗
        logged_in    当前有没有登录凭据
        count        搜索结果条数
        status       HTTP 状态码（412 说明被限流）
        verdict      一句话结论（给界面直接显示）
        hint         下一步该做什么
    """
    from . import cookies, deps

    home = resolve_home(home)
    state = cookies.status(home)

    # 用一个固定的、一定有结果的词，免得"搜不到"被误判成"cookies 无效"
    params = {"search_type": "video", "keyword": "算法", "page": "1"}
    try:
        ok, payload, error = deps.http_get_json(
            API_SEARCH, headers=cookies.bili_headers(home, extra={
                "Accept": "application/json, text/plain, */*",
            }), params=params, timeout=float(timeout))
    except Exception as exc:
        ok, payload, error = False, {}, f"{exc.__class__.__name__}: {exc}"

    videos = ((payload or {}).get("data") or {}).get("result") or []
    # 状态码从 error 里抠（deps 给的是 "HTTP 412" 这种）
    m = re.search(r"(\d{3})", str(error))
    status = int(m.group(1)) if m else (200 if ok else 0)

    out = {
        "ok": bool(ok),
        "logged_in": bool(state.get("logged_in")),
        "count": len(videos),
        "status": status,
        "error": "" if ok else str(error),
    }

    if ok and videos:
        out["verdict"] = (f"能用——搜到 {len(videos)} 条结果"
                          + ("（带登录信息）" if out["logged_in"] else "（未登录）"))
        out["hint"] = ("" if out["logged_in"]
                       else "能搜到，但未登录时限流更严。登录后更稳。")
    elif status == 412:
        if out["logged_in"]:
            out["verdict"] = "被限流（HTTP 412），但 cookies 是登录状态"
            out["hint"] = "这种是临时限流，等半分钟再试；还不行就是 B 站挡得紧。"
        else:
            out["verdict"] = "被限流（HTTP 412），而且当前没有登录信息"
            out["hint"] = "点上面的「登录获取」登录一次，这是根治办法。"
    elif not ok:
        out["verdict"] = f"请求失败：{error}"
        out["hint"] = "检查网络，或者 B 站接口又变了。"
    else:
        # 请求成功但没有结果
        out["verdict"] = "请求成功，但一条结果都没有"
        out["hint"] = ("可能 cookies 让 B 站返回了空结果（试过期的凭据会这样）。"
                       "先删掉 cookies 再试，能搜到就说明是 cookies 的问题。")
    return out

def open_url(url: str) -> bool:
    """用系统默认浏览器打开。"""
    try:
        return webbrowser.open(url, new=2)
    except Exception:
        return False


def print_links(keyword: str, limit: int = 6) -> None:
    """不联网也能给的东西：一组可点的搜索链接。"""
    lines = [ui.c(f"搜「{build_query(keyword)}」", "bold")]
    lines.append("")
    lines.append(f"  {ui.c('全部 · 综合', 'hotpink')}  {search_url(keyword)}")
    for key, label in TEMPLATE_LABELS.items():
        url = search_url(keyword, template=key)
        lines.append(f"  {ui.c(label.ljust(6), 'cyan')}  {url}")
    print(ui.box("B 站搜索链接", lines))


def print_videos(outcome: SearchOutcome, keyword: str, width: int | None = None) -> None:
    width = width or ui.term_width()
    if not outcome.ok:
        ui.warn(f"拿不到在线结果：{outcome.error}")
        print_links(keyword)
        return
    if not outcome.videos:
        ui.warn("B 站没搜到相关视频，换个说法试试")
        print_links(keyword)
        return

    lines = [
        ui.c(f"「{build_query(keyword)}」", "bold")
        + ui.c(f"  约 {outcome.num_results} 个结果", "grey"),
        "",
    ]
    for index, video in enumerate(outcome.videos, start=1):
        head = f"{ui.c(str(index), 'gold', 'bold')}. {ui.c(video.title, 'bold')}"
        lines.append(ui.pad(head, width - 6) if ui.dwidth(ui._strip_ansi(head)) < width - 6 else head)
        meta = []
        if video.author:
            meta.append(ui.c(f"UP {video.author}", "pink"))
        if video.duration_text():
            meta.append(ui.c(video.duration_text(), "grey"))
        if video.play:
            meta.append(ui.c(f"▶ {video.play_text()}", "grey"))
        lines.append("   " + "  ".join(meta))
        if video.url:
            lines.append("   " + ui.c(video.url, "plum"))
        lines.append("")
    print(ui.box("B 站搜索结果", lines, width=width))


# --------------------------------------------------------------------------
# 和 BiliSum 视频总结器打通
# --------------------------------------------------------------------------

def find_bilisum_cli() -> Path | None:
    """找 BiliSum 的 CLI 入口（node 脚本）。

    查找顺序：环境变量 BILISUM_CLI → 环境变量 BILISUM_HOME → 常见安装目录。
    想换机器用，只要设一个 BILISUM_HOME 就行。
    """
    import os

    candidates: list[Path] = []

    env_cli = os.environ.get("BILISUM_CLI")
    if env_cli:
        candidates.append(Path(env_cli))
    env_home = os.environ.get("BILISUM_HOME")
    if env_home:
        candidates.append(Path(env_home) / "resources" / "cli" / "bin" / "bilisum.js")

    candidates.append(
        Path(os.environ.get("LOCALAPPDATA", "")) 
        / "Programs" / "BiliSum" / "resources" / "cli" / "bin" / "bilisum.js"
    )

    # 常见安装位置兜底搜索
    for base in (
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs",
        Path(r"C:\Program Files"),
        Path(r"C:\Program Files (x86)"),
    ):
        if not base.exists():
            continue
        try:
            for child in base.iterdir():
                if "bilisum" in child.name.lower():
                    js = child / "resources" / "cli" / "bin" / "bilisum.js"
                    if js.exists():
                        candidates.append(js)
        except OSError:
            continue
    for path in candidates:
        if path and path.exists():
            return path
    return None


def find_node() -> str | None:
    return shutil.which("node")


def bilisum_available() -> tuple[bool, str]:
    """返回 (是否可用, 说明)。

    现在有两种用法，优先走直接托管后端（不需要 Node，也不需要桌面端）：
        1. 内置客户端直接起后端 + 走 HTTP     ← 首选
        2. 调 BiliSum 的 Node CLI            ← 兜底（没装 Node 也能走 1）
    """
    from . import bilisum

    if bilisum.installed():
        backend = bilisum.find_backend()
        return True, f"内置托管（{backend}）"

    js = find_bilisum_cli()
    if js is not None:
        node = find_node()
        if node is not None:
            return True, f"CLI 兜底（{node}）"
        return False, "找到了 BiliSum CLI，但 PATH 里没有 node"
    return False, "没找到 BiliSum（装过的话用 BILISUM_HOME 指一下安装目录）"


def summarize_via_service(url: str, home, *, on_progress=None):
    """用内置客户端总结一个视频。

    返回 (成功, 正文, 错误, summary 对象)。
    多返回一个 summary 是为了让调用方能拿到结构化字段（标题/转写/概览），
    好写质量记录——只给一段文本的话，"这次到底可不可信"就无从判断了。
    """
    from . import bilisum

    client = bilisum.Client(home)
    try:
        ok, note = client.ensure_service(on_status=on_progress)
    except bilisum.ServiceError as exc:
        return False, "", str(exc), None
    if not ok:
        return False, "", note, None
    if note and on_progress:
        on_progress(note)

    ok, task_or_error = client.create_task(url)
    if not ok:
        return False, "", task_or_error, None
    task_id = task_or_error
    if on_progress:
        on_progress(f"任务已创建：{task_id}")

    def relay(prog):
        if on_progress:
            on_progress(prog.line())

    summary = client.wait_for(task_id, on_progress=relay)
    if summary.status == "failed" or (not summary.has_content() and summary.error):
        return False, "", summary.error or "总结失败", summary
    return True, bilisum.render_summary_markdown(summary), "", summary


def summarize_video(url: str, fmt: str = "markdown", timeout: int = 3600,
                    extra_args: list[str] | None = None) -> tuple[bool, str]:
    """旧接口：调 BiliSum 的 Node CLI。保留作为兜底路径。"""
    ok, detail = bilisum_available()
    if not ok:
        return False, detail
    node = find_node()
    js = find_bilisum_cli()
    assert node and js
    cmd = [node, str(js), "summarize", url, "--format", fmt]
    if extra_args:
        cmd.extend(extra_args)
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, f"总结超时（>{timeout}s）"
    except OSError as exc:
        return False, f"启动 BiliSum 失败：{exc}"
    if proc.returncode != 0:
        tail = (proc.stderr or "").strip().splitlines()[-5:]
        return False, "BiliSum 返回错误：\n  " + "\n  ".join(tail)
    return True, proc.stdout or ""


def start_desktop_app() -> bool:
    """BiliSum 桌面端没开时，帮忙拉起来（这样 CLI 能连上同一套配置和知识库）。"""
    exe = Path(r"C:\Users\25643\AppData\Local\Programs\BiliSum\BiliSum.exe")
    if not exe.exists():
        return False
    try:
        subprocess.Popen(
            [str(exe)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            close_fds=True,
        )
        return True
    except OSError:
        return False


def desktop_running(port: int = 3838, timeout: float = 0.6) -> bool:
    """探一下桌面端服务在不在（就是 CLI 的 desktop 环境地址）。"""
    import socket

    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True
    except OSError:
        return False


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    assert expand("dp") == "动态规划"
    assert expand("DP") == "动态规划"
    assert expand("滑动窗口") == "滑动窗口"
    assert expand("未知标签") == "未知标签"

    q = build_query("二分查找", template="explain")
    assert q == "二分查找 讲解", q
    assert build_query("dp", extra="面试") == "动态规划 面试"

    url = search_url("单调栈")
    assert url.startswith("https://search.bilibili.com/all?keyword=")
    assert "%E5%8D%95%E8%B0%83%E6%A0%88" in url, url

    suggestions = queries_for_problem("每日温度", ["单调栈", "数组"], extra="")
    labels = [s[0] for s in suggestions]
    assert any("单调栈" in s[1] for s in suggestions), suggestions
    assert any("每日温度" in s[1] for s in suggestions), suggestions
    assert len(suggestions) == len(set(s[1] for s in suggestions)), "搜索词有重复"

    assert _strip_html('<em class="keyword">单调栈</em> 详解') == "单调栈 详解"
    video = Video(title="t", author="a", play=12345, duration="754")
    assert video.play_text() == "1.2万"
    assert video.duration_text() == "12:34"
    video2 = Video(title="t", author="a", duration="12:34")
    assert video2.duration_text() == "12:34"

    print("search selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()

# ---------------------------------------------------------------------------
#  在线搜索的"保险丝"：超时上限 + 结果缓存
# ---------------------------------------------------------------------------
#
# 为什么要这两样：
#
#   B 站搜索会被**限流**。限流时它不是报错，而是**很慢**（实测 33 秒）
#   并且**返回空结果** —— 在界面上就表现为"一直搜索中…"卡死。
#
#   所以：
#     ① 超过 _SEARCH_TIMEOUT 秒就放弃在线、改用"去 B 站搜"的链接
#     ② 同一关键词 _CACHE_TTL 秒内只真搜一次（重复点、多个模块搜同一个词都省一次）
#
# **不做重试**：限流是服务端的限制，越重试越糟；正确做法是立刻给可用出口。
_SEARCH_TIMEOUT = 10.0
_CACHE_TTL = 600.0
_search_cache: dict[str, tuple[float, object]] = {}


def search_online_cached(keyword: str, page: int = 1):
    """带缓存和超时的在线搜索（拿不到就返回 ok=False，调用方降级成链接）。"""
    import threading
    import time as _time

    key = f"{keyword}|{page}"
    now = _time.time()
    hit = _search_cache.get(key)
    if hit and now - hit[0] < _CACHE_TTL:
        return hit[1]

    box: dict = {}

    def _run():
        try:
            box["got"] = search_online(keyword, page=page)
        except Exception as exc:      # 任何异常都算"拿不到"
            box["err"] = exc

    th = threading.Thread(target=_run, daemon=True)
    th.start()
    th.join(_SEARCH_TIMEOUT)
    if th.is_alive() or "got" not in box:
        # 超时（或抛异常）→ 明确返回"没拿到"，让调用方降级
        return _degraded(keyword)

    got = box["got"]
    # 空结果的"成功"其实也是限流的表现 → 当成拿不到
    rows = None
    for attr in ("results", "items", "videos", "list", "data"):
        v = getattr(got, attr, None)
        if isinstance(v, list) and v:
            rows = v
            break
    if getattr(got, "ok", False) and rows:
        _search_cache[key] = (now, got)
        return got
    return _degraded(keyword)


def _degraded(keyword: str):
    """降级结果：ok=False（调用方据此给"去 B 站搜"的链接）。"""
    class _Out:
        ok = False
        error = "B 站搜索暂时拿不到结果（多半是限流了，等几分钟再试）"
        # **字段要和真实 outcome 对齐**：api_search 会读 .videos / .num_results，
        # 少一个就是 AttributeError → 接口 500（我第一版只写了 results/items，
        # 结果她拿到的是"报错"而不是"降级提示"）。
        results: list = []
        items: list = []
        videos: list = []
        num_results: int = 0

    return _Out()


