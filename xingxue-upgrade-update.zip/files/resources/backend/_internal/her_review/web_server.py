"""图形界面（Web UI）的本地服务。

为什么用"本地 HTTP 服务 + 浏览器界面"而不是 Electron / PyQt：
    1. **零依赖**：只用 Python 标准库（http.server）。装 Electron 要给礼物配
       一个几百 MB 的安装包；PyQt 也要几十 MB。她双击就能用的东西不该这么重。
    2. **界面质量**：网页能做出现代观感（圆角、阴影、过渡动画、响应式），
       Tkinter 做不到，而 PyQt 的体量我们又不想要。
    3. **可移植**：整个文件夹拷到另一台电脑照样能用，不需要安装任何东西。

设计要点：
    - 只监听 127.0.0.1，**不对外网开放**（她的学习数据不该被局域网看到）
    - 端口被占用时自动往后找（3777 → 3780-3789）
    - 每个请求一个独立的 Store 连接：HTTP 是多线程的，SQLite 连接不能跨线程共用
    - API 全部返回 JSON，错误也返回 JSON（前端统一处理，不会看到 HTML 错误页）
"""

from __future__ import annotations

import json
import mimetypes
import os
import sys
import re
import threading
import time
import webbrowser
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from . import config, gem
from .config import Config
from .db import Store

# 只在这些端口上尝试。避开常见的 3000/5000/8000（她用别的工具时容易撞）
DEFAULT_PORT = 3777
PORT_CANDIDATES = [3777, 3780, 3781, 3782, 3783, 3784, 3785, 3786, 3787, 3788, 3789]

# --------------------------------------------------------------------------
#  跨源（CORS）：桌面版**必须**有，否则界面一个数据都取不到
# --------------------------------------------------------------------------
#
# ## 为什么需要
#
# 桌面版的前端跑在 Tauri 的 WebView 里，**源是 `http://tauri.localhost`**；
# 而接口在 `http://127.0.0.1:<port>` —— 这是**跨源**。
#
# 浏览器/WebView 对跨源请求有两道卡：
#
#   ① 前端给每个请求都带了 `Content-Type: application/json`
#      （那不是"简单头"）→ 浏览器先发一个**预检** `OPTIONS`
#      → 而 `BaseHTTPRequestHandler` 默认对 OPTIONS 回 **501**
#      → 预检失败 → 真正的请求根本不发
#   ② 即使发了（简单 GET），响应里**没有** `Access-Control-Allow-Origin`
#      → JS **读不到**响应内容 → fetch 直接抛错
#
# 两种情况的界面表现是同一个：**骨架渲染出来了，但一个数据都没有**
# （侧栏在、内容区空）。旧版是 Edge 直接打开 `http://127.0.0.1:3777/`
# ——**同源**，所以这个坑从来没暴露过；改成 Tauri 之后才出现。
#
# ## 为什么之前一直没被发现
#
# 因为所有"界面能用"的验证都是**从服务端打接口**（curl / urllib / 脚本），
# 那些**不经过浏览器**，也就不会触发 CORS。真正能发现它的只有
# "把 Tauri 窗口截下来看"（审查线就是这么抓到的）。
#
# ## 安全
#
# 服务只绑 `127.0.0.1`，本来就只有本机能访问。这里也**不回显任意源**：
# 只认桌面版的源和本机源。回显（而不是 `*`）是为了以后加
# `tauri://` 之类的源时不用改判定，也更收敛。
ALLOWED_ORIGINS = (
    "http://tauri.localhost",
    "https://tauri.localhost",
    "tauri://localhost",
    "http://localhost",
    "https://localhost",
)

_LOCAL_ORIGIN = re.compile(r"^https?://(127\.0\.0\.1|localhost)(:\d+)?$")


def origin_allowed(origin: str) -> bool:
    """这个 Origin 允许跨源访问吗。"""
    if not origin:
        return False
    if origin in ALLOWED_ORIGINS:
        return True
    return bool(_LOCAL_ORIGIN.match(origin))

# 应用图标（`/icon.png` / `/favicon.ico` 用）。
#
# 旧版网页界面（`her_review/web/`）已经**移除**，所以这里不再有
# "ASSETS 目录"这个概念，也不再需要那套占位符替换
# （`<!--MASCOT-->` / `<!--ICONS-->` 是给旧 index.html 用的）。
#
# **路径要按"打包后的结构"找，不能写死开发时的相对位置**：
# 打包后 `her_review` 在 `_internal/` 里，写死 `../assets` 会指向
# `_internal/assets`——不存在，于是 /icon.png 变成 404。
# （这类"层级按开发时写、打包后结构变了"的坑，这个项目踩过三次：
#   后端 exe 路径、/app/ 目录、以及这里。）
def _icon_path_candidates() -> list[Path]:
    here = Path(__file__).resolve().parent          # her_review/
    exe = Path(sys.executable)
    cands = [
        exe.parent / "icon.png",                    # 后端 exe 同级
        exe.parent.parent / "app" / "icon.png",     # 交付形态：resources/app/icon.png
        here / "web" / "app" / "icon.png",
        here.parent / "desktop" / "dist" / "icon.png",
        here.parent / "assets" / "xingxue.png",     # 开发形态（仓库里）
    ]
    ui = _new_ui_dir()
    if ui is not None:
        cands.insert(0, ui / "icon.png")
    return cands


def find_icon() -> Path | None:
    for c in _icon_path_candidates():
        try:
            if c.is_file():
                return c
        except OSError:
            continue
    return None


def _ascii_cat_html(pose: str, theme) -> str:
    """符号猫。

    把**所有动作**（连名字和用途）都嵌进去，这样：
        - 摸一摸换表情在前端就能完成，不用往返服务器
        - 界面可以做个"换动作"的选择器，让她自己挑
    动作的唯一来源是 mascot.py（终端版共用同一份，不另抄一份）。

    数据放在 `<script type="application/json">` 里，而不是 data 属性里：
        HTML 属性不能直接放 JSON（里面的引号和 < > 要转义成实体，
        而属性值里的实体解析规则和正文不一样，很容易踩坑）。
        script 标签的正文只认 `</script`，JSON 里不会有，最省心。
    """
    import html as html_mod
    import json

    from . import mascot as mascot_mod

    poses: dict[str, str] = {}
    info: dict[str, dict] = {}
    # 遍历 POSES 本身，而不是写死一个清单——
    # 以后在 mascot.py 里加动作，界面自动就有，不用改这里。
    for name in mascot_mod.POSES:
        try:
            poses[name] = "\n".join(mascot_mod.plain(name))
        except Exception:
            continue
        meta = mascot_mod.POSES_INFO.get(name) or {}
        info[name] = {"name": meta.get("name", name), "when": meta.get("when", "")}
    if "sit" not in poses:          # 极端情况兜底
        poses["sit"] = " /\\_/\\\n( o.o )\n > ^ <"
        info["sit"] = {"name": "坐好", "when": "默认状态"}

    current = poses.get(pose) or poses["sit"]
    payload = json.dumps({"poses": poses, "info": info}, ensure_ascii=False)
    # 防止内容里出现 </script 提前闭合标签（正常不会有，但转义一下更稳）
    payload = payload.replace("</", "<\\/")
    return (
        f'<pre class="cat-ascii" data-pose="{html_mod.escape(pose, quote=True)}">'
        f'{html_mod.escape(current)}</pre>'
        f'<script type="application/json" id="catPoses">{payload}</script>'
    )


# --------------------------------------------------------------------------
# 应用上下文
# --------------------------------------------------------------------------

class WebApp:
    """把配置、数据目录和 API 装配在一起。

    每个请求会通过 context() 拿一个**独立的** Store，
    因为 ThreadingHTTPServer 是多线程的，sqlite3 连接默认不能跨线程用。
    """

    def __init__(self, home: Path | None = None, *, today: date | None = None):
        # 走和命令行入口**完全一样**的解析链（显式指定 > 环境变量 > her.local.json > 默认）。
        # 之前这里直接 Config.load(None)，不读 her.local.json，
        # 结果双击打开界面时读的是另一个空数据目录——她的题一道都看不到。
        self.cfg = config.resolve_and_load(home)
        cfg = self.cfg
        # 缓存目录必须落在**真实数据目录**下。
        # 不指的话它会用 ~/.her-review，而那个目录常常不可写，
        # 于是 diskcache 静默失效、搜索缓存一次都不生效——
        # "装好了却没用上"比没装更难查，所以这里显式指定。
        try:
            from . import deps

            deps.configure_cache(cfg.home)
        except Exception:
            pass
        # 面板迁移和 CLI 走同一套逻辑，避免两边的首页不一致
        try:
            from . import features

            cfg.migrate_panels(features.DEFAULT_PANELS)
        except Exception:
            pass
        self.theme = gem.theme_from_birthday(cfg.birthday)
        self.birthday = gem.parse_date(cfg.birthday)
        self._today_override = today
        self.started_at = date.today()

        # "界面最后一次跟我说话是什么时候"。
        # 应用窗口模式（Edge --app）关闭时服务端收不到任何通知，
        # 只能靠这个时间戳判断窗口还在不在——见 app.py 的看门狗。
        self.last_seen = time.monotonic()
        self.request_count = 0

    # ---------------- 存活标记 ----------------

    def touch(self) -> None:
        """每次请求都调一下。**必须是极轻的操作**，它在每个请求的关键路径上。"""
        self.last_seen = time.monotonic()
        self.request_count += 1

    def idle_seconds(self) -> float:
        return time.monotonic() - self.last_seen

    # ---------------- 生命周期 ----------------

    def context(self):
        """返回一个本次请求用的上下文（用完必须 close）。"""
        from . import features
        from . import plugins as plugins_mod

        class Ctx:
            pass

        ctx = Ctx()
        ctx.cfg = self.cfg
        ctx.store = Store(self.cfg.db_path)
        ctx.theme = self.theme
        ctx.birthday = self.birthday
        ctx.together = gem.parse_date(self.cfg.together_since)
        ctx.name = self.cfg.display_name()
        ctx.panels = features.PanelRegistry()
        ctx.hooks = {}
        ctx.plugins = None
        ctx.plugin_commands = {}
        ctx._web_today = self._today_override

        def today() -> date:
            return self._today_override or date.today()

        ctx.today = today
        return ctx

    def today(self) -> date:
        return self._today_override or date.today()

    def close(self) -> None:
        pass


# --------------------------------------------------------------------------
# HTTP 处理器
# --------------------------------------------------------------------------

def _new_ui_dir() -> Path | None:
    """新版桌面前端（Vue 构建产物）在哪。

    按顺序找，第一个**带 index.html** 的算数：

        ① 后端 exe 同级的 `app/`        —— exe 和前端放一起时
        ② 后端 exe **上一级**的 `app/`   —— **交付形态就是这个**：
           后端在 `resources/backend/xingxue-backend.exe`，
           前端在 `resources/app/`（兄弟目录）
        ③ `her_review/web/app/`         —— 万一打进包里的位置
        ④ 仓库里的 `desktop/dist`       —— 开发形态

    （放在这个位置而不是写死仓库路径：打包后仓库可能不在了。）

    ⚠️ 第 ② 条是我第一版漏掉的：只找了 exe 同级 →
    交付版一直报"新版前端还没构建"，而文件明明在 `resources/app`。
    层级这种东西**必须按实际部署结构核对**，不能想当然。
    """
    import sys as _sys

    here = Path(__file__).resolve().parent          # her_review/
    cands: list[Path] = []
    exe = Path(_sys.executable)
    cands.append(exe.parent / "app")
    cands.append(exe.parent.parent / "app")          # 交付形态：resources/app
    cands.append(here / "web" / "app")               # 万一打进包里的位置
    cands.append(here.parent / "desktop" / "dist")   # 开发形态：仓库里的 dist
    for c in cands:
        try:
            if (c / "index.html").is_file():
                return c
        except OSError:
            continue
    return None


class Handler(BaseHTTPRequestHandler):
    server_version = "her-review"
    app: WebApp = None  # type: ignore[assignment]

    # 静音默认的访问日志（终端里不需要刷这些）
    def log_message(self, fmt, *args):  # noqa: A003
        pass

    # ---------------- 输出辅助 ----------------

    def redirect(self, location: str) -> None:
        """302 跳转。用来把旧的根路径 `/` 送到新版界面。"""
        self.send_response(302)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        for key, value in self._cors_headers().items():
            self.send_header(key, value)
        self.end_headers()

    def _send(self, code: int, body: bytes, content_type: str,
              extra_headers: dict[str, str] | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        # 本地工具，**默认**禁掉缓存省得她改了东西看不到更新。
        # 但允许 extra_headers 覆盖（头像图片要长缓存）。
        #
        # 注意要发**一条**：以前这里写死 no-store，extra_headers 里再给一条，
        # 客户端看到的是 no-store —— 优化等于白做（我就这么踩过一次）。
        extra = dict(extra_headers or {})
        self.send_header("Cache-Control",
                         extra.pop("Cache-Control", "no-store"))
        # 跨源头**每个响应都要带**（不只是预检）——
        # 少了它，浏览器会把响应体丢掉，JS 读不到内容。
        merged = self._cors_headers()
        merged.update(extra)
        for key, value in merged.items():
            self.send_header(key, value)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def json(self, data, code: int = 200,
             extra_headers: dict[str, str] | None = None) -> None:
        body = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
        self._send(code, body, "application/json; charset=utf-8", extra_headers)

    def error(self, message: str, code: int = 400) -> None:
        self.json({"ok": False, "error": message}, code)

    def html(self, text: str, code: int = 200) -> None:
        self._send(code, text.encode("utf-8"), "text/html; charset=utf-8")

    # ---------------- 静态文件 ----------------

    def static(self, relative: str) -> None:
        """静态资源。

        旧版网页界面已经移除，现在只有两件事：

            · `/app/...`  —— 伺服**新版桌面前端**（浏览器版，同一个界面）
            · `/icon.png` / `/icon.ico` / `/favicon.ico` —— 应用图标

        其它一律 404，并**说清为什么**（不然她只会看到"找不到"，
        不知道是"旧版已经不用了"）。
        """
        # ---- 新版桌面前端：/app/... ----
        #
        # 桌面版专属能力（应用内登录 B 站等）在浏览器里不可用，
        # 前端自己会提示"只在桌面版里可用"。
        if relative in ("app", "app/") or relative.startswith("app/"):
            root = _new_ui_dir()
            if root is None:
                self.error(
                    "新版前端还没构建（跑一下 python scripts\\build_all.py）", 404)
                return
            sub = relative[3:].lstrip("/") or "index.html"
            try:
                target = (root / sub).resolve()
                target.relative_to(root.resolve())     # 防目录穿越
            except ValueError:
                self.error("非法路径", 403)
                return
            except OSError:
                self.error(f"读不了 {sub}", 404)
                return
            if target.is_dir():
                target = target / "index.html"
            if not target.is_file():
                self.error(f"找不到 {sub}", 404)
                return
            ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
            self._send(200, target.read_bytes(), ctype)
            return

        # ---- 应用图标 ----
        if relative in ("icon.png", "icon.ico", "favicon.ico"):
            icon = find_icon()
            if icon is not None:
                self._send(200, icon.read_bytes(), "image/png")
                return
            self.error("找不到图标文件（跑一下 python scripts/make_icon.py）", 404)
            return

        # ---- 其它：旧版界面已经删了 ----
        self.error(
            "这个页面没有了。旧版网页界面已经移除——"
            "请用桌面版（双击桌面上的「形学」）；"
            "想在浏览器里看，地址是 /app/",
            404)

    def _cors_headers(self) -> dict[str, str]:
        """跨源响应头。源不在白名单就返回空（等于不放开）。

        为什么**回显 Origin 而不是写 `*`**：更收敛，而且以后要加
        `tauri://` 之类的源时只改 `origin_allowed` 一处。
        """
        origin = self.headers.get("Origin") or ""
        if not origin_allowed(origin):
            return {}
        return {
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Max-Age": "600",
            "Vary": "Origin",
        }

    def do_OPTIONS(self) -> None:  # noqa: N802
        """预检。

        **这个方法是桌面版能不能用的关键**：默认实现会对 OPTIONS 回 501，
        而前端每个请求都带 `Content-Type: application/json`
        → 浏览器必先来预检 → 501 就等于"所有请求全灭"。
        """
        self.send_response(204)
        for key, value in self._cors_headers().items():
            self.send_header(key, value)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        self._dispatch("GET")

    def do_POST(self) -> None:  # noqa: N802
        self._dispatch("POST")

    def do_PUT(self) -> None:  # noqa: N802
        self._dispatch("PUT")

    def do_DELETE(self) -> None:  # noqa: N802
        self._dispatch("DELETE")

    def _body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return {}
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
            return data if isinstance(data, dict) else {"value": data}
        except (ValueError, UnicodeDecodeError):
            return {}

    def _update_upload(self) -> None:
        """接收更新包（原始 zip 字节，不是 JSON）。

        单独一条路：15 MB 的包不走 JSON（base64 会再胖 33%），
        前端直接 `fetch(..., {body: file})` 发二进制。
        """
        try:
            self.app.touch()
        except Exception:
            pass
        from . import web_api

        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            self.error("没有收到更新包内容", 400)
            return
        if length > web_api.UPDATE_UPLOAD_LIMIT:
            self.error(f"更新包太大（上限 {web_api.UPDATE_UPLOAD_LIMIT // 1024 // 1024} MB）", 413)
            return
        raw = self.rfile.read(length)
        try:
            result = web_api.api_update_upload(self.app, raw)
        except Exception as exc:
            import traceback

            traceback.print_exc()
            self.error(f"{exc.__class__.__name__}: {exc}", 500)
            return
        code = 200 if result.get("ok") else 400
        body = json.dumps(result, ensure_ascii=False).encode("utf-8")
        self._send(code, body, "application/json; charset=utf-8")

    def _dispatch(self, method: str) -> None:
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        # 更新包上传走二进制通道（见 _update_upload），不经过 JSON 解析
        if method == "POST" and path == "/api/update/package":
            self._update_upload()
            return
        payload = self._body() if method in ("POST", "PUT") else {}

        # 记一笔"界面还活着"。放在最前面，静态资源和接口都算——
        # 应用窗口模式靠它判断窗口有没有被关掉。
        try:
            self.app.touch()
        except Exception:
            pass

        # ---- 头像图片（二进制）----
        #
        # 走 JSON 那条路的话，图片要 base64 成字符串（1.5 MB → 2 MB）。
        # 这里直接吐原始字节，并让它可缓存 —— `<img>` 拉图片本来就该这样。
        if path == "/api/avatar/image" and method == "GET":
            from . import web_api

            blob = web_api.avatar_image_bytes(self.app)
            if blob is None:
                self.error("还没有头像", 404)
                return
            body, ctype = blob
            self._send(200, body, ctype, extra_headers={
                # 换头像时 URL 里的 ?v= 会变，所以这里可以放心长缓存
                "Cache-Control": "public, max-age=604800",
            })
            return

        # ---- 静态资源 ----
        if not path.startswith("/api/"):
            rel = path.lstrip("/")
            # 根路径 → 送到新版界面。
            # 旧版界面已经移除；她的旧书签/旧链接不该看到 404。
            if rel in ("", "index.html"):
                self.redirect("/app/")
                return
            self.static(rel)
            return

        from . import web_api

        try:
            result = web_api.handle(self.app, method, path, query, payload)
        except Exception as exc:  # 任何异常都要变成 JSON，不能吐 HTML 错误页
            import traceback

            traceback.print_exc()
            self.error(f"{exc.__class__.__name__}: {exc}", 500)
            return

        if result is None:
            self.error(f"没有这个接口：{method} {path}", 404)
            return
        code, data = result

        # ------------------------------------------------------------------
        #  /api/ping 带上"本实例的标识"
        # ------------------------------------------------------------------
        #
        # **为什么放在 HTTP 层而不是 web_api 里**：
        # 这是"进程/传输层"的事实（这个后端进程是谁），不是业务数据。
        # 放这里的好处是它**一定**会出现在每个后端的 ping 里，
        # 不用管 web_api 那边怎么组织。
        #
        # 用途：启动器（Rust）生成一个随机串，用环境变量
        # `XINGXUE_INSTANCE` 传给后端；然后它只认「ping 回来的标识
        # 跟自己的串一样」的后端。
        #
        # 为什么需要这个：Windows 上 `SO_REUSEADDR` **允许两个进程
        # 绑同一个 127.0.0.1:端口**（实测两个后端同时 LISTEN 3777）。
        # 只靠"端口通不通"判断就绪，会连到**别人的**后端——
        # 于是窗口显示的是另一个数据目录的内容。
        #
        # **标识别同时放响应头和 JSON body 两处，这是有原因的**：
        # 实测（审查线取证）HTTP 响应是**分两段 TCP**发出来的——
        # `end_headers()` 先把头 flush 出去，body 是之后单独写的。
        # 所以"只 read 一次"的客户端**只能看到头**。
        # 放进响应头，任何客户端第一次 read 就能拿到，
        # 不用依赖它读完整个 body。
        ping_headers = None
        if method == "GET" and path == "/api/ping" and isinstance(data, dict):
            tag = os.environ.get("XINGXUE_INSTANCE", "")
            if tag:
                data["instance"] = tag
                ping_headers = {"X-Xingxue-Instance": tag}

        self.json(data, code, extra_headers=ping_headers)


# --------------------------------------------------------------------------
# 启动
# --------------------------------------------------------------------------

def pick_port(preferred: int = DEFAULT_PORT) -> int:
    """找一个能用的端口。被占用就往后试，别因为冲突让她打不开界面。

    ## 为什么要"先探有没有人在听"，而不是只靠 bind 试

    **Windows 上 `SO_REUSEADDR` 会让"端口避让"彻底失效。**
    它不像 Unix：在 Windows 上允许两个进程**同时 bind 同一个
    `127.0.0.1:端口`**（实测：两个后端都 LISTEN 3777）。
    所以原来那句 `setsockopt(SO_REUSEADDR, 1)` 之后 bind 永远成功，
    这个函数**总是返回 3777** —— 第二个实例会和第一个抢同一个端口，
    而它的窗口读到的其实是**别人的后端**（数据目录可能都不一样）。

    这里改成两步：
      ① **连一下**：连得上就说明已经有人在 listen → 换下一个
         （本机连活端口是毫秒级：实测 0.2–16ms）
      ② 再 bind 一次做兜底

    ①的超时给 250ms：本机活端口远快于这个数；而连"死端口"在
    这台机器上要等约 2 秒才收到延迟的 RST，所以超时一律当"没人听"
    （宁可多试一个，也不要抢别人的端口）。

    真正的身份校验在启动器那边（`/api/ping` 会回 `instance`），
    所以即使这里判断错了，也不会把别人的后端当成自己的。
    """
    import socket

    def someone_listening(port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.25)
            try:
                probe.connect(("127.0.0.1", port))
                return True          # 连上了 = 有人在听
            except Exception:
                return False         # 拒绝/超时 = 没人听

    for candidate in [preferred, *PORT_CANDIDATES]:
        # 已经有人在听 → 换下一个（**不要抢**）
        if someone_listening(candidate):
            continue
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            # **不设 SO_REUSEADDR**：Windows 上它会让 bind 变成"可以抢"
            try:
                sock.bind(("127.0.0.1", candidate))
                return candidate
            except OSError:
                continue
    raise RuntimeError("端口都被占用了，试过：" + "、".join(map(str, PORT_CANDIDATES)))


def serve(home: Path | None = None, *, port: int | None = None,
          open_browser: bool = True, today: date | None = None,
          quiet: bool = False) -> None:
    """启动本地服务并（可选）自动打开界面。阻塞运行，Ctrl+C 结束。"""
    app = WebApp(home, today=today)

    class BoundHandler(Handler):
        pass

    BoundHandler.app = app
    chosen = port or pick_port()
    httpd = ThreadingHTTPServer(("127.0.0.1", chosen), BoundHandler)
    url = f"http://127.0.0.1:{chosen}/"

    if not quiet:
        # 这里刻意不拼人名：用户明确要求窗口标题只叫「形学」。
        # （应用窗口的标题栏和任务栏取的就是文档标题，带上名字会显得啰嗦。）
        print()
        print("  ╭──────────────────────────────────────────────╮")
        print("  │   形学                                       │")
        print("  ╰──────────────────────────────────────────────╯")
        print()
        print(f"     界面地址：{url}")
        print(f"     数据目录：{app.cfg.home}")
        print()
        print("     关掉这个窗口就退出了。")
        print()

    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        if not quiet:
            print("\n  已退出。")
    finally:
        httpd.server_close()
        app.close()
