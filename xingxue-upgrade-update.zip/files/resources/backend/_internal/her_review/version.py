"""形学 · 升级版 —— 版本号（唯一来源）。

改版本只改这里：
    VERSION  语义化版本（前端/设置页显示、更新包比较都用它）
    BUILD    构建标识（同版本内的小差别，可随便写）

发版脚本 `_tools/pack_upgrade/build_pack.py` 会把这里和项目根的 VERSION
一起同步成目标版本；**安装目录的 version.json 是运行时的权威来源**
（见 updater.installed_version）。

注意：APP_ID 是更新包的"身份证"——manifest.json / update.json 里的 app
字段必须等于它，否则更新器会拒绝（防止把集成电路版的包装进来）。
"""

APP_ID = "xingxue-plus"
APP_NAME = "形学 · 升级版"

VERSION = "1.1.7"
BUILD = "20261019.2052"
CHANNEL = "stable"
