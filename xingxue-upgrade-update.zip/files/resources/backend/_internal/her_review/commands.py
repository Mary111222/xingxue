"""命令实现（一）：题库相关 —— init / seed / today / add / list / show / edit / rm。

按职责拆分：这个模块只管「题目和题库」，
搜索与视频总结器在 commands_web.py，导出导入与自检在 commands_io.py，
参数解析与调度留在 cli.py。
三者共用 cli_support.py 里的交互小工具。
"""

from __future__ import annotations

from datetime import date

from . import bank, features, gem, io_formats, report, sm2, ui
from .cli_support import ask, ask_choice, ask_or, interactive, resolve
from .db import DIFFICULTIES, SOURCES


def cmd_init(args, ctx) -> int:
    print(ui.c("先花 30 秒把它变成「你的」", ctx.theme.primary, "bold"))
    print(ui.c("  这些信息只存在本机，程序用它们生成专属配色和生日效果。", "grey"))
    print()

    # 用 getattr 而不是 args.name：cmd_today 第一次运行时会直接把 args 转过来，
    # 那个 namespace 上没有 --name/--birthday/--together
    given_name = getattr(args, "name", None)
    given_birthday = getattr(args, "birthday", None)
    given_together = getattr(args, "together", None)

    # 非交互环境（管道、脚本）不弹提示，直接用命令行给的值或现有配置。
    # 否则 input() 会立刻 EOF，一个本来能成功的初始化会变成"失败"。
    name = (given_name if given_name is not None
            else ask_or("她的名字 / 昵称", ctx.cfg.name))
    birthday = (given_birthday if given_birthday is not None
                else ask_or("她的生日（YYYY-MM-DD，只写 06-01 也行）", ctx.cfg.birthday))
    together = (given_together if given_together
                else ask_or("你们认识的日子（可留空，用于「认识第 N 天」）",
                            ctx.cfg.together_since))

    parsed = gem.parse_date(birthday)
    if birthday and parsed is None:
        ui.warn(f"「{birthday}」看不懂，先按空处理（格式：2005-06-01 或 06-01）")
        birthday = ""

    ctx.cfg.update(name=name, birthday=birthday, together_since=together or "")
    ctx.cfg.save()

    theme = gem.theme_from_birthday(ctx.cfg.birthday)
    print()
    ui.ok(f"已保存到 {ctx.cfg.config_path}")
    print(ui.box("配置完成", [
        ui.c("名字      ", "grey") + ui.c(ctx.cfg.name or "（空）", theme.accent),
        ui.c("生日      ", "grey") + ui.c(ctx.cfg.birthday or "（空）", theme.accent),
        ui.c("认识的日  ", "grey") + ui.c(ctx.cfg.together_since or "（空）", theme.accent),
        "",
        ui.c("由此推导出的专属配色：", "grey") + ui.c(theme.name(), theme.primary, "bold"),
    ], width=ui.term_width(), style=theme.primary))

    print()
    if not ctx.store.count():
        # 非交互环境默认装（y），免得脚本里初始化完还是空题库
        answer = (ask_choice("现在装那 33 道经典题吗？(y/n)", {"y", "n"}, "y")
                  if interactive() else "y")
        if answer == "y":
            return cmd_seed(args, ctx)
    return 0


def cmd_seed(args, ctx) -> int:
    """装内置题库。注意：init 里也会调它，所以不能假设 args 一定带 dry_run。"""
    items = bank.as_seed_items(first_day=ctx.today())
    if getattr(args, "dry_run", False):
        for item in items:
            print(f"  {item['due']}  {item['title']}")
        ui.info(f"共 {len(items)} 道（dry-run，未写库）")
        return 0

    added = ctx.store.add_many(items)
    total = ctx.store.count()
    due_today = len(ctx.store.due(ctx.today()))
    print(ui.box("题库已装好", [
        ui.c("新增      ", "grey") + ui.c(f"{added} 道", ctx.theme.accent, "bold"),
        ui.c("题库总数  ", "grey") + ui.c(f"{total} 道", ctx.theme.accent, "bold"),
        ui.c("今天该复习 ", "grey") + ui.c(f"{due_today} 道", "gold", "bold"),
        "",
        ui.c("覆盖：双指针 / 滑窗 / 二分 / 单调栈 / DP / 图 / 并查集 / 设计 / 位运算", "grey"),
        "",
        ui.c("接下来：", "grey") + ui.c("her review", "hotpink", "bold"),
    ], width=ui.term_width(), style=ctx.theme.primary))
    return 0


def cmd_ui(args, ctx) -> int:
    """打开图形界面。

    单独给一个命令是为了"发现了界面但不会开"这种情况：
    她在终端里敲 her，帮助里就能看到 ui。
    """
    from . import web_server

    print(ui.c("正在启动图形界面…", "grey"))
    print(ui.c(f"  数据目录：{ctx.cfg.home}", "grey"))
    try:
        web_server.serve(
            ctx.cfg.home,
            port=getattr(args, "port", None),
            open_browser=not getattr(args, "no_open", False),
            today=ctx._web_today if hasattr(ctx, "_web_today") else None,
        )
    except RuntimeError as exc:
        ui.err(str(exc))
        return 1
    return 0


def cmd_today(args, ctx) -> int:
    # 完全没配过、题库也空 —— 那就是第一次打开。
    # 有终端就进引导（她第一次双击看到的东西很重要）；
    # 没有终端（脚本/管道）就给一条可以直接复制的命令，别去问一个没人回答的问题。
    if not ctx.cfg.is_configured() and not ctx.store.count():
        if interactive():
            return cmd_init(args, ctx)
        print(ui.box("还差一步", [
            ui.c("这个数据目录还没初始化过。", "grey"),
            "",
            ui.c("填上她的名字和生日：", "grey"),
            "  " + ui.c('her init --name "她的昵称" --birthday 2006-10-18', "hotpink"),
            "",
            ui.c("（生日很重要：那一天启动会出现蛋糕和专属祝福，配色也由它推导）", "grey"),
        ], width=ui.term_width(), style=ctx.theme.primary))
        return 0

    print(report.opening(ctx.store, ctx.theme, ctx.name, ctx.birthday, ctx.today()))
    print()

    # 今天的特别提醒
    announced = features.announce_reminders(ctx)
    if announced:
        print()

    # 面板区（倒数日 / 便签 / 提醒 / 今日一句 …以及她自己写的插件面板）
    only = [p.strip() for p in (getattr(args, "only", "") or "").split(",") if p.strip()] or None
    skip = {p.strip() for p in (getattr(args, "skip", "") or "").split(",") if p.strip()}
    if only is None and "reminders" in ctx.cfg.panel_order() and announced:
        skip.add("reminders")  # 上面已经报过一次了，别重复
    dashboard = features.render_home_panels(ctx, only=only, skip=skip)
    if dashboard:
        print(dashboard)

    due = ctx.store.due(ctx.today())
    if due:
        print()
        # 首页只列前几道，避免「生日当天 33 道全铺开」这种压迫感；
        # 完整队列在 her review 里，或者 her list --due
        preview = due[:8]
        print(report.problem_table(preview, ctx.theme, "今天该复习", ctx.today()))
        if len(due) > len(preview):
            print(ui.c(f"  （还有 {len(due) - len(preview)} 道，"
                       f"输入 her review 一道道来 / her list --due 看全部）", "grey"))
    if not ctx.store.count():
        print()
        print(report.empty_state(ctx.theme))

    features.fire_hooks(ctx, "startup")
    return 0


def cmd_add(args, ctx) -> int:
    title = args.title
    note = args.note
    tags = args.tags
    difficulty = args.difficulty
    url = args.url

    interactive = not title
    if interactive:
        title = ask("题名（必填）")
        if not title:
            ui.err("题名不能为空")
            return 1
        if difficulty is None:
            difficulty = ask_choice("难度 (easy/medium/hard)",
                                    {"easy", "medium", "hard", "e", "m", "h"}, "medium")
        if not tags:
            tags = ask("标签（空格或逗号分隔，可留空）")
        if not url:
            url = ask("链接（可留空）")
        if note is None:
            note = ask("关键思路（可留空，之后用 her edit 补）")

    diff = io_formats.normalize_difficulty(difficulty)
    tag_list = io_formats.normalize_tags(tags)
    try:
        pid = ctx.store.add(
            title=title,
            source=args.source or io_formats.guess_source(url or ""),
            difficulty=diff,
            tags=tag_list,
            url=url or "",
            note=note or "",
            memory=args.memory or "",
        )
    except ValueError as exc:
        ui.err(str(exc))
        return 1

    problem = ctx.store.get(pid)
    assert problem
    ui.ok(f"已加入 #{pid} {problem.title}  "
          f"（{problem.difficulty_label}｜{' '.join(tag_list) or '无标签'}）")
    ui.info(f"下次复习：{problem.due.isoformat()}（今天）　输入 her review 开始")
    return 0


def cmd_list(args, ctx) -> int:
    if args.tag:
        problems = [p for p in ctx.store.search(args.tag, include_archived=args.all)
                    if args.tag in p.tags]
    elif args.keyword:
        problems = ctx.store.search(args.keyword, include_archived=args.all)
    else:
        problems = ctx.store.all(include_archived=args.all)

    if args.difficulty:
        problems = [p for p in problems if p.difficulty == args.difficulty]
    if args.due:
        problems = [p for p in problems if p.is_due(ctx.today())]
    if args.limit:
        problems = problems[: args.limit]

    if not problems:
        print(report.empty_state(ctx.theme, "没有符合条件的题。"))
        return 0
    print(report.problem_table(problems, ctx.theme, args.title or "题目列表", ctx.today()))
    return 0


def cmd_show(args, ctx) -> int:
    problem = resolve(ctx.store, args.target)
    if not problem:
        ui.err(f"找不到「{args.target}」，试试 her list")
        return 1
    print(report.review_card(problem, 1, 1, ctx.theme, show_solution=True))
    print()
    rows = ctx.store.review_log(200)
    mine = [r for r in rows if r["problem_id"] == problem.id][:8]
    if mine:
        lines = []
        for row in mine:
            lines.append(
                ui.c(row["reviewed_on"], "grey")
                + "  "
                + ui.c(f"评分 {row['quality']}", "gold")
                + "  "
                + ui.c(f"→ 间隔 {row['interval_after']} 天", ctx.theme.accent)
            )
        print(ui.box("复习历史", lines, width=ui.term_width(), style=ctx.theme.primary))
    return 0


def cmd_edit(args, ctx) -> int:
    problem = resolve(ctx.store, args.target)
    if not problem:
        ui.err(f"找不到「{args.target}」")
        return 1

    changes: dict = {}
    if args.title:
        changes["title"] = args.title
    if args.note is not None:
        changes["note"] = args.note
    if args.memory is not None:
        changes["memory"] = args.memory
    if args.tags is not None:
        changes["tags"] = io_formats.normalize_tags(args.tags)
    if args.difficulty:
        changes["difficulty"] = io_formats.normalize_difficulty(args.difficulty)
    if args.url is not None:
        changes["url"] = args.url
    if args.archive:
        changes["archived"] = True

    if not changes and not args.edit:
        # 没给参数就进交互模式
        print(report.review_card(problem, 1, 1, ctx.theme, show_solution=True))
        print()
        print(ui.c("直接回车 = 不改。多行内容输入完后按 Ctrl+Z 回车（Windows）结束。", "grey"))
        for field, label in (
            ("title", "题名"), ("tags", "标签"), ("difficulty", "难度"),
            ("url", "链接"), ("note", "关键思路"), ("memory", "私人记忆"),
        ):
            current = problem.tags_text() if field == "tags" else getattr(problem, field)
            value = ask(f"{label}（当前：{str(current)[:40] or '空'}）", "")
            if value:
                changes[field] = io_formats.normalize_tags(value) if field == "tags" else value

    if changes:
        ctx.store.update(problem.id, **changes)
        ui.ok(f"已更新 #{problem.id}：{', '.join(changes)}")
    else:
        ui.info("没有改动")
    return 0


def cmd_rm(args, ctx) -> int:
    problem = resolve(ctx.store, args.target)
    if not problem:
        ui.err(f"找不到「{args.target}」")
        return 1
    if not args.yes:
        print(report.review_card(problem, 1, 1, ctx.theme, show_solution=True))
        if ask_choice(f"确认删除 #{problem.id}？(y/n)", {"y", "n"}, "n") != "y":
            ui.info("已取消（也可以只归档：her edit <id> --archive）")
            return 0
    ctx.store.delete(problem.id)
    ui.ok(f"已删除 #{problem.id} {problem.title}")
    return 0


def cmd_stats(args, ctx) -> int:
    if not ctx.store.count() and not ctx.store.review_count_total():
        print(report.empty_state(ctx.theme))
        return 0
    print(report.stats_view(ctx.store, ctx.theme, ctx.name, ctx.birthday,
                            ctx.together, ctx.today()))
    return 0


def cmd_demo_fill(args, ctx) -> int:
    """造一段历史复习记录，用来预览统计视图/热力图。"""
    if not ctx.store.count():
        ui.info("题库是空的，先装种子题库")
        ctx.store.add_many(bank.as_seed_items(first_day=ctx.today()))
        ui.ok(f"已装 {ctx.store.count()} 道题")
    if ctx.store.review_count_total() and not args.force:
        ui.warn(f"库里已经有 {ctx.store.review_count_total()} 条复习记录，"
                f"不想混就加 --force，或先备份")
        return 1
    written = ctx.store.simulate_history(days=args.days, per_day=args.per_day)
    ui.ok(f"造了 {written} 条复习记录（覆盖最近 {args.days} 天）")
    ui.info("现在 her stats 就能看到热力图和趋势了")
    return 0
