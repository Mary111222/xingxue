r"""BiliSum 视频总结器：直接托管它的后端服务，不需要桌面端。

为什么能这么做（这一段是实测出来的，不是猜的）：
    1. BiliSum 桌面端只是个 Electron 外壳，真正干活的是它内置的 Python 后端
       资源\backend\BiliSum\BiliSum.exe（FastAPI + uvicorn）。
    2. 那个 exe 能独立跑。桌面端启动它时传的环境变量我们也能传：
           VIDEO_SUM_HOST / VIDEO_SUM_PORT / VIDEO_SUM_ACCESS_TOKEN /
           VIDEO_SUM_APP_DATA_ROOT
    3. 它的 HTTP 接口有完整的 OpenAPI 规范，关键三条：
           POST /api/v1/tasks                 建任务
           GET  /api/v1/tasks/{id}            查状态
           GET  /api/v1/tasks/{id}/result     取结果
       （返回体里 knowledge_note_markdown 就是知识笔记，overview 是口播概览）

踩过的坑，都写在代码里了：
    - settings.json 里的 data_dir / host / port 是权威，环境变量未必生效，
      所以数据根要搬家时必须改写这个文件。
    - 复制过来的 sqlite 可能带只读权限，会报 "attempt to write a readonly
      database"，要显式 chmod。
    - 它启动时会尝试装自己的 Python 运行时，失败（Runtime Python executable
      is missing）不影响接口可用，别被日志里的 ERROR 吓到。

设计取舍：
    默认**复用她原来的数据根**（%LOCALAPPDATA%\\bilisum），这样配置、令牌、
    历史任务、知识库全都在，零迁移成本。
    只有在不满足（比如换电脑没装过）时才复制一份到程序目录里。
"""

from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import deps

# 常见安装位置
DEFAULT_INSTALL_ROOTS = [
    Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "BiliSum",
    Path(r"C:\Program Files\BiliSum"),
    Path(r"C:\Program Files (x86)\BiliSum"),
]

# 原有的数据根（桌面端用的那个）
LEGACY_DATA_ROOT = Path(os.environ.get("LOCALAPPDATA", "")) / "bilisum"

# --------------------------------------------------------------------------
# 后端载体：exe 或"托管运行时里的 Python"
# --------------------------------------------------------------------------
# 2026-10-05：BiliSum 桌面端被卸载，PyInstaller 打出来的
#     %LOCALAPPDATA%\Programs\BiliSum\resources\backend\BiliSum\BiliSum.exe
# 连同它 _internal\bin 里的 ffmpeg 一起没了，总结功能随之失效。
#
# 但**后端本体没丢**：桌面端当初把托管运行时和三个包都装在
#     %LOCALAPPDATA%\bilisum\runtime\base\
# 里（python.exe + Lib\site-packages\{video_sum_service,video_sum_core,video_sum_infra}），
# 实测 `python.exe -m video_sum_service` 能直接把同一个服务跑起来，读的是同一个数据根。
# 所以这里加一条回退：没有 exe 就用运行时直启，不再要求装桌面端。
CLI_RUNTIME_PY = (
    Path(os.environ.get("LOCALAPPDATA", "")) / "bilisum" / "runtime" / "base" / "python.exe"
)
RUNTIME_PY_ENV = "BILISUM_RUNTIME_PY"

# 服务的 Web 界面静态资源原本也在桌面端包里（runtime\apps\web\static），一并被删了；
# 而 app.py 在**导入时**就 StaticFiles(directory=WEB_STATIC_DIR)，目录不存在会直接崩。
# 官方 npm 包 bilisum 里自带同一份静态构建，指过去即可（API 与它无关）。
CLI_WEB_STATIC_DIR = (
    Path(os.environ.get("APPDATA", "")) / "npm" / "node_modules" / "bilisum"
    / "runtime" / "apps" / "web" / "static"
)

DEFAULT_PORT = 3838
# 端口被占用时依次尝试这些（和 BiliSum 桌面端的部署脚本同样的思路）
PORT_CANDIDATES = [3838, 3840, 3841, 3842, 3843]
HEALTH_TIMEOUT = 90.0        # 后端冷启动可能要几十秒
TASK_POLL_INTERVAL = 2.0
TASK_TIMEOUT = 3600.0        # 下载 + 转写 + 总结，放宽到一小时


# --------------------------------------------------------------------------
# 探测
# --------------------------------------------------------------------------

def find_install_root() -> Path | None:
    """找 BiliSum 的安装目录。"""
    env = os.environ.get("BILISUM_HOME")
    if env:
        candidate = Path(env)
        if candidate.exists():
            return candidate
    for root in DEFAULT_INSTALL_ROOTS:
        if root and root.exists():
            return root
    return None


def find_backend() -> Path | None:
    """找后端可执行文件。"""
    root = find_install_root()
    if root is None:
        return None
    name = "BiliSum.exe" if sys.platform.startswith("win") else "BiliSum"
    for candidate in (
        root / "resources" / "backend" / "BiliSum" / name,
        root / "backend" / "BiliSum" / name,
    ):
        if candidate.exists():
            return candidate
    return None


def runtime_python() -> Path | None:
    """桌面端托管运行时里的 Python（exe 不在时的后端载体）。

    `python.exe -m video_sum_service` 等价于原来的 BiliSum.exe：
    同一个服务、同一个数据根、同一套接口。
    """
    override = os.environ.get(RUNTIME_PY_ENV)
    if override:
        candidate = Path(override)
        return candidate if candidate.exists() else None
    return CLI_RUNTIME_PY if CLI_RUNTIME_PY.exists() else None


def find_backend_command() -> tuple[str, Path] | None:
    """返回 (可执行文件, 工作目录)：优先原版 exe，其次托管运行时里的 Python。

    调用方按返回值决定是"直接跑 exe"还是"python -m video_sum_service"。
    """
    backend = find_backend()
    if backend is not None:
        return str(backend), backend.parent
    python = runtime_python()
    if python is not None:
        return str(python), python.parent
    return None


def installed() -> bool:
    return find_backend() is not None or runtime_python() is not None


def find_ffmpeg_dir() -> Path | None:
    """找一份 ffmpeg 目录（里面有 ffmpeg.exe + ffprobe.exe）。

    服务的 ffmpeg 解析顺序是：VIDEO_SUM_FFMPEG_DIR → 打包目录 → 系统 PATH。
    原来那份在桌面端包的 _internal\\bin 里，随卸载没了，所以这里补一条：
    项目 vendor\\ffmpeg（我拉下来的 BtbN 构建，含 ffmpeg.exe + ffprobe.exe）。
    调用方把结果放进 VIDEO_SUM_FFMPEG_DIR 即可（服务侧只认真实存在的目录）。
    """
    candidates = [
        Path(__file__).resolve().parent.parent / "vendor" / "ffmpeg",
    ]
    for directory in candidates:
        try:
            if (directory / "ffmpeg.exe").exists() and (directory / "ffprobe.exe").exists():
                return directory
        except OSError:
            continue
    return None


def legacy_data_root() -> Path:
    """她原来桌面端用的数据根。"""
    env = os.environ.get("BILISUM_DATA_ROOT")
    if env:
        return Path(env)
    return LEGACY_DATA_ROOT


def local_data_root(home: Path) -> Path:
    """程序目录里的副本位置（迁移用）。"""
    return Path(home) / "bilisum"


# --------------------------------------------------------------------------
# 数据根准备
# --------------------------------------------------------------------------

def _make_writable(path: Path) -> None:
    """把 sqlite 及其 WAL 文件改成可写。

    为什么需要：从别处 copy 过来的库常常带着只读属性，
    后端启动时会直接报 "attempt to write a readonly database" 然后退出。
    """
    for suffix in ("", "-wal", "-shm"):
        target = Path(str(path) + suffix)
        if target.exists():
            try:
                os.chmod(target, 0o666)
            except OSError:
                pass


def prepare_data_root(home: Path, port: int = DEFAULT_PORT) -> tuple[Path, str]:
    """决定用哪个数据根，必要时把她的配置搬过来。

    返回 (数据根, 说明)。
    """
    legacy = legacy_data_root()
    legacy_ok = (legacy / "data" / "settings.json").exists()

    if legacy_ok:
        # 首选：直接用她原来的数据根（配置、令牌、知识库都在，零迁移）
        return legacy, ""

    # 退路：把能找到的东西复制到程序目录，做一个自包含的副本
    target = local_data_root(home)
    data = target / "data"
    data.mkdir(parents=True, exist_ok=True)

    source_data = legacy / "data"
    copied: list[str] = []
    if source_data.exists():
        for name in ("settings.json", "auth.json"):
            src = source_data / name
            if src.exists():
                shutil.copy2(src, data / name)
                copied.append(name)
        src_db = source_data / "video_sum.db"
        if src_db.exists():
            shutil.copy2(src_db, data / "video_sum.db")
            _make_writable(data / "video_sum.db")
            copied.append("video_sum.db")

    # 改写 settings.json 里的绝对路径和端口
    settings_path = data / "settings.json"
    if settings_path.exists():
        try:
            payload = json.loads(settings_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            payload = {}
        payload["data_dir"] = str(data)
        payload["cache_dir"] = str(data / "cache")
        payload["tasks_dir"] = str(data / "tasks")
        payload["database_url"] = f"sqlite:///{str(data).replace(chr(92), '/')}/video_sum.db"
        payload["host"] = "127.0.0.1"
        payload["port"] = port
        settings_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                                 encoding="utf-8")
    else:
        # 全新环境：给一份最小配置，让后端能起来
        settings_path.write_text(json.dumps({
            "host": "127.0.0.1", "port": port,
            "data_dir": str(data), "cache_dir": str(data / "cache"),
            "tasks_dir": str(data / "tasks"),
            "database_url": f"sqlite:///{str(data).replace(chr(92), '/')}/video_sum.db",
            "language": "zh", "summary_mode": "llm", "llm_enabled": False,
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    note = "已把配置复制到程序目录" + (f"（{'、'.join(copied)}）" if copied else "")
    return target, note


def read_token(data_root: Path) -> str:
    """读访问令牌。没有就生成一个并写进 auth.json。"""
    auth = data_root / "data" / "auth.json"
    if auth.exists():
        try:
            token = json.loads(auth.read_text(encoding="utf-8")).get("access_token", "")
            if token:
                return str(token)
        except (OSError, ValueError):
            pass
    # 生成一个新的（和桌面端同样的做法：随机 + 时间戳）
    import secrets

    token = secrets.token_urlsafe(32)
    try:
        auth.parent.mkdir(parents=True, exist_ok=True)
        auth.write_text(json.dumps({
            "access_token": token,
            "created_at": datetime.now().isoformat(timespec="seconds"),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass
    return token


def read_port(data_root: Path, default: int = DEFAULT_PORT) -> int:
    """端口从 settings.json 读（后端认这个，环境变量不一定生效）。"""
    settings = data_root / "data" / "settings.json"
    if settings.exists():
        try:
            value = json.loads(settings.read_text(encoding="utf-8")).get("port")
            if isinstance(value, int) and 1 <= value <= 65535:
                return value
        except (OSError, ValueError):
            pass
    return default


# --------------------------------------------------------------------------
# 服务状态
# --------------------------------------------------------------------------

def port_open(port: int, timeout: float = 0.4) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True
    except OSError:
        return False


def pid_file(home: Path) -> Path:
    return Path(home) / "bilisum-backend.pid"


def _read_pid(home: Path) -> int | None:
    path = pid_file(home)
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _pid_alive(pid: int) -> bool:
    if sys.platform.startswith("win"):
        try:
            proc = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"],
                                  capture_output=True, text=True, timeout=15)
            return str(pid) in (proc.stdout or "")
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


# --------------------------------------------------------------------------
# 客户端
# --------------------------------------------------------------------------

@dataclass
class TaskProgress:
    status: str = "queued"
    progress: int = 0
    stage: str = ""
    message: str = ""

    def is_done(self) -> bool:
        return self.status in ("completed", "failed", "cancelled")

    def line(self) -> str:
        parts = [f"{self.status}"]
        if self.progress:
            parts.append(f"{self.progress}%")
        if self.stage:
            parts.append(self.stage)
        if self.message:
            parts.append(self.message[:60])
        return "  ".join(parts)


@dataclass
class Summary:
    task_id: str
    status: str
    title: str = ""
    markdown: str = ""      # knowledge_note_markdown，就是知识笔记
    overview: str = ""      # 口播概览（带时间戳）
    transcript: str = ""
    raw: dict = field(default_factory=dict)
    error: str = ""

    def has_content(self) -> bool:
        return bool(self.markdown or self.overview or self.transcript)


class ServiceError(RuntimeError):
    pass


# --------------------------------------------------------------------------
# 链接规范化：av 号 → BV 号
# --------------------------------------------------------------------------

# B 站两套编号（av 号 / BV 号）指向同一个视频，有公开的换算算法。
#
# **为什么这段代码写得这么啰嗦**：我改了四版才写对，而且每一版错的时候
# 都**不会报错**——算出来的 BV 号格式完全合法，只是指向另一个视频
#（或者根本不存在）。这种错只能靠拿真实数据核对才会发现。
# 所以这里把踩过的坑都记下来，免得以后有人（包括我）再走一遍：
#
#   ① 字母表：网上流传的版本有一处是错的（'x' 和 '1' 的位置互换）。
#      我是拿 7 组真实的 (av, BV) 对反解才发现的。
#
#   ② 对齐的**形态**：base58 展开出来的数字串对应的是
#      "**交换之前**"的字符串，不是最终的 BV 号。
#      拿最终 BV 号去对齐，会出现"同一个字符在不同样本里算出不同的值"——
#      那不是字母表的问题，是对齐错了形态。
#
#   ③ 后缀长度是 **9**：BV 号是 "BV1" + 9 个字符。
#      我一开始按 "10-3=7" 算，那是把 BV 号的长度想当然记成了 12。
#      真实数据一对就露馅。
#
# 现在这段的验证情况：7 组真实 (av, BV) 对全部一致，round-trip 全部闭合。
_XOR_CODE = 23442827791579
_MASK_CODE = 2251799813685247
_MAX_AID = 1 << 51
_BASE = 58
_ALPHABET = "FcwAPNKTMug3GV5Lj7EJnHpWsx4tb8haYeviqBz6rkCy12mUSDQX9RdoZf"
_SUFFIX_LEN = 9


def _bv_swap(chars: list[str]) -> None:
    """BV 号里的两次位置交换（原地改）。正反向都用它——交换两次互为逆。"""
    chars[3], chars[9] = chars[9], chars[3]
    chars[4], chars[7] = chars[7], chars[4]


def av_to_bv(aid: int) -> str:
    """av 号 → BV 号。"""
    tmp = (_MAX_AID | aid) ^ _XOR_CODE
    digits: list[int] = []
    t = tmp
    while t > 0:
        digits.append(t % _BASE)
        t //= _BASE
    digits.reverse()
    if len(digits) > _SUFFIX_LEN:
        raise ValueError(f"av{aid} 超出 BV 能表示的范围")
    digits = [0] * (_SUFFIX_LEN - len(digits)) + digits
    mid = list("BV1" + "".join(_ALPHABET[d] for d in digits))
    _bv_swap(mid)
    return "".join(mid)


def bv_to_av(bvid: str) -> int:
    """BV 号 → av 号。"""
    chars = list(bvid)
    _bv_swap(chars)
    tmp = 0
    for ch in chars[3:]:
        tmp = tmp * _BASE + _ALPHABET.index(ch)
    return (tmp & _MASK_CODE) ^ _XOR_CODE


# 匹配 B 站视频链接里的 av 号。兼容几种常见写法：
#   /video/av123、/video/AV123、?aid=123、/video/av123/
_AV_RE = re.compile(r"(?:/video/|^)(?:av|AV)(\d{1,20})")
_AID_RE = re.compile(r"[?&]aid=(\d{1,20})")


def normalize_video_url(url: str) -> tuple[str | None, str]:
    """把用户输入的链接整理成 BiliSum 能接受的形式。

    返回 (可提交的链接, 说明)。链接明显不是视频页时返回 (None, 原因)。

    目前做两件事：
        · av 号 → BV 号（BiliSum 只认 BV，见 create_task 里的实测记录）
        · 去掉首尾空白和多余的空格
    """
    text = (url or "").strip()
    if not text:
        return None, "先粘一个视频链接进来。"

    # 只有 B 站链接才需要换算
    if "bilibili.com" in text or "b23.tv" in text:
        aid = None
        m = _AV_RE.search(text) or _AID_RE.search(text)
        if m:
            try:
                aid = int(m.group(1))
            except ValueError:
                aid = None
        if aid is not None:
            try:
                bv = av_to_bv(aid)
            except ValueError as exc:
                return None, str(exc)
            new_url = re.sub(r"(?:av|AV)\d{1,20}", bv, text, count=1)
            if new_url == text:
                # 走的是 ?aid= 形式，那就直接把整个链接换成标准 BV 链接
                new_url = f"https://www.bilibili.com/video/{bv}"
            return new_url, f"已把 av{aid} 换算成 {bv} 再提交（后端只认 BV 号）"

    return text, ""


def _selftest_bv() -> None:
    # 这几组是拿 B 站 API 核过的真实对应关系，写死在测试里。
    # 用真实数据而不是"自己算自己"——否则算法错了也测不出来。
    KNOWN = [
        (2, "BV1xx411c7mD"),
        (100, "BV1xx411c7mW"),
        (10000, "BV1bx411c7ux"),
        (170001, "BV17x411w7KC"),
        (80000000, "BV1QJ411x7za"),
        (370000000, "BV1AZ4y1j7Lk"),
        (117211888879765, "BV1fMtz67Ei9"),
    ]
    for aid, bv in KNOWN:
        got = av_to_bv(aid)
        assert got == bv, f"av{aid} 应为 {bv}，算出来 {got}"
        assert bv_to_av(bv) == aid, f"{bv} 应还原成 av{aid}"

    # 链接规范化
    cases = [
        ("https://www.bilibili.com/video/av117211888879765",
         "https://www.bilibili.com/video/BV1fMtz67Ei9"),
        ("http://www.bilibili.com/video/av170001",
         "http://www.bilibili.com/video/BV17x411w7KC"),
        ("https://www.bilibili.com/video/av170001?p=1",
         "https://www.bilibili.com/video/BV17x411w7KC?p=1"),
        ("https://www.bilibili.com/video/BV1fMtz67Ei9",
         "https://www.bilibili.com/video/BV1fMtz67Ei9"),
    ]
    for src, want in cases:
        got, _note = normalize_video_url(src)
        assert got == want, f"{src}\n  期望 {want}\n  实际 {got}"

    # ?aid= 形式
    got, _ = normalize_video_url("https://www.bilibili.com/video/BV1?aid=170001")
    assert "BV17x411w7KC" in (got or ""), got

    # 空链接要有明确提示，而不是抛异常
    got, why = normalize_video_url("")
    assert got is None and why

    print("bilisum av→BV 自测通过 ✓"
          f"（{len(KNOWN)} 组真实对应关系 + {len(cases)} 个链接规范化）")


# --------------------------------------------------------------------------
# 客户端的其余部分
# --------------------------------------------------------------------------


class Client:
    """BiliSum 后端的 Python 客户端。

    用法：
        client = Client(home)
        client.ensure_service()      # 没跑就拉起来（带就绪探测）
        task_id = client.create_task(url)
        summary = client.wait_for(task_id, on_progress=print)
    """

    def __init__(self, home: Path, *, port: int | None = None):
        self.home = Path(home)
        self._backend: Path | None = None
        self._backend_argv: list[str] | None = None
        self._backend_cwd: Path | None = None
        self._data_root: Path | None = None
        self._token = ""
        self._port = port or DEFAULT_PORT
        self._prepared = False
        self._note = ""

    # ---------------- 准备 ----------------

    def prepare(self, *, start_port: int = DEFAULT_PORT) -> None:
        """定位后端、确定数据根、读令牌和端口。"""
        if self._prepared:
            return
        located = find_backend_command()
        if located is None:
            raise ServiceError(
                "没找到 BiliSum 的后端。"
                "装过 BiliSum 的话用 BILISUM_HOME 指一下安装目录；"
                "只有托管运行时的话用 " + RUNTIME_PY_ENV + " 指一下 python.exe；"
                "或者告诉我你装在哪，我来适配。"
            )
        command, cwd = located
        if command.lower().endswith(".exe") and Path(command).name.lower().startswith("bilisum"):
            # 原版 PyInstaller 外壳：自带服务入口
            self._backend_argv = [command]
        else:
            # 托管运行时里的 Python：显式跑服务模块
            self._backend_argv = [command, "-m", "video_sum_service"]
        self._backend = Path(command)
        self._backend_cwd = cwd
        self._data_root, self._note = prepare_data_root(self.home, start_port)
        self._token = read_token(self._data_root)
        self._port = read_port(self._data_root, start_port)
        self._prepared = True

    def pick_free_port(self, preferred: int | None = None) -> int:
        """挑一个可用端口。

        借自 VeoStudyHub 的部署策略：默认 3838，被占用时依次尝试 3840~3843，
        这样"她的桌面端刚好也开着"这种情况不会导致启动失败。
        检测到端口被占但没有服务在响应（不是 BiliSum），就换一个。
        """
        self.prepare()
        base = preferred or self._port or DEFAULT_PORT

        # 首选端口空着 → 直接用
        if not port_open(base):
            return base
        # 端口有服务，而且健康检查过得去 → 那就是我们能用它
        ok, _state = self.health()
        if ok:
            return base

        # 端口被别的程序占了 → 依次试备选
        for candidate in PORT_CANDIDATES:
            if candidate == base:
                continue
            if not port_open(candidate):
                self._port = candidate
                self._remember_port(candidate)
                return candidate
        # 全占满了，只能沿用原端口（至少错误信息会对得上）
        return base

    def _remember_port(self, port: int) -> None:
        """把选中的端口写回 settings.json，保持和 BiliSum 自己的约定一致。"""
        if self._data_root is None:
            return
        settings = self._data_root / "data" / "settings.json"
        if not settings.exists():
            return
        try:
            payload = json.loads(settings.read_text(encoding="utf-8"))
            payload["port"] = port
            settings.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                                encoding="utf-8")
            self._port = port
        except (OSError, ValueError):
            pass

    @property
    def backend(self) -> Path | None:
        return self._backend

    @property
    def data_root(self) -> Path | None:
        return self._data_root

    @property
    def port(self) -> int:
        return self._port

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self._port}"

    @property
    def note(self) -> str:
        return self._note

    # ---------------- HTTP ----------------

    def _request(self, method: str, path: str, *, payload: dict | None = None,
                 timeout: float = 30.0) -> tuple[int, dict | str]:
        url = f"{self.base_url}{path}"
        data = None
        headers = {"Accept": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
            headers["X-Access-Token"] = self._token
        if payload is not None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                try:
                    return resp.status, json.loads(body)
                except json.JSONDecodeError:
                    return resp.status, body
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            try:
                return exc.code, json.loads(body)
            except json.JSONDecodeError:
                return exc.code, body
        except Exception as exc:
            return 0, f"{exc.__class__.__name__}: {exc}"

    def health(self) -> tuple[bool, str]:
        status, body = self._request("GET", "/health", timeout=3.0)
        if status != 200:
            return False, f"HTTP {status}"
        if isinstance(body, dict):
            state = body.get("status", "unknown")
            # degraded 只是它自己的运行时没装，接口照样能用
            return True, str(state)
        return True, "ok"

    def service_running(self) -> bool:
        return port_open(self._port)

    # ---------------- 启动 / 停止 ----------------

    def ensure_service(self, *, auto_start: bool = True,
                       on_status=None) -> tuple[bool, str]:
        """确保服务可用。返回 (是否可用, 说明)。

        优先级：已经在跑（无论谁起的）→ 直接用；否则自己拉起来。
        """
        self.prepare()

        if self.service_running():
            ok, state = self.health()
            if ok:
                return True, f"服务已在运行（127.0.0.1:{self._port}，状态 {state}）"

        if not auto_start:
            return False, "服务没在运行"

        if on_status:
            on_status(f"正在启动 BiliSum 后端（127.0.0.1:{self._port}）…")

        assert self._backend_argv is not None
        # 端口避让：3838 被别的程序占了就换 3840~3843，
        # 免得"她桌面端刚好开着"导致总结功能整个用不了
        chosen = self.pick_free_port()
        if chosen != self._port:
            if on_status:
                on_status(f"{self._port} 被占用，改用 {chosen}")
            self._port = chosen

        env = dict(os.environ)
        env.update({
            "VIDEO_SUM_HOST": "127.0.0.1",
            "VIDEO_SUM_PORT": str(self._port),
            "VIDEO_SUM_ACCESS_TOKEN": self._token,
            "VIDEO_SUM_APP_DATA_ROOT": str(self._data_root),
        })
        # 托管运行时直启时补两样东西（原来的 exe 是自带这两样的）：
        #   ① 静态目录：app.py 导入时就 StaticFiles()，目录不存在会崩，指到 npm 包自带的构建
        #   ② ffmpeg：本来是桌面端包里的 _internal\bin\ffmpeg.exe，现在用 vendor\ffmpeg
        if "-m" in (self._backend_argv or []):
            static_dir = os.environ.get("VIDEO_SUM_WEB_STATIC_DIR", "").strip()
            if not static_dir and CLI_WEB_STATIC_DIR.exists():
                env["VIDEO_SUM_WEB_STATIC_DIR"] = str(CLI_WEB_STATIC_DIR)
        ffmpeg_dir = os.environ.get("VIDEO_SUM_FFMPEG_DIR", "").strip()
        if not (ffmpeg_dir and Path(ffmpeg_dir, "ffmpeg.exe").exists()):
            found = find_ffmpeg_dir()
            if found is not None:
                env["VIDEO_SUM_FFMPEG_DIR"] = str(found)
        log_path = self.home / "bilisum-backend.log"
        self.home.mkdir(parents=True, exist_ok=True)
        try:
            log = log_path.open("ab")
        except OSError:
            log = subprocess.DEVNULL  # type: ignore[assignment]

        try:
            proc = subprocess.Popen(
                self._backend_argv,
                cwd=str(self._backend_cwd or Path(self._backend_argv[0]).parent),
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                close_fds=True,
            )
        except OSError as exc:
            return False, f"启动后端失败：{exc}"

        try:
            pid_file(self.home).write_text(str(proc.pid), encoding="utf-8")
        except OSError:
            pass

        deadline = time.time() + HEALTH_TIMEOUT
        while time.time() < deadline:
            if proc.poll() is not None:
                tail = ""
                try:
                    lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
                    tail = "；".join(l.strip() for l in lines[-3:])
                except OSError:
                    pass
                return False, f"后端启动后立刻退出了（返回码 {proc.returncode}）{tail}"
            if self.service_running():
                ok, state = self.health()
                if ok:
                    return True, f"后端已启动（PID {proc.pid}，状态 {state}）"
            time.sleep(0.5)

        return False, f"等 {HEALTH_TIMEOUT:.0f}s 还没就绪，日志见 {log_path}"

    def stop_service(self) -> bool:
        """停掉我们自己拉起来的那个后端（别人起的不管）。"""
        pid = _read_pid(self.home)
        if pid is None or not _pid_alive(pid):
            return False
        try:
            if sys.platform.startswith("win"):
                subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                               capture_output=True, timeout=20)
            else:
                os.kill(pid, 15)
        except Exception:
            return False
        try:
            pid_file(self.home).unlink()
        except OSError:
            pass
        return True

    # ---------------- 业务 ----------------

    # ---------------- cookies 同步 ----------------

    def get_settings(self) -> tuple[bool, dict | str]:
        """读 BiliSum 的设置。返回 (成功, 设置或错误)。"""
        self.prepare()
        status, data = self._request("GET", "/api/v1/settings", timeout=15)
        if status == 200 and isinstance(data, dict):
            return True, data
        return False, f"HTTP {status} {str(data)[:160]}"

    def set_settings(self, patch: dict) -> tuple[bool, str]:
        """改 BiliSum 的设置（部分更新）。

        **先读再合并**：PUT 是整体替换还是部分更新，不同的后端实现不一样。
        先 GET 一份、把要改的字段合进去、再 PUT 整份，
        这样不管后端怎么实现都对。
        """
        ok, current = self.get_settings()
        if not ok:
            return False, str(current)
        merged = dict(current)
        merged.update(patch)
        status, data = self._request(
            "PUT", "/api/v1/settings", payload=merged, timeout=20)
        if status in (200, 201, 204):
            return True, "已更新"
        return False, f"HTTP {status} {str(data)[:160]}"

    def sync_cookies_file(self, path) -> tuple[bool, str]:
        """把 cookies 文件路径告诉 BiliSum（给 yt-dlp 用）。

        为什么是**文件**而不是 `ytdlp_cookies_browser`：
            `yt-dlp --cookies-from-browser` 在 Windows 上不可用
            （它依赖的浏览器 cookie 解密库不支持 Windows）。
            让 BiliSum 走那条路等于让它失败。
        而我们的 cookies 已经存成 Netscape 格式了——那正是 yt-dlp 认的格式。

        返回 (成功, 说明)。失败原因原样带出去（服务没跑 / 没权限 / 字段名变了）。
        """
        from pathlib import Path as _P

        p = _P(path)
        if not p.is_file():
            return False, "cookies 文件不存在，先在界面里保存一次。"
        try:
            self.prepare()
        except Exception as exc:
            return False, f"BiliSum 后端没准备好：{exc}"
        if not self.service_running():
            return False, "BiliSum 服务没在跑，视频总结第一次用时会自动拉起来。"
        return self.set_settings({
            "ytdlp_cookies_file": str(p),
            # 明确清掉 browser 那个：在 Windows 上它只会让 yt-dlp 报错
            "ytdlp_cookies_browser": "",
        })

    def cookies_status(self) -> dict:
        """看 BiliSum 现在用的是哪个 cookies 文件。"""
        try:
            self.prepare()
        except Exception as exc:
            return {"ok": False, "reason": f"BiliSum 后端没准备好：{exc}"}
        if not self.service_running():
            return {"ok": False, "reason": "BiliSum 服务没在跑"}
        ok, data = self.get_settings()
        if not ok:
            return {"ok": False, "reason": str(data)}
        assert isinstance(data, dict)
        return {
            "ok": True,
            "cookies_file": data.get("ytdlp_cookies_file") or "",
            "cookies_browser": data.get("ytdlp_cookies_browser") or "",
        }


    def list_tasks(self, limit: int = 40) -> list[dict]:
        """拿最近的任务列表。

        为什么要这个：界面上光看"我的任务 status=queued"是不够的——
        BiliSum 的 worker 数量有限（一个任务占一个 worker 线程），
        如果有别的任务卡住了，新任务就会一直排队。
        实测遇到过：两个任务卡在 running 半小时，后面全堵着，
        而界面上只显示"进度 0%"，看起来像我们的进度条坏了。

        有了列表就能告诉她"前面还排着 N 个"，并在确实卡住时
        给出可操作的建议（取消 / 重启后端）。
        """
        status, body = self._request("GET", "/api/v1/tasks", timeout=20)
        if status != 200:
            return []
        items = body if isinstance(body, list) else (
            (body or {}).get("items") or (body or {}).get("tasks") or [])
        if not isinstance(items, list):
            return []
        out = []
        for t in items[:limit]:
            if not isinstance(t, dict):
                continue
            out.append({
                "task_id": str(t.get("id") or t.get("task_id") or ""),
                "status": str(t.get("status") or ""),
                "source": str(t.get("source") or ""),
                "title": str(t.get("title") or ""),
                "created_at": str(t.get("created_at") or ""),
                "progress": t.get("progress"),
                "error_message": str(t.get("error_message") or ""),
            })
        return out

    def cancel_task(self, task_id: str) -> tuple[bool, str]:
        """取消 / 删除一个任务。"""
        status, body = self._request("DELETE", f"/api/v1/tasks/{task_id}",
                                     timeout=20)
        if status in (200, 202, 204):
            return True, "已取消"
        detail = body.get("detail") if isinstance(body, dict) else body
        return False, f"取消失败（HTTP {status}）：{str(detail)[:100]}"

    def restart_service(self) -> tuple[bool, str]:
        """把后端重启一次。

        为什么需要这个按钮：BiliSum 的 worker 线程池**一旦死掉就再也
        不会自己恢复**——只需要一次异常（实测是一次文件占用导致的
        PermissionError），之后所有任务都只会进队列、没人处理。
        而它启动时会"Recovered N queued task(s)"，也就是**重启就能救回来**。
        实测确认：取消卡死任务没用，重启之后队列立刻开始跑。
        所以界面上必须给她一个"重启后端"的按钮，
        否则她只能自己去任务管理器里折腾。
        """
        # 先试它自己的优雅停机接口
        try:
            self._request("POST", "/api/v1/system/shutdown", timeout=15)
        except Exception:
            pass
        # 等它真的退出（不能只看接口返回，要确认端口不再监听）
        for _ in range(20):
            time.sleep(0.5)
            if not port_open(self.port, timeout=0.4):
                break
        else:
            # 优雅停机没生效，强杀
            self.stop_service()
            time.sleep(2)
        return self.ensure_service()

    def create_task(self, url: str, *, title: str = "", language: str = "zh",
                    prefer_subtitles: bool = True) -> tuple[bool, str]:
        """建一个总结任务。返回 (成功, task_id 或错误说明)。"""
        self.prepare()

        # 把 av 号链接换成 BV 号链接再提交。
        #
        # 为什么必须换：BiliSum 后端**只认 BV 号**。
        # 实测（直接打它的 API）：
        #     https://www.bilibili.com/video/av117211888879765  → HTTP 400
        #         {"detail":"当前仅支持 Bilibili 或 YouTube 单条视频链接。"}
        #     https://www.bilibili.com/video/BV1fMtz67Ei9       → HTTP 201
        # 而 B 站上两种链接都常见，用户复制到哪个都有可能——
        # 报错信息还完全没提"av 号不支持"，所以她只会觉得"这功能坏了"。
        # 所以这里自己把 av 换算成 BV，让她复制哪种链接都能用。
        fixed_url, note = normalize_video_url(url)
        if fixed_url is None:
            return False, note

        payload = {
            "input_type": "url",
            "source": fixed_url,
            "options": {
                "language": language,
                "prefer_subtitles": prefer_subtitles,
            },
        }
        if title:
            payload["title"] = title

        status, body = self._request("POST", "/api/v1/tasks", payload=payload, timeout=60)
        if status not in (200, 201):
            detail = body.get("detail") if isinstance(body, dict) else body
            return False, f"建任务失败（HTTP {status}）：{detail}"
        if not isinstance(body, dict):
            return False, f"建任务返回看不懂：{str(body)[:120]}"
        task_id = body.get("task_id") or body.get("id") or ""
        if not task_id:
            return False, f"返回里没有 task_id：{json.dumps(body, ensure_ascii=False)[:160]}"
        return True, str(task_id)

    def progress(self, task_id: str) -> TaskProgress:
        status, body = self._request("GET", f"/api/v1/tasks/{task_id}/progress", timeout=10)
        if status == 200 and isinstance(body, dict):
            return TaskProgress(
                status=str(body.get("status", "")),
                progress=int(body.get("progress") or 0),
                stage=str(body.get("latest_stage") or ""),
                message=str(body.get("latest_message") or ""),
            )
        # 退路：直接查任务详情拿状态
        status, body = self._request("GET", f"/api/v1/tasks/{task_id}", timeout=10)
        if status == 200 and isinstance(body, dict):
            return TaskProgress(
                status=str(body.get("status", "")),
                progress=int(body.get("progress") or 0),
                message=str(body.get("error_message") or ""),
            )
        return TaskProgress(status="unknown", message=f"HTTP {status}")

    def fetch_result(self, task_id: str) -> Summary:
        status, body = self._request("GET", f"/api/v1/tasks/{task_id}/result", timeout=30)
        if status != 200 or not isinstance(body, dict):
            return Summary(task_id=task_id, status="failed",
                           error=f"取结果失败（HTTP {status}）：{str(body)[:160]}")

        result = body.get("result") or {}
        if not isinstance(result, dict):
            result = {}
        summary = Summary(
            task_id=task_id,
            status=str(body.get("status", "")),
            title=str(body.get("title") or body.get("page_title") or ""),
            markdown=str(result.get("knowledge_note_markdown") or ""),
            overview=str(result.get("overview") or ""),
            transcript=str(result.get("transcript_text") or ""),
            raw=body if isinstance(body, dict) else {},
            error=str(body.get("error_message") or ""),
        )
        # 有些版本把笔记放在别的键里，兜一下
        if not summary.markdown:
            for key in ("knowledge_note", "summary_markdown", "note_markdown"):
                if result.get(key):
                    summary.markdown = str(result[key])
                    break
        return summary

    def wait_for(self, task_id: str, *, on_progress=None,
                 timeout: float = TASK_TIMEOUT,
                 interval: float = TASK_POLL_INTERVAL) -> Summary:
        """等任务完成。on_progress(TaskProgress) 用来显示进度。"""
        deadline = time.time() + timeout
        last = ""
        while time.time() < deadline:
            prog = self.progress(task_id)
            line = prog.line()
            if on_progress and line != last:
                on_progress(prog)
                last = line
            if prog.is_done():
                break
            time.sleep(interval)
        else:
            return Summary(task_id=task_id, status="timeout",
                           error=f"等超过 {timeout:.0f}s 还没结束")

        summary = self.fetch_result(task_id)
        if summary.status == "failed" and not summary.error:
            summary.error = "任务失败（后端没给原因，可以看 her plugins log 或后端日志）"
        return summary


# --------------------------------------------------------------------------
# 把结果渲染成人看的文本
# --------------------------------------------------------------------------

def render_summary_markdown(summary: Summary) -> str:
    """拼一份完整、可直接存成 .md 的内容。"""
    parts: list[str] = []
    if summary.title:
        parts.append(f"# {summary.title}")
        parts.append("")
    if summary.markdown:
        parts.append(summary.markdown.strip())
        parts.append("")
    if summary.overview:
        parts.append("## 口播概览")
        parts.append("")
        parts.append(summary.overview.strip())
        parts.append("")
    if summary.transcript:
        parts.append("## 完整转写")
        parts.append("")
        parts.append(summary.transcript.strip())
        parts.append("")
    return "\n".join(parts).strip() + "\n"


# --------------------------------------------------------------------------
# 自测（不启动服务，只测纯逻辑）
# --------------------------------------------------------------------------

def _selftest() -> None:
    # 先跑 av/bv 转换那组断言。
    #
    # **这两组本来是同一个函数名、分两处定义的**，
    # 后面那个把前面那个覆盖了，所以 500 多行的断言一直是摆设。
    # 现在拆成两个名字显式调用——重复定义不报错，只会静默失效。
    _selftest_bv()

    from . import ui
    from ._testutil import temp_home

    ui.use_color(False)

    # 端口解析
    assert read_port(Path("不存在的目录"), 9999) == 9999

    # 令牌生成要写文件并稳定。
    # 注意用 temp_home 而不是 tempfile：受限环境（只读系统 temp）里
    # tempfile 建目录会失败，temp_home 会自动退到工作目录。
    with temp_home(".selftest-bilisum") as root:
        (root / "data").mkdir(parents=True, exist_ok=True)
        token1 = read_token(root)
        token2 = read_token(root)
        assert token1 and token1 == token2, "令牌应该生成一次后稳定"
        assert len(token1) >= 20

    # Summary 渲染
    s = Summary(task_id="x", status="completed", title="测试视频",
                markdown="# 标题\n\n正文", overview="[00:00] 大家好")
    text = render_summary_markdown(s)
    assert "# 测试视频" in text and "正文" in text and "口播概览" in text, text
    assert s.has_content()

    empty = Summary(task_id="y", status="failed", error="炸了")
    assert not empty.has_content()

    # 进度行
    p = TaskProgress(status="running", progress=42, stage="asr", message="转写中")
    assert "42%" in p.line() and "转写中" in p.line(), p.line()
    assert not p.is_done()
    assert TaskProgress(status="completed").is_done()

    print("bilisum selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
