"""导入 / 导出：让这个程序不封闭。

- CSV：和 Excel / 表格互转，她自己整理题单用得上
- Markdown：从她的笔记（比如自己记的题解）里直接抓题
- JSON：完整备份，换电脑不丢数据

Markdown 解析的目标是从「人写的笔记」里提取题目。做法是：
    1. 优先认链接（[标题](https://leetcode.cn/problems/xxx/)）
    2. 其次认「题名 · 难度 · 标签」这类结构化行
    3. 认不出来的行直接跳过，不报错——导入笔记不该因为格式不标准就失败
"""

from __future__ import annotations

import csv
import io
import json
import re
from datetime import date
from pathlib import Path

# ---------------- 常量 ----------------

CSV_FIELDS = ["title", "tags", "difficulty", "source", "url", "note", "memory", "due"]

_KNOWN_URL = re.compile(
    r"https?://(?:www\.)?(?:"
    r"leetcode\.(?:cn|com)|luogu\.com\.cn|nowcoder\.com|acwing\.com|"
    r"codeforces\.com|atcoder\.jp"
    r")[^\s)\]\"'>]*",
    re.IGNORECASE,
)

# [标题](url)
_MD_LINK = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")

# - 1. 两数之和 · 简单 · 数组,哈希表
# 注意这里刻意不做「可选组」的回溯：分隔符和后面的内容都吞进 rest，交给 Python 再拆，
# 否则正则会在 "并查集 · 困难 · 图,并查集" 这种输入上把 tag 吃掉（踩过）。
_MD_STRUCTURED = re.compile(
    r"^\s*(?:[-*+]|\d+[.)])\s+(?P<title>[^·|,，\t]+?)\s*"
    r"(?:(?:[·|]|,|，)\s*(?P<rest>[^\t]+))?$"
)

_DIFF_TOKEN = re.compile(r"^(简单|容易|中等|困难|easy|medium|hard|e|m|h|mid)$", re.IGNORECASE)

_DIFF_MAP = {
    "简单": "easy", "容易": "easy", "easy": "easy", "e": "easy",
    "中等": "medium", "medium": "medium", "m": "medium", "mid": "medium",
    "困难": "hard", "hard": "hard", "h": "hard",
}

_SOURCE_MAP = {
    "leetcode.cn": "leetcode", "leetcode.com": "leetcode", "leetcode": "leetcode",
    "luogu.com.cn": "luogu", "luogu": "luogu", "洛谷": "luogu",
    "nowcoder.com": "nowcoder", "nowcoder": "nowcoder", "牛客": "nowcoder",
    "acwing.com": "acwing", "acwing": "acwing",
    "codeforces.com": "codeforces", "codeforces": "codeforces", "cf": "codeforces",
    "atcoder.jp": "atcoder", "atcoder": "atcoder",
}

_TAG_SPLIT = re.compile(r"[,，、;；/|\s]+")


def normalize_difficulty(raw: str | None) -> str:
    if not raw:
        return "medium"
    return _DIFF_MAP.get(str(raw).strip().lower(), "medium")


def normalize_tags(raw) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        items = [str(x) for x in raw]
    else:
        items = _TAG_SPLIT.split(str(raw))
    out: list[str] = []
    for tag in items:
        tag = tag.strip().lstrip("#")
        if tag and tag not in out:
            out.append(tag)
    return out


def guess_source(url: str, fallback: str = "leetcode") -> str:
    if not url:
        return fallback
    lowered = url.lower()
    for key, value in _SOURCE_MAP.items():
        if key in lowered:
            return value
    return "other"


def _parse_due(raw) -> date | None:
    if not raw:
        return None
    if isinstance(raw, date):
        return raw
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            from datetime import datetime

            return datetime.strptime(str(raw).strip(), fmt).date()
        except ValueError:
            continue
    return None


def _clean_item(raw: dict) -> dict | None:
    """把任意来源的一条记录整理成 Store.add 能吃的样子。"""
    title = (raw.get("title") or raw.get("name") or raw.get("题目") or "").strip()
    if not title:
        return None
    url = (raw.get("url") or raw.get("link") or raw.get("链接") or "").strip()
    item = {
        "title": title,
        "tags": normalize_tags(raw.get("tags") or raw.get("tag") or raw.get("标签")),
        "difficulty": normalize_difficulty(raw.get("difficulty") or raw.get("难度")),
        "source": str(raw.get("source") or raw.get("平台") or guess_source(url)),
        "url": url,
        "note": (raw.get("note") or raw.get("思路") or raw.get("备注") or "").strip(),
        "memory": (raw.get("memory") or raw.get("记忆") or "").strip(),
    }
    due = _parse_due(raw.get("due") or raw.get("到期"))
    if due:
        item["due"] = due
    if item["source"] not in {"leetcode", "luogu", "nowcoder", "acwing", "codeforces", "atcoder", "other"}:
        item["source"] = guess_source(url)
    return item


# --------------------------------------------------------------------------
# 导入
# --------------------------------------------------------------------------

def parse_csv(text: str) -> list[dict]:
    out: list[dict] = []
    reader = csv.DictReader(io.StringIO(text))
    for row in reader:
        item = _clean_item({k: v for k, v in row.items() if k})
        if item:
            out.append(item)
    return out


def _split_structured_rest(rest: str) -> tuple[str | None, list[str]]:
    """把 "困难 · 图,并查集" 拆成 (难度, [标签])。"""
    difficulty: str | None = None
    tags: list[str] = []
    tokens = [t.strip() for t in re.split(r"\s*[·|]\s*", rest) if t.strip()]
    for token in tokens:
        if difficulty is None and _DIFF_TOKEN.match(token):
            difficulty = token
            continue
        tags.extend(normalize_tags(token))
    return difficulty, tags


def parse_markdown(text: str) -> list[dict]:
    """从 Markdown 笔记里抓题。宽松解析，抓不到就跳过，不因为格式不标准就失败。

    优先级：链接行（最可靠）> 结构化列表行 > 裸 URL。
    """
    out: list[dict] = []
    seen: set[str] = set()
    lines = text.splitlines()

    def note_after(index: int) -> str:
        """题目下面紧跟的那行普通文字，当作思路。"""
        for offset in (1, 2):
            if index + offset >= len(lines):
                break
            nxt = lines[index + offset].strip()
            if not nxt:
                continue
            if nxt.startswith(("#", "-", "*", "+", "[", "|", ">", "```")):
                break
            if _KNOWN_URL.search(nxt) or _MD_LINK.search(nxt):
                break
            return nxt
        return ""

    for index, line in enumerate(lines):
        handled = False

        # 1) 链接形式：标题 + 平台 URL
        for match in _MD_LINK.finditer(line):
            title, url = match.group(1).strip(), match.group(2).strip()
            if not _KNOWN_URL.match(url) or not title or title in seen:
                continue
            seen.add(title)
            out.append(_clean_item({"title": title, "url": url, "note": note_after(index)}))
            handled = True

        # 2) 结构化列表行（没有链接时）
        if not handled:
            match = _MD_STRUCTURED.match(line)
            if match:
                title = match.group("title").strip()
                if title and title not in seen and len(title) <= 60 \
                        and not title.endswith(("：", ":")) and not title.startswith(("http", "```")):
                    difficulty, tags = _split_structured_rest(match.group("rest") or "")
                    seen.add(title)
                    out.append(
                        _clean_item(
                            {"title": title, "difficulty": difficulty, "tags": tags,
                             "note": note_after(index)}
                        )
                    )
                    handled = True

        # 3) 裸 URL 形式：题名从 URL 的 slug 推出来
        if not handled:
            bare = _KNOWN_URL.search(line)
            if bare:
                url = bare.group(0).rstrip("。，,.;")
                slug = url.rstrip("/").split("/")[-1]
                title = slug.replace("-", " ").strip()
                if title and title not in seen:
                    seen.add(title)
                    out.append(_clean_item({"title": title, "url": url}))

    return [item for item in out if item]


def parse_json(text: str) -> list[dict]:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return []
    raw_items = []
    if isinstance(payload, list):
        raw_items = payload
    elif isinstance(payload, dict):
        raw_items = payload.get("problems") or payload.get("items") or payload.get("data") or []
    out: list[dict] = []
    for raw in raw_items:
        if not isinstance(raw, dict):
            continue
        item = _clean_item(raw)
        if not item:
            continue
        # JSON 备份里带着学习状态，一并还原
        for key in ("repetitions", "interval", "ef", "lapses", "review_count"):
            if key in raw:
                item[key] = raw[key]
        out.append(item)
    return out


def parse_any(path_or_text: str, fmt: str = "auto") -> list[dict]:
    """给一个文件路径，自动按扩展名/内容判断格式。"""
    path = Path(path_or_text)
    if path.exists() and path.is_file():
        text = path.read_text(encoding="utf-8", errors="replace")
        suffix = path.suffix.lower()
        if fmt == "auto":
            fmt = {".csv": "csv", ".md": "markdown", ".markdown": "markdown",
                   ".json": "json", ".txt": "markdown"}.get(suffix, "auto")
    else:
        text = path_or_text
        suffix = ""
    if fmt == "auto":
        stripped = text.lstrip()
        if stripped.startswith(("[", "{")):
            fmt = "json"
        elif suffix == ".csv" or ("," in text.splitlines()[0] if text.splitlines() else False):
            fmt = "csv"
        else:
            fmt = "markdown"
    if fmt == "csv":
        items = parse_csv(text)
        if not items:
            items = parse_markdown(text)
    elif fmt == "json":
        items = parse_json(text)
    else:
        items = parse_markdown(text)
    return items


# --------------------------------------------------------------------------
# 导出
# --------------------------------------------------------------------------

def to_csv(problems) -> str:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=CSV_FIELDS, extrasaction="ignore")
    writer.writeheader()
    for p in problems:
        writer.writerow(
            {
                "title": p.title,
                "tags": " ".join(p.tags),
                "difficulty": p.difficulty,
                "source": p.source,
                "url": p.url,
                "note": p.note,
                "memory": p.memory,
                "due": p.due.isoformat(),
            }
        )
    return buf.getvalue()


def to_markdown(problems, title: str = "她的题单") -> str:
    from datetime import datetime

    lines = [
        f"# {title}",
        "",
        f"> 导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}　共 {len(problems)} 道",
        "",
        "| 题目 | 难度 | 标签 | 状态 | 下次复习 | 遗忘 |",
        "|---|---|---|---|---|---|",
    ]
    diff_cn = {"easy": "简单", "medium": "中等", "hard": "困难"}
    for p in problems:
        name = f"[{p.title}]({p.url})" if p.url else p.title
        lines.append(
            f"| {name} | {diff_cn.get(p.difficulty, p.difficulty)} | "
            f"{' '.join('#' + t for t in p.tags)} | {p.maturity} | "
            f"{p.due.isoformat()} | {p.lapses} |"
        )

    with_notes = [p for p in problems if p.note]
    if with_notes:
        lines.extend(["", "## 关键思路", ""])
        for p in with_notes:
            lines.append(f"### {p.title}")
            lines.append("")
            lines.append(p.note)
            if p.memory:
                lines.append("")
                lines.append(f"> {p.memory}")
            lines.append("")
    return "\n".join(lines) + "\n"


def to_json(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=2) + "\n"


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    csv_text = "title,tags,difficulty,url\n两数之和,数组 哈希表,简单,https://leetcode.cn/problems/two-sum/\n"
    items = parse_csv(csv_text)
    assert len(items) == 1, items
    assert items[0]["title"] == "两数之和"
    assert items[0]["tags"] == ["数组", "哈希表"], items[0]["tags"]
    assert items[0]["difficulty"] == "easy"

    md = """
# 我的题单
- [两数之和](https://leetcode.cn/problems/two-sum/)
  哈希表存已经见过的值
- [每日温度](https://leetcode.cn/problems/daily-temperatures/)
- https://leetcode.cn/problems/sliding-window-maximum/
"""
    items = parse_markdown(md)
    titles = [i["title"] for i in items]
    assert "两数之和" in titles, titles
    assert "每日温度" in titles, titles
    assert any("sliding window" in t for t in titles), titles
    two_sum = next(i for i in items if i["title"] == "两数之和")
    assert two_sum["note"] == "哈希表存已经见过的值", two_sum
    assert two_sum["source"] == "leetcode"

    structured = parse_markdown("- 并查集 · 困难 · 图,并查集\n- 单调栈 · 中等 · 栈\n随便一句普通的话\n")
    assert len(structured) == 2, structured
    assert structured[0]["difficulty"] == "hard"
    assert structured[0]["tags"] == ["图", "并查集"], structured[0]["tags"]

    assert normalize_difficulty("HARD") == "hard"
    assert normalize_difficulty(None) == "medium"
    assert normalize_tags("#数组、哈希表;双指针") == ["数组", "哈希表", "双指针"]

    js = parse_json('[{"title":"LRU缓存","tags":["设计"],"difficulty":"中等","ef":2.6}]')
    assert js[0]["difficulty"] == "medium" and js[0]["ef"] == 2.6, js

    assert parse_any("不存在的文件.csv") == [] or True  # 不抛异常即可
    print("io_formats selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
