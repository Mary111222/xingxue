"""听力练习：真题清单 + 音频探测。

## 不打包音频（版权）

六级真题音频是**有版权**的（上海外语教育出版社/考试院），
程序里不放任何音频文件。这里只提供：

    · 真题清单（年份/月份/套数/题量/分值）—— 规划用
    · 音频路径的登记与探测（时长、大小）
    · 前端负责播放/循环/默写

## 音频格式

mp3 / m4a / wav / flac / ogg —— 浏览器基本都能播（mp3/m4a 最稳）。
探测时长要解析音频头，标准库做不了，所以**时长靠前端 audio 元素自己报**
（`loadedmetadata` 事件），后端只登记大小。
"""
from __future__ import annotations
import re

from datetime import datetime
from pathlib import Path

AUDIO_EXT = {".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg", ".opus", ".wma"}

# 真题清单：2021-2025，每年 6 月/12 月各一套（六级听力 25 题 / 248.5 分）
REAL_PAPERS: list[dict] = []
for year in range(2021, 2026):
    for month, tag in ((6, "6月"), (12, "12月")):
        REAL_PAPERS.append({
            "key": f"{year}-{month:02d}",
            "title": f"{year}年{tag}六级听力",
            "year": year,
            "parts": [
                {"name": "长对话", "count": 8, "score": 8 * 7.1},
                {"name": "听力篇章", "count": 6, "score": 6 * 7.1},
                {"name": "讲话/报道/讲座", "count": 3, "score": 3 * 14.2},
            ],
            "total": 25,
            "full_score": 248.5,
            "minutes": 30,
        })


def kind_label(kind: str) -> str:
    return {"real": "真题", "intensive": "精听", "loop": "磨耳朵"}.get(kind, kind)


def describe_audio(raw: str) -> dict:
    """把一个本地音频路径登记成一条记录（只读、不复制文件）。"""
    p = Path(str(raw).strip().strip('"')).expanduser()
    if not p.is_absolute():
        return {"ok": False, "error": "请写完整路径（比如 D:\\听力\\2024-12.mp3）"}
    if not p.is_file():
        return {"ok": False, "error": f"找不到这个文件：{p}"}
    if p.suffix.lower() not in AUDIO_EXT:
        return {"ok": False,
                "error": f"这个扩展名（{p.suffix}）不像音频；支持 "
                         + "、".join(sorted(AUDIO_EXT))}
    try:
        size = p.stat().st_size
    except OSError as exc:
        return {"ok": False, "error": f"读不了：{exc.__class__.__name__}"}
    return {"ok": True, "title": p.stem[:120], "path": str(p),
            "ext": p.suffix.lower().lstrip("."),
            "mb": round(size / 1024 / 1024, 1)}


def _selftest() -> None:
    import tempfile

    assert len(REAL_PAPERS) == 10, len(REAL_PAPERS)
    assert REAL_PAPERS[0]["total"] == 25
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as td:
        d = Path(td)
        (d / "a.mp3").write_bytes(b"ID3" + b"\x00" * 100)
        (d / "b.txt").write_text("x", encoding="utf-8")
        assert describe_audio(str(d / "a.mp3"))["ok"]
        assert not describe_audio(str(d / "b.txt"))["ok"], "非音频要拒"
        assert not describe_audio("相对.mp3")["ok"], "相对路径要拒"
        assert not describe_audio(str(d / "nope.mp3"))["ok"], "不存在要拒"
        print("listening selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()

# B 站视频号：BV 后面 10 位左右（av 号老格式也认一下）
BILI_RE = re.compile(r"(BV[0-9A-Za-z]{8,12})")
BILI_URL_RE = re.compile(r"^https?://([\w-]+\.)*bilibili\.com/", re.I)
AV_RE = re.compile(r"^https?://([\w-]+\.)*bilibili\.com/video/av(\d+)", re.I)


def bvid_of(raw: str) -> str:
    """从链接或纯 BV 号里取出 bvid（取不到返回空）。"""
    m = BILI_RE.search(str(raw))
    return m.group(1) if m else ""


def is_bili(raw: str) -> bool:
    s = str(raw).strip()
    return bool(BILI_URL_RE.match(s) or BILI_RE.fullmatch(s) or AV_RE.match(s))


def describe_source(raw: str) -> dict:
    """统一的"来源"识别：本地音频文件 或 B 站链接。

    **两种来源走同一个入口** —— 用户不该记"哪种该填哪"。
    """
    s = str(raw).strip().strip('"')
    if not s:
        return {"ok": False, "error": "粘一个音频路径或 B 站链接"}

    if is_bili(s):
        bv = bvid_of(s)
        av = AV_RE.match(s)
        if not bv and not av:
            return {"ok": False, "error": "像是 B 站链接，但认不出视频号（BV/av）"}
        title = bv or (f"av{av.group(2)}" if av else "B站视频")
        # 试着拿一下真实标题（拿不到也不影响播放）
        pretty = ""
        try:
            from . import bilibili  # 项目里已有（视频总结在用）

            for fn in ("video_title", "title_of", "fetch_title"):
                f = getattr(bilibili, fn, None)
                if callable(f):
                    pretty = str(f(s) or "")
                    break
        except Exception:
            pretty = ""
        return {"ok": True, "source": "bilibili", "url": s, "bvid": bv or "",
                "title": (pretty or title)[:120],
                "ext": "bilibili", "mb": 0}

    got = describe_audio(s)
    if got.get("ok"):
        got["source"] = "file"
    return got

# 级别 → 名称（四级和六级的听力结构一样：25 题 / 248.5 分 / 约 30 分钟）
LEVEL_LABELS = {"cet4": "四级", "cet6": "六级"}


def real_papers(level: str = "cet6") -> list[dict]:
    """真题清单（按级别给标题；结构相同）。"""
    lab = LEVEL_LABELS.get(str(level), "六级")
    out = []
    for p in REAL_PAPERS:
        q = dict(p)
        q["title"] = str(p["title"]).replace("六级", lab)
        q["level"] = str(level)
        out.append(q)
    return out
