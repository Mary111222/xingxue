"""面板系统 + 三个内置小工具：倒数日、便签卡片、特别提醒。

设计要点（这是整个程序「可扩展」的地基）：

    内置工具不是特权代码，它们就是插件。
    倒数日 / 便签 / 提醒都通过和用户自定义插件完全相同的 PanelAPI 注册进来，
    所以「官方功能」和「她自己加的功能」在架构上没有任何区别。

面板协议（鸭子类型，不需要继承任何东西）：

    class MyPanel:
        id = "xxx"                      # 唯一标识，用在 --only/--skip 和配置里
        title = "面板标题"
        def render(self, ctx) -> str    # 返回要显示的文本（可以是多行）
        def intro(self) -> str:         # 可选：一句话介绍（her panels 里显示）

面板出任何异常都会被兜住，只显示一行提示，绝不连累首页其他部分。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Iterable

from . import gem, ui

# --------------------------------------------------------------------------
# 面板描述
# --------------------------------------------------------------------------

KIND_LABELS = {
    "event": ("事件", "pink"),
    "exam": ("考试", "hotpink"),
    "anniversary": ("纪念日", "rose"),
    "birthday": ("生日", "gold"),
}

NOTE_COLORS = {
    "pink": "pink",
    "rose": "rose",
    "plum": "plum",
    "gold": "gold",
    "violet": "violet",
    "sky": "brightcyan",
}


@dataclass
class PanelSpec:
    id: str
    title: str
    render: Callable[[Any], str]
    intro: str = ""
    source: str = "内置"


@dataclass
class PanelRegistry:
    """面板注册表。内置插件和用户插件都往这里注册。"""

    panels: dict[str, PanelSpec] = field(default_factory=dict)

    def register(self, spec: PanelSpec) -> None:
        self.panels[spec.id] = spec

    def get(self, panel_id: str) -> PanelSpec | None:
        return self.panels.get(panel_id)

    def ids(self) -> list[str]:
        return list(self.panels)

    def resolve(self, order: Iterable[str]) -> list[PanelSpec]:
        out: list[PanelSpec] = []
        for name in order:
            spec = self.panels.get(name.strip())
            if spec:
                out.append(spec)
        return out


# --------------------------------------------------------------------------
# 倒数日
# --------------------------------------------------------------------------

def _days_left(target: date, today: date) -> int:
    return (target - today).days


def _same_day_in(year: int, month: int, day: int) -> date:
    """构造某年的同一天；2 月 29 日在平年顺延到 2 月 28 日。"""
    try:
        return date(year, month, day)
    except ValueError:
        if month == 2 and day == 29:
            return date(year, 2, 28)
        raise


def _next_occurrence(target: date, yearly: bool, today: date) -> date:
    """yearly 的日子算出今年的下一次；平年 2/29 归到 2/28。"""
    if not yearly:
        return target
    candidate = _same_day_in(today.year, target.month, target.day)
    if candidate < today:
        candidate = _same_day_in(today.year + 1, target.month, target.day)
    return candidate


def _progress_bar(days_left: int, span: int, width: int = 16, style: str = "hotpink") -> str:
    """倒计时进度条：越满 = 离目标越近。

    语义（这地方很容易搞反，自测里专门断言过）：
        days_left >= 尺度 → 空条
        days_left = 0     → 满条

    关于「尺度」：一开始我直接拿整个周期（比如生日是一年 = 365 天）当分母，
    结果「还剩 14 天」只占 4%，画出来几乎全满、而且前半年完全看不出变化。
    所以这里把尺度限制在 90 天内：离得远就用 90 天当窗口，
    这样进度条在最后几个月是真的在动的。
    """
    span = max(1, span)
    scale = max(1, min(span, 90))
    if days_left > scale:
        filled = 0
    else:
        remaining = max(0, min(width, int(round(width * max(0, days_left) / scale))))
        filled = width - remaining
    return ui.c("█" * filled, style) + ui.c("░" * (width - filled), "grey")


def countdown_view(store, theme: gem.Theme, today: date | None = None,
                   *, window: int = 120, compact: bool = False,
                   show_hint: bool = True) -> list[str]:
    """被面板和 `her days` 命令共用。

    show_hint 控制「还没有倒数日，加一个：…」这段提示要不要出——
    生日行是面板额外补的，如果这里出了提示、面板又补一行生日，读起来会很怪，
    所以面板会自己决定什么时候给提示。
    """
    today = today or date.today()
    rows = store.countdowns()
    lines: list[str] = []
    upcoming: list[tuple[int, dict]] = []

    for row in rows:
        target = date.fromisoformat(row["target"])
        yearly = bool(row["yearly"])
        effective = _next_occurrence(target, yearly, today)
        left = _days_left(effective, today)
        upcoming.append((left, {"row": row, "target": target, "effective": effective,
                                "yearly": yearly, "left": left}))

    upcoming.sort(key=lambda item: item[0])

    shown = 0
    for left, info in upcoming:
        row = info["row"]
        effective = info["effective"]
        if left < 0 and not info["yearly"]:
            if compact:
                continue
            # 过去的日子：标成「已过」，并提醒可以改期或删掉，别让它一直占着版面
            lines.append(
                ui.c(ui.pad(f"#{row['id']}", 4), "grey")
                + ui.c(ui.pad("已过", 6), "grey")
                + ui.pad(row["title"], 18)
                + ui.pad(ui.c(f"{-left} 天前", "grey"), 14, "right")
                + "  "
                + ui.c(row["target"], "grey")
            )
            lines.append("        " + ui.c("已经过去了 —— her days rm 删掉，或 her days edit 改个日期", "grey"))
            shown += 1
            continue
        if left > window and compact:
            continue
        if left > window:
            continue

        kind_label, kind_color = KIND_LABELS.get(row["kind"], ("事件", "pink"))
        if left == 0:
            when = ui.c("就是今天", "gold", "bold")
        elif left == 1:
            when = ui.c("明天", "hotpink", "bold")
        else:
            when = ui.c(f"{left} 天", "hotpink", "bold")

        span = max(30, left + 30)
        head = (
            ui.c(ui.pad(f"#{row['id']}", 4), "grey")
            + ui.c(ui.pad(kind_label, 6), kind_color)
            + ui.pad(row["title"], 18)
            + ui.pad(when, 14, "right")
            + "  "
            + _progress_bar(left, span, 14, kind_color)
        )
        lines.append(head)
        if row["note"]:
            lines.append("        " + ui.c(row["note"], "plum"))
        detail = effective.isoformat()
        if info["yearly"]:
            detail += "（每年）"
        lines.append("        " + ui.c(detail, "grey"))
        shown += 1
        if compact and shown >= 3:
            break

    if not lines and show_hint:
        lines.append(ui.c("还没有倒数日。加一个：", "grey"))
        lines.append("  " + ui.c("her days add \"期末机试\" 2027-01-10 --kind exam", "hotpink"))
        lines.append("  " + ui.c("her days add \"认识纪念日\" 2023-09-01 --yearly", "hotpink"))
    return lines


def _same_day_in_year(month: int, day: int, year: int) -> date:
    return _same_day_in(year, month, day)


def _previous_birthday(birthday: date, next_one: date) -> date:
    """上一个生日：从下一个生日往回推一年（用同月同日构造，跨闰年也安全）。"""
    year = max(1, next_one.year - 1)
    return _same_day_in(year, birthday.month, birthday.day)


def _birthday_line(ctx, today: date, window: int = 120) -> str | None:
    """生日那一行（只算不写库，因为它来自配置而不是倒数日表）。"""
    birthday = gem.parse_date(ctx.cfg.birthday)
    if not birthday:
        return None
    left = gem.days_until_birthday(birthday, today)
    nb = gem.next_birthday(birthday, today)
    if left is None or left > window or nb is None:
        return None
    when = "就是今天" if left == 0 else f"{left} 天"
    # 进度条语义统一是「越接近越满」（_progress_bar 就是这么定义的）：
    # 离生日越近越满；生日当天用满格表示「到了」，第二天自然回落到 1 格（新的一岁开始）
    prev = _previous_birthday(birthday, nb)
    span = max(28, (nb - prev).days)
    return (
        ui.c(ui.pad("···", 4), "gold")
        + ui.c(ui.pad("生日", 6), "gold")
        + ui.c(ui.pad(ctx.name, 18), "gold")
        + ui.pad(ui.c(when, "gold", "bold"), 14, "right")
        + "  "
        + _progress_bar(left, span, 14, "gold")
    )


def make_countdown_panel(store, cfg, theme: gem.Theme):
    def render(ctx) -> str:
        # 用 ctx.today() 而不是 date.today()：这样 --today 预览才有效
        today = ctx.today()
        lines = countdown_view(ctx.store, ctx.theme, today, window=120, show_hint=False)
        birthday_row = _birthday_line(ctx, today)
        if birthday_row:
            if lines:
                lines.append("")
            lines.append(birthday_row)
        if not lines:
            lines.append(ui.c("还没有倒数日。加一个：", "grey"))
            lines.append("  " + ui.c("her days add \"期末机试\" 2027-01-10 --kind exam", "hotpink"))
            lines.append("  " + ui.c("her days add \"认识纪念日\" 2023-09-01 --yearly", "hotpink"))
        if len(lines) > 1:
            lines.append("")
            lines.append(ui.c("进度条越满 = 离那天越近", "grey"))
        return ui.box("倒数日", lines, width=ui.term_width(), style=ctx.theme.primary)

    return PanelSpec("countdown", "倒数日", render, intro="考试、比赛、纪念日的倒计时与进度条")


# --------------------------------------------------------------------------
# 便签卡片
# --------------------------------------------------------------------------

_CARD_MIN_W = 24


def _fit(lines: list[str], rows: int, width: int) -> list[str]:
    """把卡片补齐成固定行数，保证并排时不会错位。"""
    out = list(lines[:rows])
    while len(out) < rows:
        out.append(ui.c("│ ", "grey") + " " * width + ui.c(" │", "grey"))
    return out


def note_cards(store, theme: gem.Theme, *, limit: int = 4, width: int | None = None,
               include_archived: bool = False) -> list[str]:
    width = width or ui.term_width()
    rows_data = store.notes(include_archived)
    if not rows_data:
        return []

    card_w = max(_CARD_MIN_W, min(38, (width - 4) // 2 - 2))
    shown_rows = list(rows_data[:limit])

    # 整批便签用统一高度，而不是每两张各自定高——否则长短不一时版面会一格高一格矮
    wrapped = [ui.wrap(row["body"], card_w - 4) for row in shown_rows]
    body_rows = max(1, min(3, max((len(w) for w in wrapped), default=1)))
    cards: list[list[str]] = []

    for row, body_lines in zip(shown_rows, wrapped):
        color = NOTE_COLORS.get(row["color"], "pink")
        pin = ui.c("★", "gold") if row["pinned"] else ui.c("·", "grey")
        stamp = (row["created_at"] or "")[:10]
        head = f" {pin} {ui.c('#' + str(row['id']), 'grey')} {ui.c(stamp, 'grey')} "
        head_w = ui.dwidth(ui._strip_ansi(head))
        fill = max(0, card_w - head_w - 4)
        top = ui.c("╭─", color) + head + ui.c("─" * fill + "╮", color)

        body_lines = ui.wrap(row["body"], card_w - 4)
        shown = list(body_lines[:body_rows])
        if len(body_lines) > body_rows:
            shown[-1] = ui.truncate(shown[-1], card_w - 5) + "…"
        body = [
            ui.c("│ ", color) + ui.pad(text, card_w - 4) + ui.c(" │", color)
            for text in shown
        ]
        while len(body) < body_rows:
            body.append(ui.c("│ ", color) + " " * (card_w - 4) + ui.c(" │", color))
        bot = ui.c("╰" + "─" * (card_w - 2) + "╯", color)
        cards.append([top, *body, bot])

    lines: list[str] = []
    for index in range(0, len(cards), 2):
        pair = cards[index:index + 2]
        if len(pair) == 1:
            lines.extend(pair[0])
            continue
        left_card, right_card = pair
        for left, right in zip(left_card, right_card):
            gap = " " * max(0, card_w + 2 - ui.dwidth(ui._strip_ansi(left)))
            lines.append(left + gap + right)
        lines.append("")
    while lines and not lines[-1].strip():
        lines.pop()
    return lines


def make_notes_panel(store, cfg, theme: gem.Theme):
    def render(ctx) -> str:
        lines = note_cards(ctx.store, ctx.theme, limit=4)
        if not lines:
            lines = [
                ui.c("还没有便签。贴一张：", "grey"),
                "  " + ui.c("her note add \"今天要把 LRU 手写一遍\"", "hotpink"),
                "  " + ui.c("her note add \"周五交实验报告\" --pin", "hotpink"),
            ]
        return ui.box("便签 · 提醒自己", lines, width=ui.term_width(), style=ctx.theme.primary)

    return PanelSpec("notes", "便签卡片", render, intro="随手贴的短句、待办、想法")


# --------------------------------------------------------------------------
# 特别提醒
# --------------------------------------------------------------------------

PATTERN_LABELS = {
    "daily": "每天",
    "weekly": "每周",
    "date": "指定日期",
    "once": "到点一次",
}

_WEEKDAYS = ["", "周一", "周二", "周三", "周四", "周五", "周六", "周日"]


def reminder_when(row) -> str:
    """把提醒规则说成人话。"""
    pattern = row["pattern"]
    if pattern == "daily":
        base = "每天"
    elif pattern == "weekly":
        weekday = int(row["weekday"] or 1)
        # 注意要有「每」：只写「周一」会被读成「这周一」，而它是每周都要响的
        base = f"每{_WEEKDAYS[weekday]}" if 1 <= weekday <= 7 else "每周"
    elif pattern == "date":
        base = f"{row['date']}"
    else:
        base = f"{row['date']} 一次"
    if row["at_time"]:
        base += f" {row['at_time']}"
    return base


def make_reminders_panel(store, cfg, theme: gem.Theme):
    def render(ctx) -> str:
        rows = ctx.store.reminders_today()
        lines: list[str] = []
        if not rows:
            lines.append(ui.c("今天没有特别提醒。", "grey"))
        for row in rows:
            important = row["priority"] == "important"
            bullet = ui.c("❗", "hotpink") if important else ui.c("•", "pink")
            when = ui.c(row["at_time"] or "全天", "grey")
            body = ui.c(row["body"], "hotpink" if important else "white")
            lines.append(f"{bullet} {ui.pad(when, 7)} {body}")
            lines.append("  " + ui.c(f"（#{row['id']} {reminder_when(row)}）", "grey"))
        return ui.box("今天要记得", lines, width=ui.term_width(), style="hotpink")

    return PanelSpec("reminders", "特别提醒", render, intro="每天 / 每周 / 指定日期的提醒")


# --------------------------------------------------------------------------
# 今日一句（原来就在首页，现在也做成面板，和其他面板一起排序）
# --------------------------------------------------------------------------

def make_quote_panel(store, cfg, theme: gem.Theme):
    def render(ctx) -> str:
        from . import report

        return report.quote_block(ctx.store, ctx.theme, ctx.today())

    return PanelSpec("quote", "今日一句", render, intro="每天一句随机的话和一句关心")


# --------------------------------------------------------------------------
# 内置面板总装
# --------------------------------------------------------------------------

def register_builtin_panels(registry: PanelRegistry, ctx) -> None:
    """注册内置面板。

    注意这里**不要**用 except Exception 兜住整个注册过程：
    之前就是那么写的，结果 learning 面板因为缺个 import 静默消失了，
    首页少一块却毫无提示。内置面板出问题就该暴出来（启动自检会看到）。
    """
    theme = ctx.theme
    registry.register(make_countdown_panel(ctx.store, ctx.cfg, theme))
    registry.register(make_notes_panel(ctx.store, ctx.cfg, theme))
    registry.register(make_reminders_panel(ctx.store, ctx.cfg, theme))
    registry.register(make_quote_panel(ctx.store, ctx.cfg, theme))
    # 学习资源和专业课程面板放在 features 里
    # （它们要 import learning / curriculum，放这里会造成循环导入）
    from .features import make_course_panel, make_learning_panel

    registry.register(make_learning_panel(ctx.store, ctx.cfg, theme))
    registry.register(make_course_panel(ctx.store, ctx.cfg, theme))


def render_dashboard(ctx, registry: PanelRegistry, *, only: list[str] | None = None,
                     skip: list[str] | None = None) -> str:
    """按配置顺序渲染首页面板。单个面板出错不影响其他面板。"""
    order = [p for p in ctx.cfg.panel_order()]
    if only:
        order = only
    if skip:
        order = [name for name in order if name not in skip]

    parts: list[str] = []
    for name in order:
        spec = registry.get(name)
        if not spec:
            continue
        try:
            text = spec.render(ctx)
        except Exception as exc:  # 面板出问题不能连累首页
            text = ui.box(spec.title, [ui.c(f"这个面板暂时出错了：{exc}", "red")],
                          width=ui.term_width(), style="red")
        if text:
            parts.append(text)
    return "\n\n".join(parts)


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from ._testutil import temp_home
    from .db import Store
    from .config import Config

    ui.use_color(False)
    # 内存库 + 临时数据目录：自测不该在别人电脑上留任何文件
    with temp_home(".selftest-panels") as home:
        store = Store(":memory:")
        cfg = Config(home=home)
        theme = gem.theme_from_birthday("2005-06-01")
        today = date(2026, 6, 1)

        # 倒数日：普通事件 / 每年纪念日 / 平年 2-29
        store.add_countdown("期末机试", "2026-06-11", "exam")
        store.add_countdown("认识纪念日", "2023-09-01", "anniversary", yearly=True)
        store.add_countdown("闰日", "2004-02-29", "anniversary", yearly=True)
        lines = countdown_view(store, theme, today)
        assert any("期末机试" in ui._strip_ansi(l) for l in lines), lines
        assert any("10 天" in ui._strip_ansi(l) for l in lines), lines

        # 每年重复：2026-09-01 应该是未来，倒数应该是 92 天
        target = _next_occurrence(date(2023, 9, 1), True, today)
        assert target == date(2026, 9, 1), target
        assert _days_left(target, today) == 92

        # 平年 2/29 → 2/28
        leap = _next_occurrence(date(2004, 2, 29), True, date(2026, 3, 1))
        assert leap == date(2027, 2, 28), leap

        # 便签
        nid = store.add_note("今天要把 LRU 手写一遍", pinned=True)
        assert store.note(nid)["pinned"] == 1
        cards = note_cards(store, theme)
        assert any("LRU" in ui._strip_ansi(l) for l in cards), cards
        store.update_note(nid, archived=True)
        assert not store.notes(), "归档的便签不该出现在看板上"

        # 提醒：每天 / 每周 / 指定日期 / 一次性
        store.add_reminder("喝水", "daily")
        store.add_reminder("周会", "weekly", weekday=today.isoweekday())
        store.add_reminder("交报告", "date", on_date=today.isoformat(), priority="important")
        once_id = store.add_reminder("只响一次", "once", on_date=today.isoformat())
        rows = store.reminders_today(today)
        bodies = [r["body"] for r in rows]
        assert "喝水" in bodies and "交报告" in bodies and "只响一次" in bodies, bodies
        # 重要的排最前
        assert rows[0]["body"] == "交报告", bodies
        store.mark_reminder_fired(once_id, today)
        bodies2 = [r["body"] for r in store.reminders_today(today)]
        assert "只响一次" not in bodies2, bodies2
        # 明天就不该出现了
        assert "周会" not in [r["body"] for r in store.reminders_today(today + timedelta(days=1))]

        assert PATTERN_LABELS["weekly"] == "每周"

        # 生日行：依赖配置里的生日，只算不写库
        class _Ctx:
            pass

        ctx = _Ctx()
        ctx.store, ctx.cfg, ctx.theme = store, cfg, theme
        ctx.name = "容齐芳"
        ctx.today = lambda: today
        cfg.birthday = "2006-10-18"
        # 注意：生日行只在离生日 120 天内才显示，所以下面把「今天」设成 10-04
        near_birthday = date(2026, 10, 4)

        row = _birthday_line(ctx, date(2026, 10, 4))
        assert row and "14 天" in ui._strip_ansi(row), row
        row_on = _birthday_line(ctx, date(2026, 10, 18))
        assert row_on and "就是今天" in ui._strip_ansi(row_on), row_on
        # 进度条的满格数：离生日越近越满，生日当天重置为 0
        def filled(text: str) -> int:
            return ui._strip_ansi(text).count("█")

        # 生日当天满格；离得越远越空（尺度是 90 天，不是整个 365 天）
        assert filled(row_on) == 14, "生日当天进度条应该满格"
        assert filled(_birthday_line(ctx, date(2026, 10, 17))) == 14
        # 14 天 / 90 天尺度 → 约 76% → 11 格左右
        assert 10 <= filled(row) <= 12, f"还有 14 天时约 11 格，实际 {filled(row)}"
        assert filled(_birthday_line(ctx, date(2026, 8, 1))) <= 2, "离得远应该接近空"
        # 关键性质：越接近越满（而不是反过来）
        series = [filled(_birthday_line(ctx, date(2026, 9, 1) + timedelta(days=step)))
                  for step in range(0, 48, 7)]
        assert series == sorted(series), f"进度条应该单调递增，实际 {series}"

        # 普通倒数日照常显示（生日不通过这张表加，避免和配置里的生日重复）
        store.add_countdown("寒假开始", "2027-01-18", "event")
        visible = " ".join(ui._strip_ansi(l)
                           for l in countdown_view(store, theme, near_birthday, window=200))
        assert "寒假开始" in visible, visible
        # 生日太远就不显示这一行（免得占版面）
        assert _birthday_line(ctx, date(2026, 3, 1)) is None
        # 没填生日就不显示
        cfg.birthday = ""
        assert _birthday_line(ctx, today) is None
        cfg.birthday = "2006-10-18"

        # 面板注册表：内置面板要能注册、能按 id 取到
        registry = PanelRegistry()
        register_builtin_panels(registry, ctx)
        for panel_id in ("countdown", "notes", "reminders", "quote"):
            assert registry.get(panel_id) is not None, panel_id
        text = render_dashboard(ctx, registry, only=["countdown", "notes"])
        assert "倒数日" in text and "便签" in text, text[:200]
        # 倒数日面板要带上生日那一行（「今天」换成 10-04，生日就在 14 天后）
        ctx.today = lambda: near_birthday
        text_near = render_dashboard(ctx, registry, only=["countdown"])
        assert "容齐芳" in text_near, "倒数日面板应该显示生日行"
        assert "14 天" in text_near, text_near
        ctx.today = lambda: today
        # 不存在的面板要安静跳过
        assert render_dashboard(ctx, registry, only=["不存在"]) == ""
        store.close()
    print("panels selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
