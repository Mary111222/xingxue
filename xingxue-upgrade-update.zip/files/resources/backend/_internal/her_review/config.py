"""配置：一个 JSON 文件搞定，她可以自己改。

默认位置 ~/.her-review/config.json（可用环境变量 HER_REVIEW_HOME 覆盖，
或命令行 --home 指定，这样整个程序能塞进 U 盘随身带）。

配置文件示例：
{
  "name": "小满",
  "birthday": "2005-06-01",
  "together_since": "2023-09-01",
  "author": "",
  "theme_override": null,
  "daily_goal": 5,
  "gender": "female"
}
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

# 性别只允许这两个取值。默认 female —— 老用户的配置里没有这个键，
# 读回来是默认值，所以"现有行为完全不变"（生理期照旧显示）。
GENDERS = ("female", "male")
GENDER_LABELS = {"female": "女", "male": "男"}

DEFAULTS = {
    "name": "",
    "birthday": "",
    "together_since": "",
    "author": "",
    "daily_goal": 5,
    "palette_override": "",
    # 性别（female / male）。写进 DEFAULTS 才会被 load() 从文件读回来——
    # 漏掉的表现是"设置里选了男，重开又变回女"。
    "gender": "female",
    # 首页面板：哪些显示、什么顺序。逗号分隔的面板名。
    "panels": "countdown,course,learning,notes,reminders,quote",
    # 已经见过哪些出厂面板（防止她关掉的面板被重复加回来）
    "seen_panels_value": "",
    # 头像（data URL）。不写进 DEFAULTS 的话，存了也读不回来。
    "avatar": "",
    # 生理期。同样必须写进来——DEFAULTS 是"允许从文件读回"的白名单，
    # 漏一个字段的表现是"存了但读不回来"，很难查。
    "cycle_last_start": "",
    "cycle_length": 28,
    "cycle_period_days": 5,
    "cycle_reminder": True,
}

ENV_HOME = "HER_REVIEW_HOME"

# 本机数据目录标记文件：放在程序目录里，记录"她的数据在哪"
LOCAL_HOME_FILE = "her.local.json"


def resolve_home(explicit: Path | str | None = None) -> Path | None:
    """统一的数据目录解析链。

    优先级：显式指定 > 环境变量 > her.local.json > 默认（~/.her-review）

    为什么要有这个函数：
        原来 CLI 里自己写了一遍"先看 her.local.json"，而 Web 启动路径
        直接调 Config.load(None) —— 于是双击图形界面时读的是**另一个空数据目录**，
        她在界面上看不到自己的题。同一个概念两处实现，迟早会漏一处。
        现在两边都走这里，只有一条解析链。
    """
    if explicit:
        return Path(explicit).expanduser()
    override = os.environ.get(ENV_HOME)
    if override:
        return Path(override).expanduser()
    return load_local_home()


def resolve_and_load(explicit: Path | str | None = None) -> "Config":
    """按统一解析链找到目录并加载配置。"""
    return Config.load(resolve_home(explicit))


def default_home() -> Path:
    override = os.environ.get(ENV_HOME)
    if override:
        return Path(override).expanduser()
    return Path.home() / ".her-review"


def set_local_home(path: Path) -> Path:
    """写一个 her.local.json，指定本机的数据目录。

    用途：双击启动时，程序要知道她的数据放在哪。
    为什么不写进启动器：批处理必须是 ANSI 编码，中文路径写在里面容易出乱码；
    中文放在 UTF-8 的 JSON 里最稳。
    """
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    payload = {"home": str(path.resolve())}
    (path.parent / LOCAL_HOME_FILE).write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return path


def load_local_home(start: Path | None = None) -> Path | None:
    """从当前目录往上找 her.local.json，找到就用里面的数据目录。"""
    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        marker = candidate / LOCAL_HOME_FILE
        if marker.exists():
            try:
                payload = json.loads(marker.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return None
            value = payload.get("home")
            if value:
                target = Path(value)
                if not target.is_absolute():
                    target = candidate / target
                return target
    return None


def writable_home(preferred: Path) -> tuple[Path, str]:
    """确认数据目录可写，不行就降级。

    返回 (最终目录, 说明)。降级顺序：
        ~/.her-review  →  ./her-review-data  →  ./data
    这样在受限环境（只读家目录、U 盘、沙箱）里也不会直接崩掉。
    """
    candidates = [preferred]
    if preferred == Path.home() / ".her-review":
        candidates.append(Path.cwd() / "her-review-data")
        candidates.append(Path.cwd() / "data")

    last_error = ""
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".write-test"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            if candidate != preferred:
                return candidate, f"{preferred} 不可写（{last_error}），改用 {candidate}"
            return candidate, ""
        except OSError as exc:
            last_error = f"{exc.__class__.__name__}"
            continue
    return preferred, f"所有候选目录都不可写（{last_error}）"


@dataclass
class Config:
    home: Path = field(default_factory=default_home)
    name: str = ""
    # ---- AI 助教（默认关；密钥只存在本机）----
    ai_enabled: bool = False
    # 备考级别：cet4 / cet6（默认六级）
    cet_level: str = "cet6"
    ai_key: str = ""
    ai_model: str = "deepseek-chat"
    birthday: str = ""
    together_since: str = ""
    author: str = ""
    daily_goal: int = 5
    palette_override: str = ""
    # 性别：female / male。默认 female，保证老配置行为不变。
    # 非法值（手改配置文件写错）按 female 处理——宁可多显示，
    # 也不要因为一个拼错的值把她的周期功能"悄悄关掉"。
    gender: str = "female"
    panels: str = "countdown,course,learning,notes,reminders,quote"
    # 头像存成 data URL（base64）：
    #   整个文件夹拷到别的电脑时头像跟着走，不用另外管一个图片文件，
    #   也不会出现"文件被误删/搬家后路径失效"这种问题。
    # 体积上限见 avatar.py 的 MAX_BYTES——超了明确拒绝，不静默压缩。
    avatar: str = ""
    # 生理期记录：上次开始日期、周期长度、经期天数。
    # 只存这三个数就够做预测了——程序不猜、不诊断，只做算术。
    cycle_last_start: str = ""
    cycle_length: int = 28
    cycle_period_days: int = 5
    # 提醒开关：默认开，但她可以一句话关掉（有些人不需要天天被提醒）
    cycle_reminder: bool = True
    # 记录"已经见过哪些出厂面板"。没有它的话，她手动关掉的面板
    # 会在下次启动又被当成新面板加回来，成了关不掉的开关。
    seen_panels_value: str = ""
    # 不写进文件：加载时如果降级了数据目录，这里放一句提示
    warning: str = field(default="", compare=False)

    # ---------------- 面板 ----------------

    def panel_order(self) -> list[str]:
        """当前首页面板顺序——就是配置里存的那份，不做任何"顺手补全"。

        这里刻意保持纯读取。之前写成"每次读取都把缺失的出厂面板补进来"，
        结果 panels disable 写进去的移除会被下一次读取立刻补回来：
        关掉无效，enable 还会说"已经在首页了"。
        自愈要做，但只能做一次 —— 见 migrate_panels()，只在 load() 里调。
        """
        return [p.strip() for p in (self.panels or "").split(",") if p.strip()]

    def migrate_panels(self, defaults: list[str]) -> list[str]:
        """把出厂面板里"她配置中还没有的"补进去并写回。返回补了哪些。

        两个关键点：

        1. 只在启动时调一次（不是每次读 panel_order 都补），
           否则 panels disable 会被立刻撤销。

        2. 记一个「已经见过哪些面板」的名单（seen_panels）。
           没有它的话，她手动关掉的面板会在下次启动又被当成"新面板"加回来——
           那就成了"关不掉的开关"，比不加还烦人。
           只有真正第一次出现在这个版本里的面板才会被自动加上。
        """
        order = self.panel_order()
        seen = set(self.seen_panels())
        added: list[str] = []
        for name in defaults:
            if name in order or name in seen:
                continue
            position = defaults.index(name)
            insert_at = len(order)
            for index, existing in enumerate(order):
                if existing in defaults and defaults.index(existing) > position:
                    insert_at = index
                    break
            order.insert(insert_at, name)
            added.append(name)
        # 所有出厂面板都登记为"见过"，包括她关掉的那些
        self.seen_panels_value = ",".join(sorted(seen | set(defaults)))
        if added:
            self.set_panels(order)
        try:
            self.save()
        except OSError:
            pass
        return added

    def seen_panels(self) -> list[str]:
        return [p.strip() for p in (self.seen_panels_value or "").split(",") if p.strip()]

    def set_panels(self, names: list[str]) -> None:
        self.panels = ",".join(names)

    # ---------------- 路径 ----------------

    @property
    def config_path(self) -> Path:
        return self.home / "config.json"

    @property
    def db_path(self) -> Path:
        return self.home / "data.sqlite3"

    def ensure_home(self) -> None:
        self.home.mkdir(parents=True, exist_ok=True)

    # ---------------- 读写 ----------------

    @classmethod
    def load(cls, home: Path | str | None = None) -> "Config":
        resolved = Path(home).expanduser() if home else default_home()
        # 显式指定的目录不降级（用户说了算），默认目录才自动找可写位置
        warned = ""
        if home is None:
            resolved, warned = writable_home(resolved)
        path = resolved / "config.json"
        cfg = cls(home=resolved)
        cfg.warning = warned
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                raw = {}
            for key in DEFAULTS:
                if key in raw and raw[key] is not None:
                    setattr(cfg, key, raw[key])
        return cfg

    def save(self) -> None:
        self.ensure_home()
        payload = {k: getattr(self, k) for k in DEFAULTS}
        self.config_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )

    def update(self, **kwargs) -> None:
        for key, value in kwargs.items():
            if key in DEFAULTS and value is not None:
                setattr(self, key, value)

    # ---------------- 便捷 ----------------

    def gender_value(self) -> str:
        """归一化后的性别。

        **只在这一个地方判断性别**。以前踩过的坑就是"同一个概念两处实现"：
        接口层按一种写法判断、面板层按另一种写法判断，迟早漏一处，
        表现成"设置里选了男，某一页还在显示"。
        """
        value = str(getattr(self, "gender", "") or "").strip().lower()
        return value if value in GENDERS else "female"

    def cycle_hidden(self) -> bool:
        """生理期是否整体隐藏（男性）。

        注意：这里**只决定显不显示/能不能写**，
        绝不动作 `cycle_last_start` 这些数据——她改回女性要立刻恢复。
        """
        return self.gender_value() == "male"

    def display_name(self) -> str:
        return self.name or "同学"

    def is_configured(self) -> bool:
        return bool(self.name or self.birthday)

    def as_dict(self) -> dict:
        return asdict(self) | {"home": str(self.home)}
