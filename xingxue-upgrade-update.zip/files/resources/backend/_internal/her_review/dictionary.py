"""多义词词典：一个词的不同词性 / 不同意思。

用户要求："有些单词有多个意思不同词性，这个要考虑到，多义词的时候
不同意思要显示出来"。

## 为什么需要自己建这份表

在线翻译服务对**孤立的单词**只会给一个答案，而且经常给的是
最不常用的那个。比如：
    "address" → 它可能只给你「地址」，但读代码文档时你要的往往是「寻址」
    "heap"    → 只给「堆」，但你分不清是"一堆东西"还是数据结构那个堆
    "stack"   → 同上

对她来说这件事特别要紧：她读的是英文技术文档和题面，
一个词选错意思，整段就理解反了。

## 收词原则

**只收能确证的、而且确实有歧义的词**。不是"越多越好"：
词典里的词会直接覆盖在线翻译的结果，收错了反而更糟。
所以优先收这几类：
    · 计算机里含义和日常不同的词（address / heap / stack / thread / map）
    · 她读文档、写注释时高频遇到的动词（run / build / commit / check）
    · 考试常见的一词多义（present / subject / object / figure）

## 数据结构

    词 → [(词性, 释义, 说明, 例句), ...]

词性用缩写（n. / v. / adj. / adv. / prep.），和词典习惯一致。
例句只给最有用的那一两个，不堆砌。
"""

from __future__ import annotations

# 词性缩写 → 中文名（界面上 hover 用）
POS_NAMES: dict[str, str] = {
    "n.": "名词",
    "v.": "动词",
    "vt.": "及物动词",
    "vi.": "不及物动词",
    "adj.": "形容词",
    "adv.": "副词",
    "prep.": "介词",
    "conj.": "连词",
    "pron.": "代词",
    "num.": "数词",
    "abbr.": "缩写",
}

# 每个条目：(词性, 中文释义, 补充说明, 英文例句)
SENSE_TYPE = tuple[str, str, str, str]

MULTI_SENSE: dict[str, list[SENSE_TYPE]] = {
    # ---------------- 计算机里含义和日常不同的 ----------------
    "address": [
        ("n.", "地址；住址", "日常含义", "What's your email address?"),
        ("n.", "（计算机）内存地址", "读底层代码、看指针时是这个意思",
         "The pointer stores the address of the variable."),
        ("vt.", "处理；解决（问题）", "写作和文档里很常见",
         "We need to address this bug before release."),
        ("vt.", "称呼；对…讲话", "", "He addressed the audience."),
    ],
    "heap": [
        ("n.", "（数据结构）堆", "优先队列的底层实现",
         "A binary heap supports O(log n) insertion."),
        ("n.", "（内存）堆区", "和栈（stack）相对",
         "Objects are allocated on the heap."),
        ("n.", "一堆；大量", "日常含义", "a heap of books"),
    ],
    "stack": [
        ("n.", "（数据结构）栈", "后进先出",
         "Push the value onto the stack."),
        ("n.", "（内存）栈区", "函数调用、局部变量放这里",
         "The stack grows downward on x86."),
        ("n.", "调用栈；栈帧集合", "报错信息里看到的 stack trace",
         "Read the stack trace to find the failing call."),
        ("n.", "一摞；一堆", "日常含义", "a stack of papers"),
        ("v.", "堆叠；把…码放起来", "", "Stack the boxes here."),
    ],
    "thread": [
        ("n.", "线程", "并发里的执行单元", "Each thread has its own stack."),
        ("n.", "线；细丝", "日常含义", "a needle and thread"),
        ("n.", "（论坛）帖子串", "", "Reply in the same thread."),
        ("v.", "穿线；穿过", "", "Thread the needle."),
    ],
    "map": [
        ("n.", "映射；字典", "很多语言里就是哈希表的意思",
         "A map stores key-value pairs."),
        ("n.", "地图", "日常含义", "Look at the map."),
        ("vt.", "映射；对应", "函数式编程里的 map",
         "Map each element to its square."),
    ],
    "queue": [
        ("n.", "队列", "先进先出", "Use a queue for BFS."),
        ("n.", "队伍；排队的人", "日常含义", "a long queue"),
        ("v.", "排队；把…加入队列", "", "Queue the task for later."),
    ],
    "tree": [
        ("n.", "树（数据结构）", "", "A binary tree has at most two children."),
        ("n.", "树；树木", "日常含义", "a tall tree"),
    ],
    "hash": [
        ("n.", "哈希；散列", "", "Compute the hash of the string."),
        ("n.", "哈希表", "口语里常说 the hash", "Look it up in the hash."),
        ("n.", "# 号", "美式英语；英式叫 hash key", "Use a hash symbol."),
        ("vt.", "切碎（食物）", "日常含义", "hash the potatoes"),
    ],
    "cache": [
        ("n.", "缓存", "CPU 缓存、浏览器缓存",
         "The result is stored in a cache."),
        ("vt.", "缓存起来", "", "Cache the response for 10 minutes."),
        ("n.", "隐藏处；藏匿物", "日常/军事含义", "a cache of weapons"),
    ],
    "buffer": [
        ("n.", "缓冲区", "", "Flush the output buffer."),
        ("vt.", "缓冲；缓和", "引申义", "buffer the impact"),
        ("n.", "缓冲物", "日常含义", "a buffer zone"),
    ],
    "socket": [
        ("n.", "套接字", "网络编程", "Create a TCP socket."),
        ("n.", "插座；灯座", "日常含义", "a wall socket"),
    ],
    "port": [
        ("n.", "端口", "网络", "The service listens on port 8080."),
        ("vt.", "移植（代码）", "", "Port the app to Linux."),
        ("n.", "港口", "日常含义", "a busy port"),
    ],
    "kernel": [
        ("n.", "内核", "操作系统内核；也指卷积核",
         "The kernel schedules processes."),
        ("n.", "（坚果）仁；核心", "日常含义", "a kernel of truth"),
    ],
    "pointer": [
        ("n.", "指针", "C/C++ 里的地址变量", "dereference the pointer"),
        ("n.", "指示物；鼠标光标", "", "Move the pointer over the icon."),
    ],
    "class": [
        ("n.", "类", "面向对象里的 class", "Define a class named Point."),
        ("n.", "课；班级", "日常含义", "I have a class at nine."),
        ("n.", "等级；类别", "", "first class"),
    ],
    "object": [
        ("n.", "对象", "面向对象；也是 JSON 里的对象",
         "The object has three properties."),
        ("n.", "物体；东西", "日常含义", "a strange object"),
        ("v.", "反对（to）", "注意是 object to", "I object to this plan."),
    ],
    "interface": [
        ("n.", "接口", "编程里的 interface", "Implement this interface."),
        ("n.", "界面", "用户界面 UI", "a clean user interface"),
        ("v.", "连接；对接", "", "interface with the database"),
    ],
    "argument": [
        ("n.", "参数；实参", "编程里", "Pass two arguments to the function."),
        ("n.", "争论；论点", "日常含义", "They had an argument."),
    ],
    "field": [
        ("n.", "字段", "数据库列、类的属性", "Add a new field to the table."),
        ("n.", "领域；专业", "", "the field of computer science"),
        ("n.", "田地；场地", "日常含义", "a field of wheat"),
    ],
    "key": [
        ("n.", "键；键名", "字典的 key、键盘的键", "Use a unique key."),
        ("n.", "钥匙", "日常含义", "Where are my keys?"),
        ("adj.", "关键的；最重要的", "", "a key insight"),
    ],
    "string": [
        ("n.", "字符串", "", "Convert the number to a string."),
        ("n.", "细绳；一串", "日常含义", "a piece of string"),
        ("vt.", "串起来", "", "string the beads"),
    ],
    "bit": [
        ("n.", "位；比特", "二进制位", "A byte has eight bits."),
        ("n.", "一点；少量", "a bit 很常用", "Wait a bit."),
        ("n.", "钻头", "工具", "a drill bit"),
    ],
    "byte": [
        ("n.", "字节", "8 位", "The file is 1024 bytes."),
    ],
    "tag": [
        ("n.", "标签", "HTML 标签；给题目打标签",
         "Wrap it in a div tag."),
        ("vt.", "打标签；标记", "", "Tag this commit as v1.0."),
        ("n.", "捉人游戏", "儿童游戏", "play tag"),
    ],
    "commit": [
        ("v.", "提交（代码）", "Git 操作", "Commit your changes."),
        ("n.", "一次提交", "", "Revert the last commit."),
        ("v.", "承诺；犯（错/罪）", "日常含义",
         "commit to a plan / commit a crime"),
    ],
    "branch": [
        ("n.", "分支", "Git 分支；程序的分支", "Create a new branch."),
        ("n.", "树枝", "日常含义", "a tree branch"),
        ("v.", "分岔", "", "The road branches here."),
    ],
    "merge": [
        ("v.", "合并", "Git 合并；归并排序", "Merge the two branches."),
        ("v.", "融合；汇合", "日常含义", "The rivers merge here."),
    ],
    "run": [
        ("v.", "运行（程序）", "最常见的用法", "Run the tests."),
        ("v.", "跑；奔跑", "日常含义", "I run every morning."),
        ("n.", "一次运行；一段时期", "", "a successful run"),
        ("vt.", "经营；管理", "", "run a company"),
    ],
    "build": [
        ("v.", "构建；编译", "开发里", "Build the project."),
        ("n.", "构建产物；版本", "", "the latest build"),
        ("v.", "建造；建立", "日常含义", "build a house"),
    ],
    "call": [
        ("vt.", "调用（函数）", "编程里", "Call the function with two args."),
        ("v.", "打电话；称呼", "日常含义", "Call me tomorrow."),
        ("n.", "通话；呼叫", "", "a phone call"),
    ],
    "check": [
        ("v.", "检查；核对", "", "Check the result."),
        ("vt.", "检验；校验（返回值等）", "编程里",
         "Always check the return value."),
        ("n.", "支票；账单", "美式英语", "pay by check"),
        ("n.", "对勾；勾选", "", "Put a check in the box."),
    ],
    "return": [
        ("v.", "返回（值）", "函数返回", "Return the sum."),
        ("v.", "回来；归还", "日常含义", "Return the book."),
        ("n.", "回车键；返回", "", "Press return."),
    ],
    "index": [
        ("n.", "索引；下标", "数组下标、数据库索引",
         "Array indices start at zero."),
        ("n.", "指数；指标", "数学/经济", "the consumer price index"),
        ("vt.", "给…编索引", "", "index the book"),
    ],
    "table": [
        ("n.", "表；表格", "数据库表", "Create a table named users."),
        ("n.", "桌子", "日常含义", "sit at the table"),
    ],
    "view": [
        ("n.", "视图", "数据库视图；界面视图", "Create a view over the table."),
        ("n.", "景色；看法", "日常含义", "a nice view"),
        ("vt.", "查看；看待", "", "View the source code."),
    ],
    "order": [
        ("n.", "顺序；次序", "排序里", "Sort in ascending order."),
        ("n.", "订单；点单", "日常含义", "place an order"),
        ("vt.", "订购；命令", "", "Order a coffee."),
        ("n.", "（数学）阶；数量级", "大 O 里会看到",
         "an algorithm of order n squared"),
    ],
    "log": [
        ("n.", "日志", "程序日志", "Check the error log."),
        ("vt.", "记录（日志）", "", "Log every request."),
        ("n.", "对数", "数学", "log base 2"),
        ("n.", "原木", "日常含义", "a pile of logs"),
    ],
    "trace": [
        ("n.", "追踪；调用栈信息", "stack trace", "Read the stack trace."),
        ("vt.", "追踪；跟踪", "", "Trace the execution path."),
        ("n.", "痕迹；踪迹", "日常含义", "without a trace"),
    ],
    "domain": [
        ("n.", "域；定义域", "数学", "the domain of the function"),
        ("n.", "域名", "网络", "register a domain"),
        ("n.", "领域；范围", "", "in the domain of AI"),
    ],
    "range": [
        ("n.", "范围；区间", "编程和数学都常用", "The value is out of range."),
        ("n.", "射程；音域", "", "a wide range of options"),
        ("vt.", "在…范围内变化", "", "Prices range from 10 to 20."),
    ],
    "set": [
        ("n.", "集合", "数据结构里的 set", "A set has no duplicates."),
        ("vt.", "设置；设定", "最常见的用法", "Set the value to zero."),
        ("n.", "一套；一组", "日常含义", "a set of tools"),
    ],
    "list": [
        ("n.", "列表；链表", "", "a linked list"),
        ("vt.", "列出；列举", "", "List all files."),
    ],
    "state": [
        ("n.", "状态", "程序状态、React state", "Save the current state."),
        ("n.", "州；国家", "日常含义", "the state of Texas"),
        ("vt.", "陈述；声明", "", "State your assumptions."),
    ],
    "model": [
        ("n.", "模型", "机器学习模型；数据模型",
         "Train the model on this data."),
        ("n.", "型号；款式", "日常含义", "the latest model"),
        ("n.", "模特", "", "a fashion model"),
    ],
    "train": [
        ("vt.", "训练（模型）", "机器学习", "Train the network for 10 epochs."),
        ("n.", "火车", "日常含义", "catch the train"),
    ],
    "test": [
        ("n.", "测试；测验", "", "Write a unit test."),
        ("vt.", "测试；检验", "", "Test the function."),
    ],
    "case": [
        ("n.", "情况；案例", "", "in this case"),
        ("n.", "（switch）分支", "编程里", "Add a default case."),
        ("n.", "箱子；盒子", "日常含义", "a pencil case"),
        ("n.", "（语法）格", "英语语法", "the accusative case"),
    ],
    "loop": [
        ("n.", "循环", "", "A for loop repeats the block."),
        ("v.", "循环；重复", "", "Loop until the list is empty."),
        ("n.", "环；圈", "日常含义", "a loop of rope"),
    ],
    "sign": [
        ("n.", "符号；正负号", "数学", "the sign of the number"),
        ("n.", "标志；迹象", "", "a sign of progress"),
        ("v.", "签名；签署", "", "Sign here."),
    ],
    "power": [
        ("n.", "幂；乘方", "数学", "two to the power of ten"),
        ("n.", "功率；电力", "", "power consumption"),
        ("n.", "权力；能力", "", "the power to change"),
    ],
    "root": [
        ("n.", "根（节点）", "树结构的根；也指 Linux root 用户",
         "The root has no parent."),
        ("n.", "根号；方程的根", "数学", "the square root of nine"),
        ("n.", "根；根部", "日常含义", "the root of the plant"),
    ],
    "leaf": [
        ("n.", "叶子节点", "树结构里没有子节点的节点",
         "A leaf has no children."),
        ("n.", "树叶", "日常含义", "green leaves"),
    ],
    "path": [
        ("n.", "路径", "文件路径；图里的路径", "an absolute path"),
        ("n.", "小路；道路", "日常含义", "a garden path"),
    ],
    "scale": [
        ("n.", "规模；比例尺", "", "at a large scale"),
        ("vt.", "扩展；缩放", "系统设计里很常见",
         "Scale the service horizontally."),
        ("n.", "刻度；天平", "", "a bathroom scale"),
    ],
    "host": [
        ("n.", "主机", "网络里的 host", "The host is unreachable."),
        ("vt.", "托管；主办", "", "host a website / host a party"),
        ("n.", "主人；东道主", "日常含义", "the host of the show"),
    ],
    "client": [
        ("n.", "客户端", "网络/前后端", "The client sends a request."),
        ("n.", "客户", "日常含义", "a new client"),
    ],
    "server": [
        ("n.", "服务器", "", "Start the server."),
        ("n.", "服务员", "日常含义", "The server brought the menu."),
    ],
    "application": [
        ("n.", "应用程序", "常常简称 app", "a desktop application"),
        ("n.", "申请；应用", "日常含义",
         "an application for the job / the application of theory"),
    ],
    "compile": [
        ("vt.", "编译", "", "Compile the source files."),
        ("vt.", "汇编；编辑整理", "引申义", "compile a report"),
    ],
    "execute": [
        ("vt.", "执行", "", "Execute the query."),
        ("vt.", "处决", "日常/法律含义", "execute a prisoner"),
    ],
    "resolve": [
        ("vt.", "解析（域名/路径）", "网络和文件系统",
         "Resolve the hostname to an IP."),
        ("vt.", "解决；决心", "日常含义", "resolve the conflict"),
    ],
    "match": [
        ("n.", "匹配", "正则/模式匹配", "a pattern match"),
        ("n.", "比赛", "日常含义", "a football match"),
        ("v.", "相配；相符", "", "The colors match."),
    ],
    "pattern": [
        ("n.", "模式；模式串", "正则表达式里",
         "Match the pattern against the input."),
        ("n.", "图案；花样", "日常含义", "a floral pattern"),
    ],
    "template": [
        ("n.", "模板", "C++ 模板；文档模板",
         "a function template"),
        ("n.", "样板；范本", "日常含义", "a design template"),
    ],
    "virtual": [
        ("adj.", "虚拟的", "虚拟机、虚函数", "a virtual machine"),
        ("adj.", "实际上的；事实上的", "注意这个意思很不同",
         "the virtual leader of the group"),
    ],
    "native": [
        ("adj.", "原生的；本机的", "native code / native app",
         "Compile to native code."),
        ("adj.", "本国的；天生的", "日常含义", "a native speaker"),
    ],
    "stable": [
        ("adj.", "稳定的", "稳定排序、稳定版本",
         "A stable sort keeps equal elements in order."),
        ("n.", "马厩", "名词用法", "clean the stable"),
    ],
    "dynamic": [
        ("adj.", "动态的", "动态规划、动态类型",
         "dynamic programming / dynamic typing"),
        ("adj.", "有活力的", "日常含义", "a dynamic person"),
    ],
    "static": [
        ("adj.", "静态的", "静态类型、static 关键字",
         "a static method"),
        ("n.", "静电（噪声）", "日常含义", "static on the radio"),
    ],
    "abstract": [
        ("adj.", "抽象的", "抽象类、抽象概念",
         "an abstract class cannot be instantiated"),
        ("n.", "摘要；论文摘要", "学术写作", "read the abstract first"),
        ("vt.", "提取；抽象出", "", "abstract the common logic"),
    ],
    "concrete": [
        ("adj.", "具体的", "和 abstract 相对",
         "Give a concrete example."),
        ("n.", "混凝土", "日常含义", "a concrete wall"),
    ],
    "robust": [
        ("adj.", "健壮的；鲁棒的", "能处理异常输入",
         "The parser is robust against malformed input."),
        ("adj.", "强壮的；坚固的", "日常含义", "a robust build"),
    ],
    "elegant": [
        ("adj.", "优雅的（代码/证明）", "夸解法漂亮时用",
         "an elegant solution"),
        ("adj.", "优雅的；高雅的", "日常含义", "an elegant dress"),
    ],
    "trivial": [
        ("adj.", "平凡的；显然的", "数学里指「不用证」的那种",
         "a trivial solution"),
        ("adj.", "微不足道的", "日常含义", "a trivial matter"),
    ],
    "figure": [
        ("n.", "图；插图", "论文里的图，缩写 Fig.",
         "See Figure 3."),
        ("n.", "数字；数值", "", "sales figures"),
        ("vt.", "认为；弄明白", "figure out 很常用",
         "Figure out what went wrong."),
        ("n.", "身材；人物", "", "a public figure"),
    ],
    "present": [
        ("adj.", "当前的；出席的", "", "the present situation"),
        ("n.", "礼物", "日常含义", "a birthday present"),
        ("vt.", "提出；展示", "学术写作", "present the results"),
        ("n.", "现在时", "语法", "the present tense"),
    ],
    "subject": [
        ("n.", "科目；主题", "", "a difficult subject"),
        ("n.", "主语", "语法", "the subject of the sentence"),
        ("adj.", "受…影响的（to）", "论文里常见",
         "subject to change"),
        ("vt.", "使遭受", "", "subject to testing"),
    ],
    "issue": [
        ("n.", "问题；议题", "GitHub 上的 issue 也是这个",
         "open an issue"),
        ("n.", "（期刊的）期", "学术引用", "the latest issue"),
        ("vt.", "发布；签发", "", "issue a statement"),
    ],
    "article": [
        ("n.", "文章", "", "read the article"),
        ("n.", "冠词", "语法", "the definite article"),
        ("n.", "物品；条款", "法律", "article 5 of the treaty"),
    ],
    "mean": [
        ("vt.", "意思是；意味着", "", "What does this mean?"),
        ("n.", "平均值", "数学", "the mean of the samples"),
        ("adj.", "刻薄的；吝啬的", "日常含义", "Don't be mean."),
    ],
    "odd": [
        ("adj.", "奇数的", "数学", "odd numbers"),
        ("adj.", "奇怪的", "日常含义", "an odd smell"),
        ("adj.", "单只的", "", "an odd sock"),
    ],
    "even": [
        ("adj.", "偶数的", "数学", "even numbers"),
        ("adv.", "甚至；连…都", "", "Even a child knows that."),
        ("adj.", "平的；均匀的", "", "an even surface"),
    ],
    "prime": [
        ("adj.", "素数的", "数学", "a prime number"),
        ("adj.", "首要的；最好的", "", "prime concern"),
        ("vt.", "使准备好", "prime the pump", "prime the cache"),
    ],
    "term": [
        ("n.", "项", "数学/多项式的项", "the second term"),
        ("n.", "术语", "", "a technical term"),
        ("n.", "学期；期限", "日常含义", "this term"),
    ],
    "evaluate": [
        ("vt.", "求值", "算表达式的值", "Evaluate the expression."),
        ("vt.", "评估；评价", "日常含义", "evaluate the results"),
    ],
    "assign": [
        ("vt.", "赋值", "编程里", "Assign 5 to x."),
        ("vt.", "分配；布置（作业）", "日常含义", "assign homework"),
    ],
    "declare": [
        ("vt.", "声明（变量/函数）", "编程里",
         "Declare the variable before use."),
        ("vt.", "宣布；申报", "日常含义", "declare independence"),
    ],
    "define": [
        ("vt.", "定义", "", "Define the function here."),
        ("vt.", "界定；明确规定", "", "define the scope"),
    ],
    "implement": [
        ("vt.", "实现（接口/功能）", "", "Implement the interface."),
        ("n.", "工具；器具", "名词用法", "farm implements"),
    ],
    "inherit": [
        ("vt.", "继承", "面向对象", "The subclass inherits the method."),
        ("vt.", "继承（财产）", "日常含义", "inherit a house"),
    ],
    "override": [
        ("vt.", "重写；覆盖", "子类重写父类方法",
         "Override the toString method."),
        ("vt.", "推翻；凌驾", "", "override the veto"),
    ],
    "expose": [
        ("vt.", "暴露；开放（接口）", "把功能开放出去",
         "Expose the API to the frontend."),
        ("vt.", "使接触；揭露", "日常含义", "expose to sunlight"),
    ],
    "abort": [
        ("vt.", "中止（程序/事务）", "编程里", "Abort the transaction."),
        ("vt.", "放弃；中止", "日常含义", "abort the mission"),
    ],
    "yield": [
        ("vt.", "让出（CPU）", "并发里", "The thread yields the CPU."),
        ("vt.", "产生；得出", "", "yield a result"),
        ("n.", "产量；收益", "日常含义", "crop yield"),
    ],
    "handle": [
        ("vt.", "处理（事件/异常）", "编程里",
         "Handle the exception."),
        ("n.", "句柄", "操作系统的 handle", "a file handle"),
        ("n.", "把手", "日常含义", "the door handle"),
        ("vt.", "拿；操作", "", "Handle with care."),
    ],
    "event": [
        ("n.", "事件", "事件驱动编程", "Bind a click event."),
        ("n.", "大事；活动", "日常含义", "a big event"),
    ],
    "property": [
        ("n.", "属性", "对象的属性", "The object has three properties."),
        ("n.", "财产；房产", "日常含义", "private property"),
        ("n.", "性质；特性", "数学", "the commutative property"),
    ],
    "attribute": [
        ("n.", "属性", "HTML 属性；对象属性",
         "The href attribute holds the URL."),
        ("vt.", "把…归因于", "", "attribute success to hard work"),
    ],
    "element": [
        ("n.", "元素", "数组元素；HTML 元素",
         "the first element of the array"),
        ("n.", "要素；成分", "日常含义", "a key element"),
    ],
    "frame": [
        ("n.", "帧", "视频帧；栈帧", "30 frames per second"),
        ("n.", "框架；边框", "", "a picture frame"),
        ("vt.", "构建；陷害", "", "frame the question"),
    ],
    "pipeline": [
        ("n.", "流水线；管道", "CPU 流水线；数据处理管道",
         "The build pipeline failed."),
        ("n.", "输油管道", "日常含义", "an oil pipeline"),
    ],
    "schema": [
        ("n.", "模式；数据结构定义", "数据库 schema",
         "Update the database schema."),
    ],
    "query": [
        ("n.", "查询", "数据库查询", "Run the query."),
        ("vt.", "查询；询问", "", "Query the database."),
        ("n.", "疑问", "日常含义", "I have a query."),
    ],
    "transaction": [
        ("n.", "事务", "数据库事务", "Wrap it in a transaction."),
        ("n.", "交易", "日常含义", "a bank transaction"),
    ],
    "deadlock": [
        ("n.", "死锁", "两个线程互相等对方",
         "The two threads are in a deadlock."),
    ],
    "latency": [
        ("n.", "延迟", "网络/系统响应时间", "reduce the latency"),
    ],
    "throughput": [
        ("n.", "吞吐量", "单位时间处理多少", "high throughput"),
    ],
}


def lookup(word: str) -> list[SENSE_TYPE]:
    """查一个词的多重释义。查不到返回空列表。"""
    key = str(word or "").strip().lower()
    if not key:
        return []
    return MULTI_SENSE.get(key, [])


def is_single_word(text: str) -> bool:
    """判断输入是不是"**一个英文单词**"（而不是句子或中文）。

    只有这种情况才需要分列多义——整句翻译看的是句子意思，
    把一个词拆成四五个意思反而干扰。

    注意中英文的差别：中文没有词间空格，"这是一句话"看起来
    "没有空格、全是字母数字"，很容易被误判成单词。
    所以这里要求**必须是 ASCII 字母**——中文一律不算单词。
    （我第一版就漏了这条，自测才发现。）
    """
    t = str(text or "").strip()
    if not t:
        return False
    # 必须全是 ASCII（中文、日文、emoji 都不算）
    if not t.isascii():
        return False
    # 允许连字符和撇号：well-known、don't
    cleaned = t.replace("-", "").replace("'", "")
    return cleaned.isalnum() and not any(ch.isspace() for ch in t)


def _selftest() -> None:
    assert lookup("address"), "address 应该有多重释义"
    assert lookup("ADDRESS"), "查词应该忽略大小写"
    assert lookup("  heap  "), "查词应该忽略首尾空白"
    assert lookup("zzzz") == []
    assert lookup("") == []

    # 每个条目都要四元组，词性要在 POS_NAMES 里
    bad = []
    for word, senses in MULTI_SENSE.items():
        if not senses:
            bad.append(f"{word}: 没有释义")
            continue
        for s in senses:
            if len(s) != 4:
                bad.append(f"{word}: 条目不是四元组 {s}")
            elif s[0] not in POS_NAMES:
                bad.append(f"{word}: 词性 {s[0]!r} 不在 POS_NAMES 里")
    assert not bad, bad

    # 单词判定
    assert is_single_word("address")
    assert is_single_word("well-known")
    assert is_single_word("don't")
    assert not is_single_word("two words")
    assert not is_single_word("这是一句话")
    assert not is_single_word("")
    assert not is_single_word("hello, world")

    print(f"dictionary selftest: 全部断言通过 ✓"
          f"（{len(MULTI_SENSE)} 个多义词，"
          f"共 {sum(len(v) for v in MULTI_SENSE.values())} 条释义，"
          f"{len(POS_NAMES)} 种词性）")


if __name__ == "__main__":
    _selftest()
