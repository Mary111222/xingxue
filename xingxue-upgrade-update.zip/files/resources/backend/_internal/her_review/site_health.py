"""资源站点体检：18 个站点还能不能打开。

## 判据（和 scripts/verify_site_urls.py 保持一致）

    2xx / 3xx               正常
    403 / 429 / 503         可达但**拒绝脚本**（知乎、SO、cppreference…）
                            —— 浏览器里点开没问题，不算"挂了"
    其它 / 超时 / DNS 错误  挂了

**为什么要分类**：不分类的话，一次体检会报一堆红，她看两次就不看了。
只把"真的打不开"标出来，这个功能才有意义。

结果落盘到 `缓存/站点体检.json`（带时间戳），前端只读缓存，
"检测"按钮才触发真正的网络请求 —— 打开页面不该卡在网络等待上。
"""
from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

TIMEOUT = 6
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
_lock = threading.Lock()


def cache_path(home: Path) -> Path:
    return Path(home) / "缓存" / "站点体检.json"


def classify(status: int, err: str = "") -> str:
    if 200 <= status < 400:
        return "ok"
    if status in (403, 429, 503):
        return "bot"          # 可达，只是拒绝脚本
    if err:
        return "dead"
    return "dead"


def probe(url: str) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": UA},
                                 method="GET")
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            return {"status": r.status, "kind": classify(r.status)}
    except urllib.error.HTTPError as e:
        return {"status": e.code, "kind": classify(e.code)}
    except Exception as exc:
        return {"status": 0, "kind": "dead", "error": exc.__class__.__name__}


def check_all(sites: list[dict], workers: int = 8) -> list[dict]:
    """并发探一遍。sites: [{key,title,url}]"""
    out: list[dict] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(probe, s["url"]): s for s in sites}
        for fut in futures:
            s = futures[fut]
            try:
                r = fut.result()
            except Exception as exc:
                r = {"status": 0, "kind": "dead", "error": str(exc)}
            out.append({"key": s.get("key", ""), "title": s.get("title", ""),
                        "url": s.get("url", ""), **r})
    return out


def save(home: Path, items: list[dict]) -> dict:
    data = {"at": datetime.now().isoformat(timespec="seconds"),
            "items": items,
            "ok_count": sum(1 for i in items if i["kind"] == "ok"),
            "bot_count": sum(1 for i in items if i["kind"] == "bot"),
            "dead_count": sum(1 for i in items if i["kind"] == "dead")}
    p = cache_path(home)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data


def load(home: Path) -> dict | None:
    p = cache_path(home)
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def run_async(home: Path, sites: list[dict]) -> None:
    """后台探一遍并落盘（前端点"检测"时调用，不阻塞请求）。"""
    def work():
        with _lock:
            data = save(home, check_all(sites))
        return data
    threading.Thread(target=work, daemon=True).start()


def _selftest() -> None:
    assert classify(200) == "ok"
    assert classify(301) == "ok"
    assert classify(403) == "bot"
    assert classify(429) == "bot"
    assert classify(0, "URLError") == "dead"
    assert classify(500) == "dead"
    # 真探一个稳的站点（离线环境下会变成 dead，不算失败）
    r = probe("https://www.programmercarl.com/")
    assert r["kind"] in ("ok", "bot", "dead"), r
    print("site_health selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
