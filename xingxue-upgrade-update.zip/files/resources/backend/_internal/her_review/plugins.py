"""插件系统：让「个人偏好」变成「自己加的东西」。

设计原则（延续整个项目的零依赖路线）：

1. **插件就是一个 .py 文件**，丢进数据目录的 plugins/ 里即可，不用打包、不用安装。
2. **一个坏插件不能弄坏整个程序**：加载失败、渲染失败、命令报错都被兜住，只标注状态。
3. **内置功能和用户插件用同一套 API**：倒数日/便签/提醒也是这么注册进来的，
   所以她学会写插件之后，能做的事情和官方一模一样（没有「只有官方能改」的部分）。
4. **状态自动持久化**：api.state() 返回一个字典，用完即存，不需要自己管文件。

插件目录结构（都在 her --home 指定的数据目录下）：

    plugins/
      hello_plugin.py        单文件插件（最常用）
      my_tool/
        __init__.py          包式插件（复杂一点、有多个文件时用）

一个最小插件：

    NAME = "每周提醒我看番"
    VERSION = "1.0"
    DESCRIPTION = "周日晚上提醒我休息一下"

    def register(api):
        def render(ctx):
            return "今天也要好好休息哦"

        api.add_panel("anime", "看番提醒", render)
"""

from __future__ import annotations

import importlib.util
import shutil
import subprocess
import sys
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from . import ui
from .panels import PanelRegistry, PanelSpec

STATE_OK = "ok"
STATE_DISABLED = "disabled"
STATE_ERROR = "error"

STATE_LABELS = {
    STATE_OK: ("已加载", "brightgreen"),
    STATE_DISABLED: ("已停用", "grey"),
    STATE_ERROR: ("加载失败", "red"),
}

TEMPLATE = '''"""my_plugin —— 一个 her-review 插件。

插件就是你自己的小功能：想让首页多显示点什么、想加一条自己的命令，都写在这里。
改完直接 `her today` 就能看到效果，不需要重启什么服务。

约定：
    文件顶部的 NAME / VERSION / DESCRIPTION / AUTHOR 是给人看的元信息
    register(api) 是入口，程序启动时会调用它一次
"""

NAME = "my_plugin"
VERSION = "1.0"
DESCRIPTION = "把这里改成你这个插件是干什么的"
AUTHOR = "你的名字"

# 想让插件默认不启用，就把这行改成 True（之后用 her plugins enable my_plugin 打开）
DEFAULT_DISABLED = False


def register(api):
    """插件入口。注册面板、命令、钩子都在这里做。"""

    # ---------------- 1) 首页面板 ----------------
    # 面板就是一个函数：拿到 ctx，返回要显示的文本（多行也可以）
    def render(ctx):
        # api.state() 是一个会自动保存的字典，随你怎么用
        state = api.state()
        count = int(state.get("count", 0))

        lines = [
            "这个面板来自插件 " + api.plugin_name,
            f"我被渲染过 {count} 次",
        ]
        if ctx.store.count():
            lines.append(f"顺便：题库里现在有 {ctx.store.count()} 道题")
        return api.box("我的插件面板", lines)

    api.add_panel("my_plugin", "我的插件", render)

    # ---------------- 2) 自己的命令 ----------------
    # 挂上去之后就能用：her my_plugin greet 小明
    def greet(args, ctx):
        who = (args.who or ctx.name or "你")
        api.log(f"打招呼给 {who}")
        print(f"你好，{who}！这条来自插件命令。")
        return 0

    api.add_command(
        "greet", greet,
        help="跟某人打个招呼",
        arguments=[{"name": "who", "nargs": "?", "help": "打招呼的对象"}],
    )

    # ---------------- 3) 钩子 ----------------
    # 复习完一道题会触发（quality 是 0-5 的评分）
    @api.on("review")
    def after_review(ctx, problem, quality, **kwargs):
        if quality <= 2:
            api.log(f"「{problem.title}」没记住，已记下")

    # 程序每次启动会触发一次
    @api.on("startup")
    def on_start(ctx, **kwargs):
        state = api.state()
        state["count"] = int(state.get("count", 0)) + 1
'''

PLUGIN_TEMPLATE_DOC = """插件模板说明（照抄改就行）

最小可用插件只要三样东西：

    NAME = "插件名"          # 可以省略，默认用文件名
    DESCRIPTION = "干什么用的"
    def register(api):       # 入口
        api.add_panel("id", "标题", render)   # 首页加一块

api 能用的东西：
    api.add_panel(id, title, render)      加首页面板
    api.add_command(name, func, ...)      加子命令（her 插件名 命令名）
    api.on("startup"|"review"|"day", fn)  挂钩子
    api.state()                           一个自动保存的字典，存你的数据
    api.box(title, lines)                 画一个框（和程序其他地方一个风格）
    api.c(text, "hotpink")                上色
    api.log(msg)                          写日志
    api.warn(msg) / api.error(msg)        提示
"""


# --------------------------------------------------------------------------
# 元信息
# --------------------------------------------------------------------------

@dataclass
class PluginInfo:
    name: str
    version: str = ""
    author: str = ""
    description: str = ""
    path: Path | None = None
    state: str = STATE_OK
    error: str = ""
    panels: list[str] = field(default_factory=list)
    commands: list[str] = field(default_factory=list)
    source: str = "plugins/"

    def state_label(self) -> tuple[str, str]:
        return STATE_LABELS.get(self.state, ("未知", "grey"))

    def is_package(self) -> bool:
        return bool(self.path and self.path.is_dir())


# --------------------------------------------------------------------------
# 运行时
# --------------------------------------------------------------------------

class PluginRuntime:
    """负责发现、加载、启用/停用插件。"""

    def __init__(self, home: Path):
        self.home = Path(home)
        self.plugins_dir = self.home / "plugins"
        self.log_path = self.home / "plugins.log"
        self.infos: dict[str, PluginInfo] = {}
        self.errors: list[tuple[str, str]] = []
        self.disabled: set[str] = set()
        self.namespaces: dict[str, dict] = {}

    # ---------------- 目录 ----------------

    def ensure_dir(self) -> Path:
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        return self.plugins_dir

    def discover(self) -> list[Path]:
        """找出所有候选插件：单文件 .py 和带 __init__.py 的目录。"""
        if not self.plugins_dir.exists():
            return []
        found: list[Path] = []
        for child in sorted(self.plugins_dir.iterdir()):
            if child.name.startswith(("_", ".")):
                continue
            if child.is_file() and child.suffix == ".py":
                found.append(child)
            elif child.is_dir() and (child / "__init__.py").exists():
                found.append(child)
        return found

    # ---------------- 启停 ----------------

    def load_disabled(self, names: list[str]) -> None:
        self.disabled = set(names)

    def _is_disabled(self, name: str) -> bool:
        return name in self.disabled

    # ---------------- 状态存储 ----------------

    def namespace(self, plugin_name: str) -> dict:
        if plugin_name not in self.namespaces:
            import json

            path = self.home / f"plugin-state-{plugin_name}.json"
            data: dict = {}
            if path.exists():
                try:
                    loaded = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(loaded, dict):
                        data = loaded
                except (OSError, ValueError):
                    data = {}
            self.namespaces[plugin_name] = data
        return self.namespaces[plugin_name]

    def save_namespace(self, plugin_name: str) -> None:
        import json

        data = self.namespaces.get(plugin_name)
        if data is None:
            return
        path = self.home / f"plugin-state-{plugin_name}.json"
        try:
            self.home.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                            encoding="utf-8")
        except OSError:
            pass

    def log(self, plugin_name: str, message: str) -> None:
        from datetime import datetime

        try:
            self.home.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {plugin_name}: {message}\n")
        except OSError:
            pass

    def read_log(self, limit: int = 30) -> list[str]:
        if not self.log_path.exists():
            return []
        try:
            lines = self.log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return []
        return lines[-limit:]

    # ---------------- 加载 ----------------

    def load_all(self, panel_registry: PanelRegistry, ctx,
                 command_sink: Callable[[str, dict], None] | None = None,
                 hooks: dict[str, list[Callable]] | None = None) -> None:
        for path in self.discover():
            name = path.stem if path.is_file() else path.name
            info = PluginInfo(name=name, path=path,
                              source="plugins/" + path.name + ("/" if path.is_dir() else ""))
            if self._is_disabled(name):
                info.state = STATE_DISABLED
                self.infos[name] = info
                continue
            try:
                self._load_one(path, info, panel_registry, ctx, command_sink, hooks)
                info.state = STATE_OK
            except Exception as exc:  # 插件自己的问题，不该影响程序
                info.state = STATE_ERROR
                info.error = f"{exc.__class__.__name__}: {exc}"
                self.errors.append((name, info.error))
                self.log(name, "加载失败\n" + traceback.format_exc())
            self.infos[name] = info

    def _load_one(self, path: Path, info: PluginInfo, panel_registry: PanelRegistry,
                  ctx, command_sink, hooks) -> None:
        module_name = f"her_plugin_{info.name}"
        if path.is_dir():
            spec = importlib.util.spec_from_file_location(
                module_name, path / "__init__.py",
                submodule_search_locations=[str(path)],
            )
        else:
            spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"无法加载 {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        info.name = str(getattr(module, "NAME", info.name)) or info.name
        info.version = str(getattr(module, "VERSION", ""))
        info.author = str(getattr(module, "AUTHOR", ""))
        info.description = str(getattr(module, "DESCRIPTION", "")).strip()

        register = getattr(module, "register", None)
        if not callable(register):
            raise AttributeError("插件里没有定义 register(api)")

        api = PluginAPI(runtime=self, name=info.name, info=info,
                        registry=panel_registry, ctx=ctx,
                        command_sink=command_sink, hooks=hooks)
        register(api)
        info.panels = api._registered_panels
        info.commands = api._registered_commands
        self.save_namespace(info.name)

    # ---------------- 钩子 ----------------

    def fire(self, hooks: dict[str, list[Callable]], event: str, **kwargs) -> None:
        """触发钩子。任何插件报错都只记日志，不打断主流程。"""
        for callback in hooks.get(event, []):
            try:
                callback(**kwargs)
            except Exception:
                name = getattr(callback, "__module__", "?").replace("her_plugin_", "")
                self.log(name, f"钩子 {event} 出错\n" + traceback.format_exc())

    # ---------------- 模板 ----------------

    def create(self, name: str, *, force: bool = False) -> Path:
        """按模板生成一个新插件。名字会替换进模板里的 NAME 和各处 id。"""
        self.ensure_dir()
        safe = name.strip().replace(" ", "_")
        if not safe or not all(ch.isalnum() or ch in "_-" for ch in safe):
            raise ValueError("插件名只能用字母、数字、下划线和短横线")
        target = self.plugins_dir / f"{safe}.py"
        if target.exists() and not force:
            raise FileExistsError(f"{target} 已经存在了（加 --force 覆盖）")

        body = (
            TEMPLATE
            .replace('NAME = "my_plugin"', f'NAME = "{safe}"')
            .replace('api.add_panel("my_plugin"', f'api.add_panel("{safe}"')
            .replace('"""my_plugin ', f'"""{safe} ')
        )
        target.write_text(body, encoding="utf-8")
        readme = self.plugins_dir / "README.txt"
        if not readme.exists():
            readme.write_text(PLUGIN_TEMPLATE_DOC, encoding="utf-8")
        return target

    def open_in_editor(self, name: str) -> tuple[bool, str]:
        """用系统默认编辑器打开插件文件（Windows 上相当于双击）。"""
        target: Path | None = None
        for path in self.discover():
            candidate = path.stem if path.is_file() else path.name
            if candidate == name or (path.is_file() and path.name == name):
                target = path if path.is_file() else path / "__init__.py"
                break
        if target is None:
            guess = self.plugins_dir / (name if name.endswith(".py") else f"{name}.py")
            if guess.exists():
                target = guess
        if target is None or not target.exists():
            return False, f"没找到插件 {name}"

        if sys.platform.startswith("win"):
            import os

            try:
                os.startfile(str(target))  # type: ignore[attr-defined]
                return True, str(target)
            except OSError as exc:
                return False, str(exc)
        opener = shutil.which("open") or shutil.which("xdg-open")
        if opener:
            subprocess.Popen([opener, str(target)], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return True, str(target)
        return False, f"打开不了编辑器，文件在这里：{target}"


# --------------------------------------------------------------------------
# 插件 API（插件作者唯一需要面对的东西）
# --------------------------------------------------------------------------

class PluginAPI:
    def __init__(self, runtime: PluginRuntime, name: str, info: PluginInfo,
                 registry: PanelRegistry, ctx, command_sink=None, hooks=None):
        self._runtime = runtime
        self.plugin_name = name
        self._info = info
        self._registry = registry
        self._ctx = ctx
        self._command_sink = command_sink
        self._hooks = hooks if hooks is not None else {}
        self._registered_panels: list[str] = []
        self._registered_commands: list[str] = []

    # ---------------- 只读上下文 ----------------

    @property
    def store(self):
        return self._ctx.store

    @property
    def config(self):
        return self._ctx.cfg

    @property
    def theme(self):
        return self._ctx.theme

    @property
    def name(self) -> str:
        return self._ctx.name

    # ---------------- 注册 ----------------

    def add_panel(self, panel_id: str, title: str,
                  render: Callable[[Any], str], intro: str = "") -> None:
        """往首页加一块面板。render(ctx) 返回要显示的文本。"""
        self._registry.register(
            PanelSpec(panel_id, title, render, intro=intro, source=self.plugin_name)
        )
        self._registered_panels.append(panel_id)

    def add_command(self, name: str, func: Callable, help: str = "",
                    arguments: list[dict] | None = None) -> None:
        """加一个子命令：her <插件名> <命令名>。"""
        if self._command_sink is None:
            raise RuntimeError("当前环境不支持注册命令")
        self._command_sink(self.plugin_name, {
            "name": name, "func": func, "help": help or f"{self.plugin_name} 的命令",
            "arguments": arguments or [],
        })
        self._registered_commands.append(name)

    def on(self, event: str, func: Callable | None = None):
        """挂钩子。支持装饰器写法：@api.on("review")。"""
        def decorator(callback: Callable) -> Callable:
            self._hooks.setdefault(event, []).append(callback)
            return callback

        if func is not None:
            return decorator(func)
        return decorator

    # ---------------- 状态 ----------------

    def state(self) -> dict:
        """返回一个会自动保存的字典，用来存插件自己的数据。"""
        return self._runtime.namespace(self.plugin_name)

    def save(self) -> None:
        self._runtime.save_namespace(self.plugin_name)

    # ---------------- 输出（复用程序自己的风格，插件不用自己写渲染） ----------------

    def box(self, title: str, lines: list[str], style: str | None = None) -> str:
        return ui.box(title, lines, width=ui.term_width(),
                      style=style or self.theme.primary)

    def c(self, text: str, *styles: str) -> str:
        return ui.c(text, *styles)

    def bar(self, filled: int, total: int, width: int = 20, style: str = "hotpink") -> str:
        return ui.bar(filled, total, width=width, style=style)

    def wrap(self, text: str, width: int | None = None) -> list[str]:
        return ui.wrap(text, width or (ui.term_width() - 6))

    def log(self, message: str) -> None:
        self._runtime.log(self.plugin_name, message)

    def info(self, message: str) -> None:
        ui.info(message)

    def warn(self, message: str) -> None:
        ui.warn(message)

    def error(self, message: str) -> None:
        ui.err(message)


# --------------------------------------------------------------------------
# 自测：用一个临时目录真的加载一个插件（含故意写坏的插件）
# --------------------------------------------------------------------------

def _selftest() -> None:
    import os

    ui.use_color(False)

    good = '''
NAME = "好插件"
VERSION = "9.9"
DESCRIPTION = "用来测试加载器"
def register(api):
    api.add_panel("good", "好面板", lambda ctx: "面板内容")
    def hello(args, ctx):
        print("你好")
        return 0
    api.add_command("hello", hello, help="说你好")
    state = api.state()
    state["loaded"] = int(state.get("loaded", 0)) + 1
    @api.on("review")
    def _hook(**kwargs):
        raise RuntimeError("故意炸一下，验证钩子隔离")
'''
    bad = 'NAME = "坏插件"\ndef register(api):\n    raise ValueError("我就是坏的")\n'
    no_register = 'NAME = "没入口"\n'

    tmp_root = None
    try:
        # 在工作目录下建临时目录：系统 temp 在某些受限环境里不可写
        tmp_root = str(Path.cwd() / f".selftest-plugins-{os.getpid()}")
        home = Path(tmp_root)
        home.mkdir(parents=True, exist_ok=True)
        runtime = PluginRuntime(home)
        plugins = runtime.ensure_dir()
        (plugins / "good.py").write_text(good, encoding="utf-8")
        (plugins / "bad.py").write_text(bad, encoding="utf-8")
        (plugins / "noreg.py").write_text(no_register, encoding="utf-8")
        (plugins / "_skip_me.py").write_text("raise RuntimeError('不该被加载')", encoding="utf-8")
        pkg = plugins / "pack"
        pkg.mkdir()
        (pkg / "__init__.py").write_text(
            'NAME = "包插件"\ndef register(api):\n    api.add_panel("pack", "包面板", lambda ctx: "x")\n',
            encoding="utf-8",
        )

        registry = PanelRegistry()
        commands: dict[str, dict] = {}

        def sink(plugin_name, spec):
            commands[f"{plugin_name}:{spec['name']}"] = spec

        hooks: dict[str, list] = {}

        class _Ctx:
            store = None
            cfg = None
            theme = None
            name = "测试"

        runtime.load_all(registry, _Ctx(), command_sink=sink, hooks=hooks)

        assert runtime.infos["good"].state == STATE_OK, runtime.infos["good"]
        assert runtime.infos["good"].name == "好插件"
        assert runtime.infos["bad"].state == STATE_ERROR
        assert "我就是坏的" in runtime.infos["bad"].error
        assert runtime.infos["noreg"].state == STATE_ERROR
        assert "_skip_me" not in runtime.infos, "下划线开头的文件不该被加载"
        assert runtime.infos["pack"].state == STATE_OK
        assert registry.get("good") is not None and registry.get("pack") is not None
        assert "好插件:hello" in commands, commands

        # 状态要写盘，并且第二次加载能读到
        assert runtime.namespace("好插件")["loaded"] == 1
        runtime2 = PluginRuntime(home)
        registry2 = PanelRegistry()
        runtime2.load_all(registry2, _Ctx(), command_sink=sink, hooks={})
        assert runtime2.namespace("好插件")["loaded"] == 2, "插件状态没有持久化"

        # 停用
        runtime3 = PluginRuntime(home)
        runtime3.load_disabled(["good"])
        registry3 = PanelRegistry()
        runtime3.load_all(registry3, _Ctx(), command_sink=sink, hooks={})
        assert runtime3.infos["good"].state == STATE_DISABLED
        assert registry3.get("good") is None, "停用的插件不该注册面板"

        # 钩子隔离：坏钩子不能把主流程搞崩
        runtime.fire(hooks, "review", problem=type("P", (), {"title": "x"})(), quality=1)
        assert "故意炸一下" in (runtime.log_path.read_text(encoding="utf-8"))

        # 模板
        path = runtime.create("brand_new")
        assert path.exists() and "def register(api)" in path.read_text(encoding="utf-8")
        try:
            runtime.create("brand_new")
            raise AssertionError("重名应该报错")
        except FileExistsError:
            pass
        runtime.create("brand_new", force=True)
    finally:
        if tmp_root:
            shutil.rmtree(tmp_root, ignore_errors=True)
    print("plugins selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
