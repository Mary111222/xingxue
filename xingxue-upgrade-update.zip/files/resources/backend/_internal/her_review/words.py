"""六级词表 → 间隔重复。

## 为什么要单独一个模块

六级备考页原来只能"导入词表**看**"。背单词的核心是**重复**，
而重复的调度逻辑（SM-2）项目里**已经有了**（`her_review/sm2.py`，
题目复习一直在用）。所以这里只做三件事：

    ① 把内置词表灌进 `words` 表（幂等：已有的不重复插）
    ② 取"今天该背的"
    ③ 一次评价 → 用 sm2 算出下次该什么时候出现

**不重新实现 SM-2**：抄一份出来，以后改算法就会出现"题目一套、
单词一套"，两边不一致 —— 这是这个项目反复踩过的坑。
"""
from __future__ import annotations

from datetime import date

from . import sm2

# 三档 → SM-2 的 quality
QUALITY = {"know": 5, "fuzzy": 3, "unknown": 1}


def import_vocab(store, vocab: list[tuple]) -> dict:
    """把词表灌进库。**幂等**：同一个词不会重复插。"""
    added = 0
    skipped = 0
    for item in vocab:
        try:
            word, meaning = item[0], item[1]
            note = item[2] if len(item) > 2 else ""
        except (TypeError, IndexError):
            continue
        if store.word_exists(word):
            skipped += 1
            continue
        store.word_add(str(word), str(meaning), str(note))
        added += 1
    return {"ok": True, "added": added, "skipped": skipped,
            "total": store.words_count()}


def due(store, limit: int = 20, today: date | None = None) -> list[dict]:
    """今天该背的词（含逾期的），按逾期最久的排前面。"""
    return store.words_due(limit, today or date.today())


def review(store, word_id: int, action: str, today: date | None = None) -> dict:
    """评价一个词 → 用 SM-2 算出下次出现的时间。"""
    today = today or date.today()
    row = store.word_get(int(word_id))
    if row is None:
        return {"ok": False, "error": "找不到这个词"}
    quality = QUALITY.get(str(action))
    if quality is None:
        return {"ok": False, "error": f"不认识的评价：{action}"}
    state = sm2.SM2State(int(row["repetitions"] or 0),
                         int(row["interval"] or 0),
                         float(row["ef"] or sm2.EF_DEFAULT))
    got = sm2.review(state, quality, today)
    store.word_update(int(word_id), got.repetitions, got.interval, got.ef,
                      got.due.isoformat(), 0 if got.passed else 1)
    return {"ok": True, "word": row["word"], "passed": got.passed,
            "interval": got.interval, "due": got.due.isoformat(),
            "label": got.label}


def stats(store, today: date | None = None) -> dict:
    """词表进度：总数 / 今天到期 / 已掌握（间隔 ≥ 21 天）。"""
    return store.words_stats(today or date.today())


def _selftest() -> None:
    """用内存库跑一遍：导入 → 到期 → 认识/不认识 → 下次时间变了。"""
    import tempfile
    from pathlib import Path as _P

    from .db import Store

    with tempfile.TemporaryDirectory() as td:
        st = Store(_P(td) / "t.sqlite3")
        vocab = [("address", "v. 处理", "熟词僻义"), ("approach", "n. 方法", "")]
        got = import_vocab(st, vocab)
        assert got["added"] == 2 and got["total"] == 2, got
        assert import_vocab(st, vocab)["added"] == 0, "重复导入应该幂等"

        ds = due(st, 10)
        assert len(ds) == 2, f"新词应该都在到期队列里：{ds}"
        wid = ds[0]["id"]
        first = review(st, wid, "know")
        assert first["ok"] and first["interval"] >= 1, first
        second = review(st, wid, "unknown")
        assert second["ok"] and second["interval"] <= first["interval"],             "评了「不认识」间隔必须变短"
        assert stats(st)["total"] == 2
        # **Windows 上必须显式关连接**：不然 TemporaryDirectory 删不掉
        # （sqlite 文件还被占着）—— 断言都过了却报 PermissionError。
        st.conn.close()
        print("words selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
