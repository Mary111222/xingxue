"""专业学习模块：湖南工商大学计科专业的课程 → 知识点 → 题目/资源。

课程清单来源（可溯源，不是我凭印象写的）：
    《2025 版计算机科学与技术专业人才培养方案》
    https://cee.hutb.edu.cn/bkspy/pyfa/content_35232
    下载地址 https://cee.hutb.edu.cn/upload/history/u/cms/jsjxy/202510/261026187lfo.pdf

方案原文里的「主要课程」是：
    C 语言程序设计(计)、离散数学(计)、数据结构(计)、面向对象程序设计(计)、
    数字电子技术基础、操作系统(计)、数据库原理(计)、算法设计与分析(计)、
    计算机组成原理(计)、计算机网络原理(计)、编译原理、软件工程(计)、
    移动互联网应用开发(计)
另外从「毕业要求与课程体系对照表」里还抽到这些专业选修/实践课：
    嵌入式系统开发技术、Java 应用开发技术、数字图像处理及应用、
    面向服务的软件开发、数学建模与 MATLAB、程序设计竞赛基础、
    数据结构与算法课程设计、软件综合课程设计、程序设计综合课程设计

设计取舍：
    1. 每门课给「学期、学分、在专业里的位置」，因为她会想知道「这门课什么时候上」。
    2. 每门课挂知识点，知识点再挂：题库里的题（按标签自动匹配）+ 学习站点 + B 站搜索词。
       题目匹配是**动态**的——她以后自己加的题，只要标签对得上就会自动出现。
    3. 学分为空的地方宁可留空，不编数字。方案里没写明的就是没写明。
"""

from __future__ import annotations

from dataclasses import dataclass, field

# --------------------------------------------------------------------------
# 数据结构
# --------------------------------------------------------------------------

@dataclass(eq=False)
class Course:
    """一门课。

    eq=False 是必需的：dataclass 默认会生成 __eq__，那会把 __hash__ 置空，
    于是 Course 不能当字典键——而 coverage() 正好要拿它当键。
    这里按对象身份比较就好（同一门课在一个进程里只有一个实例）。
    """
    code: str                    # 短名，命令行用：her course ds
    name: str                    # 课程全名（和培养方案一致）
    category: str                # 专业基础 / 专业必修 / 专业选修 / 实践
    term: str = ""               # 建议修读学期（方案里有的才填）
    credit: str = ""             # 学分（方案里有的才填）
    why: str = ""                # 这门课在专业里干什么用（一句话）
    hard: str = ""               # 难在哪 / 大家一般卡在哪
    points: list[str] = field(default_factory=list)   # 知识点
    tags: list[str] = field(default_factory=list)     # 用来匹配题库里的标签
    sites: list[str] = field(default_factory=list)    # 关联的学习站点 key（见 learning.py）

    def search_words(self) -> list[str]:
        """给 B 站搜索用：课程名 + 知识点，去掉括号注释。"""
        words = [self.name.replace("（计）", "").replace("(计)", "")]
        words.extend(self.points[:3])
        return words


# 分类顺序 = 展示顺序
CATEGORIES = [
    ("专业基础", "先把地基打牢：语言、数学、数据结构"),
    ("专业必修", "专业的骨架课，也是考研和面试的主战场"),
    ("专业选修", "按兴趣和方向挑，决定你往哪走"),
    ("实践", "课程设计那一类，动手才算学会"),
]

# --------------------------------------------------------------------------
# 课程
# --------------------------------------------------------------------------

COURSES: list[Course] = [
    # ---------------- 专业基础 ----------------
    Course(
        code="c",
        name="C 语言程序设计（计）",
        category="专业基础",
        why="专业第一门语言课，也是后面数据结构、操作系统实验的语言基础。",
        hard="指针和内存。数组越界、野指针、函数传参是值传递——这三个坑几乎所有人在期中前都踩过。",
        points=["变量与类型", "流程控制", "数组与字符串", "函数与递归", "指针与内存", "结构体", "文件操作"],
        tags=["数组", "字符串", "递归", "指针"],
        sites=["runoob", "cppref"],
    ),
    Course(
        code="dm",
        name="离散数学（计）",
        category="专业基础",
        why="数据结构与算法的数学语言：集合、关系、图、逻辑都在这里第一次出现。",
        hard="证明题。习惯了算数之后，第一次要求「证明」会很别扭。",
        points=["命题逻辑", "谓词逻辑", "集合与关系", "函数", "图论基础", "树", "代数系统"],
        tags=["图", "树", "数学"],
        sites=["oi-wiki", "hello-algo"],
    ),
    Course(
        code="ds",
        name="数据结构（计）",
        category="专业基础",
        credit="",
        why="整个专业最重要的一门基础课，也是考研 408 和面试的核心。",
        hard="不是「会不会写」，是「能不能在 20 分钟内写对」。链表指针一乱就全崩，树和图的递归要想清楚。",
        points=[
            "线性表（顺序表 / 链表）", "栈与队列", "串与 KMP", "树与二叉树",
            "二叉搜索树与平衡树", "堆与优先队列", "图（存储 / 遍历）",
            "最短路径与最小生成树", "排序算法", "查找与哈希表",
        ],
        tags=["链表", "栈", "队列", "二叉树", "堆", "图", "排序", "哈希表",
              "二分查找", "递归", "字符串"],
        sites=["carl", "hello-algo", "leetcode", "oi-wiki"],
    ),
    Course(
        code="oop",
        name="面向对象程序设计（计）",
        category="专业基础",
        why="从「写函数」到「设计对象」的转折点，通常用 Java 讲。",
        hard="继承和接口的区别、多态到底怎么发生的。背概念没用，得自己写一个类层次才明白。",
        points=["类与对象", "封装", "继承", "多态", "接口与抽象类",
                "异常处理", "集合框架", "泛型", "IO 与文件"],
        tags=["设计", "面向对象"],
        sites=["runoob", "github"],
    ),
    Course(
        code="digital",
        name="数字电子技术基础",
        category="专业基础",
        why="硬件方向的第一门课，讲门电路、组合逻辑、时序逻辑。",
        hard="卡诺图化简和时序电路的状态分析。要动手做实验，光看书很难有感觉。",
        points=["数制与编码", "逻辑门", "布尔代数与卡诺图", "组合逻辑电路",
                "触发器", "时序逻辑电路", "计数器与寄存器", "存储器"],
        tags=[],
        sites=["bilibili"],
    ),

    # ---------------- 专业必修 ----------------
    Course(
        code="os",
        name="操作系统（计）",
        category="专业必修",
        why="考研 408 四大件之一，也是理解「程序为什么这样跑」的关键。",
        hard="进程同步（PV 操作、信号量）和虚拟内存。题目不难但容易想漏情况。",
        points=["进程与线程", "CPU 调度", "进程同步与互斥", "死锁",
                "内存管理", "虚拟内存与分页", "文件系统", "磁盘与 IO"],
        tags=["操作系统", "并发", "设计"],
        sites=["cs-notes", "csdiy", "bilibili"],
    ),
    Course(
        code="db",
        name="数据库原理（计）",
        category="专业必修",
        why="工作中最常用的一门课，也是各种管理系统项目的底座。",
        hard="SQL 写复杂查询（多表连接 + 分组）和范式分解。理论部分（关系代数）容易被跳过但考试要考。",
        points=["关系模型与关系代数", "SQL 基础", "SQL 复杂查询", "视图与索引",
                "范式与规范化", "事务与并发控制", "恢复技术", "存储与查询优化"],
        tags=["SQL", "数据库", "索引", "事务"],
        sites=["runoob", "cs-notes", "bilibili"],
    ),
    Course(
        code="algo",
        name="算法设计与分析（计）",
        category="专业必修",
        why="把数据结构里学的工具用起来解决问题，也是算法竞赛和机试的基础。",
        hard="动态规划。状态怎么定义、转移怎么写，这个坎过了后面就顺了。",
        points=["复杂度分析", "分治", "贪心", "动态规划", "回溯与分支限界",
                "图算法", "NP 完全性初步"],
        tags=["动态规划", "贪心", "分治", "回溯", "二分查找", "图",
              "双指针", "滑动窗口", "单调栈", "位运算", "并查集", "堆"],
        sites=["carl", "acwing", "leetcode", "luogu", "oi-wiki"],
    ),
    Course(
        code="co",
        name="计算机组成原理（计）",
        category="专业必修",
        why="考研 408 四大件之一，讲 CPU 怎么把指令变成电信号。",
        hard="指令流水线和存储器层次（Cache 映射）。要和数字电子技术接上，中间断一环就跟不上。",
        points=["数据表示与运算", "指令系统", "CPU 结构", "指令流水线",
                "存储器层次与 Cache", "总线", "IO 方式"],
        tags=["计算机组成", "缓存", "位运算"],
        sites=["cs-notes", "csdiy", "bilibili"],
    ),
    Course(
        code="net",
        name="计算机网络原理（计）",
        category="专业必修",
        why="考研 408 四大件之一，也是后端开发每天都要碰的东西。",
        hard="TCP 三次握手/四次挥手的状态变化、拥塞控制。要结合抓包实验才记得住。",
        points=["体系结构（OSI / TCP-IP）", "物理层与数据链路层", "网络层与 IP",
                "路由算法", "传输层 TCP/UDP", "TCP 可靠传输与拥塞控制",
                "应用层 HTTP/DNS", "网络安全基础"],
        tags=["网络", "TCP", "HTTP", "网络编程"],
        sites=["cs-notes", "mdn", "bilibili"],
    ),
    Course(
        code="compiler",
        name="编译原理",
        category="专业必修",
        why="把「人能读的代码」变成「机器能跑的东西」，是计算机里最漂亮的一套理论。",
        hard="语法分析（LL/LR）和语义分析。理论密度大，实验（写个小型编译器）很花时间。",
        points=["词法分析", "语法分析（自顶向下 / 自底向上）", "语义分析",
                "中间代码生成", "代码优化", "目标代码生成"],
        tags=["编译", "字符串", "递归"],
        sites=["csdiy", "bilibili"],
    ),
    Course(
        code="se",
        name="软件工程（计）",
        category="专业必修",
        why="教你怎么把「能跑的程序」变成「能被维护的项目」，也是简历上项目的理论支撑。",
        hard="不硬，但容易觉得空。真正有用的是需求分析和设计模式——做项目时回头看书才懂。",
        points=["软件过程模型", "需求分析", "结构化与面向对象设计", "UML",
                "设计模式", "软件测试", "项目管理与版本控制"],
        tags=["软件工程", "设计", "测试", "Git"],
        sites=["codefather", "github", "mdn"],
    ),
    Course(
        code="mobile",
        name="移动互联网应用开发（计）",
        category="专业必修",
        why="方案里明确用 Android 讲，也是很多课程设计和比赛的载体。",
        hard="环境配置本身就是一道坎；然后是生命周期和异步（网络请求不能放主线程）。",
        points=["Android 开发环境", "Activity 与生命周期", "View 与 ViewGroup",
                "菜单与对话框", "2D 绘图", "后台线程与异步", "SQLite 本地存储"],
        tags=["Android", "移动开发"],
        sites=["runoob", "codefather", "github"],
    ),

    # ---------------- 专业选修 ----------------
    Course(
        code="javaweb",
        name="Java 应用开发技术（计）",
        category="专业选修",
        why="后端开发的主线：从 Servlet 到 Spring 那一套。",
        hard="概念多（容器、Bean、AOP）。建议直接做一个带登录的完整小项目，比看视频有效。",
        points=["Servlet 与 JSP", "MVC 分层", "Spring 基础", "Spring Boot",
                "MyBatis 与 ORM", "REST 接口", "会话与鉴权"],
        tags=["Java", "Web", "后端"],
        sites=["runoob", "codefather", "github"],
    ),
    Course(
        code="embedded",
        name="嵌入式系统开发技术",
        category="专业选修",
        why="软硬结合的方向：单片机、外设驱动、实时系统。",
        hard="调试靠示波器和逻辑分析仪，出错时没有方便的断点。要有耐心。",
        points=["嵌入式处理器", "GPIO 与外设", "中断与定时器", "串口通信",
                "RTOS 基础", "嵌入式 Linux"],
        tags=["嵌入式", "硬件"],
        sites=["bilibili", "github"],
    ),
    Course(
        code="dip",
        name="数字图像处理及应用",
        category="专业选修",
        why="图像方向入门课，也是通往计算机视觉的第一步。",
        hard="数学（卷积、傅里叶变换）会突然变多。建议边学边用 OpenCV 跑一遍。",
        points=["图像基础与色彩空间", "灰度变换", "空间滤波", "频域处理",
                "边缘检测", "形态学操作", "图像分割"],
        tags=["图像", "视觉", "Python"],
        sites=["bilibili", "github", "mdn"],
    ),
    Course(
        code="soa",
        name="面向服务的软件开发",
        category="专业选修",
        why="讲微服务、服务治理那一套，是后端进阶的方向。",
        hard="概念多且依赖工程经验，最好在做过单体项目之后再学。",
        points=["服务化架构", "REST 与 RPC", "服务注册与发现", "网关",
                "容器与部署", "可观测性"],
        tags=["微服务", "分布式", "后端"],
        sites=["codefather", "github"],
    ),
    Course(
        code="matlab",
        name="数学建模与 MATLAB",
        category="专业选修",
        why="数学建模竞赛的主力工具，也能补一补编程里的数值思维。",
        hard="不难，但和工程编程习惯差别大（矩阵优先、向量化）。",
        points=["MATLAB 基础", "矩阵与向量化", "数据可视化",
                "数值方法", "优化与拟合", "建模案例"],
        tags=["数学", "建模"],
        sites=["bilibili"],
    ),
    Course(
        code="contest",
        name="程序设计竞赛基础",
        category="专业选修",
        why="方案里明确列出的实践课，直接对应各类程序设计竞赛和机试。",
        hard="和课内要求不同：要的是速度和正确率，模板要熟到不用想。",
        points=["输入输出与边界", "常用 STL / 库", "暴力与剪枝", "贪心",
                "动态规划专题", "图论专题", "数据结构专题", "对拍与调试"],
        tags=["竞赛", "算法", "模板"],
        sites=["acwing", "luogu", "carl", "leetcode"],
    ),

    # ---------------- 实践 ----------------
    Course(
        code="ds-design",
        name="数据结构与算法课程设计",
        category="实践",
        why="学完数据结构 + 算法后的综合训练，一般要求做出可运行的系统。",
        hard="从「写函数」到「写一个能演示的程序」，接口设计和界面（哪怕是命令行）都要自己定。",
        points=["需求与选型", "核心数据结构设计", "算法实现与测试", "报告撰写"],
        tags=["课程设计", "综合"],
        sites=["carl", "codefather", "github"],
    ),
    Course(
        code="oop-design",
        name="程序设计综合课程设计",
        category="实践",
        why="以 Java 为基础做阶段性训练，是往工程化走的第一步。",
        hard="代码一多就乱。学会分层和命名，比多写功能重要。",
        points=["项目结构", "分层设计", "异常与日志", "测试与调试"],
        tags=["课程设计", "Java"],
        sites=["codefather", "github"],
    ),
    Course(
        code="se-design",
        name="软件综合课程设计",
        category="实践",
        why="方案的收尾实践，要求用软件工程方法做完整系统，会碰 MySQL / NoSQL / Redis。",
        hard="把前面所有课串起来：需求、设计、数据库、后端、部署。时间管理是最大挑战。",
        points=["需求与原型", "数据库设计", "后端接口", "前端页面",
                "缓存（Redis）", "部署与演示"],
        tags=["课程设计", "数据库", "后端", "前端"],
        sites=["codefather", "runoob", "mdn", "github"],
    ),
]


# --------------------------------------------------------------------------
# 查询
# --------------------------------------------------------------------------

def by_code(code: str) -> Course | None:
    code = (code or "").strip().lower()
    for course in COURSES:
        if course.code == code:
            return course
    return None


def by_index(index: int) -> Course | None:
    if 1 <= index <= len(COURSES):
        return COURSES[index - 1]
    return None


def find(token: str) -> Course | None:
    """按编号 / 短名 / 课程名片段 / 知识点找一门课。"""
    token = (token or "").strip()
    if not token:
        return None
    if token.isdigit():
        return by_index(int(token))
    hit = by_code(token)
    if hit:
        return hit
    lowered = token.lower()
    for course in COURSES:
        if lowered in course.name.lower() or lowered in course.code:
            return course
    # 再按知识点/标签找
    for course in COURSES:
        if any(lowered in p.lower() for p in course.points):
            return course
    for course in COURSES:
        if any(lowered in t.lower() for t in course.tags):
            return course
    return None


def in_category(category: str) -> list[Course]:
    return [c for c in COURSES if c.category == category]


def all_tags() -> set[str]:
    out: set[str] = set()
    for course in COURSES:
        out.update(course.tags)
    return out


def course_for_tag(tag: str) -> list[Course]:
    """某个标签（题目标签）属于哪几门课。"""
    tag = (tag or "").strip().lower()
    return [c for c in COURSES if any(tag == t.lower() for t in c.tags)]


def coverage(problems) -> list[tuple[Course, int]]:
    """每门课在题库里对应多少道题（按标签匹配）。"""
    out: list[tuple[Course, int]] = []
    for course in COURSES:
        wanted = {t.lower() for t in course.tags}
        if not wanted:
            out.append((course, 0))
            continue
        count = sum(
            1 for p in problems
            if any(t.lower() in wanted for t in (p.tags or []))
        )
        out.append((course, count))
    return out


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from . import ui

    ui.use_color(False)

    assert len(COURSES) >= 18, len(COURSES)
    codes = [c.code for c in COURSES]
    assert len(codes) == len(set(codes)), "课程短名有重复"

    # 培养方案「主要课程」里点名的，必须都在
    required = ["C 语言程序设计", "离散数学", "数据结构", "面向对象程序设计",
                "数字电子技术基础", "操作系统", "数据库原理", "算法设计与分析",
                "计算机组成原理", "计算机网络原理", "编译原理", "软件工程",
                "移动互联网应用开发"]
    names = " ".join(c.name for c in COURSES)
    for item in required:
        assert item in names, f"培养方案里的「{item}」没收录"

    for course in COURSES:
        assert course.name and course.why and course.hard, f"{course.code} 说明不全"
        assert course.category in dict(CATEGORIES), f"{course.code} 分类不认识"
        assert course.points, f"{course.code} 没有知识点"
        for site in course.sites:
            assert site, course.code

    # 查找
    assert by_code("ds") is not None
    assert "数据结构" in by_code("ds").name
    assert by_index(1) is COURSES[0]
    assert by_index(0) is None and by_index(9999) is None
    assert find("操作系统") is by_code("os")
    assert find("动态规划") is by_code("algo"), "按知识点也该找得到课"
    assert find("不存在的东西xyz") is None

    # 标签 → 课程
    assert by_code("ds") in course_for_tag("二叉树")
    assert course_for_tag("压根不存在的标签") == []

    # 每门课都要能生成搜索词
    for course in COURSES:
        words = course.search_words()
        assert words and all(w.strip() for w in words), course.code
        assert "（计）" not in words[0], f"{course.code} 搜索词没清理括号"

    # 分类不为空
    for name, _ in CATEGORIES:
        assert in_category(name), f"分类 {name} 是空的"

    print("curriculum selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
