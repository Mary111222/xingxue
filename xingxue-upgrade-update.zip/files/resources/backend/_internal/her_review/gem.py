"""个性化层：由她的生日日期推导出「只属于她」的一套皮肤。

核心想法：把生日日期（YYYY-MM-DD）当成随机种子，
- 推导出一组主题配色
- 推导出一份祝福语和每日一句
- 推导出蛋糕的装饰

所以这份皮肤在世界上是唯一的：换一个人的生日，配色和文案全变。

生日当天额外触发：终端蛋糕 + 专属祝福 + 周年计数。
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import date, datetime

from . import ui

# --------------------------------------------------------------------------
# 由生日种子推导主题
# --------------------------------------------------------------------------

# 候选配色（前景色名，来自 ui._CODES）。整体是粉色系画风，八种都偏粉，
# 只是粉的方向不同——这样换生日换的是「哪一种粉」，而不是忽然变成青蓝色。
_PALETTES = [
    ("pink", "hotpink", "plum"),        # 樱花粉（最像符号喵喵）
    ("rose", "pink", "pinklight"),      # 玫瑰奶盖
    ("hotpink", "pinklight", "gold"),   # 草莓大福
    ("plum", "pink", "rose"),           # 藕粉
    ("pink", "violet", "hotpink"),      # 樱紫
    ("rose", "orange", "pink"),         # 蜜桃汽水
    ("hotpink", "violet", "pink"),      # 葡萄软糖
    ("pink", "rose", "gold"),           # 奶油草莓
]

_PALETTE_NAMES = [
    "樱花粉",
    "玫瑰奶盖",
    "草莓大福",
    "藕粉",
    "樱紫",
    "蜜桃汽水",
    "葡萄软糖",
    "奶油草莓",
]


@dataclass
class Theme:
    primary: str    # 主色：框线、标题
    accent: str     # 强调：数字、进度
    extra: str      # 点缀：提示、日期
    palette_name: str
    seed: int

    def name(self) -> str:
        return self.palette_name


def theme_from_birthday(birthday: str | None) -> Theme:
    """用生日日期当种子挑配色。生日缺失时用固定种子。"""
    raw = (birthday or "unknown").strip()
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    seed = int(digest[:8], 16)
    idx = seed % len(_PALETTES)
    primary, accent, extra = _PALETTES[idx]
    return Theme(primary, accent, extra, _PALETTE_NAMES[idx], seed)


# --------------------------------------------------------------------------
# 生日日期工具
# --------------------------------------------------------------------------

def parse_date(text: str | None) -> date | None:
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%m-%d", "%m/%d"):
        try:
            d = datetime.strptime(text.strip(), fmt).date()
            if fmt in ("%m-%d", "%m/%d"):
                d = d.replace(year=date.today().year)
            return d
        except ValueError:
            continue
    return None


def _is_leap(year: int) -> bool:
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def _clamp_feb29(d: date, year: int) -> date:
    """2 月 29 日出生的人在平年按 2 月 28 日过。"""
    if d.month == 2 and d.day == 29 and not _is_leap(year):
        return date(year, 2, 28)
    return d.replace(year=year)


def next_birthday(birthday: date | None, today: date | None = None) -> date | None:
    if birthday is None:
        return None
    today = today or date.today()
    candidate = _clamp_feb29(birthday, today.year)
    if candidate < today:
        candidate = _clamp_feb29(birthday, today.year + 1)
    return candidate


def is_birthday(birthday: date | None, today: date | None = None) -> bool:
    if birthday is None:
        return False
    today = today or date.today()
    return (birthday.month, birthday.day) == (today.month, today.day)


def days_until_birthday(birthday: date | None, today: date | None = None) -> int | None:
    nb = next_birthday(birthday, today)
    if nb is None:
        return None
    today = today or date.today()
    delta = (nb - today).days
    return 0 if delta == 0 else delta


def age_turning(birthday: date | None, today: date | None = None) -> int | None:
    """今年过的是第几个生日（按出生年算年龄）。生日只填月日时返回 None。"""
    if birthday is None or birthday.year <= 1900:
        return None
    today = today or date.today()
    nb = next_birthday(birthday, today)
    if nb is None:
        return None
    return nb.year - birthday.year


def days_together(since: date | None, today: date | None = None) -> int | None:
    if since is None:
        return None
    today = today or date.today()
    return (today - since).days


# --------------------------------------------------------------------------
# 蛋糕
# --------------------------------------------------------------------------

_CANDLE_SPARK = ["*", "+", "✦", "·"]


def cake(name: str = "", birthday: date | None = None, width: int | None = None) -> str:
    """画一个终端蛋糕。装饰由生日种子决定。"""
    theme = theme_from_birthday(birthday.isoformat() if birthday else None)
    seed = theme.seed

    # 蜡烛数量 3-6 根，由种子决定
    candles = 3 + seed % 4
    flame = _CANDLE_SPARK[seed % len(_CANDLE_SPARK)]

    top_candle = "  ".join(ui.c(flame, "brightyellow", "bold") for _ in range(candles))
    stick = "  ".join(ui.c("│", "pink") for _ in range(candles))
    frosting = ui.c("≈" * (candles * 3 + 2), theme.accent)
    layer1 = ui.c("█" * (candles * 3 + 2), theme.primary)
    cream = ui.c("~" * (candles * 3 + 2), theme.extra)
    layer2 = ui.c("█" * (candles * 3 + 4), theme.primary)
    plate = ui.c("▔" * (candles * 3 + 6), "grey")

    lines = [
        "",
        "      " + top_candle,
        "      " + stick,
        "     " + frosting,
        "     " + layer1,
        "     " + cream,
        "    " + layer2,
        "   " + plate,
    ]
    return "\n".join(lines)


def banner(name: str, birthday: date | None, today: date | None = None) -> str:
    """生日当天的横幅。"""
    theme = theme_from_birthday(birthday.isoformat() if birthday else None)
    today = today or date.today()
    who = name or "你"

    inner = 44
    pieces = [
        ui.c("HAPPY BIRTHDAY", theme.primary, "bold"),
        "",
        ui.c(f"{who}，生日快乐", theme.accent, "bold"),
    ]
    age = age_turning(birthday, today)
    if age:
        pieces.append(ui.c(f"第 {age} 个生日", "gold"))

    lines = []
    for p in pieces:
        if not p:
            lines.append("")
        else:
            visible = ui._strip_ansi(p)
            left = max(0, (inner - ui.dwidth(visible)) // 2)
            lines.append(" " * left + p)

    out = [cake(name, birthday)]
    out.append(ui.box("🎂", lines, width=inner + 6, style=theme.primary))
    return "\n".join(out)


# --------------------------------------------------------------------------
# 文案
# --------------------------------------------------------------------------

_BIRTHDAY_WISHES = [
    "愿你写的每一行代码都一次跑通，编译时间永远为零。",
    "愿你遇到的 bug 都带完整的 stack trace，愿你提的 PR 都一次过 review。",
    "愿你的 O(n²) 都被优化成 O(n log n)，愿你的努力都被看见。",
    "愿你的面试全是做过原题，愿你的 offer 全是心之所向。",
    "愿你以后每一个 deadline 都提前一天完成，剩下的时间用来睡觉。",
    "愿你的世界永远不抛异常，实在抛了也有人替你 catch。",
    "愿你被温柔对待的程度，超过你对该算法时间复杂度的期待。",
    "愿你的生活没有内存泄漏，快乐不会被 GC 回收。",
]

_DAILY_QUOTES = [
    "今天不用刷很多题，刷懂一道就够。",
    "想不出来不是笨，是还没到第三次。",
    "能讲清楚的题才算真的会，讲给空气听一遍。",
    "面试考的不是智商，是你在压力下还剩下的熟练度。",
    "把不会的题记下来，比多刷十道新题有用。",
    "慢一点没关系，别停在原地。",
    "今天状态不好就只做一道，连续比强度重要。",
    "你上一次觉得难得想哭的题，现在是不是很简单了。",
    "算法题和人生一样：先想边界条件。",
    "写不出来的时候，先写暴力解，再优化。",
    "把目标拆成今天能做完的粒度，才叫计划。",
    "你不是记不住，你只是还没复习到那一天。",
]

_MISS_YOU_LINES = [
    "今天也要好好吃饭。",
    "记得起来走两步，别一直坐着。",
    "困了就睡，题是做不完的。",
    "喝水。现在就去。",
    "眼睛累了就看看窗外，别看屏幕。",
]


def _pick(pool: list[str], salt: str) -> str:
    digest = hashlib.sha256(salt.encode("utf-8")).hexdigest()
    return pool[int(digest[:8], 16) % len(pool)]


def birthday_wish(birthday: date | None, salt: str = "") -> str:
    key = (birthday.isoformat() if birthday else "none") + salt
    return _pick(_BIRTHDAY_WISHES, key)


def daily_quote(today: date | None = None) -> str:
    today = today or date.today()
    return _pick(_DAILY_QUOTES, today.isoformat())


def daily_care(today: date | None = None) -> str:
    today = today or date.today()
    return _pick(_MISS_YOU_LINES, "care" + today.isoformat())


def greeting(name: str, hour: int | None = None) -> str:
    """按时间打招呼。"""
    if hour is None:
        hour = datetime.now().hour
    who = name or "同学"
    if 5 <= hour < 11:
        return f"早上好，{who}"
    if 11 <= hour < 14:
        return f"中午好，{who}"
    if 14 <= hour < 18:
        return f"下午好，{who}"
    if 18 <= hour < 23:
        return f"晚上好，{who}"
    return f"这么晚还在，{who}"


def countdown_line(name: str, birthday: date | None, today: date | None = None) -> str:
    """首页那行「距离生日」或「生日当天」。"""
    today = today or date.today()
    who = name or "你"
    if birthday is None:
        return ""
    if is_birthday(birthday, today):
        return ui.c(f"🎂 今天是 {who} 的生日", "gold", "bold")
    left = days_until_birthday(birthday, today)
    if left is None:
        return ""
    if left <= 30:
        return ui.c(f"🎂 距离 {who} 的生日还有 {left} 天", "gold")
    return ui.c(f"🎂 距离 {who} 的生日还有 {left} 天", "grey")
