"""本地资料：登记、搜索、预览。

## 能搜到什么程度（如实说）

    .md .txt .py .c .cpp .h .java .js .ts .json .csv .html   读正文 → **能按内容搜**
    .pdf .doc .docx .ppt .pptx .xls .xlsx .zip .png .jpg …   只按**文件名/备注/类型**搜

PDF/Word 的正文要专门的解析库（pypdf / python-docx），而这个程序的运行时
是 stdlib-only（打包出来 24 MB 就靠这个）。**不假装能解析** ——
搜不到就说搜不到，比"搜了但结果莫名其妙"好。
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

# 能读正文的扩展名
TEXT_EXT = {".md", ".markdown", ".txt", ".py", ".c", ".cpp", ".h", ".hpp",
            ".java", ".js", ".ts", ".vue", ".json", ".csv", ".html", ".css",
            ".sql", ".sh", ".bat", ".yml", ".yaml", ".ini", ".toml"}
PREVIEW_CHARS = 4000          # 正文只留前 4000 字（够搜索和预览）

KIND_LABEL = {
    ".pdf": "PDF", ".doc": "Word", ".docx": "Word", ".ppt": "PPT",
    ".pptx": "PPT", ".xls": "表格", ".xlsx": "表格",
    ".png": "图片", ".jpg": "图片", ".jpeg": "图片", ".gif": "图片", ".webp": "图片",
    ".zip": "压缩包", ".rar": "压缩包", ".7z": "压缩包",
    ".mp4": "视频", ".mkv": "视频", ".mp3": "音频", ".m4a": "音频",
}


def kind_of(path: Path) -> str:
    if path.is_dir():
        return "文件夹"
    ext = path.suffix.lower()
    if ext in TEXT_EXT:
        return "文本"
    return KIND_LABEL.get(ext, ext.lstrip(".").upper() or "文件")


def read_preview(path: Path) -> str:
    """文本类读一段正文（给搜索和预览用）。读不了就返回空。"""
    if path.suffix.lower() not in TEXT_EXT or not path.is_file():
        return ""
    try:
        if path.stat().st_size > 4 * 1024 * 1024:      # 超过 4MB 不读
            return ""
        return path.read_text(encoding="utf-8", errors="replace")[:PREVIEW_CHARS]
    except OSError:
        return ""


def describe(raw: str) -> dict:
    """把用户粘的路径变成一条可入库的记录。"""
    p = Path(str(raw).strip().strip('"')).expanduser()
    if not p.is_absolute():
        return {"ok": False, "error": "请写完整路径（比如 D:\\课件\\网络.pdf）"}
    if not p.exists():
        return {"ok": False, "error": f"找不到这个路径：{p}"}
    try:
        st = p.stat()
    except OSError as exc:
        return {"ok": False, "error": f"读不了：{exc.__class__.__name__}"}
    size = 0
    if p.is_file():
        size = int(st.st_size)
    else:
        try:
            size = sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
        except OSError:
            size = 0
    return {"ok": True, "title": p.name, "path": str(p),
            "kind": kind_of(p), "is_dir": p.is_dir(),
            "size": size, "mb": round(size / 1024 / 1024, 2),
            "preview": read_preview(p)}


def _selftest() -> None:
    import tempfile

    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as td:
        d = Path(td)
        (d / "notes.md").write_text("# 网络\nTCP 三次握手", encoding="utf-8")
        (d / "paper.pdf").write_bytes(b"%PDF-1.4 fake")
        (d / "sub").mkdir()

        got = describe(str(d / "notes.md"))
        assert got["ok"] and got["kind"] == "文本", got
        assert "三次握手" in got["preview"], "文本应该读到正文"
        got2 = describe(str(d / "paper.pdf"))
        assert got2["ok"] and got2["kind"] == "PDF", got2
        assert got2["preview"] == "", "PDF 不该假装能读正文"
        got3 = describe(str(d / "sub"))
        assert got3["ok"] and got3["kind"] == "文件夹", got3
        assert not describe("相对路径.html")["ok"], "相对路径要拒"
        assert not describe(str(d / "nope.txt"))["ok"], "不存在的要拒"
        print("materials selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
