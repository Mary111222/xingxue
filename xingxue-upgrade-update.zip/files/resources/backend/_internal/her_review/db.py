"""数据层：SQLite 存储 + 定时复习队列。

设计取舍：
- 用 SQLite 而不是 JSON：她要长期用，几千条记录、按到期时间查询都要快
- 带 schema 版本号（PRAGMA user_version）：以后我改表结构，她的数据不会丢
- 所有日期以 ISO 字符串存，本地时区按自然日算
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

from . import sm2

# v4：加了 site_favorites / site_visits（资源收藏 + 打开记录）
SCHEMA_VERSION = 15

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS problems (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    title        TEXT NOT NULL,
    source       TEXT NOT NULL DEFAULT 'leetcode',
    difficulty   TEXT NOT NULL DEFAULT 'medium',
    tags         TEXT NOT NULL DEFAULT '',
    url          TEXT NOT NULL DEFAULT '',
    note         TEXT NOT NULL DEFAULT '',   -- 关键思路 / 当时的坑
    memory       TEXT NOT NULL DEFAULT '',   -- 关于这道题的私人记忆
    repetitions  INTEGER NOT NULL DEFAULT 0,
    interval     INTEGER NOT NULL DEFAULT 0,
    ef           REAL    NOT NULL DEFAULT 2.5,
    due          TEXT    NOT NULL,
    lapses       INTEGER NOT NULL DEFAULT 0,  -- 忘了几次
    review_count INTEGER NOT NULL DEFAULT 0,
    archived     INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reviews (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    problem_id INTEGER NOT NULL REFERENCES problems(id) ON DELETE CASCADE,
    quality    INTEGER NOT NULL,
    seconds    INTEGER NOT NULL DEFAULT 0,
    ef_before  REAL,
    ef_after   REAL,
    interval_after INTEGER,
    reviewed_on TEXT NOT NULL,   -- YYYY-MM-DD，用于连续打卡统计
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_problems_due ON problems(archived, due);
CREATE INDEX IF NOT EXISTS idx_reviews_day ON reviews(reviewed_on);
CREATE INDEX IF NOT EXISTS idx_reviews_problem ON reviews(problem_id);

-- 便签卡片：贴在首页的短句、想法、待办
CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    body       TEXT NOT NULL,
    color      TEXT NOT NULL DEFAULT 'pink',
    pinned     INTEGER NOT NULL DEFAULT 0,
    archived   INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- 倒数日：考试、比赛、纪念日、生日
CREATE TABLE IF NOT EXISTS countdowns (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT NOT NULL,
    target     TEXT NOT NULL,               -- YYYY-MM-DD
    kind       TEXT NOT NULL DEFAULT 'event', -- event/exam/anniversary/birthday
    note       TEXT NOT NULL DEFAULT '',
    yearly     INTEGER NOT NULL DEFAULT 0,  -- 每年重复（纪念日）
    archived   INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

-- 特别提醒：每日 / 每周 / 指定日期 / 到点一次
CREATE TABLE IF NOT EXISTS reminders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    body       TEXT NOT NULL,
    pattern    TEXT NOT NULL DEFAULT 'daily', -- daily/weekly/date/once
    weekday    INTEGER NOT NULL DEFAULT 1,    -- weekly 用：1=周一 … 7=周日
    date       TEXT NOT NULL DEFAULT '',      -- date/once 用
    at_time    TEXT NOT NULL DEFAULT '',      -- HH:MM，留空=全天
    priority   TEXT NOT NULL DEFAULT 'normal',-- normal/important
    enabled    INTEGER NOT NULL DEFAULT 1,
    last_fired TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_notes_active ON notes(archived, pinned);
CREATE INDEX IF NOT EXISTS idx_countdowns_target ON countdowns(archived, target);
CREATE INDEX IF NOT EXISTS idx_reminders_enabled ON reminders(enabled, pattern);

-- 失败台账：把"静默降级"变成可查、可重试（借鉴"失败安全"原则）
CREATE TABLE IF NOT EXISTS failures (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kind       TEXT NOT NULL DEFAULT 'other',   -- search/summarize/plugin/import...
    summary    TEXT NOT NULL,                   -- 一句话说清是什么失败了
    detail     TEXT NOT NULL DEFAULT '',        -- 细节（可多行）
    retry      TEXT NOT NULL DEFAULT '',        -- 可以直接敲的重试命令
    attempts   INTEGER NOT NULL DEFAULT 1,
    state      TEXT NOT NULL DEFAULT 'open',    -- open/resolved
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_failures_state ON failures(state, updated_at);

-- 视频总结的质量记录：AI 出来的东西不该假装完整
CREATE TABLE IF NOT EXISTS quality_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id    TEXT NOT NULL DEFAULT '',
    title      TEXT NOT NULL DEFAULT '',
    problem_id INTEGER,
    payload    TEXT NOT NULL DEFAULT '',        -- QualityReport 的 JSON
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_quality_created ON quality_log(created_at);
CREATE INDEX IF NOT EXISTS idx_quality_problem ON quality_log(problem_id);
-- 资源收藏。site_key 是 learning.py 里 Site 的 key：
-- 用 key 不用 URL，因为 URL 会变（换域名、换搜索模板），
-- 而"我喜欢这个站"是跟着站走的。
CREATE TABLE IF NOT EXISTS site_favorites (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    site_key   TEXT NOT NULL UNIQUE,
    title      TEXT NOT NULL DEFAULT '',   -- 存个快照：站点从清单里删了也还能显示
    url        TEXT NOT NULL DEFAULT '',
    category   TEXT NOT NULL DEFAULT '',
    note       TEXT NOT NULL DEFAULT '',   -- 她可以写一句"为什么收藏这个"
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

-- 打开记录。像浏览器的历史，但**有上限**：
-- 只是"我最近去过哪"，留几百条足够。
-- 不设上限的话用一年会攒几万行，查询变慢、她也翻不动。
-- 歌单。她收藏的歌（本地），跟着数据目录走。
--
-- **不存播放直链**：网易云的直链只有 25 分钟有效期（见 music.py），
-- 存下来就是"下次点开播不了"。这里只存"这是哪首歌"，
-- 播放时重新取链——和打开记录/资源收藏一个道理。
CREATE TABLE IF NOT EXISTS music_tracks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    song_id    INTEGER NOT NULL UNIQUE,   -- 同一首不重复收
    name       TEXT NOT NULL DEFAULT '',
    artists    TEXT NOT NULL DEFAULT '',
    album      TEXT NOT NULL DEFAULT '',
    duration   INTEGER NOT NULL DEFAULT 0,   -- 秒
    cover      TEXT NOT NULL DEFAULT '',
    quality    TEXT NOT NULL DEFAULT '',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS site_visits (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    site_key   TEXT NOT NULL,
    title      TEXT NOT NULL DEFAULT '',
    url        TEXT NOT NULL DEFAULT '',
    source     TEXT NOT NULL DEFAULT 'sites',  -- sites / search / review / manual
    visited_at TEXT NOT NULL
);;
-- 专注记录（番茄钟）。一次"开始→结束"写一行。
--
-- 存的是"什么时候、专注了多久"，**不存她在干什么**——
-- 统计要的是"这周专注了几小时"，不需要知道内容（内容在便签/题里）。
CREATE TABLE IF NOT EXISTS focus_sessions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at TEXT NOT NULL,               -- ISO 时间
    minutes    INTEGER NOT NULL DEFAULT 0,
    note       TEXT NOT NULL DEFAULT '',    -- 可留空
    created_at TEXT NOT NULL
);


-- 六级词表 + 词卡的 SM-2 状态。
--
-- 字段和 problems 表**同名同义**（repetitions / interval / ef / due / lapses），
-- 因为调度用的是**同一个 sm2 模块** —— 名字不一样迟早写错。
-- 六级模考记录。分数是**她自己填的**（程序不猜），
-- 但"什么时候考的、考了多少、距目标还差多少"这三点放一起才看得出趋势。
-- 本地资料库：她自己的讲义/课件/PDF。
-- preview 只对**文本类**有内容（PDF/Word 解析不了，如实留空）。
-- B 站待看清单：搜到/总结过的视频放这儿，看完打勾。
-- 只存"哪条视频、什么时候加的、看没看"，不存播放地址
-- （B 站地址会变，和歌单一个道理）。
CREATE TABLE IF NOT EXISTS watch_list (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    title    TEXT NOT NULL,
    url      TEXT NOT NULL DEFAULT '',
    bvid     TEXT NOT NULL DEFAULT '',
    author   TEXT NOT NULL DEFAULT '',
    note     TEXT NOT NULL DEFAULT '',
    done     INTEGER NOT NULL DEFAULT 0,
    added_at TEXT NOT NULL
);


-- 阅读 / 作文 / 翻译的练习材料（听力有自己的表，不动它）。
-- module 区分三个模块；存的还是「标题 + B 站链接」，不复制视频。
-- 题目附件（贴图）。**图片本身存文件**，这里只记路径（数据库别塞二进制）。
-- 资料 ↔ 题目 互链。
-- from/to 用 (kind, id) 表示，kind 先支持 problem / material；
-- 以后要连别的（听力条目、练习题）加个 kind 就行，不用改表。
-- **一条记录就是双向的** —— 不建两份，免得删了一边还剩一边。
CREATE TABLE IF NOT EXISTS links (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    from_kind  TEXT NOT NULL,
    from_id    INTEGER NOT NULL,
    to_kind    TEXT NOT NULL,
    to_id      INTEGER NOT NULL,
    note       TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_link_from ON links(from_kind, from_id);
CREATE INDEX IF NOT EXISTS idx_link_to   ON links(to_kind, to_id);


CREATE TABLE IF NOT EXISTS attachments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    problem_id INTEGER NOT NULL,
    name       TEXT NOT NULL DEFAULT '',
    path       TEXT NOT NULL,
    size       INTEGER NOT NULL DEFAULT 0,
    added_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_attach_problem ON attachments(problem_id);


CREATE TABLE IF NOT EXISTS practices (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    module   TEXT NOT NULL DEFAULT 'reading',   -- reading / writing / translation
    title    TEXT NOT NULL,
    url      TEXT NOT NULL DEFAULT '',
    note     TEXT NOT NULL DEFAULT '',
    done     INTEGER NOT NULL DEFAULT 0,
    added_at TEXT NOT NULL
);


-- 听力练习条目：精听/真题/磨耳朵都用这一张表。
-- **只存路径，不复制音频**（音频可能几百 MB，复制没意义）。
CREATE TABLE IF NOT EXISTS listening (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kind       TEXT NOT NULL DEFAULT 'intensive',   -- real / intensive / loop
    title      TEXT NOT NULL,
    path       TEXT NOT NULL DEFAULT '',
    paper_key  TEXT NOT NULL DEFAULT '',            -- 真题用：2024-12
    transcript TEXT NOT NULL DEFAULT '',            -- 原文/逐句（前端用）
    note       TEXT NOT NULL DEFAULT '',
    replays    INTEGER NOT NULL DEFAULT 0,          -- 听过几遍
    done       INTEGER NOT NULL DEFAULT 0,          -- 精听完成打勾
    added_at   TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS materials (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT NOT NULL,
    path       TEXT NOT NULL UNIQUE,
    kind       TEXT NOT NULL DEFAULT '',
    size       INTEGER NOT NULL DEFAULT 0,
    tag        TEXT NOT NULL DEFAULT '',
    note       TEXT NOT NULL DEFAULT '',
    preview    TEXT NOT NULL DEFAULT '',
    added_at   TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS mock_exams (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    taken_on     TEXT NOT NULL,              -- YYYY-MM-DD
    total        INTEGER NOT NULL DEFAULT 0, -- 总分（满分 710）
    listening    INTEGER NOT NULL DEFAULT 0,
    reading      INTEGER NOT NULL DEFAULT 0,
    writing      INTEGER NOT NULL DEFAULT 0, -- 写作+翻译
    minutes      INTEGER NOT NULL DEFAULT 0, -- 实际用时
    note         TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS words (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    word         TEXT NOT NULL UNIQUE,
    meaning      TEXT NOT NULL DEFAULT '',
    note         TEXT NOT NULL DEFAULT '',
    repetitions  INTEGER NOT NULL DEFAULT 0,
    interval     INTEGER NOT NULL DEFAULT 0,
    ef           REAL NOT NULL DEFAULT 2.5,
    due          TEXT NOT NULL DEFAULT '',
    lapses       INTEGER NOT NULL DEFAULT 0,
    review_count INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL
);


-- 错题本：评分低的时候记一句"错在哪"。
-- 复习同一道题时先给她看 —— SM-2 只记"忘了"，不记"为什么忘"。
CREATE TABLE IF NOT EXISTS mistakes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    problem_id INTEGER NOT NULL,
    reason     TEXT NOT NULL DEFAULT '',
    kind       TEXT NOT NULL DEFAULT '',   -- 快捷标签：思路/细节/概念/时间/跳过
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mistakes_problem ON mistakes(problem_id);

-- 提醒"今天已经确认过"的记录。
-- 没有它的话，到点的提醒每次轮询都会再弹一遍（她会被烦到关掉功能）。
CREATE TABLE IF NOT EXISTS reminder_hits (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    reminder_id INTEGER NOT NULL,
    day         TEXT NOT NULL,             -- YYYY-MM-DD
    action      TEXT NOT NULL DEFAULT 'ack',
    created_at  TEXT NOT NULL,
    UNIQUE(reminder_id, day)
);

-- 目标："12月六级 500 分""这学期刷完 200 题"。
-- 进度两种算法：problems = 已复习过的题数；manual = 她自己填的进度。
CREATE TABLE IF NOT EXISTS goals (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    kind        TEXT NOT NULL DEFAULT 'problems',
    target_num  INTEGER NOT NULL DEFAULT 0,
    progress    INTEGER NOT NULL DEFAULT 0,   -- manual 用
    target_date TEXT NOT NULL DEFAULT '',
    done        INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_site_visits_time
    ON site_visits(visited_at DESC);
CREATE INDEX IF NOT EXISTS idx_site_visits_key
    ON site_visits(site_key);

"""

DIFFICULTIES = ("easy", "medium", "hard")

# 中国的算法题平台，默认 leetcode，但都支持
SOURCES = ("leetcode", "luogu", "nowcoder", "acwing", "codeforces", "atcoder", "other")


# --------------------------------------------------------------------------
# 数据结构
# --------------------------------------------------------------------------

@dataclass
class Problem:
    id: int
    title: str
    source: str = "leetcode"
    difficulty: str = "medium"
    tags: list[str] = field(default_factory=list)
    url: str = ""
    note: str = ""
    memory: str = ""
    repetitions: int = 0
    interval: int = 0
    ef: float = sm2.EF_DEFAULT
    due: date = field(default_factory=date.today)
    lapses: int = 0
    review_count: int = 0
    archived: bool = False
    created_at: str = ""

    # ---------------- 展示用 ----------------

    @property
    def maturity(self) -> str:
        return sm2.maturity(self.repetitions, self.interval)

    @property
    def difficulty_label(self) -> str:
        return {"easy": "简单", "medium": "中等", "hard": "困难"}.get(self.difficulty, self.difficulty)

    @property
    def difficulty_color(self) -> str:
        return {"easy": "brightgreen", "medium": "gold", "hard": "red"}.get(self.difficulty, "white")

    @property
    def source_label(self) -> str:
        return {
            "leetcode": "LeetCode",
            "luogu": "洛谷",
            "nowcoder": "牛客",
            "acwing": "AcWing",
            "codeforces": "Codeforces",
            "atcoder": "AtCoder",
            "other": "其他",
        }.get(self.source, self.source)

    def days_overdue(self, today: date | None = None) -> int:
        today = today or date.today()
        return (today - self.due).days

    def is_due(self, today: date | None = None) -> bool:
        today = today or date.today()
        return self.due <= today

    def tags_text(self) -> str:
        return " ".join(self.tags)

    def state(self) -> sm2.SM2State:
        return sm2.SM2State(self.repetitions, self.interval, self.ef)

    def short(self, limit: int = 34) -> str:
        return self.title if len(self.title) <= limit else self.title[: limit - 1] + "…"


def _row_to_problem(row: sqlite3.Row) -> Problem:
    return Problem(
        id=row["id"],
        title=row["title"],
        source=row["source"],
        difficulty=row["difficulty"],
        tags=[t for t in (row["tags"] or "").split() if t],
        url=row["url"],
        note=row["note"],
        memory=row["memory"],
        repetitions=row["repetitions"],
        interval=row["interval"],
        ef=row["ef"],
        due=date.fromisoformat(row["due"]),
        lapses=row["lapses"],
        review_count=row["review_count"],
        archived=bool(row["archived"]),
        created_at=row["created_at"],
    )


# --------------------------------------------------------------------------
# 仓库
# --------------------------------------------------------------------------

class Store:
    def __init__(self, path: Path | str):
        raw = str(path)
        self.in_memory = raw == ":memory:" or raw.startswith("file::memory:")
        self.path = Path(raw) if not self.in_memory else Path(":memory:")
        if not self.in_memory:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(raw if self.in_memory else str(self.path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        if not self.in_memory:
            self.conn.execute("PRAGMA journal_mode = WAL")
        self._migrate()

    # ---------------- 生命周期 ----------------

    def _migrate(self) -> None:
        """版本化迁移。

        注意：v1 时期建的库（只有 problems/reviews）不能重跑 SCHEMA_SQL 了事——
        CREATE TABLE IF NOT EXISTS 是幂等的，但要保证「老库也能补上新表」。
        所以统一用 executescript（全部 IF NOT EXISTS）补齐，再按版本号记进度。
        """
        current = self.conn.execute("PRAGMA user_version").fetchone()[0]
        if current < SCHEMA_VERSION:
            self.conn.executescript(SCHEMA_SQL)
            self.conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
            if current == 0:
                self.set_meta("created_at", datetime.now().isoformat(timespec="seconds"))
            self.set_meta("schema_version", str(SCHEMA_VERSION))
        self.conn.commit()

    # ---------------- 资源收藏 / 打开记录 ----------------
    #
    # 这两块是"像浏览器那样"的功能：收藏常去的站、记下打开过什么。
    # 设计上刻意做得比浏览器克制：
    #   · 打开记录有上限（见 record_visit），不做无限历史
    #   · 收藏可以写一句备注，比单纯的"书签"多点用处

    MAX_VISITS = 400          # 打开记录最多留这么多条
    VISITS_PER_SITE = 60      # 同一个站最多留这么多条（防止刷屏）

    def favorites(self) -> list[sqlite3.Row]:
        """收藏列表。按手动排序 + 收藏时间倒序。"""
        return list(self.conn.execute(
            "SELECT * FROM site_favorites "
            "ORDER BY sort_order ASC, id DESC"))

    def favorite_keys(self) -> set[str]:
        """只要 key 的集合——渲染资源页时用来标"已收藏"。"""
        return {str(r["site_key"]) for r in
                self.conn.execute("SELECT site_key FROM site_favorites")}

    def is_favorite(self, site_key: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM site_favorites WHERE site_key = ?",
            (site_key,)).fetchone()
        return row is not None

    def add_favorite(self, site_key: str, title: str = "", url: str = "",
                     category: str = "", note: str = "") -> bool:
        """加收藏。已经收藏过就返回 False（不报错——重复点不该崩）。"""
        key = (site_key or "").strip()
        if not key:
            raise ValueError("缺少站点标识")
        if self.is_favorite(key):
            return False
        now = datetime.now().isoformat(timespec="seconds")
        self.conn.execute(
            "INSERT INTO site_favorites"
            "(site_key, title, url, category, note, created_at) "
            "VALUES(?,?,?,?,?,?)",
            (key, title or "", url or "", category or "", note or "", now))
        self.conn.commit()
        return True

    def remove_favorite(self, site_key: str) -> bool:
        cur = self.conn.execute(
            "DELETE FROM site_favorites WHERE site_key = ?", (site_key,))
        self.conn.commit()
        return cur.rowcount > 0

    def toggle_favorite(self, site_key: str, title: str = "", url: str = "",
                        category: str = "") -> bool:
        """切换收藏状态。返回切换**之后**是不是已收藏。"""
        if self.is_favorite(site_key):
            self.remove_favorite(site_key)
            return False
        self.add_favorite(site_key, title, url, category)
        return True

    def set_favorite_note(self, site_key: str, note: str) -> bool:
        cur = self.conn.execute(
            "UPDATE site_favorites SET note = ? WHERE site_key = ?",
            (note or "", site_key))
        self.conn.commit()
        return cur.rowcount > 0

    def move_favorite(self, site_key: str, delta: int) -> bool:
        """把收藏往上/往下挪一位。delta 是 -1 或 +1。

        用"和邻居交换 sort_order"而不是重排整张表：
        改动小、也不会因为并发把顺序搞乱。
        没排过序的（sort_order 都是 0）先按当前展示顺序铺一遍。
        """
        rows = self.favorites()
        keys = [str(r["site_key"]) for r in rows]
        if site_key not in keys:
            return False
        # 第一次排序时，sort_order 可能全是 0——先铺成 0,1,2,...
        if len({int(r["sort_order"]) for r in rows}) < len(rows):
            for i, r in enumerate(rows):
                self.conn.execute(
                    "UPDATE site_favorites SET sort_order = ? WHERE id = ?",
                    (i, r["id"]))
            self.conn.commit()
            rows = self.favorites()
            keys = [str(r["site_key"]) for r in rows]
        idx = keys.index(site_key)
        target = idx + (-1 if delta < 0 else 1)
        if target < 0 or target >= len(rows):
            return False       # 已经在头/尾，不动
        a, b = rows[idx], rows[target]
        self.conn.execute("UPDATE site_favorites SET sort_order = ? WHERE id = ?",
                          (int(b["sort_order"]), a["id"]))
        self.conn.execute("UPDATE site_favorites SET sort_order = ? WHERE id = ?",
                          (int(a["sort_order"]), b["id"]))
        self.conn.commit()
        return True

    def record_visit(self, site_key: str, title: str = "", url: str = "",
                     source: str = "sites", at: str | None = None) -> None:
        """记一次打开。

        两层上限，都是为了"记录别失控"：
            VISITS_PER_SITE  同一个站最多留 60 条
                （不然反复点一个站会把整段历史刷满，看不到别的）
            MAX_VISITS       总共最多留 400 条
        """
        key = (site_key or "").strip()
        if not key:
            return
        when = at or datetime.now().isoformat(timespec="seconds")
        self.conn.execute(
            "INSERT INTO site_visits(site_key, title, url, source, visited_at) "
            "VALUES(?,?,?,?,?)",
            (key, title or "", url or "", source or "sites", when))
        # 单个站超限：删它自己最旧的
        self.conn.execute(
            "DELETE FROM site_visits WHERE site_key = ? AND id NOT IN "
            "(SELECT id FROM site_visits WHERE site_key = ? "
            " ORDER BY id DESC LIMIT ?)",
            (key, key, self.VISITS_PER_SITE))
        # 总量超限：删全局最旧的
        self.conn.execute(
            "DELETE FROM site_visits WHERE id NOT IN "
            "(SELECT id FROM site_visits ORDER BY id DESC LIMIT ?)",
            (self.MAX_VISITS,))
        self.conn.commit()

    def visits(self, limit: int = 120) -> list[sqlite3.Row]:
        """最近的打开记录，按时间倒序。"""
        return list(self.conn.execute(
            "SELECT * FROM site_visits ORDER BY id DESC LIMIT ?",
            (max(1, int(limit)),)))

    def clear_visits(self) -> int:
        """清空打开记录。返回删了多少条。"""
        n = self.conn.execute("SELECT COUNT(*) FROM site_visits").fetchone()[0]
        self.conn.execute("DELETE FROM site_visits")
        self.conn.commit()
        return int(n)

    def visit_stats(self) -> list[sqlite3.Row]:
        """按站点统计：去过几次、最后一次什么时候。

        为什么单独做这个而不是让界面自己数：
        记录有上限，界面拿到的只是最近 120 条，
        自己数出来的"次数"是错的（会被截断）。
        这里对着全表数，才是真实次数。
        """
        return list(self.conn.execute(
            "SELECT site_key, title, url, COUNT(*) AS visits, "
            "       MAX(visited_at) AS last_at "
            "FROM site_visits GROUP BY site_key "
            "ORDER BY visits DESC, last_at DESC"))


    # ---------------- 歌单 ----------------
    #
    # 和资源收藏一样：手动排序 + 时间倒序；重复收藏不报错、只返回"已收藏"。

    def music_playlist(self) -> list[sqlite3.Row]:
        """歌单。手动排序优先，其次按收藏时间倒序。"""
        return list(self.conn.execute(
            "SELECT * FROM music_tracks ORDER BY sort_order ASC, id DESC"))

    def music_has(self, song_id) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM music_tracks WHERE song_id = ?", (int(song_id),)
        ).fetchone()
        return row is not None

    def music_add(self, song_id, name: str = "", artists: str = "",
                  album: str = "", duration=0, cover: str = "",
                  quality: str = "") -> bool:
        """收进歌单。已经收过就返回 False（重复点不该报错）。"""
        try:
            sid = int(song_id)
        except (TypeError, ValueError):
            raise ValueError("缺少歌曲 id")
        if sid <= 0:
            raise ValueError("歌曲 id 不对")
        if self.music_has(sid):
            return False
        try:
            dur = int(duration or 0)
        except (TypeError, ValueError):
            dur = 0
        now = datetime.now().isoformat(timespec="seconds")
        self.conn.execute(
            "INSERT INTO music_tracks"
            "(song_id, name, artists, album, duration, cover, quality, created_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (sid, name or "", artists or "", album or "", dur,
             cover or "", quality or "", now))
        self.conn.commit()
        return True

    def music_remove(self, song_id) -> bool:
        cur = self.conn.execute(
            "DELETE FROM music_tracks WHERE song_id = ?", (int(song_id),))
        self.conn.commit()
        return cur.rowcount > 0

    def music_clear(self) -> int:
        cur = self.conn.execute("DELETE FROM music_tracks")
        self.conn.commit()
        return cur.rowcount

    def music_move(self, song_id, delta: int) -> bool:
        """往上/下挪一位。做法和资源收藏一致：和邻居交换 sort_order。"""
        try:
            sid = int(song_id)
        except (TypeError, ValueError):
            return False
        rows = self.music_playlist()
        ids = [int(r["song_id"]) for r in rows]
        if sid not in ids:
            return False
        # 没排过序时先铺一遍 0,1,2,...
        if len({int(r["sort_order"]) for r in rows}) < len(rows):
            for i, r in enumerate(rows):
                self.conn.execute(
                    "UPDATE music_tracks SET sort_order = ? WHERE id = ?",
                    (i, r["id"]))
            self.conn.commit()
            rows = self.music_playlist()
            ids = [int(r["song_id"]) for r in rows]
        idx = ids.index(sid)
        target = idx + (-1 if delta < 0 else 1)
        if target < 0 or target >= len(rows):
            return False
        a, b = rows[idx], rows[target]
        self.conn.execute("UPDATE music_tracks SET sort_order = ? WHERE id = ?",
                          (int(b["sort_order"]), a["id"]))
        self.conn.execute("UPDATE music_tracks SET sort_order = ? WHERE id = ?",
                          (int(a["sort_order"]), b["id"]))
        self.conn.commit()
        return True

    def close(self) -> None:
        try:
            self.conn.commit()
        finally:
            self.conn.close()

    def __enter__(self) -> "Store":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # ---------------- meta ----------------

    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT INTO meta(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        self.conn.commit()

    def get_meta(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default

    # ---------------- 增删改 ----------------

    def add(
        self,
        title: str,
        source: str = "leetcode",
        difficulty: str = "medium",
        tags: list[str] | None = None,
        url: str = "",
        note: str = "",
        memory: str = "",
        due: date | None = None,
    ) -> int:
        title = (title or "").strip()
        if not title:
            raise ValueError("题目名不能为空")
        now = datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute(
            """INSERT INTO problems
               (title, source, difficulty, tags, url, note, memory,
                repetitions, interval, ef, due, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?, 0, 0, ?, ?, ?, ?)""",
            (
                title,
                source if source in SOURCES else "other",
                difficulty if difficulty in DIFFICULTIES else "medium",
                " ".join(tags or []),
                url,
                note,
                memory,
                sm2.EF_DEFAULT,
                (due or date.today()).isoformat(),
                now,
                now,
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def add_many(self, items: list[dict]) -> int:
        """批量导入，按标题去重（已存在的跳过）。返回新增数量。"""
        allowed = {"title", "source", "difficulty", "tags", "url", "note", "memory", "due"}
        added = 0
        for item in items:
            if self.find_by_title(item.get("title", "")):
                continue
            self.add(**{k: v for k, v in item.items() if k in allowed})
            added += 1
        return added

    def update(self, problem_id: int, **fields) -> bool:
        allowed = {"title", "source", "difficulty", "tags", "url", "note", "memory", "due", "archived"}
        sets, values = [], []
        for key, value in fields.items():
            if key not in allowed or value is None:
                continue
            if key == "tags" and isinstance(value, list):
                value = " ".join(value)
            if key == "due" and isinstance(value, date):
                value = value.isoformat()
            if key == "archived":
                value = 1 if value else 0
            sets.append(f"{key} = ?")
            values.append(value)
        if not sets:
            return False
        sets.append("updated_at = ?")
        values.extend([datetime.now().isoformat(timespec="seconds"), problem_id])
        cur = self.conn.execute(f"UPDATE problems SET {', '.join(sets)} WHERE id = ?", values)
        self.conn.commit()
        return cur.rowcount > 0

    def archive(self, problem_id: int, archived: bool = True) -> bool:
        return self.update(problem_id, archived=archived)

    def delete(self, problem_id: int) -> bool:
        cur = self.conn.execute("DELETE FROM problems WHERE id = ?", (problem_id,))
        self.conn.commit()
        return cur.rowcount > 0

    # ---------------- 查询 ----------------

    def get(self, problem_id: int) -> Problem | None:
        row = self.conn.execute("SELECT * FROM problems WHERE id = ?", (problem_id,)).fetchone()
        return _row_to_problem(row) if row else None

    def find_by_title(self, title: str) -> Problem | None:
        row = self.conn.execute(
            "SELECT * FROM problems WHERE title = ? LIMIT 1", (title.strip(),)
        ).fetchone()
        return _row_to_problem(row) if row else None

    def search(self, keyword: str, include_archived: bool = False) -> list[Problem]:
        """标题 / 标签 / 笔记 / 记忆 模糊搜索。"""
        like = f"%{keyword.strip()}%"
        sql = """SELECT * FROM problems
                 WHERE (title LIKE ? OR tags LIKE ? OR note LIKE ? OR memory LIKE ?)"""
        params: list = [like, like, like, like]
        if not include_archived:
            sql += " AND archived = 0"
        sql += " ORDER BY due ASC, id ASC"
        return [_row_to_problem(r) for r in self.conn.execute(sql, params)]

    def due(self, today: date | None = None, limit: int | None = None) -> list[Problem]:
        """今天到期的题。排序：先逾期的，再按遗忘次数多的优先。"""
        today = today or date.today()
        sql = """SELECT * FROM problems
                 WHERE archived = 0 AND due <= ?
                 ORDER BY due ASC, lapses DESC, id ASC"""
        params: list = [today.isoformat()]
        if limit:
            sql += " LIMIT ?"
            params.append(limit)
        return [_row_to_problem(r) for r in self.conn.execute(sql, params)]

    def upcoming(self, days: int = 30, today: date | None = None) -> list[Problem]:
        today = today or date.today()
        end = today + timedelta(days=days)
        rows = self.conn.execute(
            """SELECT * FROM problems
               WHERE archived = 0 AND due > ? AND due <= ?
               ORDER BY due ASC""",
            (today.isoformat(), end.isoformat()),
        )
        return [_row_to_problem(r) for r in rows]

    def all(self, include_archived: bool = False) -> list[Problem]:
        sql = "SELECT * FROM problems"
        if not include_archived:
            sql += " WHERE archived = 0"
        sql += " ORDER BY id ASC"
        return [_row_to_problem(r) for r in self.conn.execute(sql)]

    def count(self, include_archived: bool = False) -> int:
        sql = "SELECT COUNT(*) AS n FROM problems"
        if not include_archived:
            sql += " WHERE archived = 0"
        return int(self.conn.execute(sql).fetchone()["n"])

    # ---------------- 复习 ----------------

    def submit_review(
        self,
        problem: Problem,
        quality: int,
        seconds: int = 0,
        today: date | None = None,
    ) -> sm2.SM2Result:
        """提交一次复习，写回 SM-2 状态并记账。"""
        today = today or date.today()
        result = sm2.review(problem.state(), quality, today)
        now = datetime.now().isoformat(timespec="seconds")

        self.conn.execute(
            """UPDATE problems
               SET repetitions = ?, interval = ?, ef = ?, due = ?,
                   lapses = lapses + ?, review_count = review_count + 1,
                   updated_at = ?
               WHERE id = ?""",
            (
                result.repetitions,
                result.interval,
                result.ef,
                result.due.isoformat(),
                1 if not result.passed else 0,
                now,
                problem.id,
            ),
        )
        self.conn.execute(
            """INSERT INTO reviews
               (problem_id, quality, seconds, ef_before, ef_after, interval_after,
                reviewed_on, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                problem.id,
                quality,
                max(0, int(seconds)),
                problem.ef,
                result.ef,
                result.interval,
                today.isoformat(),
                now,
            ),
        )
        self.conn.commit()

        # 回写内存里的对象，调用方可以直接展示新状态
        problem.repetitions = result.repetitions
        problem.interval = result.interval
        problem.ef = result.ef
        problem.due = result.due
        problem.review_count += 1
        if not result.passed:
            problem.lapses += 1
        return result

    def review_log(self, limit: int = 50) -> list[sqlite3.Row]:
        return list(
            self.conn.execute(
                """SELECT r.*, p.title FROM reviews r
                   JOIN problems p ON p.id = r.problem_id
                   ORDER BY r.id DESC LIMIT ?""",
                (limit,),
            )
        )

    # ---------------- 统计 ----------------

    def review_days(self) -> list[str]:
        """有复习记录的所有自然日（倒序）。"""
        rows = self.conn.execute(
            "SELECT DISTINCT reviewed_on FROM reviews ORDER BY reviewed_on DESC"
        )
        return [r["reviewed_on"] for r in rows]

    def streak(self, today: date | None = None) -> int:
        """连续打卡天数。今天还没复习时，从昨天开始算（不立刻清零）。"""
        today = today or date.today()
        days = set(self.review_days())
        if not days:
            return 0
        cursor = today
        if today.isoformat() not in days:
            cursor = today - timedelta(days=1)
            if cursor.isoformat() not in days:
                return 0
        count = 0
        while cursor.isoformat() in days:
            count += 1
            cursor -= timedelta(days=1)
        return count

    def longest_streak(self) -> int:
        days = sorted(date.fromisoformat(d) for d in self.review_days())
        if not days:
            return 0
        best = run = 1
        for prev, cur in zip(days, days[1:]):
            run = run + 1 if (cur - prev).days == 1 else 1
            best = max(best, run)
        return best

    def reviews_on(self, day: date) -> int:
        row = self.conn.execute(
            "SELECT COUNT(*) AS n FROM reviews WHERE reviewed_on = ?", (day.isoformat(),)
        ).fetchone()
        return int(row["n"])

    def review_count_total(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) AS n FROM reviews").fetchone()["n"])

    def total_seconds(self) -> int:
        return int(
            self.conn.execute("SELECT COALESCE(SUM(seconds),0) AS n FROM reviews").fetchone()["n"]
        )

    def heatmap(self, weeks: int = 18, today: date | None = None) -> list[list[int]]:
        """回到 GitHub 贡献图的样子：weeks 列 × 7 行的每日复习次数。"""
        today = today or date.today()
        # 从 weeks 周前的周日开始
        start = today - timedelta(days=today.weekday() + 1) - timedelta(days=7 * (weeks - 1))
        rows = self.conn.execute(
            """SELECT reviewed_on, COUNT(*) AS n FROM reviews
               WHERE reviewed_on >= ? GROUP BY reviewed_on""",
            (start.isoformat(),),
        )
        counts = {r["reviewed_on"]: int(r["n"]) for r in rows}
        grid: list[list[int]] = []
        for w in range(weeks):
            column = []
            for d in range(7):
                day = start + timedelta(days=w * 7 + d)
                column.append(counts.get(day.isoformat(), 0))
            grid.append(column)
        return grid

    def tag_stats(self) -> list[tuple[str, int, float, float]]:
        """每个标签：(标签, 题数, 平均熟练度, 平均 EF)。

        熟练度用「能坚持到多久复习」衡量：interval 越大越熟。
        """
        buckets: dict[str, list[Problem]] = {}
        for p in self.all():
            for tag in p.tags or ["未分类"]:
                buckets.setdefault(tag, []).append(p)
        out = []
        for tag, items in buckets.items():
            avg_interval = sum(i.interval for i in items) / len(items)
            avg_ef = sum(i.ef for i in items) / len(items)
            out.append((tag, len(items), avg_interval, avg_ef))
        out.sort(key=lambda x: (-x[1], x[2]))
        return out

    def weakest_tags(self, limit: int = 3) -> list[tuple[str, float]]:
        """最虚的标签：只统计至少 2 题的标签，按平均间隔升序。"""
        stats = [(t, n, iv) for t, n, iv, _ in self.tag_stats() if n >= 2]
        stats.sort(key=lambda x: x[2])
        return [(t, iv) for t, _, iv in stats[:limit]]

    def maturity_counts(self) -> dict[str, int]:
        counts = {"新题": 0, "学习中": 0, "复习中": 0, "已掌握": 0}
        for p in self.all():
            counts[p.maturity] = counts.get(p.maturity, 0) + 1
        return counts

    def hardest(self, limit: int = 5) -> list[Problem]:
        """忘得最多的题。"""
        items = [p for p in self.all() if p.lapses > 0]
        items.sort(key=lambda p: (-p.lapses, -p.review_count))
        return items[:limit]

    def due_forecast(self, days: int = 14, today: date | None = None) -> dict[int, int]:
        """未来 days 天，每天到期多少题。"""
        today = today or date.today()
        buckets: dict[int, int] = {i: 0 for i in range(days + 1)}
        for p in self.all():
            offset = (p.due - today).days
            if offset <= 0:
                buckets[0] += 1
            elif offset <= days:
                buckets[offset] += 1
        return buckets

    def simulate_history(self, days: int = 45, per_day: int = 7, seed: int = 20260601) -> int:
        """造一段历史复习记录，用来预览统计视图 / 演示。

        只写 reviews 和题目状态，不改变题库本身。返回值：写入的记录数。
        """
        import random

        rng = random.Random(seed)
        problems = self.all()
        if not problems:
            return 0

        today = date.today()
        written = 0
        now = datetime.now().isoformat(timespec="seconds")

        for back in range(days, -1, -1):
            day = today - timedelta(days=back)
            # 周末少一点，工作日多一点，让热力图看起来像真人
            target = max(1, int(per_day * (0.4 if day.weekday() >= 5 else 1.0) * rng.uniform(0.5, 1.5)))
            for _ in range(target):
                problem = rng.choice(problems)
                quality = rng.choices([5, 4, 3, 2, 1, 0], weights=[26, 30, 22, 12, 6, 4])[0]
                result = sm2.review(problem.state(), quality, day)

                self.conn.execute(
                    """UPDATE problems
                       SET repetitions = ?, interval = ?, ef = ?, due = ?,
                           lapses = lapses + ?, review_count = review_count + 1,
                           updated_at = ?
                       WHERE id = ?""",
                    (
                        result.repetitions,
                        result.interval,
                        result.ef,
                        result.due.isoformat(),
                        1 if not result.passed else 0,
                        now,
                        problem.id,
                    ),
                )
                self.conn.execute(
                    """INSERT INTO reviews
                       (problem_id, quality, seconds, ef_before, ef_after, interval_after,
                        reviewed_on, created_at)
                       VALUES (?,?,?,?,?,?,?,?)""",
                    (
                        problem.id,
                        quality,
                        rng.randint(90, 1500),
                        problem.ef,
                        result.ef,
                        result.interval,
                        day.isoformat(),
                        f"{day.isoformat()}T21:00:00",
                    ),
                )
                # 同步内存里的对象，循环里下一次抽到它时状态是连续的
                problem.repetitions = result.repetitions
                problem.interval = result.interval
                problem.ef = result.ef
                problem.due = result.due
                problem.review_count += 1
                if not result.passed:
                    problem.lapses += 1
                written += 1
        self.conn.commit()
        return written

    # ---------------- 待看清单 ----------------

    def watch_add(self, title: str, url: str = "", bvid: str = "",
                  author: str = "", note: str = "") -> dict:
        """加入待看。**同一个视频不重复加**（按 url 或 bvid 去重）。"""
        key = str(url or "").strip() or str(bvid or "").strip()
        if key:
            row = self.conn.execute(
                "SELECT id FROM watch_list WHERE url = ? OR (bvid != '' AND bvid = ?)",
                (str(url or ""), str(bvid or ""))).fetchone()
            if row:
                return {"id": int(row["id"]), "duplicated": True}
        cur = self.conn.execute(
            "INSERT INTO watch_list (title, url, bvid, author, note, added_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (str(title)[:200], str(url)[:400], str(bvid)[:40], str(author)[:80],
             str(note)[:200], datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "duplicated": False}

    def watch_list(self, done: int | None = None, limit: int = 200) -> list[dict]:
        sql = "SELECT * FROM watch_list"
        params: list = []
        if done is not None:
            sql += " WHERE done = ?"
            params.append(int(done))
        sql += " ORDER BY done ASC, id DESC LIMIT ?"
        params.append(max(1, int(limit)))
        return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def watch_toggle(self, wid: int, done: int | None = None) -> dict:
        row = self.conn.execute("SELECT done FROM watch_list WHERE id = ?",
                                (int(wid),)).fetchone()
        if row is None:
            return {"ok": False, "error": "找不到这条"}
        new = (1 - int(row["done"])) if done is None else (1 if done else 0)
        self.conn.execute("UPDATE watch_list SET done = ? WHERE id = ?", (new, int(wid)))
        self.conn.commit()
        return {"ok": True, "id": int(wid), "done": new}

    def watch_delete(self, wid: int) -> bool:
        cur = self.conn.execute("DELETE FROM watch_list WHERE id = ?", (int(wid),))
        self.conn.commit()
        return cur.rowcount > 0

    def watch_stats(self) -> dict:
        row = self.conn.execute(
            "SELECT COUNT(*) AS n, COALESCE(SUM(done), 0) AS d FROM watch_list").fetchone()
        return {"total": int(row["n"] or 0), "done": int(row["d"] or 0)}

    # ---------------- 资料 ↔ 题目 互链 ----------------

    def link_add(self, from_kind: str, from_id: int, to_kind: str,
                 to_id: int, note: str = "") -> dict:
        """加一条关联（**去重**：同一对只留一条）。"""
        a = (str(from_kind), int(from_id), str(to_kind), int(to_id))
        row = self.conn.execute(
            "SELECT id FROM links WHERE from_kind=? AND from_id=? AND to_kind=? AND to_id=?",
            a).fetchone()
        if row:
            return {"id": int(row["id"]), "duplicated": True}
        cur = self.conn.execute(
            "INSERT INTO links (from_kind, from_id, to_kind, to_id, note, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (*a, str(note)[:200], datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "duplicated": False}

    def links_of(self, kind: str, oid: int) -> list[dict]:
        """一个对象的全部关联（**两个方向都查**）。"""
        rows = self.conn.execute(
            "SELECT * FROM links WHERE (from_kind=? AND from_id=?) "
            "   OR (to_kind=? AND to_id=?) ORDER BY id DESC",
            (str(kind), int(oid), str(kind), int(oid))).fetchall()
        return [dict(r) for r in rows]

    def link_delete(self, lid: int) -> bool:
        cur = self.conn.execute("DELETE FROM links WHERE id = ?", (int(lid),))
        self.conn.commit()
        return cur.rowcount > 0

    def link_count(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) AS n FROM links").fetchone()["n"] or 0)

    # ---------------- 题目附件（贴图） ----------------

    def attach_add(self, problem_id: int, name: str, path: str, size: int = 0) -> dict:
        cur = self.conn.execute(
            "INSERT INTO attachments (problem_id, name, path, size, added_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (int(problem_id), str(name)[:200], str(path), int(size),
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid}

    def attachments(self, problem_id: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, problem_id, name, path, size, added_at FROM attachments "
            "WHERE problem_id = ? ORDER BY id ASC", (int(problem_id),)).fetchall()
        return [dict(r) for r in rows]

    def attachment_get(self, aid: int):
        return self.conn.execute("SELECT * FROM attachments WHERE id = ?",
                                 (int(aid),)).fetchone()

    def attach_delete(self, aid: int) -> bool:
        cur = self.conn.execute("DELETE FROM attachments WHERE id = ?", (int(aid),))
        self.conn.commit()
        return cur.rowcount > 0

    def attach_count(self, problem_id: int) -> int:
        return int(self.conn.execute(
            "SELECT COUNT(*) AS n FROM attachments WHERE problem_id = ?",
            (int(problem_id),)).fetchone()["n"] or 0)

    # ---------------- 阅读 / 作文 / 翻译 ----------------

    def practice_add(self, module: str, title: str, url: str = "",
                     note: str = "") -> dict:
        key = str(url or "").strip()
        if key:
            row = self.conn.execute("SELECT id FROM practices WHERE url = ?",
                                    (key,)).fetchone()
            if row:
                return {"id": int(row["id"]), "duplicated": True}
        cur = self.conn.execute(
            "INSERT INTO practices (module, title, url, note, added_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(module)[:20], str(title)[:200], str(url)[:500], str(note)[:400],
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "duplicated": False}

    def practices(self, module: str = "") -> list[dict]:
        sql = "SELECT * FROM practices"
        params: list = []
        if module:
            sql += " WHERE module = ?"
            params.append(str(module))
        sql += " ORDER BY done ASC, id DESC"
        return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def practice_update(self, pid: int, **fields) -> bool:
        allow = {"title", "url", "note", "done"}
        sets, params = [], []
        for k, v in fields.items():
            if k in allow:
                sets.append(f"{k} = ?")
                params.append(v)
        if not sets:
            return False
        params.append(int(pid))
        cur = self.conn.execute(f"UPDATE practices SET {', '.join(sets)} WHERE id = ?",
                                params)
        self.conn.commit()
        return cur.rowcount > 0

    def practice_delete(self, pid: int) -> bool:
        cur = self.conn.execute("DELETE FROM practices WHERE id = ?", (int(pid),))
        self.conn.commit()
        return cur.rowcount > 0

    def practice_stats(self) -> dict:
        total = int(self.conn.execute(
            "SELECT COUNT(*) AS n FROM practices").fetchone()["n"] or 0)
        return {"total": total}

    # ---------------- 听力 ----------------

    def listen_add(self, kind: str, title: str, path: str = "", paper_key: str = "",
                   transcript: str = "", note: str = "") -> dict:
        cur = self.conn.execute(
            "INSERT INTO listening (kind, title, path, paper_key, transcript, note, "
            "added_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (str(kind)[:20], str(title)[:200], str(path)[:500], str(paper_key)[:40],
             str(transcript)[:20000], str(note)[:400],
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid}

    def listening(self, kind: str = "", paper_key: str = "") -> list[dict]:
        sql = ("SELECT id, kind, title, path, paper_key, note, replays, done, added_at, "
               "       length(transcript) AS transcript_len FROM listening")
        where, params = [], []
        if kind:
            where.append("kind = ?")
            params.append(kind)
        if paper_key:
            where.append("paper_key = ?")
            params.append(paper_key)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY done ASC, id DESC"
        return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def listen_get(self, lid: int):
        return self.conn.execute("SELECT * FROM listening WHERE id = ?",
                                 (int(lid),)).fetchone()

    def listen_transcript(self, lid: int) -> str:
        row = self.listen_get(lid)
        return str(dict(row).get("transcript") or "") if row is not None else ""

    def listen_update(self, lid: int, **fields) -> bool:
        allow = {"title", "path", "paper_key", "transcript", "note", "done"}
        sets, params = [], []
        for k, v in fields.items():
            if k not in allow:
                continue
            sets.append(f"{k} = ?")
            params.append(v)
        if not sets:
            return False
        params.append(int(lid))
        cur = self.conn.execute(
            f"UPDATE listening SET {', '.join(sets)} WHERE id = ?", params)
        self.conn.commit()
        return cur.rowcount > 0

    def listen_played(self, lid: int) -> None:
        """听了一遍（replays +1）。"""
        self.conn.execute("UPDATE listening SET replays = replays + 1 WHERE id = ?",
                          (int(lid),))
        self.conn.commit()

    def listen_delete(self, lid: int) -> bool:
        cur = self.conn.execute("DELETE FROM listening WHERE id = ?", (int(lid),))
        self.conn.commit()
        return cur.rowcount > 0

    def listen_stats(self) -> dict:
        row = self.conn.execute(
            "SELECT COUNT(*) AS n, COALESCE(SUM(replays),0) AS r, "
            "COALESCE(SUM(done),0) AS d FROM listening").fetchone()
        return {"count": int(row["n"] or 0), "replays": int(row["r"] or 0),
                "done": int(row["d"] or 0)}

    # ---------------- 资料库 ----------------

    def material_add(self, title: str, path: str, kind: str, size: int,
                     preview: str = "", tag: str = "", note: str = "") -> dict:
        cur = self.conn.execute(
            "INSERT OR REPLACE INTO materials (title, path, kind, size, tag, note, "
            "preview, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (title[:200], str(path), kind[:20], int(size), tag[:40], note[:200],
             preview[:5000], datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "title": title[:200], "path": str(path)}

    def materials(self, q: str = "", limit: int = 200) -> list[dict]:
        sql = ("SELECT id, title, path, kind, size, tag, note, added_at, "
               "       substr(preview, 1, 400) AS preview "
               "FROM materials")
        params: list = []
        if q.strip():
            like = f"%{q.strip()}%"
            sql += (" WHERE title LIKE ? OR path LIKE ? OR tag LIKE ? "
                    "OR note LIKE ? OR preview LIKE ?")
            params = [like] * 5
        sql += " ORDER BY added_at DESC, id DESC LIMIT ?"
        params.append(max(1, int(limit)))
        return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def material_get(self, mid: int):
        return self.conn.execute("SELECT * FROM materials WHERE id = ?",
                                 (int(mid),)).fetchone()

    def material_delete(self, mid: int) -> bool:
        cur = self.conn.execute("DELETE FROM materials WHERE id = ?", (int(mid),))
        self.conn.commit()
        return cur.rowcount > 0

    def materials_stats(self) -> dict:
        row = self.conn.execute(
            "SELECT COUNT(*) AS n, COALESCE(SUM(size), 0) AS total FROM materials"
        ).fetchone()
        kinds = {str(r["kind"]): int(r["n"]) for r in self.conn.execute(
            "SELECT kind, COUNT(*) AS n FROM materials GROUP BY kind").fetchall()}
        return {"count": int(row["n"] or 0),
                "mb": round(int(row["total"] or 0) / 1024 / 1024, 1),
                "kinds": kinds}

    # ---------------- 六级模考 ----------------

    def mock_add(self, taken_on: str, total: int, listening: int = 0,
                 reading: int = 0, writing: int = 0, minutes: int = 0,
                 note: str = "") -> dict:
        cur = self.conn.execute(
            "INSERT INTO mock_exams (taken_on, total, listening, reading, writing, "
            "minutes, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (taken_on[:10], max(0, int(total)), max(0, int(listening)),
             max(0, int(reading)), max(0, int(writing)), max(0, int(minutes)),
             note[:200], datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "taken_on": taken_on[:10], "total": int(total)}

    def mock_list(self, limit: int = 20) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM mock_exams ORDER BY taken_on DESC, id DESC LIMIT ?",
            (max(1, int(limit)),)).fetchall()
        return [dict(r) for r in rows]

    def mock_delete(self, mid: int) -> bool:
        cur = self.conn.execute("DELETE FROM mock_exams WHERE id = ?", (int(mid),))
        self.conn.commit()
        return cur.rowcount > 0

    def mock_stats(self) -> dict:
        rows = self.mock_list(50)
        if not rows:
            return {"count": 0, "best": 0, "latest": 0, "avg": 0, "items": rows}
        totals = [int(r["total"] or 0) for r in rows]
        return {"count": len(rows), "best": max(totals), "latest": totals[0],
                "avg": round(sum(totals) / len(totals)), "items": rows}

    # ---------------- 词表（SM-2） ----------------

    def word_exists(self, word: str) -> bool:
        return self.conn.execute(
            "SELECT 1 FROM words WHERE word = ?", (str(word),)).fetchone() is not None

    def word_add(self, word: str, meaning: str, note: str = "") -> int:
        cur = self.conn.execute(
            "INSERT OR IGNORE INTO words (word, meaning, note, due, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(word), meaning[:400], note[:400], date.today().isoformat(),
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return int(cur.lastrowid or 0)

    def word_get(self, wid: int):
        return self.conn.execute("SELECT * FROM words WHERE id = ?", (int(wid),)).fetchone()

    def word_update(self, wid: int, repetitions: int, interval: int, ef: float,
                    due: str, lapses_add: int = 0) -> None:
        self.conn.execute(
            "UPDATE words SET repetitions = ?, interval = ?, ef = ?, due = ?, "
            "lapses = lapses + ?, review_count = review_count + 1 WHERE id = ?",
            (int(repetitions), int(interval), float(ef), str(due),
             int(lapses_add), int(wid)))
        self.conn.commit()

    def words_count(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) AS n FROM words").fetchone()["n"] or 0)

    def words_due(self, limit: int = 20, today: date | None = None) -> list[dict]:
        today = today or date.today()
        rows = self.conn.execute(
            "SELECT id, word, meaning, note, repetitions, interval, ef, due, lapses "
            "FROM words WHERE due <= ? ORDER BY due ASC, lapses DESC, id ASC LIMIT ?",
            (today.isoformat(), max(1, int(limit)))).fetchall()
        return [dict(r) for r in rows]

    def words_stats(self, today: date | None = None) -> dict:
        today = today or date.today()
        total = self.words_count()
        due_n = int(self.conn.execute(
            "SELECT COUNT(*) AS n FROM words WHERE due <= ?",
            (today.isoformat(),)).fetchone()["n"] or 0)
        # 掌握 = 间隔已经拉到 21 天以上（SM-2 里的"毕业"线）
        learned = int(self.conn.execute(
            "SELECT COUNT(*) AS n FROM words WHERE interval >= 21").fetchone()["n"] or 0)
        started = int(self.conn.execute(
            "SELECT COUNT(*) AS n FROM words WHERE review_count > 0").fetchone()["n"] or 0)
        return {"total": total, "due": due_n, "learned": learned,
                "started": started, "today": today.isoformat()}

    # ---------------- 错题本 ----------------

    def mistake_add(self, problem_id: int, reason: str, kind: str = "") -> dict:
        cur = self.conn.execute(
            "INSERT INTO mistakes (problem_id, reason, kind, created_at) "
            "VALUES (?, ?, ?, ?)",
            (int(problem_id), reason[:300], kind[:20],
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "problem_id": int(problem_id),
                "reason": reason[:300], "kind": kind[:20]}

    def mistakes_for(self, problem_id: int, limit: int = 5) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT id, problem_id, reason, kind, created_at FROM mistakes "
            "WHERE problem_id = ? ORDER BY id DESC LIMIT ?",
            (int(problem_id), limit)).fetchall()]

    def mistakes_recent(self, limit: int = 30) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT m.id, m.problem_id, m.reason, m.kind, m.created_at, "
            "       p.title AS title "
            "FROM mistakes m LEFT JOIN problems p ON p.id = m.problem_id "
            "ORDER BY m.id DESC LIMIT ?", (limit,)).fetchall()]

    def mistake_delete(self, mid: int) -> bool:
        cur = self.conn.execute("DELETE FROM mistakes WHERE id = ?", (int(mid),))
        self.conn.commit()
        return cur.rowcount > 0

    def mistake_counts(self) -> dict:
        """按快捷标签统计（成绩单里能看出"她最容易栽在哪一类"）。"""
        rows = self.conn.execute(
            "SELECT kind, COUNT(*) AS n FROM mistakes GROUP BY kind").fetchall()
        return {str(r["kind"] or "其它"): int(r["n"]) for r in rows}

    # ---------------- 提醒到点 ----------------

    def reminders_due(self, now: datetime | None = None) -> list[dict]:
        """今天到点、且还没确认过的提醒。

        规则（和界面上的说明一致）：
            daily    每天，到点就提醒
            weekly   指定星期几
            once     指定日期
        `at_time` 是 HH:MM；空的话当成"一整天随时"（不主动弹，避免打扰）。
        """
        now = now or datetime.now()
        today = now.date().isoformat()
        hhmm = now.strftime("%H:%M")
        weekday = now.isoweekday()          # 1=周一 … 7=周日
        acked = {int(r["reminder_id"]) for r in self.conn.execute(
            "SELECT reminder_id FROM reminder_hits WHERE day = ?", (today,))}
        out: list[dict] = []
        for r in self.conn.execute("SELECT * FROM reminders").fetchall():
            d = dict(r)
            if int(d.get("done") or 0):
                continue
            pattern = str(d.get("pattern") or "daily")
            at = str(d.get("at_time") or "").strip()
            if not at or at > hhmm:
                continue                      # 没到点
            if pattern == "weekly":
                try:
                    if int(d.get("weekday") or 1) != weekday:
                        continue
                except (TypeError, ValueError):
                    continue
            elif pattern == "once":
                if str(d.get("on_date") or "") != today:
                    continue
            if int(d["id"]) in acked:
                continue
            out.append({"id": int(d["id"]), "body": str(d.get("body") or ""),
                        "at_time": at, "pattern": pattern,
                        "important": bool(d.get("important") or 0),
                        "weekday": d.get("weekday"), "on_date": d.get("on_date")})
        return out

    def reminder_ack(self, reminder_id: int, day: str | None = None,
                     action: str = "ack") -> dict:
        day = day or datetime.now().date().isoformat()
        self.conn.execute(
            "INSERT OR REPLACE INTO reminder_hits (reminder_id, day, action, created_at) "
            "VALUES (?, ?, ?, ?)",
            (int(reminder_id), day, action[:12],
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"ok": True, "reminder_id": int(reminder_id), "day": day,
                "action": action[:12]}

    # ---------------- 目标 ----------------

    def goal_add(self, title: str, kind: str = "problems", target_num: int = 0,
                 target_date: str = "") -> dict:
        cur = self.conn.execute(
            "INSERT INTO goals (title, kind, target_num, target_date, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (title[:60], kind[:16], max(0, int(target_num)), target_date[:10],
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "title": title[:60], "kind": kind[:16],
                "target_num": max(0, int(target_num)), "target_date": target_date[:10]}

    def goals(self, include_done: bool = True) -> list[dict]:
        sql = "SELECT * FROM goals"
        if not include_done:
            sql += " WHERE done = 0"
        sql += " ORDER BY done ASC, id ASC"
        return [dict(r) for r in self.conn.execute(sql).fetchall()]

    def goal_update(self, gid: int, **fields) -> dict:
        allowed = ("title", "target_num", "progress", "target_date", "done", "kind")
        sets, params = [], []
        for k, v in fields.items():
            if k not in allowed or v is None:
                continue
            sets.append(f"{k} = ?")
            params.append(v)
        if not sets:
            return {"ok": False, "error": "没有要改的字段"}
        params.append(int(gid))
        self.conn.execute(f"UPDATE goals SET {', '.join(sets)} WHERE id = ?", params)
        self.conn.commit()
        return {"ok": True, "id": int(gid)}

    def goal_delete(self, gid: int) -> bool:
        cur = self.conn.execute("DELETE FROM goals WHERE id = ?", (int(gid),))
        self.conn.commit()
        return cur.rowcount > 0

    def reviewed_problem_count(self) -> int:
        """做过的题数（至少复习过一次）—— 目标进度用它。"""
        return int(self.conn.execute(
            "SELECT COUNT(DISTINCT problem_id) FROM reviews").fetchone()[0] or 0)

    # ---------------- 专注（番茄钟） ----------------

    def focus_add(self, started_at: str, minutes: int, note: str = "") -> dict:
        """记一笔专注。"""
        cur = self.conn.execute(
            "INSERT INTO focus_sessions (started_at, minutes, note, created_at) "
            "VALUES (?, ?, ?, ?)",
            (started_at, max(0, int(minutes)), note[:200],
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()
        return {"id": cur.lastrowid, "started_at": started_at,
                "minutes": max(0, int(minutes)), "note": note[:200]}

    def focus_stats(self, days: int = 7) -> dict:
        """最近 N 天的专注分钟数 + 合计 + 最近几笔。"""
        days = max(1, min(90, int(days)))
        rows = self.conn.execute(
            "SELECT substr(started_at, 1, 10) AS d, SUM(minutes), COUNT(*) "
            "FROM focus_sessions GROUP BY d ORDER BY d DESC LIMIT ?",
            (days,)).fetchall()
        by_day = {r[0]: {"minutes": int(r[1] or 0), "count": int(r[2] or 0)}
                  for r in rows}
        today = datetime.now().strftime("%Y-%m-%d")
        recent = [{"id": r[0], "started_at": r[1], "minutes": r[2], "note": r[3]}
                  for r in self.conn.execute(
                      "SELECT id, started_at, minutes, note FROM focus_sessions "
                      "ORDER BY id DESC LIMIT 10").fetchall()]
        total = self.conn.execute(
            "SELECT COALESCE(SUM(minutes), 0) FROM focus_sessions").fetchone()[0]
        # 按小时分布：几点效率最高（她熬夜，这个数据有意义）
        hours = {i: 0 for i in range(24)}
        for r in self.conn.execute(
                "SELECT substr(started_at, 12, 2) AS h, SUM(minutes) AS m "
                "FROM focus_sessions GROUP BY h").fetchall():
            try:
                hours[int(r["h"])] = int(r["m"] or 0)
            except (TypeError, ValueError):
                pass
        return {"by_hour": hours,
                "by_day": by_day, "today": by_day.get(today, {}).get("minutes", 0),
                "week": sum(v["minutes"] for v in by_day.values()),
                "total": int(total or 0), "recent": recent, "days": days}

    # ---------------- 便签卡片 ----------------

    def add_note(self, body: str, color: str = "pink", pinned: bool = False) -> int:
        body = (body or "").strip()
        if not body:
            raise ValueError("便签内容不能为空")
        now = datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute(
            "INSERT INTO notes(body, color, pinned, created_at, updated_at) VALUES(?,?,?,?,?)",
            (body, color, 1 if pinned else 0, now, now),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def notes(self, include_archived: bool = False) -> list[sqlite3.Row]:
        sql = "SELECT * FROM notes"
        if not include_archived:
            sql += " WHERE archived = 0"
        sql += " ORDER BY pinned DESC, sort_order ASC, id DESC"
        return list(self.conn.execute(sql))

    def note(self, note_id: int) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM notes WHERE id = ?", (note_id,)).fetchone()

    def find_note(self, token: str) -> sqlite3.Row | None:
        token = (token or "").strip()
        if token.isdigit():
            return self.note(int(token))
        row = self.conn.execute(
            "SELECT * FROM notes WHERE body LIKE ? ORDER BY id DESC LIMIT 1", (f"%{token}%",)
        ).fetchone()
        return row

    def update_note(self, note_id: int, **fields) -> bool:
        allowed = {"body", "color", "pinned", "archived", "sort_order"}
        sets, values = [], []
        for key, value in fields.items():
            if key not in allowed or value is None:
                continue
            if key in ("pinned", "archived"):
                value = 1 if value else 0
            sets.append(f"{key} = ?")
            values.append(value)
        if not sets:
            return False
        sets.append("updated_at = ?")
        values.extend([datetime.now().isoformat(timespec="seconds"), note_id])
        cur = self.conn.execute(f"UPDATE notes SET {', '.join(sets)} WHERE id = ?", values)
        self.conn.commit()
        return cur.rowcount > 0

    def delete_note(self, note_id: int) -> bool:
        cur = self.conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
        self.conn.commit()
        return cur.rowcount > 0

    # ---------------- 倒数日 ----------------

    def add_countdown(self, title: str, target: date | str, kind: str = "event",
                      note: str = "", yearly: bool = False) -> int:
        title = (title or "").strip()
        if not title:
            raise ValueError("倒数日标题不能为空")
        target_text = target.isoformat() if isinstance(target, date) else str(target)
        try:
            date.fromisoformat(target_text)
        except ValueError as exc:
            raise ValueError(f"日期格式要 YYYY-MM-DD，收到 {target_text!r}") from exc
        cur = self.conn.execute(
            """INSERT INTO countdowns(title, target, kind, note, yearly, created_at)
               VALUES(?,?,?,?,?,?)""",
            (title, target_text, kind, note, 1 if yearly else 0,
             datetime.now().isoformat(timespec="seconds")),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def countdowns(self, include_archived: bool = False) -> list[sqlite3.Row]:
        sql = "SELECT * FROM countdowns"
        if not include_archived:
            sql += " WHERE archived = 0"
        sql += " ORDER BY target ASC, id ASC"
        return list(self.conn.execute(sql))

    def countdown(self, cid: int) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM countdowns WHERE id = ?", (cid,)).fetchone()

    def find_countdown(self, token: str) -> sqlite3.Row | None:
        token = (token or "").strip()
        if token.isdigit():
            return self.countdown(int(token))
        row = self.conn.execute(
            "SELECT * FROM countdowns WHERE title LIKE ? ORDER BY id DESC LIMIT 1", (f"%{token}%",)
        ).fetchone()
        return row

    def update_countdown(self, cid: int, **fields) -> bool:
        allowed = {"title", "target", "kind", "note", "yearly", "archived"}
        sets, values = [], []
        for key, value in fields.items():
            if key not in allowed or value is None:
                continue
            if key == "yearly":
                value = 1 if value else 0
            if key == "archived":
                value = 1 if value else 0
            if key == "target" and isinstance(value, date):
                value = value.isoformat()
            sets.append(f"{key} = ?")
            values.append(value)
        if not sets:
            return False
        values.append(cid)
        cur = self.conn.execute(f"UPDATE countdowns SET {', '.join(sets)} WHERE id = ?", values)
        self.conn.commit()
        return cur.rowcount > 0

    def delete_countdown(self, cid: int) -> bool:
        cur = self.conn.execute("DELETE FROM countdowns WHERE id = ?", (cid,))
        self.conn.commit()
        return cur.rowcount > 0

    # ---------------- 特别提醒 ----------------

    def add_reminder(self, body: str, pattern: str = "daily", weekday: int = 1,
                     on_date: str = "", at_time: str = "", priority: str = "normal") -> int:
        body = (body or "").strip()
        if not body:
            raise ValueError("提醒内容不能为空")
        if pattern not in ("daily", "weekly", "date", "once"):
            raise ValueError("pattern 只能是 daily / weekly / date / once")
        cur = self.conn.execute(
            """INSERT INTO reminders(body, pattern, weekday, date, at_time, priority, created_at)
               VALUES(?,?,?,?,?,?,?)""",
            (body, pattern, int(weekday), on_date, at_time, priority,
             datetime.now().isoformat(timespec="seconds")),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def reminders(self, include_disabled: bool = True) -> list[sqlite3.Row]:
        sql = "SELECT * FROM reminders"
        if not include_disabled:
            sql += " WHERE enabled = 1"
        sql += " ORDER BY priority DESC, id ASC"
        return list(self.conn.execute(sql))

    def reminder(self, rid: int) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM reminders WHERE id = ?", (rid,)).fetchone()

    def update_reminder(self, rid: int, **fields) -> bool:
        allowed = {"body", "pattern", "weekday", "date", "at_time", "priority",
                   "enabled", "last_fired"}
        sets, values = [], []
        for key, value in fields.items():
            if key not in allowed or value is None:
                continue
            if key == "enabled":
                value = 1 if value else 0
            sets.append(f"{key} = ?")
            values.append(value)
        if not sets:
            return False
        values.append(rid)
        cur = self.conn.execute(f"UPDATE reminders SET {', '.join(sets)} WHERE id = ?", values)
        self.conn.commit()
        return cur.rowcount > 0

    def delete_reminder(self, rid: int) -> bool:
        cur = self.conn.execute("DELETE FROM reminders WHERE id = ?", (rid,))
        self.conn.commit()
        return cur.rowcount > 0

    def reminders_today(self, today: date | None = None) -> list[sqlite3.Row]:
        """今天该弹出来的提醒。weekly 看星期几，date/once 看具体日期。"""
        today = today or date.today()
        stamp = today.isoformat()
        out: list[sqlite3.Row] = []
        for row in self.reminders(include_disabled=False):
            pattern = row["pattern"]
            if pattern == "daily":
                out.append(row)
            elif pattern == "weekly" and int(row["weekday"]) == today.isoweekday():
                out.append(row)
            elif pattern in ("date", "once") and row["date"] == stamp:
                if pattern == "once" and row["last_fired"] == stamp:
                    continue  # 一次性提醒已经响过了
                out.append(row)
        out.sort(key=lambda r: (0 if r["priority"] == "important" else 1, r["at_time"] or "99:99"))
        return out

    def mark_reminder_fired(self, rid: int, today: date | None = None) -> None:
        today = today or date.today()
        self.update_reminder(rid, last_fired=today.isoformat())

    # ---------------- 导出 ----------------

    def dump(self) -> dict:
        return {
            "schema_version": SCHEMA_VERSION,
            "exported_at": datetime.now().isoformat(timespec="seconds"),
            "problems": [
                {
                    "title": p.title,
                    "source": p.source,
                    "difficulty": p.difficulty,
                    "tags": p.tags,
                    "url": p.url,
                    "note": p.note,
                    "memory": p.memory,
                    "repetitions": p.repetitions,
                    "interval": p.interval,
                    "ef": p.ef,
                    "due": p.due.isoformat(),
                    "lapses": p.lapses,
                    "review_count": p.review_count,
                }
                for p in self.all(include_archived=True)
            ],
            "reviews": [
                dict(r)
                for r in self.conn.execute("SELECT * FROM reviews ORDER BY id ASC")
            ],
            "notes": [dict(r) for r in self.conn.execute("SELECT * FROM notes ORDER BY id ASC")],
            "countdowns": [
                dict(r) for r in self.conn.execute("SELECT * FROM countdowns ORDER BY id ASC")
            ],
            "reminders": [
                dict(r) for r in self.conn.execute("SELECT * FROM reminders ORDER BY id ASC")
            ],
        }

    def load_dump(self, payload: dict, merge: bool = True) -> tuple[int, int]:
        """从 dump 恢复。返回 (导入题目数, 导入复习记录数)。"""
        p_count = r_count = 0
        id_map: dict[int, int] = {}
        for item in payload.get("problems", []):
            existing = self.find_by_title(item.get("title", "")) if merge else None
            if existing:
                id_map[item.get("id", -1)] = existing.id
                continue
            new_id = self.add(
                title=item["title"],
                source=item.get("source", "leetcode"),
                difficulty=item.get("difficulty", "medium"),
                tags=item.get("tags", []),
                url=item.get("url", ""),
                note=item.get("note", ""),
                memory=item.get("memory", ""),
                due=date.fromisoformat(item["due"]) if item.get("due") else date.today(),
            )
            self.update(
                new_id,
                repetitions=item.get("repetitions", 0),
                interval=item.get("interval", 0),
                ef=item.get("ef", sm2.EF_DEFAULT),
            )
            id_map[item.get("id", -1)] = new_id
            p_count += 1

        for row in payload.get("reviews", []):
            old_id = row.get("problem_id")
            new_id = id_map.get(old_id)
            if not new_id:
                continue
            self.conn.execute(
                """INSERT INTO reviews
                   (problem_id, quality, seconds, ef_before, ef_after, interval_after,
                    reviewed_on, created_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (
                    new_id,
                    row.get("quality", 3),
                    row.get("seconds", 0),
                    row.get("ef_before"),
                    row.get("ef_after"),
                    row.get("interval_after"),
                    row.get("reviewed_on", date.today().isoformat()),
                    row.get("created_at", datetime.now().isoformat(timespec="seconds")),
                ),
            )
            r_count += 1

        # 便签 / 倒数日 / 提醒：按内容去重后恢复
        n_count = c_count = m_count = 0
        existing_notes = {r["body"] for r in self.conn.execute("SELECT body FROM notes")}
        for row in payload.get("notes", []):
            if row.get("body") in existing_notes:
                continue
            self.add_note(row.get("body", ""), row.get("color", "pink"), bool(row.get("pinned")))
            n_count += 1

        existing_cd = {r["title"] for r in self.conn.execute("SELECT title FROM countdowns")}
        for row in payload.get("countdowns", []):
            if row.get("title") in existing_cd or not row.get("target"):
                continue
            self.add_countdown(row["title"], row["target"], row.get("kind", "event"),
                               row.get("note", ""), bool(row.get("yearly")))
            c_count += 1

        existing_rm = {r["body"] for r in self.conn.execute("SELECT body FROM reminders")}
        for row in payload.get("reminders", []):
            if row.get("body") in existing_rm:
                continue
            try:
                self.add_reminder(row.get("body", ""), row.get("pattern", "daily"),
                                  int(row.get("weekday", 1) or 1), row.get("date", "") or "",
                                  row.get("at_time", "") or "", row.get("priority", "normal"))
                m_count += 1
            except ValueError:
                continue

        self.conn.commit()
        return p_count, r_count, n_count, c_count, m_count
