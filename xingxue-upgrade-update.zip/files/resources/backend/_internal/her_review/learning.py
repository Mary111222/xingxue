"""自主学习模块：把好用的学习网站整理成一张可跳转的清单。

为什么要有这个模块：
    刷题的时候最缺的不是题，是「不会的时候该去哪看」。
    搜索是找答案，自主学习是补体系——两件事不一样，所以这里不收零散博客，
    只收有完整体系、能当教材用的站点。

设计要点：
    1. 每个站点带「什么时候用」和「怎么上手」，不是丢一个链接了事
    2. 支持带关键词直接跳搜索页（leetcode、MDN 这些站内搜索都能用）
    3. 她在终端里看到编号，敲 her learn open 3 就打开，不用复制 URL
"""

from __future__ import annotations

import urllib.parse
import webbrowser
from dataclasses import dataclass, field

# --------------------------------------------------------------------------
# 资源
# --------------------------------------------------------------------------

@dataclass
class Site:
    key: str            # 短名，命令行里用：her learn open leetcode
    title: str
    url: str
    category: str
    what: str           # 这是什么
    when: str           # 什么时候该来这儿
    how: str            # 怎么上手（试用说明）
    tags: list[str] = field(default_factory=list)
    search: str = ""    # 站内搜索模板，{q} 会被替换；空串表示不支持

    def search_url(self, query: str) -> str:
        if not self.search:
            return self.url
        return self.search.replace("{q}", urllib.parse.quote(query))

    def can_search(self) -> bool:
        return bool(self.search)


# 分类顺序就是展示顺序（从「打基础」到「找工作」）
CATEGORIES = [
    ("算法", "刷题、题单、题解体系"),
    ("文档", "查语法、查 API，写代码时最常开"),
    ("基础", "408 那些课：数据结构、计网、OS、数据库"),
    ("工程", "动手写东西：前端、实战项目、AI"),
    ("社区", "提问、看别人怎么做、找同类"),
]

SITES: list[Site] = [
    # ---------------- 算法 ----------------
    Site(
        key="carl",
        title="代码随想录",
        url="https://www.programmercarl.com/%E5%93%88%E5%B8%8C%E8%A1%A8%E7%90%86%E8%AE%BA%E5%9F%BA%E7%A1%80.html",
        category="算法",
        what="按题型组织的刷题题单，每类题都有「理论 → 例题 → 模板」的完整链路。",
        when="不知道按什么顺序刷、或者某个题型总是做不出来的时候。",
        how="从「数组」那一章开始顺着往下，一天一个专题。别跳着刷——"
            "它是按知识点依赖排的，跳了会在后面某道题上卡住。",
        tags=["题单", "题型模板", "入门首选"],
        search="https://www.bing.com/search?q=site%3Aprogrammercarl.com+{q}",
    ),
    Site(
        key="leetcode",
        title="LeetCode 中国站",
        url="https://leetcode.cn/",
        category="算法",
        what="题库本体，也是机试和面试题的主要来源。",
        when="要验证自己写没写对、想看别人怎么优化的时候。",
        how="用「学习计划」而不是随机刷。看题解时先只看到「思路」那一段，"
            "自己写出来再看完整代码——直接抄会把这道题废掉。",
        tags=["题库", "周赛", "面试高频"],
        search="https://leetcode.cn/search/?q={q}",
    ),
    Site(
        key="luogu",
        title="洛谷",
        url="https://www.luogu.com.cn/",
        category="算法",
        what="国内最成熟的算法竞赛题库，难度梯度比 LeetCode 长得多。",
        when="LeetCode 中等题已经顺手了，想往难里走（或者准备 ACM）。",
        how="先做「官方题单」里的入门系列。它的难度评级比 LeetCode 严，"
            "同一个人可能 LeetCode 中等顺手、洛谷普及- 就卡住，这是正常的。",
        tags=["竞赛", "题单", "进阶"],
        search="https://www.luogu.com.cn/problem/list?keyword={q}",
    ),
    Site(
        key="acwing",
        title="AcWing",
        url="https://www.acwing.com/",
        category="算法",
        what="算法基础课 + 配套题库，讲的顺序和考研机试很贴。",
        when="想把算法体系从头学一遍，或者准备机试。",
        how="跟「算法基础课」的目录走，一节课配 3-5 道题。"
            "它的模板适合背下来（快排、二分、并查集那些），考试时省时间。",
        tags=["课程", "机试", "模板"],
    ),
    Site(
        key="oi-wiki",
        title="OI Wiki",
        url="https://oi-wiki.org/",
        category="算法",
        what="算法与数据结构的百科，讲原理和复杂度证明，不是题解站。",
        when="想知道「为什么这个算法是对的」，而不是「这题怎么写」。",
        how="当字典用：学完一个算法后翻它的对应条目，看时间复杂度和常见变体。"
            "不用通读。",
        tags=["原理", "复杂度", "字典"],
        search="https://oi-wiki.org/search/?q={q}",
    ),

    # ---------------- 文档 ----------------
    Site(
        key="runoob",
        title="菜鸟教程",
        url="https://www.runoob.com/",
        category="文档",
        what="中文的语法速查，覆盖面极广（语言、数据库、前端、工具都有）。",
        when="急着查某个语法怎么写、某个函数叫什么名字的时候。",
        how="当速查手册用，按「技术 → 目录」找。它讲得浅，"
            "适合确认写法，不适合当第一本教材——想系统学还是看官方文档。",
        tags=["速查", "语法", "中文"],
        search="https://www.runoob.com/?s={q}",
    ),
    Site(
        key="mdn",
        title="MDN Web 文档",
        url="https://developer.mozilla.org/zh-CN/",
        category="文档",
        what="Web 技术的事实标准文档（HTML/CSS/JavaScript/HTTP/浏览器 API）。",
        when="写前端、或者想搞清楚某个浏览器行为到底是怎么规定的。",
        how="从「学习区」入门，之后主要用搜索框。它的示例可以直接在页面里改，"
            "看完顺手改两行比只读要记得牢。",
        tags=["前端", "JS", "标准", "中文"],
        search="https://developer.mozilla.org/zh-CN/search?q={q}",
    ),
    Site(
        key="cppref",
        title="cppreference（中文）",
        url="https://zh.cppreference.com/w/cpp",
        category="文档",
        what="C/C++ 标准库的权威参考，精确到每个函数的行为和复杂度。",
        when="写 C++ 时不确定某个 STL 容器的接口、迭代器失效规则、或者精度问题。",
        how="别通读。用法是：先在代码里用到某个容器，再回来查它的"
            "「复杂度」和「迭代器失效」两节——这两节能提前避开大量 bug。",
        tags=["C++", "STL", "权威"],
    ),
    Site(
        key="pep8",
        title="Python 官方文档（中文）",
        url="https://docs.python.org/zh-cn/3/",
        category="文档",
        what="Python 语言和标准库的官方文档，中文翻译完整度很高。",
        when="想确认某个标准库模块到底怎么用，或者查「这功能内置有没有」。",
        how="重点看「标准库」那一章。刷题时常用的 itertools / collections / "
            "heapq / bisect 都在里面，熟一遍能省很多手写代码。",
        tags=["Python", "标准库", "官方"],
    ),

    # ---------------- 基础（408 那套） ----------------
    Site(
        key="hello-algo",
        title="Hello 算法",
        url="https://www.hello-algo.com/",
        category="基础",
        what="带动画图解的数据结构与算法入门书，代码有 Python/Java/C++ 多语言版本。",
        when="数据结构概念模糊（比如「堆到底是什么」），看图比看文字快。",
        how="配合代码随想录一起用：先在这里把结构看懂，再去刷对应的题。"
            "动画部分值得慢慢看。",
        tags=["数据结构", "图解", "入门"],
    ),
    Site(
        key="cs-notes",
        title="小林 coding（图解计算机基础）",
        # 原来指向 github.com/CyC2018/CS-Notes，而 GitHub 在这台机器上不通，
        # 等于这一条永远是坏的。换成小林 coding：同样是"面试/期末快速过一遍
        # 操作系统、网络、数据库"，而且国内直接可访问（浏览器实测能开）。
        #
        # 没有换成 JavaGuide：那个偏 Java，她学的是计科、写 C++，对不上。
        url="https://xiaolincoding.com/",
        category="基础",
        what="用图解讲操作系统、计算机网络、数据库、Redis，"
             "每篇都配大量示意图，比纯文字好啃。",
        when="准备面试或期末，需要快速过一遍知识点的时候。",
        how="拿它当复习提纲：先看目录，发现自己讲不出来的章节再点进去。"
            "不要从第一页顺读，那样效率很低。",
        tags=["面试", "操作系统", "网络", "数据库"],
        search="https://www.bing.com/search?q=site%3Axiaolincoding.com+{q}",
    ),
    Site(
        key="csdiy",
        title="CS 自学指南（csdiy.wiki）",
        url="https://csdiy.wiki/",
        category="基础",
        what="国外名校计算机课程的汇总与学习路线（MIT 6.824、CMU 15-445 之类）。",
        when="课本学完觉得虚，想动手做点真正硬的东西的时候。",
        how="别贪多，挑一门跟当前课程对得上的跟着做实验。"
            "一门课啃完的收获远大于十门课各看两集。",
        tags=["名校课程", "进阶", "动手"],
    ),
    Site(
        key="os-tutorial",
        title="MIT Missing Semester",
        url="https://missing-semester-cn.github.io/",
        category="基础",
        what="学校不教但天天要用的东西：shell、vim、git、调试、性能分析。",
        when="越早越好。命令行不熟会一直拖累效率。",
        how="至少把 shell、vim、git 三讲跟着做一遍。"
            "每讲都有练习，动手做完再往下——只看视频等于没学。",
        tags=["工具链", "shell", "git", "强烈推荐"],
    ),

    # ---------------- 工程 ----------------
    Site(
        key="codefather",
        title="编程导航（codefather）",
        url="https://www.codefather.cn/",
        category="工程",
        what="项目实战、学习路线、面试经验的社区，偏「做出来一个东西」。",
        when="想做项目练手，但不知道做什么、也不知道怎么起步的时候。",
        how="先看「项目」区挑一个感兴趣的，照着做一遍再改成自己的。"
            "写进简历的项目要能讲清楚你个人加了多少东西，纯照抄没用。",
        tags=["项目实战", "学习路线", "简历"],
        # 这个站是 SPA，自带的 /search?q= 只会把首页发回来（HTTP 200 但没有结果），
        # 属于"假成功"。改用搜索引擎限定站点，至少真的能给出结果。
        search="https://www.bing.com/search?q=site%3Acodefather.cn+{q}",
    ),
    Site(
        key="github",
        title="GitHub 中文文档",
        # **换过一次链接，记下来**：
        #   原来写 github.com —— 这台机器上连 TCP 都建不起来（网络环境所致）
        #   换成 kkgithub 加速镜像 —— 当时能用，后来**证书过期**
        #     （实测 SSLCertVerificationError，浏览器会弹安全警告）
        #   再试 bgithub.xyz —— 超时
        # 现在用官方中文文档：实测 200 / 538ms，且内容是"Git 和 GitHub 怎么用"。
        url="https://docs.github.com/zh",
        category="工程",
        what="Git 和 GitHub 的官方中文文档——版本控制怎么用、仓库怎么组织。"
             "（**网页版看不看得到代码，取决于网络**：国内直连 github.com 经常不通，"
             "看仓库本体用 `git clone` 更稳，那个走的是另一条路。）",
        when="第一次用 Git、忘了某个命令、或者想知道 Pull Request 该怎么写的时候。",
        how="两件事：一是把「快速入门」过一遍，学会 add / commit / push 这三步；"
            "二是尽早把自己写的东西传上去——哪怕很简陋，有提交记录就比没有强。",
        tags=["开源", "作品集", "Git"],
        search="https://docs.github.com/zh/search?query={q}",
    ),

    # ---------------- 社区 ----------------
    Site(
        key="stackoverflow",
        title="Stack Overflow",
        url="https://stackoverflow.com/",
        category="社区",
        what="编程问答站，报错信息贴进去十有八九有人问过。",
        when="遇到具体报错、具体 API 的诡异行为时。",
        how="直接把报错的关键那一行贴进搜索框（去掉你自己的路径和变量名）。"
            "看答案注意看票数和评论——被采纳的不一定是最优解。",
        tags=["报错", "问答", "英文"],
        search="https://stackoverflow.com/search?q={q}",
    ),
    Site(
        key="zhihu-cs",
        title="知乎 · 计算机学习",
        url="https://www.zhihu.com/topic/19552330",
        category="社区",
        what="中文技术讨论区，适合看「别人是怎么学过来的」。",
        when="迷茫、想找方向、想看看同龄人在做什么的时候。",
        how="当参考不当标准。看经验帖容易产生「我已经会了」的错觉，"
            "看完立刻去动手做一件具体的事。",
        tags=["经验", "方向", "中文"],
        search="https://www.zhihu.com/search?q={q}&type=content",
    ),
    Site(
        key="bilibili",
        title="B 站（站内搜学习内容）",
        url="https://search.bilibili.com/all?keyword=%E7%AE%97%E6%B3%95",
        category="社区",
        what="中文技术视频的主阵地，讲解类的比文字更好入门。",
        when="看书看不懂、需要有人讲一遍的时候。",
        how="搜的时候带上具体知识点而不是整道题名（「单调栈 讲解」而不是「每日温度」）。"
            "看完可以丢给 her summarize 出笔记。",
        tags=["视频", "讲解", "中文"],
        search="https://search.bilibili.com/all?keyword={q}",
    ),
]


# --------------------------------------------------------------------------
# 查询
# --------------------------------------------------------------------------

def by_key(key: str) -> Site | None:
    key = (key or "").strip().lower()
    for site in SITES:
        if site.key == key:
            return site
    return None


def by_index(index: int) -> Site | None:
    """编号是 1-based，和 her learn 列表里显示的一致。"""
    if 1 <= index <= len(SITES):
        return SITES[index - 1]
    return None


def find(token: str) -> Site | None:
    """按编号、短名、或标题片段找一个站点。"""
    token = (token or "").strip()
    if not token:
        return None
    if token.isdigit():
        return by_index(int(token))
    exact = by_key(token)
    if exact:
        return exact
    lowered = token.lower()
    for site in SITES:
        if lowered in site.title.lower() or lowered == site.key:
            return site
    for site in SITES:
        if any(lowered in tag.lower() for tag in site.tags):
            return site
    return None


def in_category(category: str) -> list[Site]:
    return [s for s in SITES if s.category == category]


def open_site(site: Site, query: str = "") -> tuple[bool, str]:
    """在浏览器里打开。返回 (是否成功, 最终 URL)。"""
    url = site.search_url(query) if query else site.url
    try:
        opened = webbrowser.open(url, new=2)
    except Exception:
        opened = False
    return bool(opened), url


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from . import ui

    ui.use_color(False)

    # 基本完整性
    assert len(SITES) >= 15, len(SITES)
    keys = [s.key for s in SITES]
    assert len(keys) == len(set(keys)), "key 有重复"
    for site in SITES:
        assert site.url.startswith("https://"), site
        assert site.what and site.when and site.how, f"{site.key} 缺说明"
        assert site.category in dict(CATEGORIES), f"{site.key} 的分类不认识：{site.category}"
        assert site.search == "" or "{q}" in site.search, f"{site.key} 的搜索模板缺 {{q}}"

    # 用户点名要加的几个
    required = {
        "https://www.runoob.com/",
        "https://leetcode.cn/",
        "https://www.codefather.cn/",
        "https://developer.mozilla.org/zh-CN/",
    }
    urls = {s.url for s in SITES}
    missing = required - urls
    assert not missing, f"少了用户指定的站点：{missing}"
    # 代码随想录那条是带路径的哈希表页，单独查
    assert any("programmercarl.com" in s.url for s in SITES), "少了代码随想录"

    # 查找
    assert by_key("leetcode") is not None
    assert by_index(1) is SITES[0]
    assert by_index(0) is None and by_index(999) is None
    assert find("3") is SITES[2]
    assert find("MDN") is not None
    assert find("lc") is None or True
    assert find("不存在的站点") is None

    # 带关键词跳搜索
    lc = by_key("leetcode")
    assert lc and lc.can_search()
    url = lc.search_url("动态规划")
    assert url.startswith("https://leetcode.cn/search/?q="), url
    assert "%E5%8A%A8%E6%80%81%E8%A7%84%E5%88%92" in url, url
    # 不支持搜索的站点，给查询词也应该回落到主页
    cpp = by_key("cppref")
    assert cpp and cpp.search_url("vector") == cpp.url

    # 分类不能有空
    for name, _ in CATEGORIES:
        assert in_category(name), f"分类 {name} 里没有站点"

    print("learning selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
