"""SM-2 间隔重复算法（SuperMemo 2，1987）。

纯函数实现，不碰数据库，方便单独测试。

评分 q（0-5）：
    0 完全忘了        "又白学了"
    1 有印象但想不起来  "眼熟，但不会"
    2 想起来一点，卡壳  "写出来是错的"
    3 勉强写出来，很慢  "能过，但心虚"
    4 顺利写完，有小瑕疵 "稳"
    5 秒杀，可以直接面试 "这题我闭眼写"

规则（离散 SM-2，Anki 的祖先）：
    q < 3   → 答错：连击清零，间隔重置为 1 天，第二天必须重来
    q >= 3  → 答对：EF 更新，间隔按当前阶段推进

EF（Easiness Factor）区间 [1.3, 2.8]，永远不删题，只会越算越准。
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

EF_MIN = 1.3
EF_MAX = 2.8
EF_DEFAULT = 2.5

# 首次答对的初始间隔（天），比 SuperMemo 原版稍微缓一点，更适合学生节奏
FIRST_INTERVAL = 1
SECOND_INTERVAL = 3

QUALITY_LABELS = {
    0: ("完全忘了", "又白学了"),
    1: ("有印象", "眼熟，但写不出"),
    2: ("想起来一点", "写出来是错的"),
    3: ("勉强写出来", "能过，但心虚"),
    4: ("顺利写完", "稳"),
    5: ("秒杀", "这题我闭眼写"),
}


@dataclass
class SM2State:
    """一道题在某个时刻的复习状态。"""

    repetitions: int = 0   # 连续答对次数
    interval: int = 0      # 当前间隔（天）
    ef: float = EF_DEFAULT  # 难度系数


@dataclass
class SM2Result:
    repetitions: int
    interval: int
    ef: float
    due: date
    passed: bool
    label: str


def update_ef(ef: float, quality: int) -> float:
    """EF' = EF + (0.1 - (5-q) * (0.08 + (5-q) * 0.02))"""
    delta = 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)
    return round(min(EF_MAX, max(EF_MIN, ef + delta)), 2)


def next_interval(repetitions: int, previous_interval: int, ef: float) -> int:
    """算出下一次间隔（天）。

    repetitions = 本次评分后「连续答对的次数」（1-based）：
        1 → 1 天（刚记住，明天必须来）
        2 → 3 天
        n → 上一次间隔 × EF
    """
    if repetitions <= 1:
        return FIRST_INTERVAL
    if repetitions == 2:
        return SECOND_INTERVAL
    base = previous_interval if previous_interval > 0 else SECOND_INTERVAL
    return max(1, int(round(base * ef)))


def review(state: SM2State, quality: int, today: date | None = None) -> SM2Result:
    """吃进当前状态和本次评分，吐出新的复习安排。"""
    if quality not in range(6):
        raise ValueError(f"评分必须是 0-5，收到 {quality!r}")
    today = today or date.today()

    if quality < 3:
        # 答错：连击清零，明天再来（但 EF 仍然按公式下降一点，记录这题变难了）
        new_ef = update_ef(state.ef, quality)
        new_ef = max(EF_MIN, new_ef)
        return SM2Result(
            repetitions=0,
            interval=FIRST_INTERVAL,
            ef=new_ef,
            due=today + timedelta(days=FIRST_INTERVAL),
            passed=False,
            label=QUALITY_LABELS[quality][0],
        )

    new_ef = update_ef(state.ef, quality)
    reps = state.repetitions + 1
    interval = next_interval(reps, state.interval, new_ef)
    return SM2Result(
        repetitions=reps,
        interval=interval,
        ef=new_ef,
        due=today + timedelta(days=interval),
        passed=True,
        label=QUALITY_LABELS[quality][0],
    )


def human_interval(days: int) -> str:
    """把天数说人话。"""
    if days <= 0:
        return "今天"
    if days == 1:
        return "明天"
    if days < 7:
        return f"{days} 天后"
    if days < 30:
        weeks = days / 7
        return f"{days} 天后（约 {weeks:.1f} 周）"
    if days < 365:
        return f"{days} 天后（约 {days / 30:.1f} 个月）"
    return f"{days} 天后（约 {days / 365:.1f} 年）"


def maturity(repetitions: int, interval: int) -> str:
    """给题目分级：新题 / 学习中 / 复习中 / 已掌握。"""
    if repetitions == 0:
        return "新题"
    if interval < 7:
        return "学习中"
    if interval < 30:
        return "复习中"
    return "已掌握"


def forecast(states: list[SM2State], days: int = 30) -> dict[int, int]:
    """简单预测未来几天每天大概要复习多少题（不含答错回流）。"""
    buckets: dict[int, int] = {}
    for st in states:
        d = min(st.interval, days)
        buckets[d] = buckets.get(d, 0) + 1
    return buckets


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    today = date(2026, 1, 1)

    # 1. 全对：间隔应该是 1 → 3 → 3*EF → ...
    st = SM2State()
    r1 = review(st, 5, today)
    assert r1.interval == 1, r1
    assert r1.repetitions == 1
    assert r1.ef == 2.6, r1.ef  # q=5 → EF +0.1

    st = SM2State(r1.repetitions, r1.interval, r1.ef)
    r2 = review(st, 5, today)
    assert r2.interval == 3, r2

    st = SM2State(r2.repetitions, r2.interval, r2.ef)
    r3 = review(st, 5, today)
    assert r3.interval == int(round(3 * 2.7)) == 8, r3
    assert r3.due == today + timedelta(days=8)

    # 1b. q=3 首次答对也只给 1 天（不跳级）
    st = SM2State()
    r = review(st, 3, today)
    assert r.passed is True and r.interval == 1, r
    # 第二次仍只给 3 天
    r = review(SM2State(r.repetitions, r.interval, r.ef), 3, today)
    assert r.interval == 3, r

    # 2. 答错：连击清零、间隔回 1、EF 下降且有下限
    st = SM2State(repetitions=9, interval=120, ef=2.5)
    bad = review(st, 0, today)
    assert bad.repetitions == 0
    assert bad.interval == 1
    assert bad.passed is False
    assert bad.ef < 2.5

    # 3. EF 下限不会被击穿
    ef = EF_DEFAULT
    for _ in range(50):
        ef = update_ef(ef, 0)
    assert ef == EF_MIN, ef

    # 4. EF 上限
    ef = EF_DEFAULT
    for _ in range(50):
        ef = update_ef(ef, 5)
    assert ef == EF_MAX, ef

    # 5. q=3 算通过，但 EF 下降（2.5 + 0.1 - 2*0.14 = 2.36）
    st = SM2State()
    r = review(st, 3, today)
    assert r.passed is True
    assert r.ef == 2.36, r.ef

    # 6. 非法评分要报错
    try:
        review(SM2State(), 7, today)
        raise AssertionError("应该抛 ValueError")
    except ValueError:
        pass

    print("sm2 selftest: 6 组断言全部通过 ✓")


if __name__ == "__main__":
    _selftest()
