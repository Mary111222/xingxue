"""测试辅助：给自测一个「用完就消失」的临时目录。

为什么需要：自测里会调到 cfg.save()，如果数据目录用的是 Path(".")，
就会在调用者的工作目录里留下 config.json 之类的垃圾。
（这坑踩过：仓库根目录莫名多出一个 config.json。）
"""

from __future__ import annotations

import os
import shutil
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


def _usable(path: Path) -> bool:
    """光能建目录还不够——受限沙箱里常见「目录建得出来、文件写不进去」。

    所以这里真的写一个探针文件再删掉，确认这个目录是可用的。
    """
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".write-probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return True
    except OSError:
        return False


@contextmanager
def temp_home(prefix: str = ".selftest") -> Iterator[Path]:
    """产出一个临时数据目录，退出时删掉。

    优先系统 temp；确认不可写（受限沙箱、只读临时区）就退到当前目录下，
    名字里带进程号，避免并发跑测试时互相踩。
    """
    candidate: Path | None = None
    try:
        import tempfile

        candidate = Path(tempfile.mkdtemp(prefix=prefix + "-"))
    except OSError:
        candidate = None

    if candidate is None or not _usable(candidate):
        if candidate is not None:
            shutil.rmtree(candidate, ignore_errors=True)
        candidate = Path.cwd() / f"{prefix}-{os.getpid()}"
        candidate.mkdir(parents=True, exist_ok=True)
    try:
        yield candidate
    finally:
        shutil.rmtree(candidate, ignore_errors=True)
