"""命令实现（三）：导入导出、自检。

导出不只是导出题单——便签、倒数日、提醒也一起走，
这样「她的东西」能整体搬到另一台电脑上。
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from . import bank, bilisum, curriculum, deps, evidence, features, gem, io_formats
from . import learning, mascot, panels
from . import avatar, cet6, cycle, encouragement
from . import failures as failures_mod
from . import queue as queue_mod
from . import plugins as plugins_mod
from . import search, sm2, ui
from .panels import PATTERN_LABELS, reminder_when


def cmd_import(args, ctx) -> int:
    from . import failures

    items = io_formats.parse_any(args.path, fmt=args.format)
    if not items:
        ui.err(f"没能从 {args.path} 里解析出题目")
        ui.info("支持：CSV / Markdown（含题目链接的笔记）/ JSON")
        failures.record(
            ctx.store, "import", "导入时没解析出题目",
            detail=f"文件：{args.path}",
            retry=f'her import "{args.path}"',
        )
        return 1

    # JSON 备份里带学习状态和便签，走 load_dump 才能完整恢复
    target = Path(args.path)
    if target.exists() and target.suffix.lower() == ".json":
        import json as _json

        try:
            payload = _json.loads(target.read_text(encoding="utf-8", errors="replace"))
        except _json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict) and "problems" in payload:
            p_count, r_count, n_count, c_count, m_count = ctx.store.load_dump(payload)
            ui.ok(f"已恢复 {p_count} 道题、{r_count} 条复习记录")
            extra = []
            if n_count:
                extra.append(f"{n_count} 张便签")
            if c_count:
                extra.append(f"{c_count} 个倒数日")
            if m_count:
                extra.append(f"{m_count} 条提醒")
            if extra:
                ui.info("另外恢复了 " + "、".join(extra))
            return 0

    if args.dry_run:
        for item in items:
            print(f"  [{item['difficulty']}] {item['title']}  {' '.join(item['tags'])}")
        ui.info(f"共解析出 {len(items)} 道（dry-run，未写库）")
        return 0

    added = ctx.store.add_many(items)
    skipped = len(items) - added
    ui.ok(f"导入 {added} 道" + (f"，跳过重复 {skipped} 道" if skipped else ""))
    # 把导进来的题目名报出来：不然她只看到「导入 3 道」，不知道是哪 3 道
    for item in items[:12]:
        ui.info("  · " + item["title"])
    if len(items) > 12:
        ui.info(f"  · …还有 {len(items) - 12} 道，用 her list 看全部")
    ui.info(f"题库总数 {ctx.store.count()} 道")
    return 0


def cmd_export(args, ctx) -> int:
    problems = ctx.store.all(include_archived=True)
    if not problems and not ctx.store.notes():
        ui.err("题库是空的，没什么可导出")
        return 1

    if args.format == "csv":
        text, suffix = io_formats.to_csv(problems), ".csv"
    elif args.format == "markdown":
        title = (ctx.cfg.name + "的题单") if ctx.cfg.name else "题单"
        text, suffix = io_formats.to_markdown(problems, title), ".md"
    else:
        text, suffix = io_formats.to_json(ctx.store.dump()), ".json"

    if args.output:
        path = Path(args.output)
    else:
        out_dir = ctx.cfg.home / "export"
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"her-review-{datetime.now():%Y%m%d-%H%M%S}{suffix}"
    path.write_text(text, encoding="utf-8")
    ui.ok(f"已导出 {len(problems)} 道题到 {path}")

    if args.format == "markdown" or getattr(args, "extras", False):
        extras = _export_extras(ctx)
        if extras:
            extra_path = path.with_name(path.stem + "-便签倒数日.md")
            extra_path.write_text(extras, encoding="utf-8")
            ui.ok(f"便签 / 倒数日 / 提醒也导出了：{extra_path}")

    if args.format == "json":
        ui.info("这个文件可以在另一台电脑上 her import 恢复，学习进度和便签一起带走")
    return 0


def _export_extras(ctx) -> str:
    """把便签、倒数日、提醒导成 Markdown。"""
    notes = ctx.store.notes(include_archived=True)
    days = ctx.store.countdowns(include_archived=True)
    reminders = ctx.store.reminders()
    if not (notes or days or reminders):
        return ""
    lines = ["# 便签 / 倒数日 / 提醒", ""]
    if notes:
        lines.append("## 便签")
        lines.append("")
        for row in notes:
            marks = []
            if row["pinned"]:
                marks.append("置顶")
            if row["archived"]:
                marks.append("已归档")
            suffix = f"　（{'、'.join(marks)}）" if marks else ""
            lines.append(f"- {row['body']}{suffix}")
        lines.append("")
    if days:
        lines.append("## 倒数日")
        lines.append("")
        for row in days:
            repeat = "　每年重复" if row["yearly"] else ""
            note = f"　{row['note']}" if row["note"] else ""
            lines.append(f"- {row['target']}　{row['title']}{repeat}{note}")
        lines.append("")
    if reminders:
        lines.append("## 提醒")
        lines.append("")
        for row in reminders:
            state = "" if row["enabled"] else "（已停用）"
            lines.append(
                f"- {row['body']}　{PATTERN_LABELS.get(row['pattern'], row['pattern'])}"
                f"　{reminder_when(row)}{state}"
            )
        lines.append("")
    return "\n".join(lines)


def cmd_doctor(args, ctx) -> int:
    """自检：把「为什么不能用」一次性讲清楚。"""
    width = ui.term_width()
    lines: list[str] = []

    from . import __version__

    lines.append(ui.c("程序版本  ", "grey") + ui.c(f"her-review {__version__}", ctx.theme.accent))
    lines.append(ui.c("数据目录  ", "grey") + ui.c(str(ctx.cfg.home), "grey"))
    lines.append(ui.c("数据库    ", "grey") + ui.c(str(ctx.cfg.db_path), "grey")
                 + ui.c(f"  （{'存在' if ctx.cfg.db_path.exists() else '还没建'}）", "grey"))
    lines.append(ui.c("题库      ", "grey") + ui.c(f"{ctx.store.count()} 道", ctx.theme.accent))
    lines.append(ui.c("配色种子  ", "grey") + ui.c(ctx.theme.name(), ctx.theme.primary)
                 + ui.c(f"  (seed {ctx.theme.seed})", "grey"))
    lines.append("")
    lines.append(ui.c("终端      ", "grey")
                 + ui.c(f"{ui.term_width()}×{ui.term_height()}", "grey")
                 + ui.c(f"  颜色{'可用' if ui.has_color() else '已关闭（不影响使用）'}", "grey"))
    lines.append(ui.c("名字      ", "grey") + ui.c(ctx.cfg.name or "（未设置）", "grey"))
    birthday_hint = ""
    if ctx.birthday:
        left = gem.days_until_birthday(ctx.birthday, ctx.today())
        birthday_hint = f"  距离 {left} 天" if left is not None else ""
    lines.append(ui.c("生日      ", "grey") + ui.c(ctx.cfg.birthday or "（未设置）", "grey")
                 + ui.c(birthday_hint, "grey"))
    lines.append("")

    online = search.http_available()
    lines.append(ui.c("B 站搜索  ", "grey")
                 + (ui.c("在线（终端里直接看结果）", "brightgreen") if online
                    else ui.c("离线（仍然可以生成搜索链接并打开浏览器）", "gold")))
    ok, detail = search.bilisum_available()
    lines.append(ui.c("视频总结器 ", "grey")
                 + (ui.c("可用", "brightgreen") + ui.c(f"  {detail}", "grey") if ok
                    else ui.c(detail, "gold")))
    lines.append(ui.c("桌面端服务 ", "grey")
                 + (ui.c("127.0.0.1:3838 在线", "brightgreen") if search.desktop_running()
                    else ui.c("未运行（总结时会尝试拉起）", "grey")))

    # 面板与插件
    order = ctx.cfg.panel_order()
    lines.append("")
    lines.append(ui.c("首页面板  ", "grey")
                 + ui.c("、".join(order) if order else "（全部关掉了）", "plum"))
    runtime = getattr(ctx, "plugins", None)
    if runtime is not None:
        total = len(runtime.infos)
        bad = sum(1 for i in runtime.infos.values() if i.state == plugins_mod.STATE_ERROR)
        disabled = sum(1 for i in runtime.infos.values()
                       if i.state == plugins_mod.STATE_DISABLED)
        summary = f"{total} 个" if total else "还没有插件"
        if bad:
            summary += ui.c(f"（{bad} 个加载失败）", "red")
        if disabled:
            summary += ui.c(f"（{disabled} 个已停用）", "grey")
        lines.append(ui.c("插件      ", "grey") + ui.c(summary, "plum")
                     + ui.c(f"  {runtime.plugins_dir}", "grey"))
    lines.append(ui.c("便签 / 倒数日 ", "grey")
                 + ui.c(f"{len(ctx.store.notes())} 张 / {len(ctx.store.countdowns())} 个", "plum")
                 + ui.c(f"    提醒 {len(ctx.store.reminders())} 条", "plum"))

    # 可选增强库（bootstrap.py 装的）
    from . import deps

    report = deps.capability_report()
    ready = [i for i in report if i["available"]]
    lines.append("")
    lines.append(ui.c("增强库    ", "grey")
                 + ui.c(f"{len(ready)}/{len(report)} 可用", "brightgreen" if ready else "gold"))
    for item in report:
        mark = ui.c("●", "brightgreen") if item["available"] else ui.c("○", "grey")
        version = ui.c(f" {item['version']}", "grey") if item["version"] else ""
        lines.append(f"  {mark} " + ui.c(ui.pad(item["name"], 14), "plum")
                     + version + ui.c("  " + item["purpose"], "grey"))
    if not ready:
        lines.append("  " + ui.c("装法：python bootstrap.py（不装也能完整运行）", "grey"))

    print(ui.box("自检", lines, width=width, style=ctx.theme.primary))
    return 0


def cmd_selftest(args, ctx) -> int:
    print(ui.c("跑单元自测（不碰你的数据）", ctx.theme.primary, "bold"))
    print()
    sm2._selftest()
    search._selftest()
    io_formats._selftest()
    mascot._selftest()
    panels._selftest()
    plugins_mod._selftest()
    features._selftest()
    learning._selftest()
    curriculum._selftest()
    bilisum._selftest()
    evidence._selftest()
    failures_mod._selftest()
    queue_mod._selftest()
    encouragement._selftest()
    avatar._selftest()
    cet6._selftest()
    cycle._selftest()
    bank_titles = [b["title"] for b in bank.BANK]
    assert len(bank_titles) == len(set(bank_titles))
    print(f"bank: {len(bank.BANK)} 道题，无重名 ✓")
    print()
    ui.ok("全部通过")
    return 0
