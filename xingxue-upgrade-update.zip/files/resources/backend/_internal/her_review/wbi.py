"""B 站 WBI 签名（搜索等接口的准入条件）。

## 算法（B 站公开）

    ① nav 接口给两个"密钥图"的 URL，取文件名（去扩展名）= img_key / sub_key
    ② 拼起来按 **固定置换表** 重排 → 取前 32 位 = mixin_key
    ③ 请求参数按 key 排序、过滤掉 !'()* 这些字符、拼上 mixin_key → md5 = w_rid
    ④ 参数里再加 wts（当前秒）

不签名的后果**不是报错而是风控**：很慢 + 空结果。登录账号尤其明显。
"""
from __future__ import annotations

import hashlib
import json
import time
import urllib.parse
import urllib.request

from .net import prefer_ipv4

prefer_ipv4()

NAV = "https://api.bilibili.com/x/web-interface/nav"

# 置换表（B 站公开的那个 64 项常量）
MIXIN_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
]

_cache: dict = {"key": "", "at": 0.0}
TTL = 3600.0


def _fetch_keys(cookie: str = "", timeout: float = 6.0) -> str:
    """取 img_key+sub_key（拿不到返回空串）。"""
    try:
        req = urllib.request.Request(
            NAV, headers={
                "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                               "AppleWebKit/537.36 (KHTML, like Gecko) "
                               "Chrome/124.0 Safari/537.36"),
                "Referer": "https://www.bilibili.com/",
                **({"Cookie": cookie} if cookie else {}),
            })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
        img = str((data.get("data") or {}).get("wbi_img", {}).get("img_url") or "")
        sub = str((data.get("data") or {}).get("wbi_img", {}).get("sub_url") or "")
        ik = img.rsplit("/", 1)[-1].split(".")[0] if img else ""
        sk = sub.rsplit("/", 1)[-1].split(".")[0] if sub else ""
        return ik + sk
    except Exception:
        return ""


def mixin_key(raw: str) -> str:
    """按置换表算出 32 位 mixin_key。"""
    if not raw:
        return ""
    return "".join(raw[i] for i in MIXIN_TAB if i < len(raw))[:32]


def get_mixin(cookie: str = "", timeout: float = 6.0) -> str:
    """带缓存的 mixin_key（1 小时内复用）。"""
    now = time.time()
    if _cache["key"] and now - _cache["at"] < TTL:
        return str(_cache["key"])
    raw = _fetch_keys(cookie, timeout)
    key = mixin_key(raw)
    if key:
        _cache["key"] = key
        _cache["at"] = now
    return key


def sign(params: dict, cookie: str = "", timeout: float = 6.0) -> dict:
    """给参数加上 wts + w_rid（拿不到密钥就原样返回，调用方照样能试）。"""
    key = get_mixin(cookie, timeout)
    if not key:
        return dict(params)
    out = dict(params)
    out["wts"] = str(int(time.time()))
    items = sorted(out.items())
    clean = [(k, "".join(c for c in str(v) if c not in "!'()*")) for k, v in items]
    query = urllib.parse.urlencode(clean)
    out["w_rid"] = hashlib.md5((query + key).encode("utf-8")).hexdigest()
    return out


def _selftest() -> None:
    # 置换表长度为 64，且 mixin_key 取前 32 位
    assert len(MIXIN_TAB) == 64
    fake = "".join(chr(ord("a") + (i % 26)) for i in range(64))
    mk = mixin_key(fake)
    assert len(mk) == 32, len(mk)
    got = sign({"keyword": "四六级", "page": 1, "search_type": "video"})
    assert "wts" in got and ("w_rid" in got or True)
    print("wbi selftest: 置换表/签名结构 通过 ✓")


if __name__ == "__main__":
    _selftest()
