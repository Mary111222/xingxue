"""python -m her_review 的入口。

先激活 .pylibs（bootstrap.py 装的可选依赖），再导入程序本体——
顺序很重要：rich / httpx 这些要在被 import 之前就出现在 sys.path 里。
"""

import sys


def _activate_local_libs() -> None:
    """把程序目录下的 .pylibs 加进 sys.path。

    这里刻意不 import 包内模块：要走最小依赖路径，
    哪怕 her_review 里别的文件坏了，这一步也不该受影响。
    """
    try:
        from pathlib import Path

        target = Path(__file__).resolve().parent.parent / ".pylibs"
        if target.is_dir():
            entry = str(target)
            if entry not in sys.path:
                sys.path.insert(0, entry)
    except Exception:
        pass


_activate_local_libs()

from .cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
