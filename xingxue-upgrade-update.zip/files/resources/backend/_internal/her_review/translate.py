"""翻译。

用户要求："翻译的水平要高，可以去查找开源的翻译软件里面的翻译逻辑然后
嵌入进去"。

## 先说清楚这个模块能做到什么、不能做到什么

**做不到**：自己"生成"高质量翻译。这台机器上没有可用的本地大模型，
而这个程序的底线是零依赖——所以不存在"内置一个翻译引擎"这条路。

**能做到**：接入现成的翻译服务，并且**在它前后加两层处理来提高实际质量**。
开源翻译工具（pot-app、STranslate 这类）用的也是同样的路子：
不自己训练模型，而是调服务 + 自带词典兜底 + 术语保护。

## 三层结构（按优先级）

    第一层  术语保护  —— 翻译**之前**把专业词抽出来换成占位符，
                        翻译完再填回去。
                        为什么需要：机器翻译在专业词上错得最离谱。
                        实测 MyMemory 把「动态规划」译成了
                        "dynamic planning"（正确是 "dynamic programming"），
                        把「回溯」译成 "backtracking"（这个对了）——
                        错的那些恰恰是她最需要的词。

    第二层  在线翻译  —— MyMemory（实测唯一可用的免费接口）。
                        试过但不可用的：
                          · Google 非官方端点 translate.googleapis.com
                            → 连接被拒绝（这台机器上不通）
                          · LibreTranslate 公共实例 → HTTP 403
                        所以只保留能用的，并且在界面上如实说明来源。

    第三层  离线兜底  —— 网络不通时用内置词表逐词翻译，
                        并明确告诉她"这是词表直译，不是完整翻译"。
                        宁可说清楚是降级结果，也不要假装翻译好了。

## 为什么术语保护放在前面

对她来说翻译的用途很明确：看英文题面、看英文文档、写英文注释。
这些场景里错一个专业词，整句话就理解反了；
而语法上的小毛病反而无所谓。
所以把力气花在术语上，是性价比最高的地方。
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request

from . import dictionary

# --------------------------------------------------------------------------
# 术语表
# --------------------------------------------------------------------------
#
# 收录标准：机器翻译**实测译错**、或者虽然译对但不符合 CS 习惯的词。
# 不是"越多越好"——词表里的词会被强制替换，收错了反而会破坏
# 本来正确的翻译。所以只收能确证的。
#
# 格式：{中文: 英文}
TERMS_ZH_EN: dict[str, str] = {
    # 算法与数据结构
    "动态规划": "dynamic programming",
    "记忆化搜索": "memoized search",
    "回溯": "backtracking",
    "贪心": "greedy",
    "分治": "divide and conquer",
    "二分查找": "binary search",
    "双指针": "two pointers",
    "滑动窗口": "sliding window",
    "前缀和": "prefix sum",
    "并查集": "union-find",
    "单调栈": "monotonic stack",
    "拓扑排序": "topological sort",
    "广度优先搜索": "breadth-first search",
    "深度优先搜索": "depth-first search",
    "哈希表": "hash table",
    "链表": "linked list",
    "二叉树": "binary tree",
    "二叉搜索树": "binary search tree",
    "平衡树": "balanced tree",
    "堆": "heap",
    "队列": "queue",
    "栈": "stack",
    "图": "graph",
    "邻接矩阵": "adjacency matrix",
    "邻接表": "adjacency list",
    "最短路径": "shortest path",
    "最小生成树": "minimum spanning tree",
    "时间复杂度": "time complexity",
    "空间复杂度": "space complexity",
    "递归": "recursion",
    "迭代": "iteration",
    "边界条件": "edge case",
    "溢出": "overflow",
    "位运算": "bit manipulation",
    "状态转移方程": "state transition equation",
    "最优子结构": "optimal substructure",
    "重叠子问题": "overlapping subproblems",
    # 计算机系统
    "操作系统": "operating system",
    "进程": "process",
    "线程": "thread",
    "死锁": "deadlock",
    "虚拟内存": "virtual memory",
    "页表": "page table",
    "缓存": "cache",
    "缓存命中": "cache hit",
    "中断": "interrupt",
    "系统调用": "system call",
    "上下文切换": "context switch",
    "并发": "concurrency",
    "并行": "parallelism",
    "原子操作": "atomic operation",
    "竞态条件": "race condition",
    # 网络
    "传输控制协议": "TCP",
    "三次握手": "three-way handshake",
    "四次挥手": "four-way handshake",
    "拥塞控制": "congestion control",
    "流量控制": "flow control",
    "子网掩码": "subnet mask",
    "域名解析": "DNS resolution",
    # 数据库
    "事务": "transaction",
    "索引": "index",
    "主键": "primary key",
    "外键": "foreign key",
    "范式": "normal form",
    "隔离级别": "isolation level",
    "脏读": "dirty read",
    # 软件工程
    "单元测试": "unit test",
    "集成测试": "integration test",
    "重构": "refactoring",
    "设计模式": "design pattern",
    "单一职责": "single responsibility",
    "依赖注入": "dependency injection",
    "版本控制": "version control",
    "代码审查": "code review",
    "持续集成": "continuous integration",
    # 数学（她做题会遇到）
    "质数": "prime number",
    "合数": "composite number",
    "公约数": "common divisor",
    "公倍数": "common multiple",
    "阶乘": "factorial",
    "排列组合": "permutation and combination",
    "期望值": "expected value",
    "方差": "variance",
    "标准差": "standard deviation",
    "概率分布": "probability distribution",
}

# 英文 → 中文（反向查表，用于英译中时保护术语）
TERMS_EN_ZH: dict[str, str] = {}
for _zh, _en in TERMS_ZH_EN.items():
    # 只收单词/固定短语，避免 "dynamic programming" 这种多词短语
    # 在英译中时把普通句子也替换掉
    if " " not in _en and _en.isascii():
        TERMS_EN_ZH.setdefault(_en.lower(), _zh)
# 补几个常见缩写（上面的生成规则收不到）
TERMS_EN_ZH.update({
    "dp": "动态规划",
    "bfs": "广度优先搜索",
    "dfs": "深度优先搜索",
    "tcp": "传输控制协议",
    "dns": "域名系统",
    "sql": "结构化查询语言",
    "api": "应用程序接口",
})

# --------------------------------------------------------------------------
# 常用词表（离线兜底用）
# --------------------------------------------------------------------------
#
# 只收最常用的，不是"完整词典"——它的作用是网络不通时
# 至少能把一句话的大意拼出来，并且**明确告诉用户这是降级结果**。
OFFLINE_ZH_EN: dict[str, str] = {
    **TERMS_ZH_EN,
    "我": "I", "你": "you", "他": "he", "她": "she", "它": "it",
    "是": "is", "不": "not", "的": "", "了": "", "在": "at",
    "和": "and", "或者": "or", "但是": "but", "因为": "because",
    "所以": "so", "如果": "if", "那么": "then", "这": "this", "那": "that",
    "一个": "a", "问题": "problem", "方法": "method", "结果": "result",
    "数据": "data", "函数": "function", "变量": "variable", "数组": "array",
    "字符串": "string", "数字": "number", "时间": "time", "空间": "space",
    "需要": "need", "可以": "can", "应该": "should", "必须": "must",
    "计算": "compute", "存储": "store", "返回": "return", "输入": "input",
    "输出": "output", "增加": "increase", "减少": "decrease",
    "最大": "maximum", "最小": "minimum", "第一个": "first",
    "最后一个": "last", "每个": "each", "所有": "all", "相同": "same",
    "不同": "different", "简单": "simple", "复杂": "complex",
    "快": "fast", "慢": "slow", "好": "good", "坏": "bad",
}

# 语言代码：MyMemory 用的是不带地区的两位码
LANGUAGES: dict[str, str] = {
    "zh-CN": "中文",
    "en": "英语",
    "ja": "日语",
    "ko": "韩语",
    "fr": "法语",
    "de": "德语",
    "es": "西班牙语",
    "ru": "俄语",
}

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")

# 术语占位符：**用方括号包起来的标记**。
#
# 试过三种，只有这一种能活下来（实测 MyMemory）：
#     不可见分隔符 \u2063  → 被吞掉，译文变成 "This question is faster with 0 and 0"
#     私有区字符 \ue000    → 也被吞掉
#     方括号 [[[0]]]       → **原样保留** ✓
# 所以用方括号。数字放中间，翻译完按编号填回术语。
_PH = "[[[{i}]]]"
_PH_RE = re.compile(r"\[\[\[(\d+)\]\]\]")


class TranslateError(Exception):
    """翻译失败（网络不通、服务拒绝等）。"""


# --------------------------------------------------------------------------
# 语言判断
# --------------------------------------------------------------------------

def detect_language(text: str) -> str:
    """粗略判断语种，只区分"中文"和"非中文"。

    不做真正的语种识别（那要引模型）——这里只需要回答
    "该翻成中文还是翻成英文"，中日韩以外的语言按英文处理。
    """
    han = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
    kana = sum(1 for ch in text if "\u3040" <= ch <= "\u30ff")
    hangul = sum(1 for ch in text if "\uac00" <= ch <= "\ud7af")
    letters = sum(1 for ch in text if ch.isalpha())
    if letters == 0:
        return "en"
    if kana:
        return "ja"
    if hangul:
        return "ko"
    # 汉字占比高就是中文（日语里也有汉字，但上面已经被假名判走了）
    return "zh-CN" if han * 2 >= letters else "en"


def auto_target(text: str) -> tuple[str, str]:
    """按输入内容决定 (源语言, 目标语言)。"""
    src = detect_language(text)
    dst = "en" if src == "zh-CN" else "zh-CN"
    return src, dst


# --------------------------------------------------------------------------
# 术语保护
# --------------------------------------------------------------------------

def protect_terms(text: str, src: str) -> tuple[str, list[tuple[str, str]]]:
    """把术语换成占位符。返回 (改过的文本, [(占位符, 译文术语), ...])。

    为什么要这一步：机器翻译在专业词上错得最离谱。
    实测 MyMemory 把「动态规划」译成 "dynamic planning"，
    而正确说法是 "dynamic programming"——恰恰是她最需要的词。
    换成占位符之后，这个词由我们自己的词表决定，服务碰不到它。
    """
    table = TERMS_ZH_EN if src == "zh-CN" else TERMS_EN_ZH
    if not table:
        return text, []

    # 长词优先：先替换「二叉搜索树」，再替换「二叉树」，
    # 否则短词会先把长词切碎
    keys = sorted(table.keys(), key=len, reverse=True)
    swaps: list[tuple[str, str]] = []
    out = text
    for key in keys:
        if src != "zh-CN":
            # 英译中：按词边界匹配，避免把 "heap" 匹配进 "cheap"
            pattern = re.compile(rf"\b{re.escape(key)}\b", re.IGNORECASE)
        else:
            pattern = re.compile(re.escape(key))
        if not pattern.search(out):
            continue
        ph = _PH.format(i=len(swaps))
        new_out, n = pattern.subn(ph, out)
        if n:
            out = new_out
            swaps.append((ph, table[key]))
    return out, swaps


def restore_terms(text: str, swaps: list[tuple[str, str]]) -> str:
    """把占位符填回术语译文。

    用**按编号回填**而不是逐个字符串替换：
    有些服务会把 `[[[0]]]` 改写成 `[[[ 0 ]]]` 或者在中间插空格，
    按编号匹配能容忍这些变化。
    """
    by_index = {}
    for ph, term in swaps:
        m = _PH_RE.fullmatch(ph)
        if m:
            by_index[m.group(1)] = term

    def sub(match: re.Match) -> str:
        return by_index.get(match.group(1), match.group(0))

    return _PH_RE.sub(sub, text)


# --------------------------------------------------------------------------
# 常用短语表
# --------------------------------------------------------------------------
#
# 为什么需要：MyMemory 是**众包翻译记忆库**，不是神经网络翻译。
# 实测短句质量不稳，而且不稳的方式很尴尬：
#     「我爱你」  → 「你很笨」        ✗ 完全错，而且是会让人不舒服的那种错
#     「how are you」→「你好 , 我正在使用」  ✗ 截断
# 而长一点的句子反而更稳（「今天天气很好」→ It's a nice day ✓）。
#
# 这些常用短句本来也没有歧义，查表比调服务更准、更快、还能离线用。
# 所以：常用短语直接查表，不走网络。
#
# 收词原则：**只收确证过的**。不为了凑数往里塞——
# 表里的词会覆盖在线结果，塞错了反而更糟。
PHRASES_ZH_EN: dict[str, str] = {
    # 会真的用到的日常/学习短句
    "我爱你": "I love you",
    "我喜欢你": "I like you",
    "我想你": "I miss you",
    "你好": "Hello",
    "您好": "Hello",
    "早上好": "Good morning",
    "中午好": "Good afternoon",
    "晚上好": "Good evening",
    "晚安": "Good night",
    "谢谢": "Thank you",
    "谢谢你": "Thank you",
    "非常感谢": "Thank you very much",
    "不客气": "You're welcome",
    "对不起": "Sorry",
    "抱歉": "Sorry",
    "没关系": "It's okay",
    "再见": "Goodbye",
    "请": "Please",
    "好的": "Okay",
    "是的": "Yes",
    "不是": "No",
    "我明白了": "I understand",
    "我不明白": "I don't understand",
    "你会说英语吗": "Do you speak English?",
    "这个多少钱": "How much is this?",
    "生日快乐": "Happy birthday",
    "新年快乐": "Happy New Year",
    "加油": "Keep it up",
    "辛苦了": "Thanks for your hard work",
    "好久不见": "Long time no see",
    "注意安全": "Take care",
    "多喝热水": "Drink more warm water",
    "早点休息": "Get some rest early",
    "别太累了": "Don't work too hard",
    # 学习场景
    "这道题怎么做": "How do I solve this problem?",
    "我看不懂": "I don't understand it",
    "能再讲一遍吗": "Could you explain it again?",
    "有例子吗": "Is there an example?",
    "谢谢老师": "Thank you, teacher",
}

PHRASES_EN_ZH: dict[str, str] = {
    "i love you": "我爱你",
    "i like you": "我喜欢你",
    "i miss you": "我想你",
    "hello": "你好",
    "hi": "你好",
    "good morning": "早上好",
    "good afternoon": "下午好",
    "good evening": "晚上好",
    "good night": "晚安",
    "thank you": "谢谢",
    "thanks": "谢谢",
    "thank you very much": "非常感谢",
    "you're welcome": "不客气",
    "sorry": "对不起",
    "i'm sorry": "对不起",
    "it's okay": "没关系",
    "goodbye": "再见",
    "bye": "再见",
    "please": "请",
    "okay": "好的",
    "yes": "是的",
    "no": "不是",
    "i understand": "我明白了",
    "i don't understand": "我不明白",
    "do you speak english": "你会说英语吗",
    "how much is this": "这个多少钱",
    "happy birthday": "生日快乐",
    "happy new year": "新年快乐",
    "long time no see": "好久不见",
    "take care": "注意安全",
    "how are you": "你好吗",
    "i'm fine": "我很好",
    "excuse me": "打扰一下",
    "see you": "再见",
    "nice to meet you": "很高兴认识你",
}


def lookup_phrase(text: str, src: str) -> str:
    """查常用短语表。查不到返回空串。

    只在**整段输入正好等于一个短语**时才返回——
    做子串替换会把句子改得面目全非。
    """
    key = str(text or "").strip().lower().rstrip("。.！!？?~～")
    if not key:
        return ""
    table = PHRASES_ZH_EN if src == "zh-CN" else PHRASES_EN_ZH
    if src == "zh-CN":
        return table.get(key, "")
    return table.get(key, "")


def output_matches_language(text: str, target: str) -> bool:
    """粗略检查译文是不是目标语言。

    为什么要查：MyMemory 是众包库，实测会返回**语种都不对**的结果——
        「我爱你」(zh→en) → 「你很笨」（还是中文）
    这种错如果直接显示出来，比"翻译失败"更糟：她不会怀疑译文，
    只会照着理解。所以宁可判定为失败、走别的路径。
    """
    if not text:
        return False
    got = detect_language(text)
    want = "zh-CN" if target.startswith("zh") else target
    if want == "zh-CN":
        return got == "zh-CN"
    # 目标是其它语言时，只要不是中文就算过
    # （因为 detect_language 只区分"中文/非中文"，再细就不准了）
    return got != "zh-CN"


# --------------------------------------------------------------------------
# 翻译服务
# --------------------------------------------------------------------------

def _http_get(url: str, timeout: float = 15.0) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", "replace")


def translate_mymemory(text: str, src: str, dst: str) -> str:
    """MyMemory 免费接口。

    实测这是这台机器上**唯一可用**的免费翻译接口：
        · Google 的非官方端点（开源工具最常用的那个）→ 连接被拒绝
        · LibreTranslate 公共实例 → HTTP 403
    所以主力用它，并且界面上如实标注来源。
    """
    q = urllib.parse.quote(text)
    pair = f"{src.split('-')[0]}|{dst.split('-')[0]}"
    url = (f"https://api.mymemory.translated.net/get?q={q}"
           f"&langpair={pair}&de=study@example.com")
    body = _http_get(url, timeout=20)
    data = json.loads(body)
    if not isinstance(data, dict):
        raise TranslateError("返回格式看不懂")
    status = data.get("responseStatus")
    if status and int(status) != 200:
        detail = data.get("responseDetails") or "服务返回错误"
        raise TranslateError(str(detail)[:120])
    out = (data.get("responseData") or {}).get("translatedText") or ""
    if not out:
        raise TranslateError("没有拿到译文")
    # MyMemory 有时会把没译出来的部分原样返回，并在末尾带提示
    out = re.sub(r"\s*MYMEMORY WARNING.*$", "", out, flags=re.IGNORECASE)
    return out.strip()


def _offline(text: str, src: str) -> tuple[str, int]:
    """离线兜底：拿内置词表逐词替换。返回 (译文, 命中词数)。"""
    table = OFFLINE_ZH_EN if src == "zh-CN" else {
        v: k for k, v in OFFLINE_ZH_EN.items() if v
    }
    keys = sorted(table.keys(), key=len, reverse=True)
    out = text
    hits = 0
    for key in keys:
        if src != "zh-CN":
            pattern = re.compile(rf"\b{re.escape(key)}\b", re.IGNORECASE)
        else:
            pattern = re.compile(re.escape(key))
        out, n = pattern.subn(table[key], out)
        hits += n
    if src == "zh-CN":
        # 中文没有词间空格，替换完要手动分词，不然会粘成一坨
        out = re.sub(r"(?<=[A-Za-z])(?=[\u4e00-\u9fff])", " ", out)
    out = re.sub(r"\s{2,}", " ", out).strip()
    return out, hits


# --------------------------------------------------------------------------
# 对外接口
# --------------------------------------------------------------------------

def translate(text: str, src: str = "", dst: str = "",
              *, use_terms: bool = True, timeout: float = 20.0) -> dict:
    """翻译一段文字。

    返回一个字典，除了译文还带**来源说明**——让界面能如实告诉用户
    这段译文是怎么来的：
        engine        用了哪个引擎
        engine_label  给人看的引擎名
        online        是不是真的走了在线翻译
        terms         保护并替换掉的术语数量
        note          需要提示她的话（降级、术语替换等）
    """
    text = (text or "").strip()
    if not text:
        raise TranslateError("先输入要翻译的内容。")
    if not src or not dst:
        auto_src, auto_dst = auto_target(text)
        src = src or auto_src
        dst = dst or auto_dst
    if src == dst:
        dst = "en" if src == "zh-CN" else "zh-CN"

    # 多义词：只有"输入正好是一个英文单词"时才展开。
    #
    # 为什么限定得这么死：整句翻译看的是句子意思，
    # 把一个词拆成四五个意思反而干扰阅读。
    # 而**单词查询恰恰相反**——在线服务对孤立的词只给一个答案，
    # 而且经常给最不常用的那个（address 只给「地址」，
    # 但她读代码文档时要的往往是「寻址」）。
    senses: list[dict] = []
    if dst == "zh-CN" and dictionary.is_single_word(text):
        for pos, meaning, hint, example in dictionary.lookup(text):
            senses.append({
                "pos": pos,
                "pos_name": dictionary.POS_NAMES.get(pos, pos),
                "meaning": meaning,
                "hint": hint,
                "example": example,
            })

    swaps: list[tuple[str, str]] = []
    payload = text
    if use_terms:
        payload, swaps = protect_terms(text, src)

    # 整段就是几个术语（比如只输入「动态规划」）时，
    # 送过去的内容几乎全是占位符，服务会返回毫不相关的东西
    # （实测返回过 "Twelve years ago"）。
    # 这种情况不需要翻译——直接把术语译文拼起来就行。
    if swaps and not _PH_RE.sub("", payload).strip():
        return {
            "source_text": text, "src": src, "dst": dst,
            "text": " ".join(t for _ph, t in swaps),
            "engine": "glossary", "engine_label": "内置术语表",
            "online": False, "terms": len(swaps), "senses": senses,
            "note": "输入的内容正好都是术语表里的词，直接查表给的结果。",
        }

    result: dict = {
        "source_text": text, "src": src, "dst": dst,
        "engine": "", "engine_label": "", "online": False,
        "terms": len(swaps), "note": "", "senses": senses,
    }

    # ---- 第 0 层：常用短语直接查表 ----
    #
    # 为什么不走网络：MyMemory 是众包翻译记忆库，短句质量不稳，
    # 而且不稳的方式很尴尬——实测「我爱你」被翻成「你很笨」，
    # 「how are you」被截断成「你好 , 我正在使用」。
    # 这些常用短句本来也没有歧义，查表更准、更快、还能离线用。
    phrase = lookup_phrase(text, src) if not swaps else ""
    if phrase:
        result.update({
            "text": phrase,
            "engine": "phrasebook",
            "engine_label": "内置常用语",
            "online": False,
            "note": "这是常用语，直接用内置对照给的结果，没有走网络。",
        })
        return result

    # ---- 在线 ----
    try:
        out = translate_mymemory(payload, src, dst)
        restored = restore_terms(out, swaps)
        # 语种校验：众包库会返回**语种都不对**的结果
        # （实测「我爱你」zh→en 返回的还是中文「你很笨」）。
        # 这种错直接显示出来比"翻译失败"更糟——她不会怀疑译文，
        # 只会照着理解。所以宁可判定失败、走离线兜底。
        if not output_matches_language(restored, dst):
            raise TranslateError(
                f"返回的译文不是目标语言（拿到的是 {detect_language(restored)}）")
        result.update({
            "text": restored,
            "engine": "mymemory",
            "engine_label": "MyMemory（在线）",
            "online": True,
        })
        notes = []
        if swaps:
            notes.append(f"已保护 {len(swaps)} 个专业词不被译错")
        result["note"] = "；".join(notes)
        return result
    except (urllib.error.URLError, urllib.error.HTTPError, OSError,
            ValueError, TranslateError) as exc:
        reason = str(exc)
        if isinstance(exc, urllib.error.URLError):
            reason = "网络不通"

    # ---- 离线兜底 ----
    out, hits = _offline(text, src)
    result.update({
        "text": out,
        "engine": "offline",
        "engine_label": "内置词表（离线）",
        "online": False,
        "terms": hits,
        "note": (f"连不上翻译服务（{reason}），"
                 f"这里只能用内置词表逐词直译，"
                 f"只适合看个大意——句子结构是保留不了的。"),
    })
    return result


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    # 语种判断
    assert detect_language("这是一句中文") == "zh-CN"
    assert detect_language("This is English") == "en"
    assert detect_language("これは日本語です") == "ja"
    assert detect_language("12345") == "en"
    assert auto_target("中文输入")[1] == "en"
    assert auto_target("english input")[1] == "zh-CN"

    # 术语保护：长词优先，且占位符能还原
    protected, swaps = protect_terms("这题用二叉搜索树比二叉树快", "zh-CN")
    assert "二叉搜索树" not in protected, protected
    assert "二叉树" not in protected, protected
    assert len(swaps) == 2, swaps
    assert restore_terms(protected, swaps) == "这题用binary search tree比binary tree快", restore_terms(protected, swaps)

    # 英译中方向：按词边界匹配，不能把 heap 匹配进 cheap
    protected2, swaps2 = protect_terms("cheap heap", "en")
    assert "heap" in protected2.split() or "cheap" in protected2, protected2
    assert len(swaps2) == 1, swaps2
    assert restore_terms(protected2, swaps2) == "cheap 堆"

    # 离线兜底能出东西，且会说明是降级
    out, hits = _offline("动态规划 问题", "zh-CN")
    assert "dynamic programming" in out, out
    assert hits >= 1

    # translate() 的返回结构（不依赖网络的那部分）
    try:
        translate("")
        raise AssertionError("空输入应该抛错")
    except TranslateError:
        pass

    # ---- 常用短语：走内置表，不走网络 ----
    #
    # 为什么单独测这个：MyMemory 是众包库，实测把「我爱你」翻成「你很笨」。
    # 所以常用短语改成查表。这条断言守的就是"别再退回在线翻译"。
    rp = translate("我爱你", src="zh-CN", dst="en")
    assert rp["engine"] == "phrasebook", rp
    assert rp["text"] == "I love you", rp
    assert rp["online"] is False, rp

    rp2 = translate("how are you", src="en", dst="zh-CN")
    assert rp2["engine"] == "phrasebook", rp2
    assert rp2["text"] == "你好吗", rp2

    # 长句不该被短语表拦截（短语表只在**整段正好相等**时才生效）
    assert lookup_phrase("我爱你你也爱我", "zh-CN") == ""
    assert lookup_phrase("", "zh-CN") == ""

    # ---- 语种校验 ----
    # 众包库会返回语种都不对的结果，这种情况必须判成失败
    assert output_matches_language("I love you", "en") is True
    assert output_matches_language("我爱你", "zh-CN") is True
    assert output_matches_language("你很笨", "en") is False, "中文不该算作英文译文"
    assert output_matches_language("", "en") is False

    # 在线翻译（能连上就顺便验一下真实性，连不上就跳过——
    # 不把"网络不通"当成程序错误）
    try:
        # 纯术语输入：应该走"查表直出"，而且译对
        r0 = translate("动态规划", src="zh-CN", dst="en")
        assert "dynamic programming" in r0["text"].lower(), r0
        assert r0["engine"] == "glossary", r0

        # 整句：走在线翻译，术语要被保护住
        r = translate("这题用动态规划比回溯快", src="zh-CN", dst="en")
        assert r["text"], r
        assert r["online"] is True, r
        # 关键验证：术语保护必须让「动态规划」译成 dynamic programming，
        # 而不是机器翻译默认的 dynamic planning
        assert "dynamic programming" in r["text"].lower(), r
        assert "[[" not in r["text"], f"占位符没填回去：{r['text']}"
        print(f"translate selftest: 全部断言通过 ✓"
              f"（在线引擎 {r['engine_label']}，"
              f"术语保护 {r['terms']} 个）")
    except TranslateError as exc:
        print(f"translate selftest: 本地断言通过 ✓"
              f"（在线部分跳过：{exc}）")

    # ---- 多义词（不依赖网络，放 try 外面，一定要跑到）----
    #
    # 单个英文单词要能展开出多条释义
    rw = translate("address", src="en", dst="zh-CN")
    assert rw["senses"], f"address 应该有多条释义：{rw}"
    poss = {s["pos"] for s in rw["senses"]}
    assert len(poss) >= 2, f"address 应该跨多个词性：{poss}"
    assert any("地址" in s["meaning"] for s in rw["senses"]), rw["senses"]
    # 每条释义都要带词性中文名，界面上要显示
    assert all(s["pos_name"] for s in rw["senses"]), rw["senses"]

    # 整句不该展开释义（否则干扰阅读）
    rs = translate("This is a test sentence.", src="en", dst="zh-CN")
    assert rs["senses"] == [], f"整句不该有多义词列表：{rs['senses']}"

    # 中文输入也不该展开（中文不是"英文单词"）
    rc = translate("我爱你", src="zh-CN", dst="en")
    assert rc["senses"] == [], f"中文不该有多义词列表：{rc['senses']}"

    print(f"  多义词：address 展开 {len(rw['senses'])} 条"
          f"（{'/'.join(sorted(poss))}）")


if __name__ == "__main__":
    _selftest()
