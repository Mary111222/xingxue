"""命令行入口：her（或者 python -m her_review）。

一次完整的「卡壳 → 看懂 → 沉淀」闭环：
    her review          # 复习到期的题
      ├─ n             # 看关键思路
      ├─ s             # 不懂 → 搜 B 站（终端里给结果，挑一个就打开）
      ├─ b             # 干脆丢给视频总结器，出摘要 + 知识笔记
      ├─ w             # 把总结写回这道题的笔记里
      └─ 0-5           # 评分，SM-2 安排下次复习

这个文件只负责三件事：装配上下文、解析参数、调度命令。
具体命令实现在 commands.py / commands_web.py / commands_io.py，
面板与插件相关的在 features.py。
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

from . import commands, commands_io, commands_web, features, gem, panels
from . import plugins as plugins_mod
from . import ui
from .cli_support import InputClosed
from . import config
from .config import Config, load_local_home
from .db import DIFFICULTIES, SOURCES, Store


# --------------------------------------------------------------------------
# 上下文
# --------------------------------------------------------------------------

class Ctx:
    """一次运行需要的全部状态。命令函数都拿它当第一个参数（除了 args）。"""

    def __init__(self, cfg: Config, store: Store, theme: gem.Theme):
        self.cfg = cfg
        self.store = store
        self.theme = theme
        self.birthday = gem.parse_date(cfg.birthday)
        self.together = gem.parse_date(cfg.together_since)
        # 面板 / 插件（在 build_ctx 里装配）
        self.panels = panels.PanelRegistry()
        self.hooks: dict[str, list] = {}
        self.plugins: plugins_mod.PluginRuntime | None = None
        self.plugin_commands: dict[str, dict] = {}
        self._today_override: date | None = None

    @property
    def name(self) -> str:
        return self.cfg.display_name()

    def today(self) -> date:
        return self._today_override or date.today()


def _load_disabled_plugins(cfg: Config) -> list[str]:
    """停用列表单独存在 config.json 的 plugins_disabled 字段里。"""
    path = cfg.config_path
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    value = payload.get("plugins_disabled") or []
    return [str(v) for v in value] if isinstance(value, list) else []


def build_ctx(args) -> Ctx:
    # 数据目录解析链统一在 config.resolve_home 里（显式 > 环境变量 > her.local.json > 默认）
    home = config.resolve_home(getattr(args, "home", None))
    cfg = Config.load(home)
    if getattr(args, "no_color", False) or not sys.stdout.isatty():
        ui.use_color(False)
    if cfg.warning:
        ui.warn(cfg.warning)
        ui.info("想固定数据位置：her --home <目录>，或设环境变量 HER_REVIEW_HOME")
    try:
        store = Store(cfg.db_path)
    except OSError as exc:
        ui.err(f"打不开数据库 {cfg.db_path}：{exc}")
        ui.info("换一个可写目录试试：her --home ./my-data today")
        raise SystemExit(2)
    theme = gem.theme_from_birthday(cfg.birthday)
    ctx = Ctx(cfg, store, theme)

    # 缓存目录跟着数据目录走（不指的话会退到 ~/.her-review，那里常常不可写，
    # 于是搜索缓存静默失效——"装好了却没用上"最难查）
    try:
        from . import deps

        deps.configure_cache(cfg.home)
    except Exception:
        pass

    # 日期覆盖：为了能验证「生日当天/纪念日」这类跟日期绑定的效果，也为了写测试
    override = getattr(args, "today", None)
    if override:
        parsed = gem.parse_date(override)
        if parsed is None:
            ui.warn(f"--today 的日期看不懂：{override}（要 YYYY-MM-DD）")
        else:
            ctx._today_override = parsed
            ui.info(f"（已把「今天」假定为 {parsed.isoformat()}，仅供预览，不影响真实数据）")

    # 内置面板先注册，用户插件后注册（同名时插件覆盖内置，这样她能改官方行为）
    panels.register_builtin_panels(ctx.panels, ctx)
    # 一次性迁移：把新版本新增的内置面板补进老配置。
    # 只在启动时做一次（不放在 panel_order() 里，否则 disable 会被立刻撤销）。
    fresh_panels = cfg.migrate_panels(features.DEFAULT_PANELS)
    if fresh_panels:
        ui.info("这个版本带了新面板，已加到首页：" + "、".join(fresh_panels))

    runtime = plugins_mod.PluginRuntime(cfg.home)
    runtime.load_disabled(_load_disabled_plugins(cfg))

    def command_sink(plugin_name: str, spec: dict) -> None:
        ctx.plugin_commands.setdefault(plugin_name, {})[spec["name"]] = spec

    try:
        runtime.load_all(ctx.panels, ctx, command_sink=command_sink, hooks=ctx.hooks)
    except Exception as exc:  # 插件系统本身出问题也不能拦住程序
        ui.warn(f"插件加载出现异常（已忽略）：{exc}")
    ctx.plugins = runtime
    return ctx


# --------------------------------------------------------------------------
# 参数解析
# --------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="her",
        description="她的刷题复习系统：SM-2 间隔重复 + 一键搜 B 站 + 视频总结器 + 面板插件",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
常用：
  her                 看看今天该复习什么
  her review          开始复习（0-5 评分，n 看思路，s 搜 B 站，b 总结视频）
  her search dp       不懂「动态规划」？直接搜 B 站
  her search --problem 每日温度    按某道题的知识点搜
  her note add "..."  贴一张便签
  her days add "期末机试" 2027-01-10 --kind exam
  her remind add "喝水" -p daily
  her plugins new mine            自己加一个功能
  her stats           成绩单：热力图、最虚的知识点、未来两周压力
  her seed            装那 33 道经典题
""",
    )
    parser.add_argument("--home", help="数据目录（默认 ~/.her-review）")
    parser.add_argument("--no-color", action="store_true", help="关掉颜色")
    parser.add_argument("--today", help="把「今天」假定成某一天 YYYY-MM-DD（用于预览生日等效果）")
    parser.add_argument("--version", action="version", version="her-review 2.0.0")

    sub = parser.add_subparsers(dest="command")

    # ---------------- 入门 ----------------

    p = sub.add_parser("init", help="初始化：名字、生日、认识的日期")
    p.add_argument("--name")
    p.add_argument("--birthday")
    p.add_argument("--together")
    p.set_defaults(func=commands.cmd_init)

    p = sub.add_parser("seed", help="装内置的经典题库")
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=commands.cmd_seed)

    # ---------------- 每日 ----------------

    p = sub.add_parser("today", help="今天该复习什么（首页）")
    p.add_argument("--only", help="只显示指定面板，逗号分隔，例：countdown,notes")
    p.add_argument("--skip", help="跳过指定面板，逗号分隔")
    p.set_defaults(func=commands.cmd_today)

    p = sub.add_parser("day", help="今天的一切：首页 + 提醒 + 全部面板")
    p.set_defaults(func=features.cmd_day)

    # ---------------- 题目 ----------------

    p = sub.add_parser("add", help="加一道题")
    p.add_argument("title", nargs="?", help="题名（不给就进交互模式）")
    p.add_argument("-t", "--tags", help="标签，空格或逗号分隔")
    p.add_argument("-d", "--difficulty",
                   choices=list(DIFFICULTIES) + ["简单", "中等", "困难"], help="难度")
    p.add_argument("-s", "--source", choices=list(SOURCES), help="平台")
    p.add_argument("-u", "--url", help="题目链接")
    p.add_argument("-n", "--note", help="关键思路")
    p.add_argument("-m", "--memory", help="私人记忆（只给她看的备注）")
    p.set_defaults(func=commands.cmd_add)

    p = sub.add_parser("list", help="列题目")
    p.add_argument("keyword", nargs="?", help="关键词")
    p.add_argument("--tag", help="只看某个标签")
    p.add_argument("--difficulty", choices=list(DIFFICULTIES))
    p.add_argument("--due", action="store_true", help="只看今天到期的")
    p.add_argument("--all", action="store_true", help="包含已归档")
    p.add_argument("--limit", type=int)
    p.add_argument("--title")
    p.set_defaults(func=commands.cmd_list)

    p = sub.add_parser("show", help="看一道题的详情和复习历史")
    p.add_argument("target", help="题号或关键词")
    p.set_defaults(func=commands.cmd_show)

    p = sub.add_parser("edit", help="改一道题")
    p.add_argument("target")
    p.add_argument("--title")
    p.add_argument("--note")
    p.add_argument("--memory")
    p.add_argument("--tags")
    p.add_argument("--difficulty", choices=list(DIFFICULTIES))
    p.add_argument("--url")
    p.add_argument("--archive", action="store_true", help="归档（不再出现在复习队列里）")
    p.add_argument("--edit", action="store_true", help="强制进交互模式")
    p.set_defaults(func=commands.cmd_edit)

    p = sub.add_parser("rm", help="删一道题")
    p.add_argument("target")
    p.add_argument("-y", "--yes", action="store_true")
    p.set_defaults(func=commands.cmd_rm)

    p = sub.add_parser("review", help="开始复习（核心）")
    p.add_argument("--limit", type=int, help="最多复习几道")
    p.add_argument("--extra", help="额外复习匹配这个关键词的题")
    p.add_argument("--no-auto-open", action="store_true", help="搜 B 站时不自动打开浏览器")
    p.add_argument("--show-solution", action="store_true", help="一上来就显示思路（不推荐）")
    p.add_argument("--no-banner", action="store_true")
    p.set_defaults(func=commands_web.cmd_review)

    p = sub.add_parser("stats", help="成绩单和热力图")
    p.set_defaults(func=commands.cmd_stats)

    # ---------------- 搜 B 站 / 视频总结 ----------------

    p = sub.add_parser("search", help="搜 B 站（不会就搜）")
    p.add_argument("keyword", nargs="?", help="搜索关键词")
    p.add_argument("-p", "--problem", help="按某道题的知识点搜（题号或关键词）")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--pick", help="直接打开第几个结果")
    p.add_argument("--open", action="store_true", help="直接打开第一个结果")
    p.add_argument("--print-only", action="store_true", help="只打印，不交互")
    p.add_argument("--links-only", action="store_true", help="不联网，只给搜索链接")
    p.add_argument("--offline", action="store_true", help="不调接口，只给链接")
    p.add_argument("--summarize", action="store_true", help="直接总结选中的视频")
    p.add_argument("--save", action="store_true", help="总结结果写回题目笔记")
    p.set_defaults(func=commands_web.cmd_search)

    p = sub.add_parser("summarize", help="总结一个视频（自动托管 BiliSum 后端，不用开桌面端）")
    p.add_argument("url", help="视频链接或 BV 号")
    p.add_argument("--problem", help="总结结果关联到哪道题")
    p.add_argument("--save", action="store_true", help="写回题目笔记")
    p.add_argument("--format", default="markdown", choices=["markdown", "json", "transcript"])
    p.set_defaults(func=commands_web.cmd_summarize)

    p = sub.add_parser("video", help="视频总结器：看状态 / 手动启动 / 停止内置服务")
    p.add_argument("action", nargs="?", default="status",
                   choices=["status", "start", "stop"], help="默认 status")
    p.set_defaults(func=commands_web.cmd_video)

    # ---------------- 自主学习 ----------------

    p = sub.add_parser("learn", help="学习网站清单：刷题/文档/基础/项目，点开就跳",
                       description="自主学习模块。列出整理好的学习网站，带「什么时候用、怎么上手」。"
                                   "也可以直接 her learn 文档 按分类看。")
    p.add_argument("action", nargs="?", default="list",
                   help="list（默认）/ open 打开某个 / search 按关键词找；也可直接写分类名")
    p.add_argument("name", nargs="?", help="open 时给编号/短名；search 时给关键词；也可直接给分类名")
    p.add_argument("query", nargs="?", help="open 时可选：站内搜索的关键词")
    p.add_argument("--category", help="只看某个分类：算法 / 文档 / 基础 / 工程 / 社区")
    p.add_argument("--print-only", action="store_true", help="只打印链接，不打开浏览器")
    p.add_argument("--clear", action="store_true",
                   help="her learn history --clear：清空打开记录")
    p.set_defaults(func=features.cmd_learn)

    # ---------------- 图形界面 ----------------

    p = sub.add_parser("ui", help="打开图形界面（推荐用这个，比终端舒服）",
                       description="启动本地界面并自动打开浏览器。"
                                   "界面和终端共用同一份数据，两边随便换着用。")
    p.add_argument("--port", type=int, default=None, help="端口（被占用会自动换）")
    p.add_argument("--no-open", action="store_true", help="不要自动打开浏览器")
    p.set_defaults(func=commands.cmd_ui)

    # ---------------- 失败台账与质量 ----------------

    p = sub.add_parser("failures", help="待处理的问题：静默失败在这里现形，可重试可标记",
                       description="程序里所有「降级但不崩」的地方都会在这里留一条记录，"
                                   "并给出可以直接敲的重试命令。")
    p.add_argument("action", nargs="?", default="list",
                   choices=["list", "done", "clear"], help="默认 list")
    p.add_argument("name", nargs="?", help="done 时的编号，或 all")
    p.add_argument("--all", action="store_true", help="连已解决的也显示")
    p.add_argument("-y", "--yes", action="store_true", help="clear 时不问")
    p.set_defaults(func=features.cmd_failures)

    p = sub.add_parser("quality", help="生成质量：视频总结到底可信到什么程度")
    p.add_argument("--limit", type=int, default=8, help="显示几条")
    p.set_defaults(func=features.cmd_quality)

    # ---------------- 六级备考 ----------------

    p = sub.add_parser("cet6", help="六级备考：倒计时、B 站视频方向、真题备考材料",
                       description="考试日期来自官方通知。视频存的是搜索词不是链接——"
                                   "视频会下架，搜索词不会。备考材料可以一键导进题库，"
                                   "和算法题一起做间隔重复。")
    p.add_argument("action", nargs="?", default="overview",
                   choices=["overview", "videos", "add"],
                   help="默认看总览；videos 看某个方向的视频；add 导进题库")
    p.add_argument("key", nargs="?", default="",
                   help="videos 时的序号或 key")
    p.add_argument("--kind", default="all",
                   help="add 时导哪部分：all / vocab / writing / translation")
    p.set_defaults(func=features.cmd_cet6)

    # ---------------- 专业学习 ----------------

    p = sub.add_parser("course", help="专业学习：按课程看知识点、题目、视频和资源",
                       description="对照《2025 版计科专业人才培养方案》的课程清单。"
                                   "直接写课程名也行：her course 数据结构")
    p.add_argument("action", nargs="?", default="overview",
                   help="默认总览；list 课程表 / show 某门课 / search 按知识点找 / tags 标签对照")
    p.add_argument("name", nargs="?", help="课程短名（ds/os/net…）、课程名片段，或搜索关键词")
    p.set_defaults(func=features.cmd_course)

    # ---------------- 面板 ----------------

    p = sub.add_parser("panels", help="管理首页面板：看、开关、换顺序")
    p.add_argument("action", nargs="?", default="list",
                   choices=["list", "enable", "disable", "up", "down", "move", "reset"],
                   help="list=看 / enable|disable=开关 / up|down=上下移 / move=指定位置 / reset=恢复默认")
    p.add_argument("name", nargs="?", help="面板 id（或 move 时的原位置序号）")
    p.add_argument("extra", nargs="?", help="move 时的目标位置序号")
    p.set_defaults(func=features.cmd_panels)

    # ---------------- 便签 ----------------

    p = sub.add_parser("note", help="便签卡片：随手贴的短句、待办")
    p.add_argument("action", nargs="?", default="list",
                   choices=["list", "add", "edit", "pin", "archive", "unarchive",
                            "rm", "color"],
                   help="默认 list")
    p.add_argument("text", nargs="?", help="内容 / 编号 / 关键词")
    p.add_argument("value", nargs="?", help="color 动作时的颜色名")
    p.add_argument("--pin", action="store_true", help="添加时直接置顶")
    p.add_argument("--color", help="颜色：" + "/".join(panels.NOTE_COLORS))
    p.add_argument("--all", action="store_true", help="包含已归档")
    p.add_argument("-y", "--yes", action="store_true", help="删除时不问")
    p.set_defaults(func=features.cmd_note)

    # ---------------- 倒数日 ----------------

    p = sub.add_parser("days", help="倒数日：考试 / 比赛 / 纪念日",
                       description="倒数日列表。注意：生日会自动显示（来自 init 时填的生日），"
                                   "不需要在这里重复添加。")
    p.add_argument("action", nargs="?", default="list",
                   choices=["list", "add", "edit", "done", "rm"], help="默认 list")
    p.add_argument("title", nargs="?", help="标题 / 编号 / 关键词")
    p.add_argument("date", nargs="?", help="日期 YYYY-MM-DD")
    p.add_argument("--kind", choices=["event", "exam", "anniversary", "birthday"],
                   help="类型（影响颜色和标签）")
    p.add_argument("--note", help="备注")
    p.add_argument("--yearly", action="store_true", help="每年重复（纪念日用）")
    p.add_argument("--all", action="store_true", help="看全年（默认只看 120 天内的）")
    p.add_argument("-y", "--yes", action="store_true", help="删除时不问")
    p.set_defaults(func=features.cmd_days)

    # ---------------- 提醒 ----------------

    p = sub.add_parser("remind", help="特别提醒：每天 / 每周 / 指定日期")
    p.add_argument("action", nargs="?", default="list",
                   choices=["list", "add", "on", "off", "rm"], help="默认 list")
    p.add_argument("text", nargs="?", help="内容 / 编号 / 关键词")
    p.add_argument("-p", "--pattern", choices=["daily", "weekly", "date", "once"],
                   help="daily 每天 / weekly 每周 / date 指定日期 / once 只响一次")
    p.add_argument("-w", "--weekday", type=int, choices=range(1, 8),
                   help="weekly 用：1=周一 … 7=周日")
    p.add_argument("-d", "--date", help="date/once 用的日期 YYYY-MM-DD")
    p.add_argument("-a", "--at", help="时间 HH:MM（留空=全天）")
    p.add_argument("-i", "--important", action="store_true", help="标成重要，每天优先显示")
    p.set_defaults(func=features.cmd_remind)

    # ---------------- 插件 ----------------

    p = sub.add_parser("plugins", help="插件：自己给程序加功能")
    p.add_argument("action", nargs="?", default="list",
                   choices=["list", "new", "open", "enable", "disable", "dir", "log", "doc"],
                   help="默认 list；doc 看怎么写插件")
    p.add_argument("name", nargs="?", help="插件名")
    p.add_argument("--force", action="store_true", help="new 时覆盖已存在的")
    p.add_argument("--limit", type=int, default=30, help="log 显示多少行")
    p.set_defaults(func=features.cmd_plugins)

    # ---------------- 数据进出 ----------------

    p = sub.add_parser("import", help="从 CSV / Markdown / JSON 导入")
    p.add_argument("path")
    p.add_argument("--format", default="auto", choices=["auto", "csv", "markdown", "json"])
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=commands_io.cmd_import)

    p = sub.add_parser("export", help="导出题单（可带便签/倒数日/提醒）")
    p.add_argument("--format", default="markdown", choices=["markdown", "csv", "json"])
    p.add_argument("-o", "--output")
    p.add_argument("--extras", action="store_true", help="额外导出一份便签/倒数日/提醒")
    p.set_defaults(func=commands_io.cmd_export)

    # ---------------- 工具 ----------------

    p = sub.add_parser("doctor", help="自检：环境、网络、视频总结器、插件")
    p.set_defaults(func=commands_io.cmd_doctor)

    p = sub.add_parser("demo-fill", help="造一段历史复习记录（预览统计图用）")
    p.add_argument("--days", type=int, default=60)
    p.add_argument("--per-day", type=int, default=7)
    p.add_argument("--force", action="store_true", help="已有记录时也继续（会混在一起）")
    p.set_defaults(func=commands.cmd_demo_fill)

    p = sub.add_parser("selftest", help="跑单元自测")
    p.set_defaults(func=commands_io.cmd_selftest)

    return parser


# --------------------------------------------------------------------------
# 调度
# --------------------------------------------------------------------------

def plugin_dispatch(args, ctx: Ctx) -> int:
    """插件命令的执行入口：her <插件名> <命令名> [参数...]"""
    func = getattr(args, "_plugin_func", None)
    if func is None:
        ui.err(f"插件「{args.command}」里没有这个命令")
        return 1
    try:
        return func(args, ctx) or 0
    except Exception as exc:  # 插件报错不能崩整个程序
        ui.err(f"插件命令出错：{exc.__class__.__name__}: {exc}")
        runtime = getattr(ctx, "plugins", None)
        if runtime is not None:
            import traceback

            runtime.log(args.command, "命令出错\n" + traceback.format_exc())
            ui.info(f"详细堆栈已写入 {runtime.log_path}（her plugins log）")
        return 1


def first_command(argv: list[str]) -> str | None:
    """从原始 argv 里挑出子命令名。

    为什么不直接用 parser.parse_known_args：
        遇到还没注册的插件命令名时，argparse 会把它当成「多余的位置参数」，
        command 会是 None（而不是那个名字），于是插件就永远挂不上去。
    这里手工扫描更可靠：跳过全局开关和它们后面的值，第一个剩下的非选项就是子命令。
    """
    value_flags = {"--home", "--today", "--only", "--skip", "--limit", "--format", "--output", "-o",
                   "--page", "--pick", "--pattern", "-p", "--weekday", "-w", "--date", "-d",
                   "--at", "-a", "--name", "--birthday", "--together", "--notes", "--color",
                   "--problem", "--extra", "--title", "--tags", "-t", "--difficulty",
                   "--source", "-s", "--url", "-u", "--note", "-n", "--memory", "-m"}
    index = 0
    while index < len(argv):
        token = argv[index]
        if token == "--":
            return argv[index + 1] if index + 1 < len(argv) else None
        if token.startswith("-"):
            if token in value_flags:
                index += 2  # 连它的值一起跳过
                continue
            index += 1
            continue
        return token
    return None


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    ui.configure_stdio()  # 先保证输出不会因为编码问题崩掉
    parser = build_parser()

    # ---- 第一遍：先拿到数据目录，才知道有哪些插件命令要挂上去 ----
    pre = argparse.ArgumentParser(add_help=False)
    pre.add_argument("--home")
    pre.add_argument("--no-color", action="store_true")
    pre_args, _ = pre.parse_known_args(argv)
    command = first_command(argv)

    plugin_registry: dict[str, dict] = {}
    # 只有「看起来不像内置命令」的名字才需要探测插件，省掉一次多余的启动开销
    builtin = set(parser._subparsers._group_actions[0].choices) if parser._subparsers else set()
    if command and command not in builtin:
        probe_ctx = build_ctx(pre_args)
        names = sorted(probe_ctx.plugin_commands)
        if names:
            subparsers = None
            for action in parser._actions:  # 找到子命令那一组
                if isinstance(action, argparse._SubParsersAction):
                    subparsers = action
                    break
            if subparsers is not None:
                for plugin_name in names:
                    if plugin_name in subparsers.choices:
                        continue  # 不覆盖内置命令
                    p = subparsers.add_parser(plugin_name, help=f"[插件] {plugin_name}")
                    p.set_defaults(func=plugin_dispatch)
                    inner = p.add_subparsers(dest="_plugin_command")
                    for cmd_name, spec in probe_ctx.plugin_commands[plugin_name].items():
                        cp = inner.add_parser(cmd_name, help=spec.get("help", ""))
                        for arg in spec.get("arguments", []):
                            kwargs = {k: v for k, v in arg.items()
                                      if k in ("help", "default", "type", "choices", "nargs")}
                            cp.add_argument(arg["name"], **kwargs)
                        plugin_registry[f"{plugin_name}:{cmd_name}"] = spec
        probe_ctx.store.close()

    args = parser.parse_args(argv)

    # 不带子命令 = her today
    if not getattr(args, "func", None):
        args.func = commands.cmd_today

    ctx = build_ctx(args)
    if getattr(args, "_plugin_command", None):
        spec = plugin_registry.get(f"{args.command}:{args._plugin_command}")
        if spec:
            args._plugin_func = spec["func"]
    try:
        return args.func(args, ctx) or 0
    except KeyboardInterrupt:
        print()
        ui.info("已退出")
        return 130
    except InputClosed:
        # 输入流提前结束（管道读完 / 她按了 Ctrl+D）：
        # 任何交互点抛出来的都在这儿统一收口，绝不无限循环、也绝不甩堆栈。
        #
        # 退出码给 1 而不是 0：走到这条路说明**操作没做完**
        # （她按 Ctrl+D 想退出、脚本忘了喂输入）。
        # 报成 0 会让"明明没干成"看起来像成功——这正是要避免的那类假象。
        print()
        ui.info("输入结束了，已停止当前操作")
        return 1
    finally:
        ctx.store.close()


if __name__ == "__main__":
    sys.exit(main())
