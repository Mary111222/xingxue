"""应用更新（应用内一键更新 → 重启后替换程序，数据不动）。

## 为什么是"重启后替换"而不是"当场替换"

Windows 下正在运行的程序文件（exe、`_internal` 里的 python dll/pyz）是**占用**的，
当场覆盖会失败。所以流程是：

    设置页点「⬇ 一键更新（自动下载）」
        ↓
    读 update.json（三路直链容错）→ 比版本 → 下载更新包（三路容错）
        ↓
    校验 sha256（必须）+ 解压到 staging（只读旧程序，不写它）
        ↓
    写 数据/update/pending.json
        ↓
    「立即重启并更新」→ 启动一个隐藏的 PowerShell：
        等当前后端进程退出 → taskkill xingxue.exe / xingxue-backend.exe
        → 把 staging/files/* 覆盖到安装目录（逐个重试）→ 启动 xingxue.exe
        ↓
    新版本启动后，状态接口发现 pending.to == 当前版本 → 自动清掉 pending

用户也可以「选择更新包」（作者把 zip 直接发过来，不走网络）——走的是
同一个校验 + 暂存 + 重启替换流程。

## 安全边界（更新器只做三件事：校验、复制、启动）

    · 只认我们自己的 manifest（app id / 版本号 / 文件清单），app id 不对直接拒绝
    · 每个文件逐一校验 sha256 和大小；下载的 zip 还先校验 update.json 里的 sha256
    · 只允许写 manifest 列出的相对路径；明确禁止 `数据/`、`..`、绝对路径
    · 从不执行更新包里的任何程序

## 目录约定

    安装目录（程序文件）：
        打包版 = `sys.executable` 往上三级
                 （后端在 `<安装目录>/resources/backend/xingxue-backend.exe`）
        开发版 = 仓库根目录
        可用环境变量 `XINGXUE_APP_DIR` 覆盖（测试用；打包版不要设）
    数据目录：`.her_review` 的 `ctx.cfg.home`（her.local.json 指定），
    更新暂存放 `<数据目录>/update/`，**不碰**安装目录里的任何数据。
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

from .version import APP_ID, APP_NAME, BUILD, VERSION

# 更新包上限：正常 15MB 左右，留足余量但别让人误选超大文件
MAX_PACKAGE_BYTES = 200 * 1024 * 1024
MAX_UNCOMPRESSED_BYTES = 800 * 1024 * 1024
MAX_FILES = 8000
DATA_DIRNAME = "数据"
VERSION_FILE = "version.json"

PENDING_NAME = "pending.json"
STAGING_NAME = "staging"
UPDATE_DIRNAME = "update"

_WIN = sys.platform == "win32"
# 正常子进程即可（Windows 里父进程退出不会杀子进程）。
# 实测 DETACHED_PROCESS 下 powershell.exe 会静默退出、脚本根本不跑，所以不用它。
_CREATE_FLAGS = 0

# 替换程序用 PowerShell 脚本（不是 cmd 批处理）。
#
# 为什么不用 .cmd：实测在「无控制台 + 管道」的环境里，批处理里的
# `tasklist ... | find ...` 会一直卡住（管道那行不返回）。
# PowerShell 的 Wait-Process + Copy-Item 没有这个问题，而且报错信息更清楚。
# 脚本本身是纯 ASCII，路径全部走环境变量（中文路径不经过脚本编码）。
_APPLY_PS1 = r"""$ErrorActionPreference = 'Continue'
$targetPid = 0
[void][int]::TryParse($env:XINGXUE_PID, [ref]$targetPid)
if ($targetPid -gt 0) { Wait-Process -Id $targetPid -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 700
$appdir  = $env:XINGXUE_APPDIR
$staging = $env:XINGXUE_STAGING
$exe     = $env:XINGXUE_EXE
$log     = $env:XINGXUE_LOG
function Log($msg) {
    try { Add-Content -LiteralPath $log -Value ("[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg) -Encoding UTF8 } catch {}
}
function KillApp() {
    foreach ($name in @('xingxue.exe', 'xingxue-backend.exe')) {
        try { & taskkill.exe /F /IM $name 2>$null | Out-Null; Log ("taskkill " + $name) } catch { Log ("taskkill " + $name + " failed: " + $_.Exception.Message) }
    }
    Start-Sleep -Milliseconds 900
}
function CopyFiles($src, $dst, $tries) {
    for ($i = 1; $i -le $tries; $i++) {
        try {
            Copy-Item -Path $src -Destination $dst -Recurse -Force -ErrorAction Stop
            return $true
        } catch {
            Log ("copy try " + $i + " failed: " + $_.Exception.Message)
            Start-Sleep -Milliseconds (700 * $i)
        }
    }
    return $false
}
Log "apply start"
KillApp
$copied = CopyFiles (Join-Path $staging 'files\*') $appdir 6
if ($copied) {
    Log "copy ok"
    try { Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue } catch {}
} else {
    Log "copy failed after retries"
}
try {
    Start-Process -FilePath (Join-Path $appdir $exe) -WorkingDirectory $appdir
    Log "started"
} catch {
    Log ("start failed: " + $_.Exception.Message)
}
Log "apply done"
"""


class UpdateError(Exception):
    """更新失败（面向用户的中文消息，可以直接显示）。"""


# --------------------------------------------------------------------------
# 基础信息
# --------------------------------------------------------------------------

def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def app_dir() -> Path:
    """程序目录（安装目录）：打包版 = 后端 exe 往上三级；开发版 = 仓库根目录。

    `XINGXUE_APP_DIR` 是**测试用**覆盖（让开发态/测试指向一个假程序目录，
    不会真的去动安装目录）。
    """
    override = os.environ.get("XINGXUE_APP_DIR")
    if override:
        return Path(override).resolve()
    if is_frozen():
        # <安装目录>/resources/backend/xingxue-backend.exe → 安装目录
        return Path(sys.executable).resolve().parent.parent.parent
    return Path(__file__).resolve().parent.parent


def exe_name() -> str:
    """主程序 exe 文件名（更新替换完要把它拉起来）。"""
    return "xingxue.exe"


def installed_version(program_dir: Path | None = None) -> str:
    """读程序目录里的 version.json；没有就退回代码里的 VERSION。"""
    base = program_dir or app_dir()
    try:
        data = json.loads((base / VERSION_FILE).read_text(encoding="utf-8"))
        return str(data.get("version") or VERSION)
    except (OSError, ValueError):
        return VERSION


def installed_build(program_dir: Path | None = None) -> str:
    base = program_dir or app_dir()
    try:
        data = json.loads((base / VERSION_FILE).read_text(encoding="utf-8"))
        return str(data.get("build") or BUILD)
    except (OSError, ValueError):
        return BUILD


def _vtuple(text: str) -> tuple[int, ...] | None:
    """把 1.2.3 解析成 (1,2,3)；解析不了返回 None。"""
    m = re.fullmatch(r"\s*v?(\d+(?:\.\d+){0,3})(?:[-+].*)?\s*", str(text or ""))
    if not m:
        return None
    parts = [int(x) for x in m.group(1).split(".")]
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def compare_versions(a: str, b: str) -> int:
    """a>b 返回 1，相等 0，a<b 返回 -1（解析失败按 0 处理）。"""
    ta, tb = _vtuple(a), _vtuple(b)
    if ta is None or tb is None:
        return 0
    return (ta > tb) - (ta < tb)


# --------------------------------------------------------------------------
# 目录
# --------------------------------------------------------------------------

def update_root(data_dir: Path) -> Path:
    return Path(data_dir) / UPDATE_DIRNAME


def staging_dir(data_dir: Path) -> Path:
    return update_root(data_dir) / STAGING_NAME


def pending_file(data_dir: Path) -> Path:
    return update_root(data_dir) / PENDING_NAME


def apply_log(data_dir: Path) -> Path:
    return update_root(data_dir) / "apply.log"


def read_pending(data_dir: Path) -> dict | None:
    try:
        data = json.loads(pending_file(data_dir).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def _write_pending(data_dir: Path, info: dict) -> None:
    root = update_root(data_dir)
    root.mkdir(parents=True, exist_ok=True)
    _write_bytes_retry(pending_file(data_dir),
                       json.dumps(info, ensure_ascii=False, indent=2).encode("utf-8"))


def clear_pending(data_dir: Path) -> None:
    try:
        pending_file(data_dir).unlink()
    except OSError:
        pass


def _clear_staging(data_dir: Path) -> None:
    _force_remove(staging_dir(data_dir))


def _force_remove(path: Path) -> bool:
    """尽力删掉目录/文件：先去掉只读属性，再删；删不掉就改名挪开。

    返回 True 表示原来的路径已经不在了（可以安全重建）。
    被安全软件/其他进程短暂占用时 Windows 会报 PermissionError，
    这里不抛异常 —— 调用方会换一个新目录。
    """
    p = Path(path)
    if not p.exists():
        return True
    if p.is_file():
        try:
            os.chmod(p, stat.S_IWRITE)
            p.unlink()
            return True
        except OSError:
            return False
    for root, dirs, files in os.walk(p):
        for name in files:
            try:
                os.chmod(os.path.join(root, name), stat.S_IWRITE)
            except OSError:
                pass
        for name in dirs:
            try:
                os.chmod(os.path.join(root, name), stat.S_IWRITE)
            except OSError:
                pass
    shutil.rmtree(p, ignore_errors=True)
    if not p.exists():
        return True
    try:
        trash = p.with_name(f"{p.name}-trash-{int(time.time() * 1000)}")
        p.rename(trash)
        shutil.rmtree(trash, ignore_errors=True)
        return not p.exists()
    except OSError:
        return False


def _staging_candidates(data_dir: Path) -> list[Path]:
    """暂存目录候选：默认位置 → 新的同级目录 → 系统临时目录 → LocalAppData。

    为什么要有候选：Windows 上旧 staging 里的文件可能被安全软件/进程短暂锁住，
    删不掉也覆盖不了（就是「Permission denied: ..._internal\\ucrtbase.dll」那种）。
    这时换一个全新目录继续，更新就不会卡死。
    """
    root = update_root(data_dir)
    stamp = str(int(time.time() * 1000))
    out: list[Path] = [staging_dir(data_dir), root / f"staging-{stamp}"]
    try:
        out.append(Path(tempfile.gettempdir()) / f"xingxue-update-{stamp}")
    except OSError:
        pass
    local = os.environ.get("LOCALAPPDATA")
    if local:
        out.append(Path(local) / "xingxue-update" / f"staging-{stamp}")
    return out


def _write_bytes_retry(target: Path, blob: bytes, attempts: int = 6) -> None:
    """写文件；被安全软件/占用短暂锁住时自动重试几次。"""
    target.parent.mkdir(parents=True, exist_ok=True)
    last: Exception | None = None
    for i in range(attempts):
        try:
            if target.exists():
                try:
                    os.chmod(target, stat.S_IWRITE)
                except OSError:
                    pass
            target.write_bytes(blob)
            return
        except OSError as exc:
            last = exc
            time.sleep(0.2 * (i + 1))
    assert last is not None
    raise last


def active_staging(data_dir: Path) -> Path:
    """这次 pending 实际使用的暂存目录（可能不是默认的 数据/update/staging）。"""
    pending = read_pending(data_dir)
    raw = str((pending or {}).get("staging") or "").strip()
    if raw:
        try:
            return Path(raw)
        except (OSError, ValueError):
            pass
    return staging_dir(data_dir)


# --------------------------------------------------------------------------
# 校验 / 解压
# --------------------------------------------------------------------------

def _sha256_bytes(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def _safe_relpath(name: str) -> str:
    """校验 manifest 里的文件路径，返回规范化的 posix 相对路径。"""
    raw = str(name or "").strip().replace("\\", "/")
    if not raw:
        raise UpdateError("更新包里有空文件名")
    if raw.startswith("/") or re.match(r"^[A-Za-z]:", raw):
        raise UpdateError(f"更新包含绝对路径，已拒绝：{raw}")
    parts = [p for p in raw.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise UpdateError(f"更新包含 .. 路径，已拒绝：{raw}")
    norm = "/".join(parts)
    if not norm:
        raise UpdateError("更新包里有空文件名")
    if norm.split("/")[0] == DATA_DIRNAME:
        raise UpdateError("更新包试图写「数据」目录，已拒绝（更新不会碰数据）")
    return norm


def _read_manifest(zf: zipfile.ZipFile) -> dict:
    try:
        raw = zf.read("manifest.json")
    except KeyError:
        raise UpdateError("这不是一个有效的更新包：缺少 manifest.json")
    except (OSError, zipfile.BadZipFile) as exc:
        raise UpdateError(f"更新包读取失败：{exc}")
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise UpdateError("更新包的 manifest.json 不是合法 JSON")
    if not isinstance(manifest, dict):
        raise UpdateError("manifest.json 格式不对")
    if str(manifest.get("app") or "") != APP_ID:
        raise UpdateError("这个更新包不是「形学 · 升级版」的")
    version = str(manifest.get("version") or "").strip()
    if _vtuple(version) is None:
        raise UpdateError(f"更新包版本号看不懂：{version!r}")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise UpdateError("更新包里的文件清单是空的")
    if len(files) > MAX_FILES:
        raise UpdateError("更新包文件数量异常，已拒绝")
    manifest["version"] = version
    manifest["_files"] = []          # [(规范化路径, sha256, size)]
    seen = set()
    total = 0
    for item in files:
        if not isinstance(item, dict):
            raise UpdateError("更新包文件清单格式不对")
        norm = _safe_relpath(item.get("path"))
        if norm in seen:
            raise UpdateError(f"更新包文件清单里有重复路径：{norm}")
        seen.add(norm)
        sha = str(item.get("sha256") or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{64}", sha):
            raise UpdateError(f"文件校验值不合法：{norm}")
        try:
            size = int(item.get("size") or 0)
        except (TypeError, ValueError):
            raise UpdateError(f"文件大小不合法：{norm}")
        if size < 0:
            raise UpdateError(f"文件大小不合法：{norm}")
        total += size
        if total > MAX_UNCOMPRESSED_BYTES:
            raise UpdateError("更新包解压后太大了，已拒绝")
        manifest["_files"].append((norm, sha, size))
    return manifest


def _extract_verified(zf: zipfile.ZipFile, manifest: dict, staging: Path) -> int:
    """把 zip 里的 files/* 解压到 staging/files/*，逐个文件校验大小和 sha256。"""
    files_dir = staging / "files"
    files_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for norm, sha, size in manifest["_files"]:
        member = f"files/{norm}"
        try:
            info = zf.getinfo(member)
        except KeyError:
            raise UpdateError(f"更新包缺少文件：{norm}")
        blob = zf.read(info)
        if len(blob) != size:
            raise UpdateError(f"文件大小不对：{norm}")
        if _sha256_bytes(blob) != sha:
            raise UpdateError(f"文件校验失败（可能没下载完整）：{norm}")
        target = files_dir / norm
        _write_bytes_retry(target, blob)
        count += 1
    return count


def validate_and_stage(
    data_dir: Path,
    raw: bytes,
    *,
    program_dir: Path | None = None,
    allow_dev: bool = False,
) -> dict:
    """校验更新包并解压到 staging（不替换任何现有文件）。

    返回 {ok, version, from, files, size, notes, pending}；
    失败抛 UpdateError（消息可直接给用户看）。
    """
    data = Path(data_dir)
    program = Path(program_dir or app_dir())

    if os.environ.get("XINGXUE_UPDATE_ALLOW_DEV") == "1":
        allow_dev = True
    if not allow_dev and not is_frozen():
        raise UpdateError("开发模式不支持自动更新（只在打包版里生效）。"
                          "想测试请用打包后的程序。")
    if len(raw) > MAX_PACKAGE_BYTES:
        raise UpdateError(f"更新包太大（{len(raw) / 1024 / 1024:.1f} MB），已拒绝")
    if not raw:
        raise UpdateError("没有收到更新包内容")

    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
    except (zipfile.BadZipFile, OSError):
        raise UpdateError("这个文件不是有效的 zip 更新包")
    with zf:
        manifest = _read_manifest(zf)
        current = installed_version(program)
        new = manifest["version"]
        min_ver = str(manifest.get("min_version") or "").strip()
        if min_ver and _vtuple(min_ver) and _vtuple(current) and _vtuple(current) < _vtuple(min_ver):
            raise UpdateError(
                f"当前版本 {current} 太旧了（这个更新包要求至少 {min_ver}），"
                "请用完整安装包更新。")
        if compare_versions(new, current) <= 0:
            raise UpdateError(f"更新包版本 {new} 不比当前版本 {current} 新，不需要更新。")

        # 解压到 staging：默认目录删不掉/写不进（只读、被安全软件占用）时自动换目录
        old_default = staging_dir(data)
        _force_remove(old_default)
        staging: Path | None = None
        count = 0
        errors: list[str] = []
        for cand in _staging_candidates(data):
            try:
                _force_remove(cand)
                cand.mkdir(parents=True, exist_ok=True)
                count = _extract_verified(zf, manifest, cand)
                staging = cand
                break
            except UpdateError:
                _force_remove(cand)
                raise
            except OSError as exc:
                errors.append(f"{cand}: {exc}")
                _force_remove(cand)
                continue
        if staging is None:
            raise UpdateError(
                "解压更新包失败：暂存目录写不进去，可能被 Windows 安全中心/杀毒软件拦住了。"
                "可以试试：① 把程序文件夹移到「文档/桌面」以外的普通目录；"
                "② 暂时关闭杀毒软件的实时防护再点一次；"
                "③ 用安装包重装到本机（会装到 AppData，不受影响）。"
                "详细错误：" + "；".join(errors[-2:]))
        staging_note = "" if staging == old_default else f"暂存目录已自动换到：{staging}"
        _write_bytes_retry(
            staging / "manifest.json",
            json.dumps({k: v for k, v in manifest.items() if not k.startswith("_")},
                       ensure_ascii=False, indent=2).encode("utf-8"))
        pending = {
            "kind": "update",
            "from": current,
            "to": new,
            "build": str(manifest.get("build") or ""),
            "notes": str(manifest.get("notes") or ""),
            "files": count,
            "size": sum(s for _, _, s in manifest["_files"]),
            "staged_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "staging": str(staging),
            "staging_note": staging_note,
        }
        _write_pending(data, pending)
        return {
            "ok": True,
            "version": new,
            "from": current,
            "files": count,
            "size": pending["size"],
            "notes": pending["notes"],
            "staging": str(staging),
            "staging_note": staging_note,
            "pending": pending,
        }


# --------------------------------------------------------------------------
# 下载（固定分支三路直链 + 系统 curl + 证书兜底）
# --------------------------------------------------------------------------

def _host(url: str) -> str:
    m = re.match(r"^https?://([^/]+)", str(url or ""))
    return m.group(1) if m else str(url or "?")[:40]


def _short(exc: BaseException, limit: int = 140) -> str:
    text = str(exc or "").replace("\n", " ").strip()
    return text[:limit] + ("…" if len(text) > limit else "")


def _looks_like_ssl_error(exc: BaseException) -> bool:
    text = f"{exc} {getattr(exc, 'reason', '')}".lower()
    return ("certificate" in text or "ssl" in text or "cert" in text)


def _curl_exe() -> Path | None:
    exe = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "curl.exe"
    return exe if exe.is_file() else None


def _download_urllib(url: str, timeout: float, verify: bool = True) -> bytes:
    context = None
    if not verify:
        # 仅作最后兜底（加速器/代理替换证书时）；更新包后面还会做 sha256 校验
        context = ssl._create_unverified_context()  # noqa: S323
    req = urllib.request.Request(url, headers={
        "User-Agent": "xingxue-upgrade-updater/1.0",
        "Cache-Control": "no-cache",
    })
    with urllib.request.urlopen(req, timeout=timeout, context=context) as resp:
        data = resp.read(MAX_PACKAGE_BYTES + 1)
    return data


def _download_curl(url: str, timeout: float) -> bytes:
    """用 Windows 自带的 curl.exe 下载（走系统证书/系统代理，Python SSL 出问题时它往往能通）。"""
    curl = _curl_exe()
    if curl is None:
        raise UpdateError("系统没有 curl.exe，跳过这个下载通道")
    fd, tmp_name = tempfile.mkstemp(prefix="xingxue-dl-", suffix=".bin")
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        cmd = [str(curl), "-L", "--fail", "--silent", "--show-error",
               "--ssl-no-revoke",          # 有些网络查不了证书吊销状态，不加会报 CRYPT_E_NO_REVOCATION_CHECK
               "--connect-timeout", "20", "--max-time", str(int(timeout)),
               "-o", str(tmp), url]
        proc = subprocess.run(cmd, capture_output=True, timeout=timeout + 30)
        if proc.returncode != 0:
            err = (proc.stderr or b"").decode("utf-8", "replace").strip()[:300]
            raise UpdateError(f"curl 下载失败（{proc.returncode}）：{err}")
        return tmp.read_bytes()
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


def _validate_download(data: bytes, *, what: str) -> bytes:
    if not data:
        raise UpdateError(f"下载到的{what}是空的")
    if len(data) > MAX_PACKAGE_BYTES:
        raise UpdateError(f"下载到的{what}太大，已放弃")
    return data


def _download_any(urls: list[str], *, timeout: float = 240.0,
                  what: str = "更新包") -> tuple[bytes, str]:
    """按"通道优先"的顺序尝试：所有地址先直连 → 全失败再全部用系统 curl →
    再不行全部跳过证书校验。

    为什么不是"一个地址把三种办法试完再换下一个"：国内网络下
    raw.githubusercontent 的 **Python urllib 直连**可能一直卡到超时，
    而系统 curl 很快就能通；如果死磕第一个地址，用户会等好几分钟。
    按通道分层，任何一路能通就能尽快拿到东西。
    """
    urls = [str(u or "").strip() for u in urls]
    urls = [u for u in urls if u.lower().startswith(("http://", "https://"))]
    if not urls:
        raise UpdateError(f"没有可用的{what}下载地址")
    errors: list[str] = []
    rounds = (
        ("直连", lambda url: _download_urllib(url, min(timeout, 45.0), True)),
        ("curl", lambda url: _download_curl(url, min(timeout, 120.0))),
        ("跳过证书", lambda url: _download_urllib(url, min(timeout, 60.0), False)),
    )
    for label, fetch in rounds:
        for url in urls:
            try:
                blob = fetch(url)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{label} {_host(url)}：{_short(exc)}")
                continue
            try:
                return _validate_download(blob, what=what), url
            except UpdateError as exc:
                errors.append(f"{label} {_host(url)}：{exc}")
                continue
    raise UpdateError(f"{what}下载失败：" + "；".join(errors[-3:]))


def _parse_meta(raw: bytes) -> dict:
    """解析 update.json（固定分支里的更新信息）。"""
    try:
        meta = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise UpdateError("更新信息不是合法 JSON（可能被网络拦截返回了网页）")
    if not isinstance(meta, dict):
        raise UpdateError("更新信息格式不对")
    app = str(meta.get("app") or "").strip()
    if app and app != APP_ID:
        raise UpdateError("这个更新信息不是「形学 · 升级版」的")
    version = str(meta.get("version") or "").strip()
    if _vtuple(version) is None:
        raise UpdateError(f"更新信息里的版本号看不懂：{version!r}")
    urls = meta.get("urls")
    clean: list[str] = []
    if isinstance(urls, list):
        for item in urls:
            text = str(item or "").strip()
            if text.lower().startswith(("http://", "https://")) and text not in clean:
                clean.append(text)
    if not clean:
        from .update_sites import DOWNLOAD_FALLBACKS, DOWNLOAD_URL

        clean = [u for u in [DOWNLOAD_URL, *DOWNLOAD_FALLBACKS] if u]
    if not clean:
        raise UpdateError("更新信息里没有下载地址")
    meta["urls"] = clean
    meta["version"] = version
    sha = str(meta.get("sha256") or "").strip().lower()
    if sha and not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise UpdateError("更新信息里的 sha256 校验值不合法")
    meta["sha256"] = sha
    return meta


def fetch_update_meta() -> dict:
    """读 update.json（多路直链容错），返回校验过格式的 meta。

    为什么要**把所有路都读一遍再取最高版本**（而不是第一条成功就返回）：
    raw.githubusercontent / jsDelivr 都是 CDN，同一个固定路径刚发布新版本时，
    可能一路已经刷新、另一路还是旧文件。如果第一条成功就返回，
    读到的旧 update.json 会说"已是最新"，用户就永远收不到更新。
    取"所有成功读到的版本里最高的那个"才稳。

    通道顺序也是分层的（直连 → 系统 curl → 跳过证书）：国内网络下
    Python 的 urllib 连 raw.githubusercontent 可能卡到超时，而系统 curl
    经常几秒就通；不能在一个地址上死磕。
    """
    from .update_sites import META_URLS

    if not META_URLS:
        raise UpdateError("还没配置更新通道（构建时没生成 her_review/github_config.py）")
    errors: list[str] = []
    best: dict | None = None
    ok_urls: set[str] = set()
    rounds = (
        ("直连", lambda url: _download_urllib(url, 12.0, True)),
        ("curl", lambda url: _download_curl(url, 25.0)),
        ("跳过证书", lambda url: _download_urllib(url, 12.0, False)),
    )
    for label, fetch in rounds:
        for url in META_URLS:
            if url in ok_urls:
                continue
            try:
                raw = fetch(url)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{label} {_host(url)}：{_short(exc)}")
                continue
            ok_urls.add(url)
            try:
                meta = _parse_meta(raw)
            except UpdateError as exc:
                errors.append(f"{label} {_host(url)}：{exc}")
                continue
            meta["meta_url"] = url
            if best is None or _meta_key(meta) > _meta_key(best):
                best = meta
    if best is None:
        raise UpdateError("读取更新信息失败（连不上下载服务器）：" + "；".join(errors[-2:]))
    return best


def _meta_key(meta: dict) -> tuple:
    """比较两个 update.json 谁更新：先看版本号，同版本再看 build（时间戳串）。"""
    return (_vtuple(str(meta.get("version") or "")) or (0, 0, 0),
            str(meta.get("build") or ""))


def _validate_package_bytes(raw: bytes, meta: dict) -> bytes:
    """校验下载到的更新包：大小 + sha256（必须通过）。"""
    if not raw:
        raise UpdateError("下载到的更新包是空的")
    if len(raw) > MAX_PACKAGE_BYTES:
        raise UpdateError("下载到的更新包太大，已放弃")
    if not raw.startswith(b"PK"):
        raise UpdateError("下载到的不是 zip 更新包（可能被网络拦截返回了网页）")
    try:
        size = int(meta.get("size") or 0)
    except (TypeError, ValueError):
        size = 0
    if size > 0 and len(raw) != size:
        raise UpdateError(f"更新包大小不对（期望 {size} 字节，实际 {len(raw)}）")
    sha = str(meta.get("sha256") or "").strip().lower()
    if not sha:
        raise UpdateError("更新信息里没有 sha256 校验值，已拒绝安装")
    got = _sha256_bytes(raw)
    if got != sha:
        raise UpdateError("更新包校验失败（sha256 不一致）")
    return raw


def fetch_package(meta: dict) -> bytes:
    """按 update.json 里的地址下载更新包，**每一路拿到就当场校验 sha256**。

    为什么按路由逐条校验（而不是先拿到内容再校验）：CDN 缓存不一致时，
    前一路可能还是旧包（sha 对不上），后面的路已经是新包——必须跳过
    内容不对的那一路继续试，不能直接报错。
    """
    from .update_sites import DOWNLOAD_FALLBACKS, DOWNLOAD_URL

    urls: list[str] = list(meta.get("urls") or [])
    for extra in [DOWNLOAD_URL, *DOWNLOAD_FALLBACKS]:
        if extra and extra not in urls:
            urls.append(extra)
    errors: list[str] = []
    ok_urls: set[str] = set()
    rounds = (
        ("直连", lambda url: _download_urllib(url, 45.0, True)),
        ("curl", lambda url: _download_curl(url, 120.0)),
        ("跳过证书", lambda url: _download_urllib(url, 60.0, False)),
    )
    for label, fetch in rounds:
        for url in urls:
            if url in ok_urls:
                continue
            try:
                raw = fetch(url)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{label} {_host(url)}：{_short(exc)}")
                continue
            ok_urls.add(url)
            try:
                _validate_package_bytes(raw, meta)
            except UpdateError as exc:
                errors.append(f"{label} {_host(url)}：{exc}（可能是 CDN 还没刷新）")
                continue
            meta["downloaded_from"] = url
            return raw
    raise UpdateError("下载更新包失败：" + "；".join(errors[-2:])
                      + "。 如果一直校验失败，多半是分发服务器还在缓存旧文件，"
                        "过几分钟再点一次；或点「打开下载页」用浏览器手动下载后"
                        "「选择更新包」。")


def download_and_stage(data_dir: Path, program_dir: Path | None = None) -> dict:
    """应用内一键更新：读 update.json → 比版本 → 下载 → 校验 → 暂存。

    **不替换现有程序**；真正替换要用户点「立即重启并更新」。
    """
    program = Path(program_dir or app_dir())
    meta = fetch_update_meta()
    current = installed_version(program)
    latest = str(meta.get("version") or "")
    if compare_versions(latest, current) <= 0:
        raise UpdateError(f"当前已是最新版本（{current}）。")
    raw = fetch_package(meta)
    info = validate_and_stage(data_dir, raw, program_dir=program)
    info["latest"] = latest
    info["meta"] = {k: v for k, v in meta.items() if k in
                    ("version", "build", "size", "sha256", "notes", "meta_url", "downloaded_from")}
    return info


def cancel(data_dir: Path) -> dict:
    """取消这次已暂存的更新（删掉 staging 和 pending，不动现有程序）。"""
    data = Path(data_dir)
    staging = active_staging(data)
    clear_pending(data)
    _force_remove(staging)
    _clear_staging(data)
    return {"ok": True, "message": "已取消这次更新"}


# --------------------------------------------------------------------------
# 应用（重启后替换）
# --------------------------------------------------------------------------

def _write_apply_script(data_dir: Path) -> Path:
    root = update_root(data_dir)
    root.mkdir(parents=True, exist_ok=True)
    # 清掉以前遗留的脚本（脚本自己删除自己偶尔会失败）
    for pat in ("apply-*.cmd", "apply-*.ps1"):
        for old in root.glob(pat):
            try:
                old.unlink()
            except OSError:
                pass
    script = root / f"apply-{int(time.time())}.ps1"
    script.write_text(_APPLY_PS1, encoding="ascii")
    return script


def spawn_applier(data_dir: Path, program_dir: Path | None = None, pid: int | None = None,
                  staging: Path | None = None) -> Path:
    """启动"等进程退出 → 关旧程序 → 拷贝新文件 → 启动新 exe"的脚本（分离进程）。"""
    if not _WIN:
        raise UpdateError("自动更新目前只支持 Windows")
    program = Path(program_dir or app_dir())
    staging = Path(staging or active_staging(data_dir))
    script = _write_apply_script(data_dir)
    env = os.environ.copy()
    env.update({
        "XINGXUE_PID": str(pid if pid is not None else os.getpid()),
        "XINGXUE_APPDIR": str(program),
        "XINGXUE_STAGING": str(staging),
        "XINGXUE_EXE": exe_name(),
        "XINGXUE_LOG": str(apply_log(data_dir)),
    })
    powershell = (Path(os.environ.get("SystemRoot", r"C:\Windows"))
                  / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe")
    launcher = [str(powershell), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden", "-File", str(script)]
    if not powershell.is_file():
        launcher = ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                    "-WindowStyle", "Hidden", "-File", str(script)]
    subprocess.Popen(
        launcher,
        cwd=str(data_dir),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=_CREATE_FLAGS,
        close_fds=True,
    )
    return script


def schedule_exit(delay: float = 1.2) -> None:
    """后台线程：稍等一下（让 HTTP 响应先发出去）→ 退出后端进程。

    后端退出后，PowerShell 脚本会收掉旧主程序窗口、替换文件、再启动新版本。
    """

    def _run() -> None:
        time.sleep(max(0.4, float(delay)))
        os._exit(0)

    threading.Thread(target=_run, daemon=True).start()


def apply_now(data_dir: Path, program_dir: Path | None = None) -> dict:
    """开始替换流程：写 PowerShell 脚本并启动它；调用方随后负责 schedule_exit()。"""
    pending = read_pending(data_dir)
    if not pending:
        raise UpdateError("还没有准备好更新包，请先「一键更新」或「选择更新包」。")
    staging = active_staging(data_dir)
    if not staging.is_dir():
        raise UpdateError("更新包暂存目录不见了，请重新下载或重新选择更新包。")
    script = spawn_applier(data_dir, program_dir, staging=staging)
    return {"ok": True, "version": pending.get("to"), "from": pending.get("from"),
            "script": str(script), "restart": True}


# --------------------------------------------------------------------------
# 给状态接口用
# --------------------------------------------------------------------------

def make_state(data_dir: Path, program_dir: Path | None = None) -> dict:
    data = Path(data_dir)
    program = Path(program_dir or app_dir())
    current = installed_version(program)
    pending = read_pending(data)
    # 上次的更新已经装上了（重启后）：清掉 pending/staging，
    # 否则设置页会一直显示"已准备好更新 1.1.6 → 1.1.7"，而当前已经是 1.1.7。
    if pending and compare_versions(str(pending.get("to") or ""), current) == 0:
        try:
            _force_remove(active_staging(data))
        except OSError:
            pass
        clear_pending(data)
        pending = None
    writable = False
    try:
        probe = program / ".update_write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        writable = True
    except OSError:
        writable = False
    update_root(data).mkdir(parents=True, exist_ok=True)
    return {
        "ok": True,
        "version": current,
        "build": installed_build(program),
        "app_dir": str(program),
        "data_dir": str(data),
        "exe": exe_name(),
        "dev_mode": not is_frozen(),
        "writable": writable,
        "pending": pending,
        "staging_ready": active_staging(data).is_dir(),
        "max_package_mb": round(MAX_PACKAGE_BYTES / 1024 / 1024),
        "apply_log": str(apply_log(data)),
    }


# --------------------------------------------------------------------------
# 自测（python -m her_review.updater）
# --------------------------------------------------------------------------

def _make_package(version: str, files: dict[str, bytes], *, app: str = APP_ID,
                  bad_sha: bool = False, traversal: bool = False) -> bytes:
    buf = io.BytesIO()
    entries = []
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        items = dict(files)
        if traversal:
            items["../evil.txt"] = b"x"
        for name, blob in items.items():
            zf.writestr(f"files/{name}", blob)
            sha = _sha256_bytes(blob) if not bad_sha else "0" * 64
            entries.append({"path": name, "sha256": sha, "size": len(blob)})
        manifest = {
            "app": app,
            "version": version,
            "build": "test",
            "min_version": "1.0.0",
            "published_at": datetime.now().isoformat(timespec="seconds"),
            "notes": "自测",
            "files": entries,
        }
        zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
    return buf.getvalue()


def _selftest() -> None:
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        data = base / "数据"
        program = base / "程序"
        data.mkdir()
        program.mkdir()
        (program / "version.json").write_text(
            json.dumps({"version": "1.1.6", "build": "old"}), encoding="utf-8")
        (program / "app.txt").write_text("old", encoding="utf-8")

        # 坏包：不是 zip
        try:
            validate_and_stage(data, b"not a zip", program_dir=program, allow_dev=True)
            raise AssertionError("坏包应该报错")
        except UpdateError:
            pass
        # 坏包：app id 不对
        pkg = _make_package("1.1.7", {"app.txt": b"new"}, app="other-app")
        try:
            validate_and_stage(data, pkg, program_dir=program, allow_dev=True)
            raise AssertionError("app id 不对应该报错")
        except UpdateError:
            pass
        # 坏包：路径穿越
        pkg = _make_package("1.1.7", {"app.txt": b"new"}, traversal=True)
        try:
            validate_and_stage(data, pkg, program_dir=program, allow_dev=True)
            raise AssertionError("路径穿越应该报错")
        except UpdateError:
            pass
        # 坏包：sha 不对
        pkg = _make_package("1.1.7", {"app.txt": b"new"}, bad_sha=True)
        try:
            validate_and_stage(data, pkg, program_dir=program, allow_dev=True)
            raise AssertionError("sha 不对应该报错")
        except UpdateError:
            pass
        # 版本不比当前新
        pkg = _make_package("1.1.6", {"app.txt": b"new"})
        try:
            validate_and_stage(data, pkg, program_dir=program, allow_dev=True)
            raise AssertionError("旧版本应该报错")
        except UpdateError:
            pass
        # 好包：staging + pending
        pkg = _make_package("1.1.7", {
            "app.txt": b"new",
            "version.json": json.dumps({"version": "1.1.7", "build": "new"}).encode(),
        })
        info = validate_and_stage(data, pkg, program_dir=program, allow_dev=True)
        assert info["ok"] and info["version"] == "1.1.7", info
        files_dir = staging_dir(data) / "files"
        assert (files_dir / "app.txt").read_bytes() == b"new"
        assert read_pending(data)["to"] == "1.1.7"
        assert compare_versions("1.2.0", "1.10.0") < 0
        assert compare_versions("1.10.0", "1.10.0") == 0
        assert compare_versions("1.1.7", "1.1.6") > 0
        assert _safe_relpath("a/b.txt") == "a/b.txt"
        for bad in ("../x", "/abs", "C:/x", "数据/config.json", "", "a/../../b"):
            try:
                _safe_relpath(bad)
                raise AssertionError(f"应该拒绝：{bad!r}")
            except UpdateError:
                pass

        # update.json 解析
        meta = _parse_meta(json.dumps({
            "app": "xingxue-plus", "version": "1.1.8", "sha256": "a" * 64,
            "urls": ["https://raw.githubusercontent.com/x/y/b/z.zip"],
        }).encode())
        assert meta["version"] == "1.1.8" and meta["urls"], meta
        try:
            _parse_meta(json.dumps({"app": "xingxue-ic", "version": "2.0.0"}).encode())
            raise AssertionError("app 不对的 update.json 应该报错")
        except UpdateError:
            pass

        # 模拟「默认暂存目录写不进去（Permission denied）」→ 自动换新暂存目录
        clear_pending(data)
        _clear_staging(data)
        real_extract = _extract_verified

        def _locked_extract(zf, manifest, staging):
            if Path(staging) == staging_dir(data):
                raise PermissionError(13, "Permission denied",
                                      str(staging / "files" / "_internal" / "ucrtbase.dll"))
            return real_extract(zf, manifest, staging)

        globals()["_extract_verified"] = _locked_extract
        try:
            pkg2 = _make_package("1.1.8", {
                "app.txt": b"v2",
                "version.json": json.dumps({"version": "1.1.8", "build": "new"}).encode(),
            })
            info2 = validate_and_stage(data, pkg2, program_dir=program, allow_dev=True)
            assert info2["ok"], info2
            used = active_staging(data)
            assert used != staging_dir(data), "默认暂存目录写不进时应该换一个暂存目录"
            assert (used / "files" / "app.txt").read_bytes() == b"v2"
            assert str(info2["staging"]) == str(used)
            assert info2["staging_note"], "应该提示暂存目录换了位置"
            print("默认暂存目录写不进时自动换目录：通过")
        finally:
            globals()["_extract_verified"] = real_extract

        # 状态：pending 的 to == 当前版本时应自动清掉（模拟更新已装好、重启后）
        (program / "version.json").write_text(
            json.dumps({"version": "1.1.8", "build": "new"}), encoding="utf-8")
        state = make_state(data, program)
        assert state["version"] == "1.1.8", state
        assert state["pending"] is None, state
        print("更新装好后自动清 pending：通过")

        _force_remove(staging_dir(data))
        _force_remove(active_staging(data))
        clear_pending(data)
        print("updater selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
