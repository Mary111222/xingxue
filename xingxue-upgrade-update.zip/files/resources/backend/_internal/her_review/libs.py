"""可选增强库的加载。

背景：这个程序的底线是**零第三方依赖**——不装任何库也能完整运行。
`bootstrap.py` 可以把 rich / httpx / diskcache 这些"锦上添花"的库
装到程序目录下的 `.pylibs/`，装了更好用，不装也能跑。

**为什么单独抽成一个模块**（这是踩过坑的）：

    原来每个入口各自写一份 `_activate_local_libs()`。
    结果 `__main__.py`（命令行）和 `web.py`（浏览器模式）都有，
    而后来新加的 `app.py`（桌面窗口模式）**漏了**。

    后果很难发现，因为两边都不报错：
        · 命令行 `her doctor` 说"6/6 可用"（它激活了）
        · 界面里的环境自检说"未安装"（它没激活）
    同一个程序两个说法，用户第一反应是"这程序不可信"。

    所以现在只有**这一个** `activate()`，三个入口都调它，
    并且 verify_libs.py 里有一条测试专门守"所有入口都调了"。
"""

from __future__ import annotations

import sys
from pathlib import Path

# 程序目录下的库目录名
LOCAL_LIB_DIR = ".pylibs"


def local_lib_path(anchor: str | Path | None = None) -> Path:
    """算出 .pylibs 的绝对路径。

    默认以**这个文件所在包的上一级**（也就是程序根目录）为基准，
    而不是当前工作目录——双击启动时工作目录可能是别处。
    """
    if anchor is not None:
        return Path(anchor) / LOCAL_LIB_DIR
    # __file__ = <root>/her_review/libs.py → parent.parent = <root>
    return Path(__file__).resolve().parent.parent / LOCAL_LIB_DIR


def activate(anchor: str | Path | None = None) -> bool:
    """把 .pylibs 加进 sys.path。返回是否真的加了。

    必须在使用那些库**之前**调用——rich / httpx 这些一旦被 import，
    模块对象就定下来了，之后再改 sys.path 也没用。

    目录不存在就安静返回 False（没装增强库是完全正常的状态）。
    """
    path = local_lib_path(anchor)
    if not path.is_dir():
        return False
    text = str(path)
    if text in sys.path:
        return False
    # 放在最前面：这样 .pylibs 里的版本优先于系统里可能存在的旧版本，
    # 保证"我装的那份"就是实际生效的那份。
    sys.path.insert(0, text)
    return True


def prepare() -> list[str]:
    """激活增强库，并做目录规范化。

    返回已激活的库名列表（给入口打印用）。

    目录规范化（site.addsitedir）不能少：用 sys.path.insert 的话
    `.pylibs/*.dist-info` 不会被识别成"已安装的包"，
    于是 `importlib.metadata.version("rich")` 拿不到版本号，
    环境自检里那一栏会显示成 `unknown`。
    我自己被这个坑过一次。
    """
    path = local_lib_path()
    if not path.is_dir():
        return []

    import site

    # addsitedir 会处理 .pth 文件并把 dist-info 登记进 importlib.metadata
    site.addsitedir(str(path))
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

    names: list[str] = []
    try:
        from . import deps

        names = [lib.key for lib in getattr(deps, "LIBRARIES", [])
                 if deps.available(lib.key)]
    except Exception:
        pass
    return names


if __name__ == "__main__":  # pragma: no cover - 手动自测入口
    p = local_lib_path()
    print(f".pylibs 路径：{p}")
    print(f"存在：{p.is_dir()}")
    got = prepare()
    print(f"已激活：{got or '（没有）'}")
