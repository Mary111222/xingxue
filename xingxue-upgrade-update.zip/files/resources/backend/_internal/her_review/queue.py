"""复习队列：四层过滤 + 标签规范化。

借自 VeoStudyHub 的"题型形状校验"思想：
    不同题型有各自的合法形状（单选只能一个答案、答案必须在选项里…），
    只靠"模型自觉"就会出现无法评分的结果，所以要在服务端按形状拒绝。
    而且它把"候选清洗 → 形状校验 → 去重"拆成独立步骤，
    避免校验逻辑堆在一个高复杂度函数里。

对应到 her 的复习队列，问题是：
    "今天该复习什么"这只是个 SQL 查询（due <= today），没有任何校验。
    于是会出现这些真实情况：
    - 一道题没有 note 也没有 url，复习时她只能干瞪眼（信息缺失）
    - 标签是手打的，"DP" 和 "动态规划" 被当成两个知识点，统计就废了
    - 同一天到期几十道，队列过长反而让人不想开始

所以这里把队列构建拆成四层，每层职责单一、都能单独测：

    第 1 层 资格（eligible）：归档的不进队列
    第 2 层 形状（shape）   ：缺 note 又缺 url 的标为"信息不足"，仍进队列但提醒
    第 3 层 去重（dedupe）  ：标题重复、或同一道题同时被 due 和 extra 选中
    第 4 层 限额（cap）     ：按优先级排序后截断，并如实报告"被截掉多少"

输出带一份 QueueReport，她能看到"今天为什么是这几道"。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import ui

# --------------------------------------------------------------------------
# 标签规范化
# --------------------------------------------------------------------------

# 题库自带的标准标签（bank.py 里的 tags 汇总），作为"已知词汇表"
def standard_tags() -> set[str]:
    from . import bank

    tags: set[str] = set()
    for item in bank.BANK:
        tags.update(item.get("tags") or [])
    return tags


# 常见写法 → 标准写法。她手打的时候总会写出各种变体。
TAG_ALIASES: dict[str, str] = {
    "dp": "动态规划",
    "动态规划dp": "动态规划",
    "动规": "动态规划",
    "dfs": "DFS",
    "深度优先": "DFS",
    "深度优先搜索": "DFS",
    "bfs": "BFS",
    "广度优先": "BFS",
    "广度优先搜索": "BFS",
    "二分": "二分查找",
    "二分法": "二分查找",
    "binary search": "二分查找",
    "双指针法": "双指针",
    "two pointers": "双指针",
    "滑窗": "滑动窗口",
    "滑动窗体": "滑动窗口",
    "单调队列": "单调栈",
    "linked list": "链表",
    "tree": "二叉树",
    "树": "二叉树",
    "graph": "图",
    "图论": "图",
    "hash": "哈希表",
    "hashmap": "哈希表",
    "哈希": "哈希表",
    "heap": "堆",
    "优先队列": "堆",
    "stack": "栈",
    "queue": "队列",
    "bit": "位运算",
    "位操作": "位运算",
    "recursion": "递归",
    "回溯法": "回溯",
    "贪心法": "贪心",
    "排序算法": "排序",
    "字符串匹配": "字符串",
    "并查集uf": "并查集",
    "union find": "并查集",
    "trie": "字典树",
    "前缀树": "字典树",
    "segment tree": "线段树",
    "线段树入门": "线段树",
    "kmp算法": "字符串",
}


@dataclass
class TagNormalization:
    tags: list[str] = field(default_factory=list)
    changed: dict[str, str] = field(default_factory=dict)   # 原 → 规范
    unknown: list[str] = field(default_factory=list)        # 不在标准词汇表里的

    def summary(self) -> str:
        if not self.changed and not self.unknown:
            return "标签都规范"
        parts = []
        if self.changed:
            pairs = "、".join(f"{k}→{v}" for k, v in list(self.changed.items())[:4])
            parts.append(f"规范化 {len(self.changed)} 个（{pairs}）")
        if self.unknown:
            parts.append(f"非标准 {len(self.unknown)} 个（{'、'.join(self.unknown[:4])}）")
        return "；".join(parts)


def normalize_tags(tags: list[str]) -> TagNormalization:
    """把标签统一到标准写法。

    三条规则：
        1. 别名表直接映射（dp → 动态规划）
        2. 大小写统一：DFS/BFS/DP 这类保持大写，其余保持原样
        3. 不在标准词汇表里的**保留但记录**——她可能就是想加自己的标签，
           不能因为"不在表里"就丢掉她的东西
    """
    standard = standard_tags()
    lower_map = {t.lower(): t for t in standard}
    result = TagNormalization()
    seen: set[str] = set()

    for raw in tags or []:
        tag = (raw or "").strip().lstrip("#")
        if not tag:
            continue
        key = tag.lower()
        canonical = ""

        if key in TAG_ALIASES:
            canonical = TAG_ALIASES[key]
        elif tag in standard:
            canonical = tag
        elif key in lower_map:
            canonical = lower_map[key]
        else:
            # 不在标准表里：看看去掉常见后缀能不能对上
            for suffix in ("算法", "基础", "入门", "专题", "问题"):
                if key.endswith(suffix) and key[: -len(suffix)] in lower_map:
                    canonical = lower_map[key[: -len(suffix)]]
                    break
            if not canonical:
                canonical = tag

        if canonical != tag:
            result.changed[tag] = canonical
        if canonical not in seen:
            seen.add(canonical)
            result.tags.append(canonical)
        if canonical not in standard:
            result.unknown.append(canonical)

    return result


# --------------------------------------------------------------------------
# 队列
# --------------------------------------------------------------------------

@dataclass
class QueueReport:
    requested: int = 0                # 请求要几道（0 = 不限）
    eligible: int = 0                 # 第 1 层通过
    shape_ok: int = 0                 # 第 2 层通过
    deduped: int = 0                  # 第 3 层去掉几道
    dropped_by_cap: int = 0           # 第 4 层截掉几道
    skipped_archived: int = 0
    thin: list[str] = field(default_factory=list)      # 信息不足的题（仍进队列）
    duplicates: list[str] = field(default_factory=list)
    tag_note: str = ""

    def lines(self) -> list[str]:
        out: list[str] = []
        if self.eligible:
            out.append(ui.c("候选      ", "grey")
                       + ui.c(f"{self.eligible} 道", "plum")
                       + (ui.c(f"（归档跳过 {self.skipped_archived} 道）", "grey")
                          if self.skipped_archived else ""))
        if self.deduped:
            out.append(ui.c("去重      ", "grey")
                       + ui.c(f"去掉 {self.deduped} 道", "grey")
                       + ui.c(f"（{'、'.join(self.duplicates[:3])}）", "grey"))
        if self.dropped_by_cap:
            out.append(ui.c("限额      ", "grey")
                       + ui.c(f"按优先级截掉 {self.dropped_by_cap} 道，明天再来", "gold"))
        if self.thin:
            out.append(ui.c("信息不足  ", "grey")
                       + ui.c(f"{len(self.thin)} 道没写思路也没存链接", "gold")
                       + ui.c(f"（{'、'.join(self.thin[:3])}）", "grey"))
        if self.tag_note:
            out.append(ui.c("标签      ", "grey") + ui.c(self.tag_note, "grey"))
        return out


def build_queue(store, today, *, limit: int = 0, extra_keyword: str = "") -> tuple[list, QueueReport]:
    """构建复习队列。返回 (题目列表, 过滤报告)。"""
    report = QueueReport(requested=limit)

    # ---- 第 1 层：资格（归档的永远不进）----
    candidates = store.due(today)
    archived = store.count(include_archived=True) - store.count()
    report.skipped_archived = max(0, archived)
    report.eligible = len(candidates)

    if extra_keyword:
        extra = [p for p in store.search(extra_keyword) if p not in candidates]
        candidates = candidates + extra

    # ---- 第 2 层：形状（信息够不够复习）----
    # 缺 note 又缺 url 的题：复习时既想不起思路、也打不开题目，标注出来
    for problem in candidates:
        if not (problem.note or "").strip() and not (problem.url or "").strip():
            report.thin.append(problem.short(18))
    report.shape_ok = len(candidates)

    # ---- 第 3 层：去重 ----
    seen_titles: dict[str, object] = {}
    unique: list = []
    for problem in candidates:
        key = (problem.title or "").strip().lower()
        if key and key in seen_titles:
            report.duplicates.append(problem.short(16))
            report.deduped += 1
            continue
        if key:
            seen_titles[key] = problem
        unique.append(problem)

    # 排序：逾期最久、忘得最多、信息完整的优先
    def priority(problem) -> tuple:
        has_info = 0 if (problem.note or problem.url) else 1
        return (problem.due, -problem.lapses, has_info, problem.id)

    unique.sort(key=priority)

    # ---- 第 4 层：限额 ----
    if limit and len(unique) > limit:
        report.dropped_by_cap = len(unique) - limit
        unique = unique[:limit]

    return unique, report


def normalize_problem_tags(store, problems) -> tuple[int, TagNormalization]:
    """把一批题目的标签规范化并写回。返回 (改了几道, 规范化汇总)。"""
    merged = TagNormalization()
    touched = 0
    for problem in problems:
        result = normalize_tags(problem.tags)
        merged.changed.update(result.changed)
        merged.unknown.extend(t for t in result.unknown if t not in merged.unknown)
        if result.tags != problem.tags:
            store.update(problem.id, tags=result.tags)
            touched += 1
    return touched, merged


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from ._testutil import temp_home
    from .db import Store
    from datetime import date

    ui.use_color(False)

    # ---- 标签规范化 ----
    r = normalize_tags(["dp", "二分", "hash", "#数组"])
    assert r.tags == ["动态规划", "二分查找", "哈希表", "数组"], r.tags
    assert r.changed["dp"] == "动态规划"

    # 大小写与标准词
    r = normalize_tags(["DFS", "bfs", "数组"])
    assert "DFS" in r.tags and "BFS" in r.tags, r.tags
    assert not r.unknown, f"DFS/BFS 是标准标签，不该算未知：{r.unknown}"

    # 她自己的标签要保留
    r = normalize_tags(["我的自创标签"])
    assert r.tags == ["我的自创标签"], "不在词表里也要保留，不能丢她的东西"
    assert r.unknown == ["我的自创标签"]

    # 去重
    r = normalize_tags(["dp", "动态规划", "DP"])
    assert r.tags == ["动态规划"], r.tags

    # 空值
    assert normalize_tags([]).tags == []
    assert normalize_tags(["", "  "]).tags == []

    with temp_home(".selftest-queue") as home:
        store = Store(":memory:")
        # 用一个"永远是过去"的日子 + 显式指定 due，
        # 这样测试结果和运行当天的真实日期无关（否则今天变了测试就红）
        today = date(2020, 6, 1)
        past = date(2020, 1, 1)

        # 一道信息完整的题
        full = store.add("完整题", tags=["动态规划"], url="https://x.com/1",
                         note="关键：状态定义", due=past)
        # 一道信息不足的题（没 note 没 url）
        thin = store.add("信息不足题", tags=["数组"], due=past)
        # 一道归档的（不该进队列）
        archived = store.add("归档题", tags=["数组"], due=past)
        store.archive(archived)

        queue, report = build_queue(store, today)
        titles = [p.title for p in queue]
        assert "完整题" in titles and "信息不足题" in titles, titles
        assert "归档题" not in titles, "归档题不该进队列"
        assert report.eligible == 2, report.eligible
        assert report.thin == ["信息不足题"], report.thin
        # 信息完整的排前面
        assert titles[0] == "完整题", titles

        # 限额
        for i in range(5):
            store.add(f"补充题{i}", tags=["数组"], note="有思路", due=past)
        queue, report = build_queue(store, today, limit=3)
        assert len(queue) == 3, len(queue)
        assert report.dropped_by_cap > 0, report.dropped_by_cap
        assert any("截掉" in ui._strip_ansi(l) for l in report.lines())

        # 去重：加一道同名的
        store.add("完整题", tags=["数组"], due=past)
        queue, report = build_queue(store, today, limit=0)
        assert report.deduped >= 1, report.deduped
        assert report.duplicates, report.duplicates

        # 标签写回
        store.update(full, tags=["dp", "二分"])
        touched, merged = normalize_problem_tags(store, [store.get(full)])
        assert touched == 1, touched
        assert store.get(full).tags == ["动态规划", "二分查找"], store.get(full).tags
        assert merged.changed

        store.close()

    print("queue selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
