"""从已登录的浏览器里读 B 站 cookies。

## 这条路能不能走通，取决于浏览器版本

Chromium 系（Edge / Chrome）的 cookies 加密方式**变过两次**：

    老版本   `v10` / `v11` 前缀，DPAPI（用户级密钥）
             → 同一个 Windows 用户下的程序可以解密 ✓

    127+     `v20` 前缀，**App-Bound Encryption**
             密钥绑定了具体的应用（浏览器自己），别处解不开 ✗

Edge 154 这种版本基本可以确定是 v20，也就是说**自动抓多半拿不到登录凭据**。

## 所以这个模块的设计原则：诚实

**不假装成功。** 具体做法：

    · 每一步的失败原因都**原样带出来**（文件锁着 / v20 加密 / 没找到 B 站 cookie）
    · 返回结构里带 `can_auto`，界面据此决定是"点一下就行"还是"请手动粘贴"
    · **绝不返回一个空的但看着成功的 cookies**——那会让界面显示"已登录"
      而搜索照样 412，变成最难查的那种问题

## 手动粘贴仍然是主力

不管自动能不能用，`cookies.save()` 那条路（她复制粘贴）
**永远可用、永远可靠**。所以界面上两条路都给，只是措辞不同：
自动那条成功就成功，失败就明确说"这个浏览器版本读不了，用下面的粘贴"。
"""

from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import os
import shutil
import sqlite3
import tempfile
from pathlib import Path

# 只找 she 可能用的几个。找不到就是找不到，不做全盘搜索
# （全盘搜索既慢又像恶意软件的行为）。
CHROMIUM_BROWSERS = {
    "Edge": ("LOCALAPPDATA", "Microsoft/Edge/User Data"),
    "Chrome": ("LOCALAPPDATA", "Google/Chrome/User Data"),
    "Brave": ("LOCALAPPDATA", "BraveSoftware/Brave-Browser/User Data"),
    "Chromium": ("LOCALAPPDATA", "Chromium/User Data"),
}

# Firefox 的 cookies 是**明文**的，不需要解密
FIREFOX = ("APPDATA", "Mozilla/Firefox")

BILI_HOSTS = ("%bilibili.com%", "%bilibili.cn%")


# --------------------------------------------------------------------------
#  DPAPI
# --------------------------------------------------------------------------

class _BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD),
                ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(data: bytes) -> bytes | None:
    """解一段 DPAPI 密文（当前用户）。失败返回 None。"""
    if not data:
        return None
    try:
        buf = ctypes.create_string_buffer(data, len(data))
        blob_in = _BLOB(len(data), ctypes.cast(buf,
                                              ctypes.POINTER(ctypes.c_char)))
        blob_out = _BLOB()
        ok = ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(blob_in), None, None, None, None, 0,
            ctypes.byref(blob_out))
        if not ok:
            return None
        out = ctypes.string_at(blob_out.pbData, blob_out.cbData)
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)
        return out
    except Exception:
        return None


def _decrypt_chromium(enc: bytes) -> tuple[str, str]:
    """解 Chromium 的 encrypted_value。

    返回 (明文, 说明)。说明里写清是怎么解的、或者为什么解不开——
    上层要用它给用户一句准确的话。
    """
    if not enc:
        return "", "空值"
    prefix = enc[:3].decode("latin1", "replace")

    if prefix == "v20":
        return "", ("这个浏览器的 cookie 是 v20（App-Bound）加密的，"
                    "密钥绑定了浏览器本身，外部程序解不开。")
    if prefix in ("v10", "v11"):
        out = _dpapi(enc[3:])
        if out is None:
            return "", f"DPAPI 解密失败（前缀 {prefix}）"
        return _strip_hmac(out), "DPAPI"
    # 没有前缀：老格式，直接 DPAPI
    out = _dpapi(enc)
    if out is None:
        return "", "DPAPI 解密失败（无前缀）"
    return _strip_hmac(out), "DPAPI（旧格式）"


def _strip_hmac(raw: bytes) -> str:
    """Chromium 新版在明文前面加了 32 字节 HMAC，要去掉。

    怎么判断有没有那 32 字节：先试着整体当 UTF-8 解，
    解得通且看不出二进制垃圾就用整体；否则去掉前 32 字节再解。
    比"一律去掉 32 字节"稳——后者在旧格式上会把值切坏。
    """
    def looks_ok(text: str) -> bool:
        # 不能有控制字符，也不能太长
        return bool(text) and len(text) < 4096 and all(
            c.isprintable() or c in "\t " for c in text)

    whole = raw.decode("utf-8", "replace")
    if looks_ok(whole):
        return whole
    if len(raw) > 32:
        tail = raw[32:].decode("utf-8", "replace")
        if looks_ok(tail):
            return tail
    return whole


# --------------------------------------------------------------------------
#  复制被占用的 sqlite 库
# --------------------------------------------------------------------------

def _copy_locked_db(src: Path) -> tuple[Path | None, str]:
    """把被浏览器占着的 cookies 库拷一份出来。

    浏览器运行时对这个文件是**排他锁**，`shutil.copy2` 会报
    `WinError 32 另一个程序正在使用此文件`。
    所以用 Win32 的 `CreateFileW` 显式请求共享读，
    再用 `CopyFileExW`。

    还是拷不动就说明浏览器锁得很死——让用户关掉浏览器是最省事的办法，
    所以这里如实把原因带出去，界面上提示"先完全关掉浏览器"。
    """
    tmp = Path(tempfile.gettempdir()) / f"_xx_ck_{os.getpid()}_{src.stem}.db"
    try:
        if tmp.exists():
            tmp.unlink()
    except OSError:
        pass

    # 先试最普通的复制（浏览器没在跑的时候能成）
    try:
        shutil.copy2(src, tmp)
        return tmp, ""
    except OSError as first:
        pass

    # 再试 Win32 共享读。
    #
    # 注意这里**必须自己 ReadFile**，不能"打开成功就退回 shutil.copy2"——
    # 我第一版就是那么写的，结果明明能以共享模式打开，复制却照样失败
    # （shutil 内部用的是独占打开）。开了句柄就直接读。
    #
    # ## 为什么把"打不开"和"读不到"分开报
    #
    # 第一版两种情况都报"浏览器正锁着 cookies 文件，先关掉浏览器"。
    # 但那句话在**第二种情况下是错的**：句柄打开成功说明共享读是被允许的，
    # 失败的是读取本身。让她去关浏览器是白费功夫，
    # 而且会以为"关了就好"——关了发现还是不行，就更迷惑了。
    #
    # 所以分开：
    #     打不开   → 确实是锁，让她关浏览器（这条她能自己解决）
    #     读不到   → 说明是别的原因，把 Windows 错误码带出去
    GENERIC_READ = 0x80000000
    FILE_SHARE_ALL = 0x00000001 | 0x00000002 | 0x00000004
    OPEN_EXISTING = 3
    INVALID = 0xFFFFFFFFFFFFFFFF
    try:
        h = ctypes.windll.kernel32.CreateFileW(
            str(src), GENERIC_READ, FILE_SHARE_ALL, None, OPEN_EXISTING,
            0, None)
        if h == INVALID or h == -1:
            err = ctypes.windll.kernel32.GetLastError()
            # 32 = ERROR_SHARING_VIOLATION（真的是锁）
            # 5  = ERROR_ACCESS_DENIED（权限，不是"等一等"能解决的）
            if err == 32:
                return None, ("浏览器正锁着 cookies 文件（共享读也被拒）。"
                              "**先把浏览器完全关掉**（任务栏里也要退），再试一次。")
            if err == 5:
                return None, ("没有权限读这个文件（错误码 5）。"
                              "关浏览器没用——可能是安全软件挡着。"
                              "用下面的手动粘贴方式。")
            return None, (f"打不开 cookies 文件（Windows 错误码 {err}）。"
                          "用下面的手动粘贴方式。")
        try:
            # 分块读出来（cookies 库一般几百 KB，一次读完也行）
            buf_size = 1024 * 256
            chunk = ctypes.create_string_buffer(buf_size)
            read = wt.DWORD(0)
            data = bytearray()
            total = wt.DWORD(0)
            while True:
                ok = ctypes.windll.kernel32.ReadFile(
                    h, chunk, buf_size, ctypes.byref(read), None)
                if not ok or read.value == 0:
                    break
                data += chunk.raw[:read.value]
                total.value += read.value
                # 保险丝：cookies 库不该超过 64MB
                if total.value > 64 * 1024 * 1024:
                    break
            ctypes.windll.kernel32.CloseHandle(h)
            if not data:
                return None, "文件读出来是空的。"
            tmp.write_bytes(bytes(data))
            return tmp, ""
        except Exception as exc:
            try:
                ctypes.windll.kernel32.CloseHandle(h)
            except Exception:
                pass
            return None, f"读文件失败：{exc}"
    except Exception as exc:
        return None, f"读不了被占用的文件：{exc}"


def _read_db(db: Path) -> tuple[list[tuple[str, str]], str, str]:
    """读一个 cookies 库，返回 (B站cookies, 说明, 解密方式)。"""
    tmp, why = _copy_locked_db(db)
    if tmp is None:
        return [], why, ""
    try:
        conn = sqlite3.connect(str(tmp), timeout=5)
        rows = conn.execute(
            "SELECT name, encrypted_value FROM cookies "
            "WHERE host_key LIKE ? OR host_key LIKE ?",
            BILI_HOSTS).fetchall()
        conn.close()
    except Exception as exc:
        return [], f"读库失败：{exc}", ""
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass

    if not rows:
        return [], ("这个浏览器里没有 B 站的 cookie——"
                    "说明没用它登录过 B 站。"), ""

    out: list[tuple[str, str]] = []
    methods: set[str] = set()
    reasons: list[str] = []
    for name, enc in rows:
        value, how = _decrypt_chromium(enc or b"")
        if value:
            out.append((name, value))
            methods.add(how)
        elif how:
            reasons.append(f"{name}：{how}")

    if not out:
        return [], "；".join(reasons[:3]) or "所有 cookie 都解不开", ""
    return out, "", "/".join(sorted(methods))


def _read_firefox(db: Path) -> tuple[list[tuple[str, str]], str, str]:
    """Firefox 的 cookies 是明文的，直接读。"""
    tmp, why = _copy_locked_db(db)
    if tmp is None:
        return [], why, ""
    try:
        conn = sqlite3.connect(str(tmp), timeout=5)
        rows = conn.execute(
            "SELECT name, value FROM moz_cookies "
            "WHERE host LIKE ? OR host LIKE ?", BILI_HOSTS).fetchall()
        conn.close()
    except Exception as exc:
        return [], f"读库失败：{exc}", ""
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    if not rows:
        return [], "这个浏览器里没有 B 站的 cookie。", ""
    return [(n, v) for n, v in rows if v], "", "明文（Firefox）"


# --------------------------------------------------------------------------
#  对外接口
# --------------------------------------------------------------------------

def candidates() -> list[tuple[str, Path]]:
    """本机有哪些浏览器的 cookies 库可读。返回 [(名字, 库路径)]。"""
    out: list[tuple[str, Path]] = []
    for name, (env, rel) in CHROMIUM_BROWSERS.items():
        base = os.environ.get(env)
        if not base:
            continue
        d = Path(base) / rel
        if not d.is_dir():
            continue
        # Default / Profile 1 / Profile 2 …
        for db in sorted(d.glob("*/Network/Cookies")):
            out.append((f"{name}（{db.parent.parent.name}）", db))
    env, rel = FIREFOX
    base = os.environ.get(env)
    if base:
        for db in sorted((Path(base) / rel).glob("*/cookies.sqlite")):
            out.append((f"Firefox（{db.parent.name}）", db))
    return out


def available() -> dict:
    """能不能自动抓。给界面用来决定显示什么。

    `can_auto` 为 False 时，界面应该**明确说原因**，
    并引导到手动粘贴——而不是给一个点了没用的按钮。
    """
    cands = candidates()
    if not cands:
        return {
            "can_auto": False,
            "browsers": [],
            "reason": "本机没找到 Edge / Chrome / Firefox 的 cookies 库。",
            "hint": "用下面的手动粘贴方式。",
        }
    return {
        "can_auto": True,
        "browsers": [{"label": n, "path": str(p)} for n, p in cands],
        "reason": "",
        "hint": "点「登录获取」会从上面的浏览器里读。",
    }


def extract(home: Path, which: str = "") -> dict:
    """从浏览器读 B 站 cookies，存到 `home` 下。

    `which`：指定用哪个（`candidates()` 里的 label）。留空就挨个试。

    **`home` 是必传的**：这个模块不该自己去猜数据目录——
    那是配置层的事，猜错了会把 cookies 存到别的地方，
    表现为"保存成功了但搜索还是 412"，很难查。

    返回值里 `ok` 只有在**真的拿到了登录凭据**时才为 True。
    拿到游客 cookie（只有 buvid3 之类）算**失败**——
    因为那解决不了限流，而返回成功会让界面显示"已登录"却照样 412。
    """
    from . import cookies as ck

    cands = candidates()
    if not cands:
        return {"ok": False, "error": "本机没找到可读的浏览器 cookies 库。",
                "hint": "用下面的手动粘贴方式。", "tried": []}

    targets = [(n, p) for n, p in cands if not which or which == n]
    if not targets:
        targets = cands

    tried: list[dict] = []
    for label, db in targets:
        if "Firefox" in label:
            rows, why, how = _read_firefox(db)
        else:
            rows, why, how = _read_db(db)
        got = dict(rows)
        logged = ck.is_logged_in(got)
        tried.append({
            "browser": label, "count": len(got), "logged_in": logged,
            "why": why, "method": how,
        })
        if logged:
            ok, msg, saved = ck.save(
                home, "; ".join(f"{k}={v}" for k, v in got.items()))
            if not ok:
                return {"ok": False, "error": msg, "hint": "存不下来，"
                        "检查数据目录的写权限。", "tried": tried}
            return {
                "ok": True,
                "browser": label,
                "count": len(saved),
                "method": how,
                "message": f"已从 {label} 读到 {len(saved)} 个 cookie（{how}）。",
                "tried": tried,
            }

    # 都没拿到登录凭据——把每个的失败原因带出去
    reasons = []
    for t in tried:
        if t["why"]:
            reasons.append(f"{t['browser']}：{t['why']}")
        else:
            reasons.append(f"{t['browser']}：只拿到 {t['count']} 个"
                           f"非登录 cookie")
    # 判断是不是 App-Bound 挡的，好给更准的建议
    appbound = any("App-Bound" in (t.get("why") or "") for t in tried)
    hint = ("这个浏览器版本的 cookie 用了 App-Bound 加密"
            "（专门防外部程序读取），自动读不了。"
            "用下面的手动粘贴方式，一次就好。"
            if appbound else "用下面的手动粘贴方式。")
    return {
        "ok": False,
        "error": "；".join(reasons[:3]),
        "hint": hint,
        "appbound": appbound,
        "tried": tried,
    }



def _selftest() -> None:
    """只测纯逻辑部分（依赖本机环境的读库/解密不好做确定性断言）。

    重点是 `_strip_hmac`——它判断"要不要去掉前 32 字节 HMAC"。
    判错的后果是**解出来的 cookie 值是坏的**，
    表现为"保存成功了但搜索还是 412"，极难查。
    """
    # ① 没有 HMAC 前缀的（旧格式），整体就是值，不该被切
    assert _strip_hmac(b"SESSDATA_VALUE") == "SESSDATA_VALUE", \
        _strip_hmac(b"SESSDATA_VALUE")

    # ② 带 32 字节 HMAC 的（新格式），要去掉前面那 32 字节
    hmac = bytes(range(32))          # 32 字节二进制，不是可打印字符
    assert _strip_hmac(hmac + b"REALVALUE") == "REALVALUE", \
        repr(_strip_hmac(hmac + b"REALVALUE"))

    # ③ 空值
    assert _strip_hmac(b"") == "", repr(_strip_hmac(b""))

    # ④ v20 前缀要被识别成"解不开"，而不是硬解出一个垃圾值
    value, why = _decrypt_chromium(b"v20" + b"garbage")
    assert value == "", f"v20 不该解出值，却得到 {value!r}"
    assert "App-Bound" in why, why

    # ⑤ 没有可读库时 available() 要如实说，不能假装能自动抓
    info = available()
    assert "can_auto" in info and "reason" in info, info
    if not info["can_auto"]:
        assert info["reason"], "不能自动抓时必须给出原因"

    # ⑥ candidates() 返回的都是真实存在的路径
    for label, db in candidates():
        assert db.is_file(), f"{label} 指向不存在的文件：{db}"

    print("  browser_cookies selftest：全部断言通过 ✓")


if __name__ == "__main__":
    # 只跑自检。**不在这里多打信息**——verify.py 会把每个模块的
    # stdout 收进报告，多打的东西会挤掉真正要看的结果
    # （我第一版就是这样，报告里出现了一个浏览器的名字，看着像断言失败）。
    import sys

    sys.stdout.reconfigure(encoding="utf-8")
    _selftest()
