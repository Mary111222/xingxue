"""展示层：把数据渲染成终端界面。

所有视图都接受注入的 Theme / Config，方便测试时固定「今天」的日期。
"""

from __future__ import annotations

from datetime import date, timedelta

from . import gem, mascot, sm2, ui
from .db import Problem, Store

DIFF_WIDTH = 4
_HEAT_CHARS = ["·", "▪", "▩", "█"]


# --------------------------------------------------------------------------
# 符号喵喵（看板娘）
# --------------------------------------------------------------------------

def mascot_block(pose: str = "sit", text: str = "", salt: str = "",
                 title: str = "符号喵喵") -> str:
    """看板娘 + 台词。挑不出来就不用她，绝不挡路。"""
    try:
        return mascot.in_box(pose, text, salt=salt, title=title,
                             width=ui.term_width(), style="pink")
    except Exception:
        return ""


# --------------------------------------------------------------------------
# 顶部信息条
# --------------------------------------------------------------------------

def header(store: Store, theme: gem.Theme, name: str, birthday: date | None,
           today: date | None = None) -> str:
    today = today or date.today()
    width = ui.term_width()
    due_count = len(store.due(today))
    total = store.count()
    streak = store.streak(today)

    line1 = ui.c(gem.greeting(name), theme.primary, "bold")
    # 星期写成「周日」而不是「日曜」：后者是古称，日常没人这么说话
    weekday = "周「 + 」一二三四五六日"[today.weekday()]
    line2 = ui.c(today.strftime("%Y-%m-%d"), "grey") + ui.c(f"  {weekday}", "grey")

    stats = []
    if due_count:
        stats.append(ui.c(f"待复习 {due_count}", theme.accent, "bold"))
    else:
        stats.append(ui.c("今天没有到期的题", "brightgreen"))
    stats.append(ui.c(f"题库 {total}", "grey"))
    if streak:
        stats.append(ui.c(f"连续 {streak} 天", "gold"))
    # 有待处理的失败就摆出来。可观测性的关键：不能只藏在 her failures 里，
    # 得出现在她每天都会看的那一屏，否则等于没有。
    try:
        from . import failures as failures_mod

        pending = failures_mod.count_open(store)
        if pending:
            stats.append(ui.c(f"待处理 {pending}", "red", "bold"))
    except Exception:
        pass
    line3 = ui.c("  ·  ", "grey").join(stats)

    lines = [line1, line2, line3]
    # 鼓励语：和界面上是同一套语料（同一天同一句，不会一刷新就换）
    try:
        from datetime import datetime as _dt

        from . import encouragement

        due_now = len(store.due(today)) if today else 0
        kind, msg = encouragement.suitable_for_now(
            today, _dt.now().hour,
            is_birthday=gem.is_birthday(birthday, today) if birthday else False,
            due_count=due_now,
        )
        if msg:
            mark = {"birthday": "🎂", "done": "🌙", "latenight": "🌙"}.get(kind, "✿")
            lines.append("")
            lines.append(ui.c(f"  {mark} ", theme.accent) + ui.c(msg, "plum", "bold"))
    except Exception:
        pass
    countdown = gem.countdown_line(name, birthday, today)
    if countdown:
        lines.append(countdown)

    return ui.box("", lines, width=width, style=theme.primary)


def opening(store: Store, theme: gem.Theme, name: str, birthday: date | None,
            today: date | None = None, compact: bool = False) -> str:
    """程序启动时看到的第一屏。生日当天自动换成蛋糕横幅，符号喵喵站岗。"""
    today = today or date.today()
    parts: list[str] = []

    if gem.is_birthday(birthday, today):
        parts.append(gem.banner(name, birthday, today))
        parts.append("")
        parts.append(ui.c("  " + gem.birthday_wish(birthday, name), "gold"))
        parts.append("")

    parts.append(header(store, theme, name, birthday, today))

    due_count = len(store.due(today))
    if not compact:
        speech = gem.greeting(name) + "。"
        if due_count:
            speech += f"今天有 {due_count} 道题等着你。"
        else:
            speech += "今天没有到期的题。"
        parts.append("")
        parts.append(mascot_block("sit" if due_count else "sleep", speech,
                                  salt=today.isoformat()))
        # 注意：完整首页里的「今日一句」交给面板系统渲染（面板可关也可排序），
        # 这里只在 compact 模式补上，避免同一页出现两遍。
    elif due_count:
        parts.append("")
        parts.append(
            "  "
            + ui.c("今天有 ", "grey")
            + ui.c(str(due_count), theme.accent, "bold")
            + ui.c(" 道题等着你，输入 ", "grey")
            + ui.c("her review", "hotpink", "bold")
            + ui.c(" 开始", "grey")
        )

    return "\n".join(parts)


def quote_block(store: Store, theme: gem.Theme, today: date | None = None) -> str:
    """底部那句「今日一句 + 关心」。"""
    today = today or date.today()
    width = ui.term_width()
    inner = width - 6
    lines: list[str] = []
    for raw in ui.wrap(gem.daily_quote(today), inner):
        lines.append(ui.c(raw, theme.extra, "italic"))
    lines.append("")
    lines.append(ui.c("  " + gem.daily_care(today), "grey"))
    return ui.box("今日一句", lines, width=width, style="grey")


# --------------------------------------------------------------------------
# 复习卡片
# --------------------------------------------------------------------------

def review_card(problem: Problem, index: int, total: int, theme: gem.Theme,
                show_solution: bool = False) -> str:
    width = ui.term_width()
    inner = width - 6
    lines: list[str] = []

    # 标题行：难度 + 题名
    diff = ui.c(f"[{problem.difficulty_label}]", problem.difficulty_color, "bold")
    lines.append(f"{diff} {ui.c(problem.title, 'bold')}")
    lines.append(
        ui.c(f"#{problem.id}  {problem.maturity}  遗忘 {problem.lapses} 次", "grey")
        + "    "
        + ui.c(f"EF {problem.ef:.2f}  间隔 {problem.interval} 天", "grey")
    )

    if problem.tags:
        lines.append("")
        lines.append("  ".join(ui.c(f"#{t}", theme.accent) for t in problem.tags))

    if problem.url:
        lines.append("")
        lines.append(ui.c(problem.url, "plum"))

    # 默认先不给思路，让她自己回想（这是间隔重复的关键）
    if show_solution:
        if problem.note:
            lines.append("")
            lines.append(ui.c("关键思路", theme.primary, "bold"))
            for raw in ui.wrap(problem.note, inner - 2):
                lines.append("  " + raw)
        if problem.memory:
            lines.append("")
            lines.append(ui.c("私人记忆", "pink", "bold"))
            for raw in ui.wrap(problem.memory, inner - 2):
                lines.append("  " + ui.c(raw, "grey"))
    else:
        lines.append("")
        lines.append(ui.c("先自己想，想完再看思路（按 n）", "grey"))

    title = f"复习 {index}/{total}"
    return ui.box(title, lines, width=width, style=theme.primary)


def suggestions_block(problem: Problem, theme: gem.Theme, extra: str = "") -> str:
    """卡壳时的 B 站搜索建议——这是「从不会到看懂」的最短路径。"""
    from . import search

    width = ui.term_width()
    inner = width - 6
    items = search.queries_for_problem(problem.title, problem.tags, extra)
    lines: list[str] = []
    for index, (label, kw) in enumerate(items, start=1):
        url = search.search_url(kw)
        lines.append(ui.c(f"{index}. ", "gold") + ui.c(label, "bold") + ui.c(f"  ({kw})", "grey"))
        for raw in ui.wrap(url, inner - 3):
            lines.append("   " + ui.c(raw, "cyan"))
        lines.append("")
    while lines and not lines[-1]:
        lines.pop()
    cat = mascot_block("search", "不会就搜，我把放大镜举好了", title="符号喵喵 · 找视频")
    return (cat + "\n" if cat else "") + ui.box("不懂？直接搜 B 站", lines, width=width, style=theme.extra)


def rating_block(theme: gem.Theme) -> str:
    width = ui.term_width()
    lines: list[str] = []
    for q in (5, 4, 3, 2, 1, 0):
        label, hint = sm2.QUALITY_LABELS[q]
        color = "brightgreen" if q >= 4 else ("gold" if q == 3 else "red")
        lines.append(
            ui.c(f"[{q}]", color, "bold")
            + " "
            + ui.pad(label, 14)
            + ui.c(hint, "grey")
        )
    lines.append("")
    lines.append(
        ui.c("[n]", "hotpink") + " 看思路    "
        + ui.c("[s]", "hotpink") + " 搜 B 站    "
        + ui.c("[b]", "violet") + " 丢给视频总结器    "
        + ui.c("[o]", "hotpink") + " 打开题目    "
        + ui.c("[q]", "grey") + " 先退出"
    )
    return ui.box("这道题记得怎么样", lines, width=width, style=theme.primary)


def review_summary(problem: Problem, result: sm2.SM2Result, theme: gem.Theme,
                   due_today_left: int) -> str:
    width = ui.term_width()
    if result.passed:
        head = ui.c("✓ 记住了", "brightgreen", "bold")
    else:
        head = ui.c("✗ 忘了，明天再来", "red", "bold")

    lines = [
        head + ui.c(f"   评分 {result.label}", "grey"),
        "",
        ui.c("下次复习：", "grey") + ui.c(sm2.human_interval(result.interval), theme.accent, "bold")
        + ui.c(f"（{result.due.isoformat()}）", "grey"),
        ui.c("当前状态：", "grey") + f"{problem.maturity}   "
        + ui.c(f"EF {result.ef:.2f}", "grey") + "   "
        + ui.c(f"连续答对 {result.repetitions} 次", "grey"),
    ]
    if due_today_left > 0:
        lines.append("")
        lines.append(ui.c(f"今天还剩 {due_today_left} 道", "gold"))
    else:
        lines.append("")
        lines.append(ui.c("今天的任务清空了 🎉", "brightgreen", "bold"))

    if result.passed:
        speech = f"记住了！{sm2.human_interval(result.interval)}再见它一次。"
        cat = mascot_block("cheer", speech, salt=problem.title, title="符号喵喵 · 干得漂亮")
    else:
        cat = mascot_block("cry", "忘了不要紧，明天再来一次就好。", salt=problem.title,
                           title="符号喵喵 · 别丧")
    return (cat + "\n" if cat else "") + ui.box("", lines, width=width, style=theme.primary)


# --------------------------------------------------------------------------
# 列表
# --------------------------------------------------------------------------

def problem_table(problems: list[Problem], theme: gem.Theme, title: str = "题目",
                  today: date | None = None, show_due: bool = True) -> str:
    today = today or date.today()
    width = ui.term_width()
    inner = width - 6

    # 列宽分配：id(4) 难度(4) 标题(弹性) 标签(弹性) 到期(10)
    fixed = 4 + 1 + DIFF_WIDTH + 1 + 11 + 1
    flex = max(20, inner - fixed)
    title_w = int(flex * 0.56)
    tag_w = flex - title_w

    head = (
        ui.c(ui.pad("ID", 4), "grey")
        + " "
        + ui.c(ui.pad("难度", DIFF_WIDTH), "grey")
        + " "
        + ui.c(ui.pad("题目", title_w), "grey")
        + " "
        + ui.c(ui.pad("标签", tag_w), "grey")
        + " "
        + ui.c(ui.pad("到期", 10, "right"), "grey")
    )
    lines = [head, ui.c("─" * inner, "grey")]

    for p in problems:
        if show_due:
            if p.due < today:
                due_text = f"逾期 {p.days_overdue(today)} 天"
                due_color = "red"
            elif p.due == today:
                due_text = "今天"
                due_color = "gold"
            else:
                due_text = p.due.strftime("%m-%d")
                due_color = "grey"
        else:
            due_text = ""
            due_color = "grey"

        line = (
            ui.c(ui.pad(str(p.id), 4), "grey")
            + " "
            + ui.c(ui.pad(p.difficulty_label[:2], DIFF_WIDTH), p.difficulty_color)
            + " "
            + ui.pad(p.short(title_w), title_w)
            + " "
            + ui.c(ui.pad(" ".join(p.tags[:2]), tag_w), theme.accent)
            + " "
            + ui.pad(ui.c(due_text, due_color), 10, "right")
        )
        lines.append(line)

    if not problems:
        lines.append(ui.c("（空）", "grey"))

    return ui.box(f"{title} · {len(problems)} 道", lines, width=width, style=theme.primary)


# --------------------------------------------------------------------------
# 统计
# --------------------------------------------------------------------------

def heatmap_block(store: Store, theme: gem.Theme, weeks: int = 18,
                  today: date | None = None) -> str:
    """GitHub 贡献图风格的复习热力图。"""
    today = today or date.today()
    grid = store.heatmap(weeks, today)
    lines: list[str] = []

    for row in range(7):
        cells = []
        for col in range(weeks):
            count = grid[col][row]
            if count == 0:
                cells.append(ui.c(_HEAT_CHARS[0], "grey"))
            elif count <= 2:
                cells.append(ui.c(_HEAT_CHARS[1], theme.primary))
            elif count <= 5:
                cells.append(ui.c(_HEAT_CHARS[2], theme.accent))
            else:
                cells.append(ui.c(_HEAT_CHARS[3], theme.accent, "bold"))
        lines.append(" " + " ".join(cells))

    lines.append("")
    lines.append(
        ui.c("  少 ", "grey")
        + ui.c(_HEAT_CHARS[0], "grey") + " "
        + ui.c(_HEAT_CHARS[1], theme.primary) + " "
        + ui.c(_HEAT_CHARS[2], theme.accent) + " "
        + ui.c(_HEAT_CHARS[3], theme.accent, "bold")
        + ui.c(" 多", "grey")
        + ui.c(f"      最近 {weeks} 周 · 总共 {store.review_count_total()} 次复习", "grey")
    )
    return ui.box("复习热力图", lines, width=ui.term_width(), style=theme.primary)


def stats_view(store: Store, theme: gem.Theme, name: str, birthday: date | None,
               together_since: date | None = None, today: date | None = None) -> str:
    today = today or date.today()
    width = ui.term_width()
    parts: list[str] = []

    total = store.count()
    due = len(store.due(today))
    streak = store.streak(today)
    longest = store.longest_streak()
    reviews = store.review_count_total()
    seconds = store.total_seconds()

    if streak >= 3:
        speech = f"连续 {streak} 天，你是真的在往前走。"
    elif reviews:
        speech = "数据在长，慢慢来。"
    else:
        speech = "还没开始复习，先刷一道试试？"
    cat = mascot_block("cheer" if streak >= 3 else "sit", speech, salt="stats",
                       title="符号喵喵 · 成绩单")
    if cat:
        parts.append(cat)
        parts.append("")

    parts.append(ui.box(
        f"{name or '你'}的复习成绩单",
        [
            ui.c("题目总数  ", "grey") + ui.c(str(total), theme.accent, "bold")
            + ui.c("      今天待复习  ", "grey") + ui.c(str(due), "gold", "bold"),
            ui.c("累计复习  ", "grey") + ui.c(f"{reviews} 次", theme.accent, "bold")
            + ui.c("      投入时间  ", "grey")
            + ui.c(f"{seconds // 3600} 小时 {seconds % 3600 // 60} 分", theme.accent, "bold"),
            ui.c("连续打卡  ", "grey") + ui.c(f"{streak} 天", "gold", "bold")
            + ui.c("      历史最长  ", "grey") + ui.c(f"{longest} 天", "gold"),
        ],
        width=width,
        style=theme.primary,
    ))

    # 掌握程度分布
    counts = store.maturity_counts()
    lines = []
    order = ["新题", "学习中", "复习中", "已掌握"]
    colors = {"新题": "grey", "学习中": "gold", "复习中": theme.accent, "已掌握": "brightgreen"}
    for key in order:
        value = counts.get(key, 0)
        lines.append(
            ui.pad(key, 8)
            + ui.bar(value, max(1, total), width=20, style=colors[key])
            + "  "
            + ui.c(str(value), colors[key])
        )
    parts.append("")
    parts.append(ui.box("掌握程度", lines, width=width, style=theme.primary))

    # 最虚的知识点
    weak = store.weakest_tags(3)
    lines = []
    if weak:
        for tag, interval in weak:
            hint = "几乎没复习到" if interval < 3 else f"平均间隔 {interval:.1f} 天"
            lines.append(ui.c(f"#{tag}", "red", "bold") + "  " + ui.c(hint, "grey"))
        lines.append("")
        lines.append(ui.c("搜一下补一补：her search " + weak[0][0], "hotpink"))
    else:
        lines.append(ui.c("数据还太少，多刷几道再来看", "grey"))
    parts.append("")
    parts.append(ui.box("最虚的三个知识点", lines, width=width, style=theme.primary))

    # 忘得最多的题
    hardest = store.hardest(5)
    if hardest:
        lines = []
        for p in hardest:
            lines.append(
                ui.c(f"忘 {p.lapses} 次 ", "red")
                + ui.pad(p.short(28), 28)
                + ui.c(" ".join(p.tags[:2]), theme.accent)
            )
        parts.append("")
        parts.append(ui.box("最不容易记住的题", lines, width=width, style=theme.primary))

    parts.append("")
    parts.append(heatmap_block(store, theme, today=today))

    # 未来 14 天压力
    forecast = store.due_forecast(14, today)
    lines = []
    peak = max(forecast.values()) if forecast else 0
    for offset in range(15):
        count = forecast.get(offset, 0)
        label = "今天" if offset == 0 else f"+{offset}天"
        bar_width = 0 if peak == 0 else int(round(18 * count / peak))
        lines.append(
            ui.c(ui.pad(label, 6), "grey")
            + ui.c("█" * bar_width, theme.accent)
            + ("  " + ui.c(str(count), "grey") if count else "")
        )
    parts.append("")
    parts.append(ui.box("未来两周的复习压力", lines, width=width, style=theme.primary))

    # 私人纪念日计数：这是这个程序「送人」的那部分
    extra_lines = []
    if birthday:
        left = gem.days_until_birthday(birthday, today)
        if gem.is_birthday(birthday, today):
            extra_lines.append(ui.c(f"🎂 今天是 {name or '她'} 的生日", "gold", "bold"))
        elif left is not None:
            extra_lines.append(
                ui.c("距离生日  ", "grey") + ui.c(f"{left} 天", "gold", "bold")
                + ui.c(f"（{gem.next_birthday(birthday, today).isoformat()}）", "grey")
            )
    if together_since:
        days = gem.days_together(together_since, today)
        if days is not None:
            extra_lines.append(
                ui.c("认识第    ", "grey") + ui.c(f"{days} 天", "pink", "bold")
            )
    if extra_lines:
        parts.append("")
        parts.append(ui.box("还有", extra_lines, width=width, style="pink"))

    return "\n".join(parts)


# --------------------------------------------------------------------------
# 杂项
# --------------------------------------------------------------------------

def empty_state(theme: gem.Theme, hint: str = "") -> str:
    lines = [
        ui.c("这里还是空的", "plum"),
        "",
        ui.c("her seed", "hotpink", "bold") + ui.c("      装 33 道经典题（第一次用建议先跑这个）", "grey"),
        ui.c("her add <题名>", "hotpink", "bold") + ui.c("  加一道题", "grey"),
        ui.c("her import <文件>", "hotpink", "bold") + ui.c("  从 CSV / Markdown / JSON 批量导入", "grey"),
    ]
    if hint:
        lines.extend(["", ui.c(hint, "gold")])
    cat = mascot_block("money", "先有题，才有一切。", title="符号喵喵 · 等投喂")
    return (cat + "\n" if cat else "") + ui.box("开始使用", lines, width=ui.term_width(), style=theme.primary)


def progress_line(done: int, total: int, theme: gem.Theme) -> str:
    return (
        ui.c("进度  ", "grey")
        + ui.bar(done, max(1, total), width=24, style=theme.accent)
        + ui.c(f"  {done}/{total}", "grey")
    )
