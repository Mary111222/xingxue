"""一套 SVG 图标，用来替掉界面里的 emoji。

## 先说清楚这套图标的来源

用户要的是"AI 生成的 SVG 图标"。**我没有 AI 绘图能力**——
不能凭空生成插画。所以这里是**手写的几何 SVG**：
统一 24×24 视口、1.7px 描边、圆角线帽，风格上接近 Feather / Lucide 那一类。
它比 emoji 好在三点：
    · 大小、粗细、颜色完全统一（emoji 是彩色位图，各平台长得都不一样）
    · 用 currentColor，能跟着主题配色走（emoji 不行）
    · 不依赖系统字体，换台电脑不会变成方框

## 为什么内联成 <symbol> 雪碧图

    · 不用为每个图标发一个请求（本地服务，但也没必要）
    · 一份定义到处 <use>，改一处全变
    · 不引外部依赖（这个程序的底线是零依赖）

## 图标怎么画的

全部基于 24×24 网格、主要落在整数格和半格上，
这样小尺寸下也不会糊。每一条路径都尽量用最简单的几何形状拼，
不用手绘曲线——手绘曲线在没有视觉反馈的情况下很容易画歪。
"""

from __future__ import annotations

# 每一项：(symbol id, 内部 SVG 内容)
# 统一约定：stroke 用 currentColor，fill 为 none（线性图标）
ICONS: dict[str, str] = {
    # ---------------- 导航 ----------------
    "i-home": (
        '<path d="M3.5 10.5 12 4l8.5 6.5"/>'
        '<path d="M5.5 9.5V19a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V9.5"/>'
        '<path d="M9.5 20v-5.5h5V20"/>'
    ),
    "i-review": (
        '<rect x="4" y="3.5" width="16" height="17" rx="2.5"/>'
        '<path d="M8 8.5h8M8 12h8M8 15.5h5"/>'
    ),
    "i-search": (
        '<circle cx="10.5" cy="10.5" r="6.5"/>'
        '<path d="m15.5 15.5 4.5 4.5"/>'
    ),
    "i-video": (
        '<rect x="2.5" y="5" width="14" height="14" rx="2.5"/>'
        '<path d="m16.5 10.5 5-3v9l-5-3z"/>'
    ),
    "i-target": (
        '<circle cx="12" cy="12" r="8.5"/>'
        '<circle cx="12" cy="12" r="4.5"/>'
        '<circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/>'
    ),
    "i-course": (
        '<path d="M12 4 2.5 8.5 12 13l9.5-4.5z"/>'
        '<path d="M6 10.5v5c0 1.4 2.7 2.5 6 2.5s6-1.1 6-2.5v-5"/>'
        '<path d="M21.5 8.5v5"/>'
    ),
    "i-compass": (
        '<circle cx="12" cy="12" r="8.5"/>'
        '<path d="m15.5 8.5-2 5-5 2 2-5z"/>'
    ),
    "i-tools": (
        '<path d="M5 8.5h14M5 15.5h14"/>'
        '<circle cx="9" cy="8.5" r="2"/>'
        '<circle cx="15" cy="15.5" r="2"/>'
    ),
    "i-note": (
        '<path d="M5 3.5h9l5 5v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-16a1 1 0 0 1 1-1z"/>'
        '<path d="M14 3.5v5h5"/>'
        '<path d="M8 13h7M8 16.5h5"/>'
    ),
    "i-calendar": (
        '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/>'
        '<path d="M3.5 9.5h17M8 3v4M16 3v4"/>'
        '<circle cx="8.5" cy="14" r="1" fill="currentColor" stroke="none"/>'
    ),
    "i-bell": (
        '<path d="M6.5 10a5.5 5.5 0 0 1 11 0c0 4 1.5 5.5 1.5 5.5H5s1.5-1.5 1.5-5.5z"/>'
        '<path d="M10 18.5a2 2 0 0 0 4 0"/>'
    ),
    "i-chart": (
        '<path d="M4 20V4"/>'
        '<path d="M4 20h16"/>'
        '<rect x="7.5" y="12" width="3" height="5"/>'
        '<rect x="12.5" y="8.5" width="3" height="8.5"/>'
        '<rect x="17" y="5.5" width="3" height="11.5"/>'
    ),
    "i-help": (
        '<circle cx="12" cy="12" r="8.5"/>'
        '<path d="M9.5 9.5a2.6 2.6 0 1 1 3.2 2.5c-.5.2-.7.6-.7 1.1v.6"/>'
        '<circle cx="12" cy="16.8" r="1" fill="currentColor" stroke="none"/>'
    ),
    "i-settings": (
        '<circle cx="12" cy="12" r="3"/>'
        '<path d="M12 2.5v2.8M12 18.7v2.8M4.2 7.2l2.4 1.4M17.4 15.4l2.4 1.4'
        'M4.2 16.8l2.4-1.4M17.4 8.6l2.4-1.4"/>'
    ),
    "i-stethoscope": (
        '<path d="M6 3.5v5a5 5 0 0 0 10 0v-5"/>'
        '<path d="M4 3.5h4M14 3.5h4"/>'
        '<path d="M11 13.5v2.5a4 4 0 0 0 8 0v-1"/>'
        '<circle cx="19" cy="12" r="1.6"/>'
    ),

    # ---------------- 工具箱 ----------------
    "i-translate": (
        '<path d="M3.5 6h9M8 3.5v2.5"/>'
        '<path d="M10.5 6c0 4-3 7.5-7 9"/>'
        '<path d="M5.5 9.5c1.2 2.4 3.2 4 5.5 4.8"/>'
        '<path d="m12.5 20.5 4-10 4 10"/>'
        '<path d="M14 17.5h5"/>'
    ),
    "i-timer": (
        '<circle cx="12" cy="13.5" r="7.5"/>'
        '<path d="M12 10v3.5l2.5 1.5"/>'
        '<path d="M9.5 2.5h5"/>'
    ),
    "i-ruler": (
        '<rect x="2.5" y="8.5" width="19" height="7" rx="1.5" '
        'transform="rotate(-20 12 12)"/>'
        '<path d="M7 9.5v2M10.5 8v3M14 6.5v3M17.5 5v2"/>'
    ),
    "i-text": (
        '<path d="M5 6.5V4.5h14v2"/>'
        '<path d="M12 4.5v15"/>'
        '<path d="M9 19.5h6"/>'
    ),
    "i-lock": (
        '<rect x="4.5" y="10" width="15" height="10.5" rx="2.5"/>'
        '<path d="M8 10V7a4 4 0 0 1 8 0v3"/>'
        '<circle cx="12" cy="15" r="1.3" fill="currentColor" stroke="none"/>'
    ),
    "i-braces": (
        '<path d="M9 3.5C6.5 3.5 7 8 5 8.5c2 .5 1.5 5 4 5"/>'
        '<path d="M15 3.5c2.5 0 2 4.5 4 5-2 .5-1.5 5-4 5"/>'
        '<path d="M9 20.5c-2.5 0-2-4.5-4-5 2-.5 1.5-5 4-5"/>'
        '<path d="M15 20.5c2.5 0 2-4.5 4-5-2-.5-1.5-5-4-5"/>'
    ),
    "i-clock": (
        '<circle cx="12" cy="12" r="8.5"/>'
        '<path d="M12 7v5.2l3.5 2"/>'
    ),
    "i-key": (
        '<circle cx="7.5" cy="12" r="3.5"/>'
        '<path d="M11 12h9M17 12v3.5M20 12v2.5"/>'
    ),
    "i-percent": (
        '<path d="M18.5 5.5 5.5 18.5"/>'
        '<circle cx="7.5" cy="7.5" r="2.8"/>'
        '<circle cx="16.5" cy="16.5" r="2.8"/>'
    ),
    "i-datediff": (
        '<rect x="3" y="5" width="18" height="15.5" rx="2.5"/>'
        '<path d="M3 9.5h18M8 3v4M16 3v4"/>'
        '<path d="M8 14h3M13 14h3"/>'
    ),

    # ---------------- 状态 / 装饰 ----------------
    "i-flower": (
        '<circle cx="12" cy="12" r="2.2"/>'
        '<path d="M12 9.8c0-2.4-1-4-3-4s-2 2.6 1 3.6"/>'
        '<path d="M14.2 12c2.4 0 4-1 4-3s-2.6-2-3.6 1"/>'
        '<path d="M12 14.2c0 2.4 1 4 3 4s2-2.6-1-3.6"/>'
        '<path d="M9.8 12c-2.4 0-4 1-4 3s2.6 2 3.6-1"/>'
    ),
    "i-sparkle": (
        '<path d="M12 3.5 13.8 9l5.7 1.8-5.7 1.9L12 18.5l-1.8-5.8L4.5 10.8 '
        '9.5 9z"/>'
    ),
    "i-inbox": (
        '<path d="M3.5 13.5 6 6h12l2.5 7.5"/>'
        '<path d="M3.5 13.5h5l1 2.5h5l1-2.5h5v5a1.5 1.5 0 0 1-1.5 1.5h-14'
        'a1.5 1.5 0 0 1-1.5-1.5z"/>'
    ),
    "i-clipboard": (
        '<rect x="4.5" y="4.5" width="15" height="16" rx="2"/>'
        '<path d="M9 4.5V3.5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1"/>'
        '<path d="M8.5 10h7M8.5 13.5h7M8.5 17h4"/>'
    ),
    "i-check": (
        '<path d="m4.5 12.5 5 5 10-11"/>'
    ),
    "i-alert": (
        '<path d="M12 3.5 21.5 20h-19z"/>'
        '<path d="M12 9.5v5"/>'
        '<circle cx="12" cy="17.2" r="1" fill="currentColor" stroke="none"/>'
    ),
    "i-scarf": (
        '<path d="M7 4c0 3 2 5 5 5s5-2 5-5"/>'
        '<path d="M6.5 8.5 7 20l3-3 2 3 2-3 3 3 .5-11.5"/>'
    ),
    "i-walk": (
        '<circle cx="13" cy="4.5" r="1.8"/>'
        '<path d="M13 7.5 11 13l2.5 2 1 5"/>'
        '<path d="M11 13 7 15M13.5 11.5 18 13"/>'
    ),
    "i-chocolate": (
        '<rect x="4.5" y="4.5" width="15" height="15" rx="2"/>'
        '<path d="M4.5 9.5h15M4.5 14.5h15M9.5 4.5v15M14.5 4.5v15"/>'
    ),
    "i-moon": (
        '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/>'
    ),
    "i-sun": (
        '<circle cx="12" cy="12" r="4"/>'
        '<path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2'
        'M5.2 5.2l1.4 1.4M17.4 17.4l1.4 1.4M5.2 18.8l1.4-1.4M17.4 6.6l1.4-1.4"/>'
    ),
    "i-drop": (
        '<path d="M12 3.5s5.5 6 5.5 9.5a5.5 5.5 0 0 1-11 0C6.5 9.5 12 3.5 12 3.5z"/>'
    ),
    "i-coffee": (
        '<path d="M4.5 8h12v7a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4z"/>'
        '<path d="M16.5 9.5h1.5a2.5 2.5 0 0 1 0 5h-1.5"/>'
        '<path d="M7 3.5v2M11 3.5v2M15 3.5v2"/>'
    ),
    "i-backpack": (
        '<path d="M6 9.5a6 6 0 0 1 12 0V20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1z"/>'
        '<path d="M9.5 9.5V7a2.5 2.5 0 0 1 5 0v2.5"/>'
        '<path d="M9 14h6"/>'
    ),
    "i-basket": (
        '<path d="M3.5 9.5h17l-2 10a1 1 0 0 1-1 .8H6.5a1 1 0 0 1-1-.8z"/>'
        '<path d="m8 9.5 3-6M16 9.5l-3-6M9.5 13v4M14.5 13v4"/>'
    ),
    "i-book": (
        '<path d="M4 4.5h6a3 3 0 0 1 3 3V20a2.5 2.5 0 0 0-2.5-2.5H4z"/>'
        '<path d="M20 4.5h-6a3 3 0 0 0-3 3V20a2.5 2.5 0 0 1 2.5-2.5H20z"/>'
    ),
    "i-pencil": (
        '<path d="M4 20h4L19.5 8.5a2.1 2.1 0 0 0-3-3L5 17z"/>'
        '<path d="M14.5 6.5 17.5 9.5"/>'
    ),
    "i-trash": (
        '<path d="M4.5 7h15M9 7V4.5h6V7"/>'
        '<path d="M6.5 7 7.5 20a1 1 0 0 0 1 .9h7a1 1 0 0 0 1-.9L17.5 7"/>'
        '<path d="M10.5 11v6M13.5 11v6"/>'
    ),
    "i-plus": (
        '<path d="M12 5v14M5 12h14"/>'
    ),
    "i-up": ('<path d="m6 14 6-6 6 6"/>'),
    "i-down": ('<path d="m6 10 6 6 6-6"/>'),
    "i-external": (
        '<path d="M14 4.5h5.5V10"/>'
        '<path d="M19.5 4.5 11 13"/>'
        '<path d="M17 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h5"/>'
    ),
    "i-star": (
        # 收藏用的星标。描边版和填充版共用一个路径，
        # 靠 CSS 改 fill 来区分状态——省一个图标，
        # 也保证两个状态大小完全一致。
        '<path d="m12 3.8 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.7-5.2 2.7 '
        '1-5.8-4.2-4.1 5.8-.8z"/>'
    ),
    "i-grid": (
        '<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/>'
        '<rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/>'
        '<rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/>'
        '<rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/>'
    ),
    "i-stack": (
        '<path d="M12 3.5 3 8l9 4.5L21 8z"/>'
        '<path d="m3 12.5 9 4.5 9-4.5"/>'
        '<path d="m3 16.5 9 4.5 9-4.5"/>'
    ),
}


def sprite() -> str:
    """生成一段可以插进 HTML 的 <svg> 雪碧图。

    用 display:none 藏起来，页面上用 <use href="#i-xxx"> 引用。
    """
    parts = [
        '<svg xmlns="http://www.w3.org/2000/svg" style="display:none" '
        'aria-hidden="true" id="iconSprite">'
    ]
    for name, body in ICONS.items():
        parts.append(
            f'<symbol id="{name}" viewBox="0 0 24 24" '
            f'fill="none" stroke="currentColor" stroke-width="1.7" '
            f'stroke-linecap="round" stroke-linejoin="round">{body}</symbol>'
        )
    parts.append("</svg>")
    return "".join(parts)


def icon(name: str, cls: str = "ico", extra: str = "") -> str:
    """生成一个图标元素。

    name 可以带 `i-` 前缀也可以不带；写错了会退回一个方框，
    而不是留下空白（空白会让人以为是布局问题）。
    """
    key = name if name.startswith("i-") else f"i-{name}"
    if key not in ICONS:
        key = "i-grid"
    attrs = f' class="{cls}"' if cls else ""
    if extra:
        attrs += " " + extra
    return (f'<svg{attrs} aria-hidden="true"><use href="#{key}"/></svg>')


def names() -> list[str]:
    return sorted(ICONS)


def _selftest() -> None:
    assert len(ICONS) >= 40, f"图标太少：{len(ICONS)}"
    bad = []
    for name, body in ICONS.items():
        if not name.startswith("i-"):
            bad.append(f"{name}: 名字该以 i- 开头")
        if not body.strip():
            bad.append(f"{name}: 内容是空的")
        # 路径必须有配平的引号，不然生成的 SVG 会坏掉
        if body.count('"') % 2:
            bad.append(f"{name}: 双引号不配对")
        # 不许写死颜色——图标要用 currentColor 跟着主题走
        if "#" in body:
            bad.append(f"{name}: 里面写死了颜色")
    assert not bad, bad

    s = sprite()
    assert s.startswith("<svg"), s[:40]
    assert s.endswith("</svg>"), s[-40:]
    assert s.count("<symbol") == len(ICONS), s.count("<symbol")

    # 单独取一个图标
    one = icon("home")
    assert 'href="#i-home"' in one, one
    assert icon("home", cls="nav-ico").count('class="nav-ico"') == 1
    # 名字写错要退回方框，不能留空
    assert 'href="#i-grid"' in icon("根本没有这个图标"), icon("根本没有这个图标")
    # 带不带前缀都要能认
    assert 'href="#i-home"' in icon("i-home")

    print(f"icons selftest: 全部断言通过 ✓（{len(ICONS)} 个图标）")


if __name__ == "__main__":
    import sys

    sys.stdout.reconfigure(encoding="utf-8")
    _selftest()
