"""扩展功能的命令层：面板管理、便签、倒数日、提醒、插件、每日任务。

单独成一个模块，是为了不让 cli.py 继续膨胀下去——它已经够长了。
这里每个 cmd_* 都遵守 cli.py 的约定：签名 (args, ctx) -> int。
"""

from __future__ import annotations

import shutil
import sys
from datetime import date, datetime
from pathlib import Path

from . import gem, learning, panels, search, ui
from .panels import PATTERN_LABELS, PanelRegistry, PanelSpec, reminder_when

# 面板出厂顺序。enable / reset 都以它为准，避免「加回来的面板跑到最后」这种不一致。
DEFAULT_PANELS = ["countdown", "course", "learning", "notes", "reminders", "quote"]


# --------------------------------------------------------------------------
# 自主学习：学习网站清单
# --------------------------------------------------------------------------

def _site_lines(sites: list, *, show_url: bool = True, numbered: bool = True) -> list[str]:
    """把站点渲染成清单行。编号 = 在整个 SITES 里的位置，方便 her learn open 3。"""
    lines: list[str] = []
    for site in sites:
        index = learning.SITES.index(site) + 1
        head = ui.pad(f"{index:2d}.", 4) if numbered else "    "
        lines.append(
            ui.c(head, "grey")
            + ui.c(ui.pad(site.title, 22), "hotpink", "bold")
            + ui.c(" ".join(f"#{t}" for t in site.tags[:3]), "plum")
        )
        lines.append("    " + ui.c(site.what, "white"))
        lines.append("    " + ui.c("什么时候来：", "grey") + ui.c(site.when, "grey"))
        lines.append("    " + ui.c("怎么上手：", "grey") + ui.c(site.how, "grey"))
        if show_url:
            lines.append("    " + ui.c(site.url, "plum"))
        lines.append("")
    while lines and not lines[-1]:
        lines.pop()
    return lines


def cmd_learn(args, ctx) -> int:
    action = args.action or "list"

    # 容错：her learn 文档 这样写时，「文档」会被 argparse 当成 action。
    # 只要它不是已知的动作名，就当成分类/站点处理（她记不住语法也不该被卡住）。
    known_actions = {"list", "open", "o", "go", "search", "find", "s",
                     "star", "fav", "favorite", "history", "hist", "recent"}
    if action not in known_actions:
        args.query = args.query or args.name
        args.name = action
        action = "list"

    # her learn open <编号|短名> [关键词]
    if action in ("open", "o", "go"):
        site = learning.find(args.name or "")
        if site is None:
            ui.err(f"找不到「{args.name}」，用 her learn 看清单")
            return 1
        query = args.query or ""
        if query and not site.can_search():
            ui.warn(f"「{site.title}」不支持站内搜索，给你打开主页")
            query = ""
        url = site.search_url(query) if query else site.url
        if getattr(args, "print_only", False):
            ui.info(f"「{site.title}」→ {url}")
            return 0
        opened, url = learning.open_site(site, query)
        # 顺手记一笔，和界面共用同一份记录。
        # 记不上不该影响"打开"这个主要动作，所以单独兜住。
        try:
            ctx.store.record_visit(site.key, site.title, url, source="cli")
        except Exception:
            pass
        ui.ok(("已打开：" if opened else "链接（请手动打开）：") + url)
        if query:
            ui.info(f"在「{site.title}」里搜：{query}")
        return 0

    # her learn star [站点]   —— 看收藏 / 切换收藏
    if action in ("star", "fav", "favorite"):
        target = (args.name or "").strip()
        if not target:
            rows = ctx.store.favorites()
            if not rows:
                ui.info("还没有收藏。用 her learn star <站点> 收藏一个，")
                ui.info("或者直接在界面「学习资源」页点星标。")
                return 0
            lines = []
            for i, r in enumerate(rows, 1):
                title = r["title"] or r["site_key"]
                cat = f"  ({r['category']})" if r["category"] else ""
                lines.append(f"{i:2d}. {title}{cat}")
                if r["note"]:
                    lines.append(f"      {r['note']}")
                lines.append(f"      {r['url']}")
            print(ui.box(f"我的收藏 · {len(rows)} 个",
                         lines, width=ui.term_width(),
                         style=ctx.theme.primary))
            return 0

        site = learning.find(target)
        if site is None:
            # 收藏里可能有但清单里没了（站点被删过），也允许取消
            if ctx.store.is_favorite(target):
                ctx.store.remove_favorite(target)
                ui.ok(f"已取消收藏「{target}」（它已经不在清单里了）")
                return 0
            ui.err(f"找不到「{target}」，用 her learn 看清单")
            return 1
        now_fav = ctx.store.toggle_favorite(
            site.key, site.title, site.url, site.category)
        if now_fav:
            ui.ok(f"已收藏「{site.title}」")
            ui.info(f"想看收藏列表：her learn star")
        else:
            ui.ok(f"已取消收藏「{site.title}」")
        return 0

    # her learn history        —— 看打开记录
    if action in ("history", "hist", "recent"):
        if getattr(args, "clear", False):
            n = ctx.store.clear_visits()
            ui.ok(f"已清空 {n} 条打开记录（收藏不受影响）")
            return 0
        rows = ctx.store.visits(limit=40)
        if not rows:
            ui.info("还没有打开记录。")
            ui.info("用 her learn open <站点> 打开过的会记在这里。")
            return 0
        lines = []
        for r in rows:
            when = str(r["visited_at"] or "").replace("T", " ")[:16]
            title = r["title"] or r["site_key"]
            lines.append(f"{when}  {title}")
        stats = ctx.store.visit_stats()[:8]
        if stats:
            lines.append("")
            lines.append("去得最多的：")
            for s in stats:
                title = s["title"] or s["site_key"]
                lines.append(f"  {title}  ×{s['visits']}")
        print(ui.box(f"打开记录 · 最近 {len(rows)} 条",
                     lines, width=ui.term_width(),
                     style=ctx.theme.primary))
        return 0

    if action in ("search", "find", "s"):
        keyword = args.name or ""
        if not keyword:
            ui.err("要给个关键词：her learn search 动态规划")
            return 1
        lowered = keyword.lower()
        hits = [
            s for s in learning.SITES
            if lowered in s.title.lower()
            or lowered in s.what.lower()
            or lowered in s.when.lower()
            or any(lowered in t.lower() for t in s.tags)
        ]
        if not hits:
            ui.warn(f"清单里没有跟「{keyword}」相关的站点")
            ui.info("可以试试 her search（搜 B 站）或者 her learn 看全部")
            return 0
        print(ui.box(f"「{keyword}」相关的学习站点",
                     _site_lines(hits, show_url=True), width=ui.term_width(),
                     style=ctx.theme.primary))
        return 0

    # her learn <分类>
    if args.name and not args.category:
        sites = [s for s in learning.SITES
                 if s.category == args.name
                 or args.name.lower() in s.category.lower()]
        if sites:
            print(ui.box(f"学习资源 · {args.name}",
                         _site_lines(sites), width=ui.term_width(),
                         style=ctx.theme.primary))
            return 0
        ui.warn(f"没有叫「{args.name}」的分类，下面是完整清单")

    if args.category:
        sites = [s for s in learning.SITES
                 if s.category == args.category
                 or args.category.lower() in s.category.lower()]
        print(ui.box(f"学习资源 · {args.category}",
                     _site_lines(sites), width=ui.term_width(), style=ctx.theme.primary))
        return 0

    # 默认：全部清单，按分类分组
    width = ui.term_width()
    blocks: list[str] = []
    for name, hint in learning.CATEGORIES:
        sites = learning.in_category(name)
        if not sites:
            continue
        blocks.append(ui.box(
            f"{name} · {hint}",
            _site_lines(sites),
            width=width,
            style=ctx.theme.primary,
        ))
    print("\n\n".join(blocks))
    print()
    print(ui.c("  打开某个：her learn open 3        ", "grey")
          + ui.c("按关键词找：her learn search 前端", "grey"))
    print(ui.c("  支持站内搜索的站点，可以带上关键词直接跳：", "grey"))
    print(ui.c("    her learn open leetcode 动态规划", "hotpink"))
    return 0


def make_learning_panel(store, cfg, theme: gem.Theme):
    """首页那一小块：挑几个最常用的，剩下的用 her learn 看。"""

    # 首页只放这些（顺序就是展示顺序）：入门、刷题、查文档、打基础、做项目
    featured_keys = ["carl", "leetcode", "mdn", "runoob", "hello-algo", "codefather"]

    def render(ctx) -> str:
        lines: list[str] = []
        for key in featured_keys:
            site = learning.by_key(key)
            if site is None:
                continue
            index = learning.SITES.index(site) + 1
            lines.append(
                ui.pad(f"{index:2d}.", 4)
                + ui.c(ui.pad(site.title, 20), "hotpink", "bold")
                + ui.c(site.tags[0] if site.tags else "", "plum")
            )
        lines.append("")
        lines.append(ui.c("打开：her learn open 2          ", "grey")
                     + ui.c("全部 " + str(len(learning.SITES)) + " 个：her learn", "grey"))
        lines.append(ui.c("带关键词直接跳：her learn open leetcode 动态规划", "hotpink"))
        return ui.box("自主学习 · 该去哪看", lines, width=ui.term_width(),
                      style=ctx.theme.primary)

    return PanelSpec("learning", "自主学习", render,
                     intro="学习网站清单：刷题、查文档、打基础、做项目")


# --------------------------------------------------------------------------
# 专业学习：课程 → 知识点 → 题目/资源
# --------------------------------------------------------------------------

def _course_matches(course, problems) -> list:
    """这门课在题库里对应哪些题（按标签匹配，所以她以后加的题会自动进来）。"""
    wanted = {t.lower() for t in course.tags}
    if not wanted:
        return []
    return [p for p in problems
            if any(t.lower() in wanted for t in (p.tags or []))]


def _course_block(course, ctx, *, detail: bool = True) -> list[str]:
    """渲染一门课的卡片内容。"""
    lines: list[str] = []
    head = ui.c(course.name, "hotpink", "bold")
    lines.append(head + ui.c(f"   [{course.category}]", "plum")
                 + (ui.c(f"   #{course.code}", "grey") if detail else ""))
    if detail:
        lines.append("  " + ui.c("这门课干什么：", "grey") + course.why)
        lines.append("  " + ui.c("难在哪：", "grey") + ui.c(course.hard, "gold"))

    if course.points:
        lines.append("")
        lines.append("  " + ui.c("知识点", "hotpink"))
        # 两列排，省版面
        points = course.points
        width = max(18, (ui.term_width() - 10) // 2)
        for index in range(0, len(points), 2):
            pair = points[index:index + 2]
            lines.append("    " + "  ".join(ui.pad("· " + p, width) for p in pair).rstrip())

    # 题库里对应的题
    problems = _course_matches(course, ctx.store.all())
    lines.append("")
    if problems:
        # 只列最需要复习的几道（到期优先）
        today = ctx.today()
        problems.sort(key=lambda p: (p.due, -p.lapses))
        lines.append("  " + ui.c(f"题库里对应的题（{len(problems)} 道）", "hotpink"))
        for p in problems[:6]:
            flag = ui.c("●", "gold") if p.is_due(today) else ui.c("○", "grey")
            lines.append(f"    {flag} " + ui.pad(f"#{p.id} {p.short(22)}", 30)
                         + ui.c(p.maturity, "grey"))
        if len(problems) > 6:
            lines.append("    " + ui.c(f"…还有 {len(problems) - 6} 道："
                                       f"her list --tag {course.tags[0] if course.tags else ''}", "grey"))
    else:
        lines.append("  " + ui.c("题库里还没有对应这道课的题", "grey"))
        if course.tags:
            lines.append("    " + ui.c(f"想加就用这些标签：{'、'.join(course.tags[:5])}", "grey"))

    # 学习资源
    if course.sites:
        lines.append("")
        lines.append("  " + ui.c("去哪学", "hotpink"))
        for key in course.sites:
            site = learning.by_key(key)
            if site is None:
                continue
            lines.append(f"    {ui.c(site.title, 'pink')}  " + ui.c(site.url, "plum"))
    return lines


def cmd_course(args, ctx) -> int:
    """专业学习模块：按课程看知识点、题目、视频和学习资源。"""
    from . import curriculum

    action = args.action or "overview"
    known = {"overview", "list", "show", "search", "tags"}

    # 容错：her course ds 这种写法，"ds" 会被当成 action
    if action not in known:
        args.name = args.name or action
        action = "show"

    problems = ctx.store.all()

    # ---------------- 单门课详情 ----------------
    if action in ("show", "detail"):
        course = curriculum.find(args.name or "")
        if course is None:
            ui.err(f"找不到课程「{args.name}」，用 her course list 看清单")
            return 1
        lines = _course_block(course, ctx)
        print(ui.box(course.name, lines, width=ui.term_width(), style=ctx.theme.primary))
        print()
        # 给出可以直接复制的下一步命令
        print(ui.c("  下一步：", "grey"))
        print("    " + ui.c(f"her search {course.search_words()[1] if len(course.search_words()) > 1 else course.name}",
                            "hotpink") + ui.c("   搜 B 站讲解", "grey"))
        if course.tags:
            print("    " + ui.c(f"her list --tag {course.tags[0]}", "hotpink")
                  + ui.c("   看这门课的题", "grey"))
            print("    " + ui.c(f"her review --extra {course.tags[0]}", "hotpink")
                  + ui.c("   直接开始复习这类题", "grey"))
        if course.sites:
            print("    " + ui.c(f"her learn open {course.sites[0]}", "hotpink")
                  + ui.c("   打开学习站点", "grey"))
        return 0

    # ---------------- 清单 ----------------
    if action == "list":
        if args.name:
            courses = [c for c in curriculum.COURSES
                       if args.name in c.category or args.name.lower() in c.name.lower()]
        else:
            courses = list(curriculum.COURSES)
        coverage = dict(curriculum.coverage(problems))
        lines = []
        for course in courses:
            count = coverage.get(course, 0)
            bar = ui.bar(min(count, 20), 20, width=10,
                         style="hotpink" if count else "grey")
            lines.append(
                ui.c(ui.pad(course.code, 12), "plum")
                + ui.pad(course.name, 24)
                + bar
                + "  "
                + ui.c(f"{count} 道" if count else "暂无", "grey" if not count else "gold")
            )
        lines.append("")
        lines.append(ui.c("看某一门：her course ds        ", "grey")
                     + ui.c("按知识点找：her course search 动态规划", "grey"))
        print(ui.box(f"专业课程 · {len(courses)} 门", lines,
                     width=ui.term_width(), style=ctx.theme.primary))
        return 0

    # ---------------- 按知识点搜 ----------------
    if action == "search":
        keyword = (args.name or "").strip()
        if not keyword:
            ui.err("给个关键词：her course search 动态规划")
            return 1
        lowered = keyword.lower()
        hits: list[tuple] = []
        for course in curriculum.COURSES:
            matched = [p for p in course.points if lowered in p.lower()]
            if matched or lowered in course.name.lower():
                hits.append((course, matched))
        if not hits:
            ui.warn(f"课程清单里没有和「{keyword}」相关的知识点")
            ui.info("试试 her learn search / her search 到别处找")
            return 0
        lines = []
        for course, matched in hits:
            lines.append(ui.c(course.name, "hotpink", "bold")
                         + ui.c(f"  [{course.category}]", "plum"))
            for point in matched[:6]:
                lines.append("    · " + point)
            lines.append("    " + ui.c(f"her course {course.code}", "grey")
                         + ui.c("  看详情", "grey"))
            lines.append("")
        while lines and not lines[-1]:
            lines.pop()
        print(ui.box(f"「{keyword}」在哪门课里", lines,
                     width=ui.term_width(), style=ctx.theme.primary))
        return 0

    # ---------------- 标签总览 ----------------
    if action == "tags":
        by_tag: dict[str, list] = {}
        for course in curriculum.COURSES:
            for tag in course.tags:
                by_tag.setdefault(tag, []).append(course)
        counts = {p.id: p for p in problems}
        lines = []
        for tag in sorted(by_tag):
            courses = by_tag[tag]
            same = sum(1 for p in counts.values()
                       if any(t.lower() == tag.lower() for t in (p.tags or [])))
            lines.append(
                ui.c(ui.pad("#" + tag, 16), "hotpink")
                + ui.c(ui.pad(f"{same} 道", 8), "gold" if same else "grey")
                + ui.c("、".join(c.code for c in courses[:3]), "plum")
            )
        print(ui.box("标签 → 课程 对照", lines, width=ui.term_width(),
                     style=ctx.theme.primary))
        return 0

    # ---------------- 总览（默认） ----------------
    coverage = dict(curriculum.coverage(problems))
    total_courses = len(curriculum.COURSES)
    with_problems = sum(1 for c in curriculum.COURSES if coverage.get(c, 0))
    total_points = sum(len(c.points) for c in curriculum.COURSES)

    lines = [
        ui.c("计算机科学与技术", "hotpink", "bold"),
        ui.c("  课程清单来自《2025 版专业人才培养方案》", "grey"),
        "",
        ui.c("课程      ", "grey") + ui.c(f"{total_courses} 门", "gold")
        + ui.c(f"（其中 {with_problems} 门在题库里有对应题）", "grey"),
        ui.c("知识点    ", "grey") + ui.c(f"{total_points} 个", "gold"),
        ui.c("题库覆盖  ", "grey") + ui.c(f"{ctx.store.count()} 道题", "gold"),
    ]
    print(ui.box("专业学习", lines, width=ui.term_width(), style=ctx.theme.primary))
    print()

    blocks = []
    for name, hint in curriculum.CATEGORIES:
        courses = curriculum.in_category(name)
        if not courses:
            continue
        body = []
        for course in courses:
            count = coverage.get(course, 0)
            body.append(
                ui.c(ui.pad(course.code, 12), "plum")
                + ui.pad(course.name, 24)
                + ui.c(f"{count} 道" if count else "—", "gold" if count else "grey")
            )
        body.append("")
        body.append(ui.c(hint, "grey"))
        blocks.append(ui.box(name, body, width=ui.term_width(), style=ctx.theme.primary))
    print("\n\n".join(blocks))
    print()
    print(ui.c("  看某门课：her course ds        ", "grey")
          + ui.c("知识点搜索：her course search 动态规划", "grey"))
    print(ui.c("  标签对照：her course tags       ", "grey")
          + ui.c("完整课程表：her course list", "grey"))
    return 0


def make_course_panel(store, cfg, theme: gem.Theme):
    """首页那块：挑几门主干课，显示题库覆盖情况。"""

    featured = ["ds", "algo", "os", "net", "db", "co"]

    def render(ctx) -> str:
        from . import curriculum

        problems = ctx.store.all()
        coverage = dict(curriculum.coverage(problems))
        lines = []
        for code in featured:
            course = curriculum.by_code(code)
            if course is None:
                continue
            count = coverage.get(course, 0)
            lines.append(
                ui.c(ui.pad(course.name, 22), "hotpink")
                + ui.bar(min(count, 20), 20, width=8,
                         style="hotpink" if count else "grey")
                + "  "
                + ui.c(f"{count} 道" if count else "—", "gold" if count else "grey")
            )
        lines.append("")
        lines.append(ui.c("全部课程：her course          ", "grey")
                     + ui.c("按知识点找：her course search 动态规划", "grey"))
        return ui.box("专业学习 · 主干课覆盖", lines, width=ui.term_width(),
                      style=ctx.theme.primary)

    return PanelSpec("course", "专业学习", render,
                     intro="对照培养方案看每门课的知识点、题目和资源")


# --------------------------------------------------------------------------
# 六级备考
# --------------------------------------------------------------------------

def cmd_cet6(args, ctx) -> int:
    """六级备考：倒计时、分阶段建议、视频方向、备考材料。"""
    from . import cet6

    action = args.action or "overview"

    if action == "videos":
        return _cet6_videos(ctx, getattr(args, "key", "") or "")

    if action == "add":
        kinds = []
        what = (getattr(args, "kind", "") or "all").lower()
        if what in ("all", "全部"):
            kinds = ["vocab", "writing", "translation"]
        elif what in ("vocab", "词", "词汇"):
            kinds = ["vocab"]
        elif what in ("writing", "作文"):
            kinds = ["writing"]
        elif what in ("translation", "翻译"):
            kinds = ["translation"]
        else:
            ui.err(f"不认识的内容类型：{what}（可选 all / vocab / writing / translation）")
            return 1
        added = cet6.import_problems(ctx.store, kinds=kinds)
        if added:
            ui.ok(f"已导入 {added} 条到题库，和算法题一起进复习队列")
            ui.info("它们带了「六级」标签，可以 her list --tag 六级 只看这些")
        else:
            ui.info("这些已经在题库里了，没有重复添加")
        return 0

    # ---- 总览 ----
    today = ctx.today()
    prog = cet6.progress(today)
    kind, advice = cet6.urgency(today)
    cov = cet6.coverage()

    lines: list[str] = []
    if prog["passed"]:
        lines.append(ui.c("考试已经过去了。", "grey"))
        lines.append(ui.c("成绩查询：", "grey") + ui.c(cet6.RESULT_URL, "plum"))
    else:
        # 倒计时
        lines.append(
            ui.c("考试  ", "grey")
            + ui.c(f"{cet6.EXAM_DATE.isoformat()}  {cet6.EXAM_TIME}", "bold")
            + ui.c(f"    口试 {cet6.SPEAKING_DATES}", "grey")
        )
        days = prog["days_left"]
        color = "red" if days <= 21 else ("gold" if days <= 60 else "brightgreen")
        lines.append(ui.c("还剩  ", "grey") + ui.c(f"{days} 天", color, "bold"))
        lines.append(ui.c("进度  ", "grey") + ui.bar(prog["percent"], 100, 30, color)
                     + ui.c(f" {prog['percent']}%", "grey"))
        lines.append("")
        lines.append(ui.c("  " + advice, "plum"))
        lines.append("")
        lines.append(ui.c("准考证  ", "grey")
                     + ui.c(f"{cet6.TICKET_DATE.isoformat()} 9 时起可打印", "grey"))
        lines.append(ui.c("报名/查询  ", "grey") + ui.c(cet6.REGISTER_URL, "grey"))

    print(ui.box("英语六级备考", lines, width=ui.term_width(), style=ctx.theme.primary))

    # 卷面结构（内容长，用无框排版——框线不会自动换行，长句会把框顶破）
    print()
    print(ui.box("卷面结构与拿分策略", [
        ui.c("总分 710，425 通过。做题顺序就是下面这个顺序。", "grey"),
    ], width=ui.term_width(), style=ctx.theme.primary))
    for s in cet6.SECTIONS:
        print()
        print("  " + ui.c(ui.pad(s["name"], 4), "bold")
              + ui.c(f"{s['ratio']:>4}  ", "gold")
              + ui.c(f"{s['score']:>6} 分  ", "plum")
              + ui.c(f"{s['minutes']} 分钟", "grey"))
        print("  " + ui.c(s["order"], "grey"))
        for tip in s["tips"]:
            print("    " + ui.c("· " + _plain_tip(tip), "grey"))

    # 视频方向（每条三行，用无框）
    print()
    print(ui.box("B 站备考视频方向", [
        ui.c("存的是搜索词不是链接——视频会下架，搜索词不会。", "grey"),
    ], width=ui.term_width(), style=ctx.theme.primary))
    for i, v in enumerate(cet6.VIDEO_TOPICS, start=1):
        kind_label = {"system": "系统课", "drill": "专项练",
                      "skill": "技巧", "vocab": "词汇"}.get(v.kind, v.kind)
        print()
        print(f"  {ui.c(str(i) + '.', 'gold')} " + ui.c(v.title, "bold")
              + ui.c(f"  [{kind_label}]", "grey"))
        print("     " + ui.c(v.why, "grey"))
        print("     " + ui.c("搜：", "grey") + ui.c(v.query, "plum")
              + ui.c(f"　建议 {v.minutes}", "grey") if v.minutes else "")
    print()
    print(ui.c("  看某个方向的最新视频：her cet6 videos <序号>", "grey"))

    # 备考材料
    print()
    print(ui.box("备考材料（能直接变成复习题）", [
        ui.c(f"高频词       {cov['vocab']} 个（每个都写了为什么容易错）", "plum"),
        ui.c(f"作文框架     {cov['writing_frames']} 个（够覆盖绝大部分题目）", "plum"),
        ui.c(f"翻译主题     {cov['translation_topics']} 类 / {cov['translation_words']} 个词条", "plum"),
        "",
        ui.c("导进题库就和算法题一起做间隔重复：", "grey"),
        ui.c("  her cet6 add              全部导入", "hotpink"),
        ui.c("  her cet6 add vocab        只导高频词", "hotpink"),
        ui.c("  her cet6 add writing      只导作文框架", "hotpink"),
        ui.c("  her cet6 add translation  只导翻译主题", "hotpink"),
        "",
        ui.c("真题不内嵌（有版权，编一份假的更糟）。自己拿：", "grey"),
        ui.c(f"  {cet6.RESULT_URL}", "grey"),
        ui.c("  B 站搜「六级真题精讲」，跟着讲解过一遍", "grey"),
    ], width=ui.term_width(), style=ctx.theme.primary))
    return 0


def _plain_tip(text: str) -> str:
    """去掉给界面用的 Markdown 标记（终端里 ** 不会变成粗体，只会显得碍眼）。"""
    return text.replace("**", "")


def _cet6_videos(ctx, which: str) -> int:
    """看某个备考方向的最新 B 站视频。"""
    from . import cet6, search

    if not which:
        ui.err("要给一个序号或 key：her cet6 videos 2")
        ui.info("序号见 her cet6 里的列表")
        return 1

    topic = None
    if which.isdigit():
        index = int(which)
        if 1 <= index <= len(cet6.VIDEO_TOPICS):
            topic = cet6.VIDEO_TOPICS[index - 1]
    else:
        topic = cet6.by_key(which)
    if topic is None:
        ui.err(f"没有这个方向：{which}")
        ui.info("用 her cet6 看可用的序号")
        return 1

    print(ui.c("正在搜 B 站…", "grey"))
    ok, videos, error = cet6.resolve_videos(topic.key, limit=6)
    if not ok:
        ui.warn(f"没搜到（{error}）")
        ui.info("直接打开搜索页自己找：" + topic.search_url())
        return 0

    lines = [ui.c(f"搜的是：{topic.query}", "grey"), ""]
    for i, v in enumerate(videos, start=1):
        lines.append(ui.c(f"{i}. ", "gold") + ui.c(v["title"], "bold"))
        lines.append(ui.c(f"   UP {v['author']}", "grey")
                     + (ui.c(f"  {v['duration']}", "grey") if v["duration"] else "")
                     + (ui.c(f"  ▶ {v['play']}", "grey") if v["play"] else ""))
        lines.append(ui.c(f"   {v['url']}", "plum"))
    print(ui.box(topic.title, lines, width=ui.term_width(), style=ctx.theme.primary))
    return 0


# --------------------------------------------------------------------------
# 失败台账与生成质量
# --------------------------------------------------------------------------

def cmd_failures(args, ctx) -> int:
    """看/清失败记录。

    存在的意义：程序里到处都有 except + 降级，不崩是好事，
    但如果她永远不知道该次失败过，"不崩"就变成了"悄悄出错"。
    """
    from . import failures as failures_mod

    action = args.action or "list"

    if action == "list":
        items = failures_mod.open_failures(ctx.store)
        lines = failures_mod.render_list(ctx.store, include_resolved=bool(args.all))
        if items:
            lines.append("")
            lines.append(ui.c("解决之后：her failures done <编号>", "grey")
                         + ui.c("     全部标记：her failures done all", "grey"))
        print(ui.box(f"待处理的问题 · {len(items)} 条", lines,
                     width=ui.term_width(), style=ctx.theme.primary))
        return 0

    if action == "done":
        target = (args.name or "").strip()
        if target == "all":
            cur = ctx.store.conn.execute(
                "UPDATE failures SET state = 'resolved' WHERE state = 'open'"
            )
            ctx.store.conn.commit()
            ui.ok(f"已标记解决 {cur.rowcount} 条")
            return 0
        if not target.isdigit():
            ui.err("要给编号：her failures done 3（或 her failures done all）")
            return 1
        if failures_mod.resolve(ctx.store, int(target)):
            ui.ok(f"已标记 #{target} 为已解决")
            return 0
        ui.err(f"没有编号为 {target} 的记录")
        return 1

    if action == "clear":
        if not args.yes:
            from .cli_support import ask_choice

            if ask_choice("清空全部失败记录？(y/n)", {"y", "n"}, "n") != "y":
                ui.info("已取消")
                return 0
        n = failures_mod.clear(ctx.store)
        ui.ok(f"已清空 {n} 条记录")
        return 0

    ui.err(f"不认识的动作 {action}")
    return 1


def cmd_quality(args, ctx) -> int:
    """看视频生成的质量记录（AI 出来的东西不该假装完整）。"""
    import json

    from . import evidence

    rows = list(ctx.store.conn.execute(
        "SELECT * FROM quality_log ORDER BY id DESC LIMIT ?", (args.limit or 8,)
    ))
    if not rows:
        print(ui.box("生成质量", [
            ui.c("还没有视频总结记录。", "grey"),
            "",
            ui.c("总结一个视频之后，这里会写清：", "grey"),
            ui.c("  · 转写是从 B 站字幕来的，还是语音识别出来的", "grey"),
            ui.c("  · 有没有真的用上大模型", "grey"),
            ui.c("  · 内容有没有被裁剪、来源指纹是什么", "grey"),
            "",
            ui.c("her summarize <视频链接> --problem <题号> --save", "hotpink"),
        ], width=ui.term_width(), style=ctx.theme.primary))
        return 0

    with_note = 0
    for row in rows:
        try:
            report = evidence.QualityReport.from_dict(json.loads(row["payload"] or "{}"))
        except (ValueError, TypeError):
            continue
        if report.has_note:
            with_note += 1
        stamp = (row["created_at"] or "")[:16].replace("T", " ")
        print(ui.box(f"{report.title or '（无标题）'}   ·   {stamp}",
                     report.lines(), width=ui.term_width(), style=ctx.theme.primary))
        print()

    print(ui.c(f"  近 {len(rows)} 次生成里，{with_note} 次拿到了完整笔记。", "grey"))
    print(ui.c("  可信度低不等于失败——它只是告诉你这份材料能信到什么程度。", "grey"))
    return 0


# --------------------------------------------------------------------------
# 每日任务：提醒 + 钩子
# --------------------------------------------------------------------------

def announce_reminders(ctx, *, mark: bool = True) -> int:
    """把今天的特别提醒报出来。返回条数。"""
    rows = ctx.store.reminders_today(ctx.today())
    if not rows:
        return 0
    lines: list[str] = []
    for row in rows:
        important = row["priority"] == "important"
        bullet = ui.c("❗", "hotpink", "bold") if important else ui.c("•", "pink")
        when = ui.pad(ui.c(row["at_time"] or "全天", "grey"), 7)
        body = ui.c(row["body"], "hotpink", "bold") if important else row["body"]
        lines.append(f"{bullet} {when} {body}")
        if mark and row["pattern"] == "once":
            ctx.store.mark_reminder_fired(row["id"], ctx.today())
    title = f"今天有 {len(rows)} 条提醒"
    print(ui.box(title, lines, width=ui.term_width(), style="hotpink"))
    return len(rows)


def fire_hooks(ctx, event: str, **kwargs) -> None:
    """触发插件钩子。ctx 上没有插件系统（比如测试）时安静跳过。"""
    runtime = getattr(ctx, "plugins", None)
    hooks = getattr(ctx, "hooks", None)
    if runtime is None or hooks is None:
        return
    runtime.fire(hooks, event, ctx=ctx, **kwargs)


def cmd_day(args, ctx) -> int:
    """今天的全部信息：首页 + 提醒 + 面板区，一次性看全。"""
    from . import report

    # 生日从配置现场解析，不依赖 ctx 上有没有缓存字段
    birthday = getattr(ctx, "birthday", None) or gem.parse_date(ctx.cfg.birthday)
    print(report.opening(ctx.store, ctx.theme, ctx.name, birthday, ctx.today()))
    print()
    announced = announce_reminders(ctx)
    if announced:
        print()
    # 提醒已经在上面单独报过一次了，面板区里跳过，避免同一页出现两遍
    dashboard = render_home_panels(ctx, skip={"reminders"})
    if dashboard:
        print(dashboard)
    fire_hooks(ctx, "day")
    return 0


# --------------------------------------------------------------------------
# 面板
# --------------------------------------------------------------------------

def _panel_intro(spec) -> str:
    from . import plugins as plugins_mod

    mark = ""
    if spec.source not in ("内置",):
        mark = ui.c(f"  [插件 {spec.source}]", "violet")
    enabled = ""
    return ui.c(spec.title, "hotpink", "bold") + mark + enabled + (
        f"    {ui.c(spec.intro, 'grey')}" if spec.intro else ""
    )


def cmd_panels(args, ctx) -> int:
    action = args.action or "list"

    if action == "list":
        order = ctx.cfg.panel_order()
        registry: PanelRegistry = ctx.panels
        lines: list[str] = []
        for index, name in enumerate(order, start=1):
            spec = registry.get(name)
            if spec is None:
                lines.append(ui.c(f"{index}. {name}", "red") + ui.c("  （找不到这个面板）", "grey"))
                continue
            lines.append(f"{index}. " + _panel_intro(spec))
        rest = [pid for pid in registry.ids() if pid not in order]
        if rest:
            lines.append("")
            lines.append(ui.c("没有显示在首页的：", "grey"))
            for pid in rest:
                spec = registry.get(pid)
                lines.append("   " + ui.c(pid, "grey") + "  " + ui.c(spec.title if spec else "", "grey"))
        lines.append("")
        lines.append(ui.c("调整顺序：her panels move <序号> <新位置>", "grey"))
        lines.append(ui.c("临时只看某几个：her today --only countdown,notes", "grey"))
        return _print_box("首页面板", lines, ctx)

    if action in ("enable", "add", "on"):
        name = args.name
        spec = ctx.panels.get(name) if name else None
        if not name or spec is None:
            ui.err(f"没有叫「{name}」的面板。用 her panels list 看可用的")
            return 1
        order = ctx.cfg.panel_order()
        if name in order:
            ui.info(f"「{spec.title}」已经在首页了")
            return 0
        # 放回它的出厂位置，而不是无脑追加到末尾
        if name in DEFAULT_PANELS:
            position = DEFAULT_PANELS.index(name)
            insert_at = len(order)
            for index, existing in enumerate(order):
                if existing in DEFAULT_PANELS and DEFAULT_PANELS.index(existing) > position:
                    insert_at = index
                    break
            order.insert(insert_at, name)
        else:
            order.append(name)
        ctx.cfg.set_panels(order)
        ctx.cfg.save()
        ui.ok(f"已把「{spec.title}」加回首页")
        return 0

    if action in ("disable", "remove", "off"):
        name = args.name
        order = ctx.cfg.panel_order()
        if name not in order:
            ui.err(f"首页本来就没有「{name}」")
            return 1
        order.remove(name)
        ctx.cfg.set_panels(order)
        ctx.cfg.save()
        ui.ok(f"已把「{name}」从首页移除（面板还在，随时能加回来）")
        return 0

    if action in ("up", "down"):
        name = args.name
        order = ctx.cfg.panel_order()
        if name not in order:
            ui.err(f"首页上没有「{name}」")
            return 1
        index = order.index(name)
        target = index - 1 if action == "up" else index + 1
        if target < 0 or target >= len(order):
            ui.info("已经到边界了")
            return 0
        order[index], order[target] = order[target], order[index]
        ctx.cfg.set_panels(order)
        ctx.cfg.save()
        ui.ok("顺序已更新：" + " → ".join(order))
        return 0

    if action == "move":
        order = ctx.cfg.panel_order()
        try:
            src = int(args.name) - 1
            dst = int(args.extra) - 1
        except (TypeError, ValueError):
            ui.err("用法：her panels move <序号> <新位置>（序号从 her panels list 里看）")
            return 1
        if not (0 <= src < len(order)) or not (0 <= dst < len(order)):
            ui.err("序号超范围了")
            return 1
        name = order.pop(src)
        order.insert(dst, name)
        ctx.cfg.set_panels(order)
        ctx.cfg.save()
        ui.ok("顺序已更新：" + " → ".join(order))
        return 0

    if action == "reset":
        ctx.cfg.set_panels(list(DEFAULT_PANELS))
        ctx.cfg.save()
        ui.ok("面板顺序已恢复默认")
        return 0

    ui.err(f"不认识的动作 {action}")
    return 1


def _print_box(title: str, lines: list[str], ctx) -> int:
    print(ui.box(title, lines, width=ui.term_width(), style=ctx.theme.primary))
    return 0


def render_home_panels(ctx, *, only: list[str] | None = None,
                       skip: set[str] | None = None) -> str:
    """首页面板区的统一入口。"""
    registry: PanelRegistry | None = getattr(ctx, "panels", None)
    if registry is None:
        return ""
    skip_list = list(skip) if skip else None
    return panels.render_dashboard(ctx, registry, only=only, skip=skip_list)


# --------------------------------------------------------------------------
# 便签
# --------------------------------------------------------------------------

def cmd_note(args, ctx) -> int:
    action = args.action or "list"

    if action in ("add", "new"):
        body = args.text
        if not body:
            from .cli_support import ask

            body = ask("便签内容")
        if not body:
            ui.err("内容不能为空")
            return 1
        nid = ctx.store.add_note(body, args.color or "pink", pinned=bool(args.pin))
        ui.ok(f"贴好了 #{nid}" + ("（已置顶）" if args.pin else ""))
        return 0

    if action == "list":
        rows = ctx.store.notes(include_archived=bool(args.all))
        if not rows:
            print(ui.box("便签", [
                ui.c("一张便签都没有", "grey"),
                "",
                ui.c("her note add \"今天要把 LRU 手写一遍\"", "hotpink"),
                ui.c("her note add \"周五交实验报告\" --pin", "hotpink"),
            ], width=ui.term_width(), style=ctx.theme.primary))
            return 0
        cards = panels.note_cards(ctx.store, ctx.theme, limit=20,
                                  include_archived=bool(args.all))
        print("\n".join(cards))
        print()
        print(ui.c(f"共 {len(rows)} 张 · her note rm <编号> 删除 · her note pin <编号> 置顶", "grey"))
        return 0

    row = ctx.store.find_note(args.text or "")
    if row is None:
        ui.err(f"找不到便签「{args.text}」")
        return 1

    if action in ("rm", "delete"):
        if not args.yes:
            from .cli_support import ask_choice

            if ask_choice(f"删掉便签 #{row['id']}「{row['body'][:20]}」？(y/n)",
                          {"y", "n"}, "n") != "y":
                ui.info("已取消")
                return 0
        ctx.store.delete_note(row["id"])
        ui.ok(f"已删除 #{row['id']}")
        return 0

    if action == "pin":
        new_value = not bool(row["pinned"])
        ctx.store.update_note(row["id"], pinned=new_value)
        ui.ok(f"#{row['id']} " + ("已置顶 ★" if new_value else "已取消置顶"))
        return 0

    if action in ("archive", "done"):
        ctx.store.update_note(row["id"], archived=True)
        ui.ok(f"已归档 #{row['id']}（her note list --all 还能看到）")
        return 0

    if action == "unarchive":
        ctx.store.update_note(row["id"], archived=False)
        ui.ok(f"已恢复 #{row['id']}")
        return 0

    if action == "edit":
        from .cli_support import ask

        body = ask("新的内容", row["body"])
        if body and body != row["body"]:
            ctx.store.update_note(row["id"], body=body)
            ui.ok("已更新")
        else:
            ui.info("没有改动")
        return 0

    if action == "color":
        # 用法：her note color <编号> <颜色>
        # 颜色走独立的位置参数（value），这样两种写法都能用：
        #   her note color 1 rose
        #   her note color 1 --color rose
        wanted = (getattr(args, "value", None) or args.color or "").strip()
        if wanted in panels.NOTE_COLORS:
            ctx.store.update_note(row["id"], color=wanted)
            ui.ok(f"#{row['id']} 换成了 {wanted}")
            return 0
        if args.color in panels.NOTE_COLORS:
            ctx.store.update_note(row["id"], color=args.color)
            ui.ok(f"#{row['id']} 换成了 {args.color}")
            return 0
        ui.err("可选颜色：「 + 」、".join(panels.NOTE_COLORS))
        ui.info("用法：her note color <编号> <颜色>")
        return 1

    ui.err(f"不认识的动作 {action}")
    return 1


# --------------------------------------------------------------------------
# 倒数日
# --------------------------------------------------------------------------

def cmd_days(args, ctx) -> int:
    action = args.action or "list"

    if action in ("add", "new"):
        title = args.title
        target = args.date
        if not title:
            from .cli_support import ask

            title = ask("这是什么日子")
        if not target:
            from .cli_support import ask

            target = ask("哪一天（YYYY-MM-DD）")
        if not title or not target:
            ui.err("标题和日期都要给")
            return 1
        try:
            cid = ctx.store.add_countdown(
                title, target, args.kind or "event", args.note or "",
                yearly=bool(args.yearly),
            )
        except ValueError as exc:
            ui.err(str(exc))
            return 1
        row = ctx.store.countdown(cid)
        left = panels._days_left(date.fromisoformat(row["target"]), ctx.today())
        ui.ok(f"已加入 #{cid}「{title}」")
        if left >= 0:
            ui.info(f"还有 {left} 天" + ("（每年重复）" if args.yearly else ""))
        else:
            ui.info(f"这个日子已经过去 {-left} 天了" + ("（每年重复，看下一次）" if args.yearly else ""))
        if (args.kind or "event") == "birthday":
            ui.info("提示：生日本来就会自动显示在首页（来自 init 填的生日），"
                    "不用再加一条，除非你想单独备注点什么")
        return 0

    if action == "list":
        # --all 看全年（默认只看 120 天内的，避免清单太长）
        window = 3650 if getattr(args, "all", False) else 120
        lines = panels.countdown_view(ctx.store, ctx.theme, ctx.today(), window=window)
        birthday_row = panels._birthday_line(ctx, ctx.today(), window=window)
        if birthday_row:
            if lines:
                lines.append("")
            lines.append(birthday_row)
        if not lines:
            ui.warn("还没有倒数日")
        return _print_box("倒数日", lines, ctx)

    row = ctx.store.find_countdown(args.title or "")
    if row is None:
        ui.err(f"找不到「{args.title}」")
        return 1

    if action in ("rm", "delete"):
        if not args.yes:
            from .cli_support import ask_choice

            if ask_choice(f"删掉 #{row['id']}「{row['title']}」？(y/n)", {"y", "n"}, "n") != "y":
                ui.info("已取消")
                return 0
        ctx.store.delete_countdown(row["id"])
        ui.ok(f"已删除 #{row['id']}")
        return 0

    if action == "done":
        ctx.store.update_countdown(row["id"], archived=True)
        ui.ok(f"已归档 #{row['id']}")
        return 0

    if action == "edit":
        from .cli_support import ask

        title = ask("标题", row["title"])
        target = ask("日期", row["target"])
        note = ask("备注", row["note"])
        yearly = ask("每年重复？(y/n)", "y" if row["yearly"] else "n").lower() == "y"
        try:
            ctx.store.update_countdown(row["id"], title=title, target=target,
                                       note=note, yearly=yearly)
            ui.ok("已更新")
        except ValueError as exc:
            ui.err(str(exc))
            return 1
        return 0

    ui.err(f"不认识的动作 {action}")
    return 1


# --------------------------------------------------------------------------
# 提醒
# --------------------------------------------------------------------------

def cmd_remind(args, ctx) -> int:
    action = args.action or "list"

    if action in ("add", "new"):
        body = args.text
        if not body:
            from .cli_support import ask

            body = ask("提醒内容")
        if not body:
            ui.err("内容不能为空")
            return 1
        pattern = args.pattern or "daily"
        weekday = args.weekday or 1
        on_date = args.date or ""
        if pattern == "weekly" and args.weekday is None:
            weekday = ctx.today().isoweekday()
        if pattern in ("date", "once") and not on_date:
            on_date = ctx.today().isoformat()
        try:
            rid = ctx.store.add_reminder(body, pattern, weekday, on_date,
                                        args.at or "",
                                        "important" if args.important else "normal")
        except ValueError as exc:
            ui.err(str(exc))
            return 1
        row = ctx.store.reminder(rid)
        ui.ok(f"已加入 #{rid}：{body}")
        ui.info(f"规则：{reminder_when(row)}"
                + ("　❗重要" if args.important else ""))
        return 0

    if action == "list":
        # 默认全部列出（含停用的），用 × 标出来。
        # 之前默认只显示启用的，导致「我刚加的提醒怎么不见了」。
        rows = ctx.store.reminders()
        if not rows:
            print(ui.box("提醒", [
                ui.c("还没有提醒", "grey"),
                "",
                ui.c("her remind add \"喝水\"                每天", "hotpink"),
                ui.c("her remind add \"周会\" -p weekly -w 1  每周一", "hotpink"),
                ui.c("her remind add \"交报告\" -p date -d 2026-06-10", "hotpink"),
            ], width=ui.term_width(), style=ctx.theme.primary))
            return 0
        today_ids = {r["id"] for r in ctx.store.reminders_today(ctx.today())}
        lines: list[str] = []
        for row in rows:
            flag = ui.c("●", "hotpink") if row["id"] in today_ids else ui.c("○", "grey")
            if not row["enabled"]:
                flag = ui.c("×", "grey")
            mark = ui.c("❗", "hotpink") if row["priority"] == "important" else " "
            lines.append(
                f"{flag} {mark} " + ui.c(ui.pad(f"#{row['id']}", 5), "grey")
                + ui.pad(row["body"], 24)
                + ui.c(ui.pad(PATTERN_LABELS.get(row["pattern"], row["pattern"]), 10), "plum")
                + ui.c(reminder_when(row), "grey")
            )
        lines.append("")
        lines.append(ui.c("● 今天要响　○ 平时不响　× 已停用", "grey"))
        return _print_box("提醒", lines, ctx)

    row = ctx.store.reminder(int(args.text)) if (args.text or "").isdigit() else None
    if row is None:
        for candidate in ctx.store.reminders():
            if args.text and args.text in candidate["body"]:
                row = candidate
                break
    if row is None:
        ui.err(f"找不到提醒「{args.text}」（用编号或内容片段）")
        return 1

    if action in ("rm", "delete"):
        ctx.store.delete_reminder(row["id"])
        ui.ok(f"已删除 #{row['id']}")
        return 0

    if action in ("on", "off"):
        enabled = action == "on"
        ctx.store.update_reminder(row["id"], enabled=enabled)
        ui.ok(f"#{row['id']} 已{'启用' if enabled else '停用'}")
        return 0

    ui.err(f"不认识的动作 {action}")
    return 1


# --------------------------------------------------------------------------
# 插件
# --------------------------------------------------------------------------

def cmd_plugins(args, ctx) -> int:
    action = args.action or "list"
    runtime = getattr(ctx, "plugins", None)
    if runtime is None:
        ui.err("插件系统没有初始化（这是程序内部状态，请重试或报告问题）")
        return 1

    if action == "list":
        lines: list[str] = []
        if not runtime.infos:
            lines.append(ui.c("还没有装任何插件。", "grey"))
        for info in runtime.infos.values():
            state_text, color = info.state_label()
            title = ui.c(info.name, "hotpink", "bold")
            version = ui.c(f" v{info.version}", "grey") if info.version else ""
            lines.append(f"{ui.c('●', color)} {title}{version}  " + ui.c(f"[{state_text}]", color))
            if info.description:
                lines.append("    " + ui.c(info.description, "plum"))
            detail = []
            if info.panels:
                detail.append("面板 " + "、".join(info.panels))
            if info.commands:
                detail.append("命令 " + "、".join(info.commands))
            if info.author:
                detail.append("作者 " + info.author)
            if detail:
                lines.append("    " + ui.c("　".join(detail), "grey"))
            if info.state == STATE_ERROR_TEXT:
                lines.append("    " + ui.c(info.error, "red"))
        lines.append("")
        lines.append(ui.c(f"插件目录：{runtime.plugins_dir}", "grey"))
        lines.append(ui.c("新建一个：her plugins new my_plugin", "grey"))
        lines.append(ui.c("写错了不要紧，坏插件不会影响程序其他地方", "grey"))
        return _print_box("插件", lines, ctx)

    if action in ("enable", "disable"):
        name = args.name
        target = None
        for info in runtime.infos.values():
            if info.name == name or (info.path and info.path.stem == name):
                target = info.name
                break
        if target is None:
            ui.err(f"没有叫「{name}」的插件")
            return 1
        disabled = set(getattr(ctx.cfg, "plugins_disabled", []) or [])
        if action == "enable":
            disabled.discard(target)
            ui.ok(f"已启用「{target}」，重启后生效（其实下次运行就是新的了）")
        else:
            disabled.add(target)
            ui.ok(f"已停用「{target}」")
        _save_disabled(ctx, sorted(disabled))
        return 0

    if action in ("new", "create"):
        name = args.name
        if not name:
            ui.err("要给插件起个名字：her plugins new my_plugin")
            return 1
        try:
            path = runtime.create(name, force=bool(args.force))
        except FileExistsError as exc:
            ui.err(str(exc))
            return 1
        except ValueError as exc:
            ui.err(str(exc))
            return 1
        ui.ok(f"建好了：{path}")
        ui.info(f"用 her plugins open {name} 打开它开始写（改完直接 her today 就能看到）")
        ui.info(f"它自带的示例命令：her {name} greet 你的名字")
        return 0

    if action == "open":
        ok, detail = runtime.open_in_editor(args.name or "")
        if ok:
            ui.ok(f"已用系统默认编辑器打开：{detail}")
        else:
            ui.err(detail)
            return 1
        return 0

    if action == "dir":
        runtime.ensure_dir()
        ui.info(str(runtime.plugins_dir))
        ok, detail = runtime.open_in_editor("__none__")
        return 0

    if action == "log":
        lines = runtime.read_log(args.limit or 30)
        if not lines:
            ui.info("插件日志还是空的")
            return 0
        print(ui.box("插件日志", [ui.c(l, "grey") for l in lines],
                     width=ui.term_width(), style=ctx.theme.primary))
        return 0

    if action == "doc":
        print(ui.box("怎么写插件", [
            ui.c("1. her plugins new my_plugin", "hotpink") + ui.c("   生成模板文件", "grey"),
            ui.c("2. her plugins open my_plugin", "hotpink") + ui.c("   打开编辑器改", "grey"),
            ui.c("3. her today", "hotpink") + ui.c("   直接看效果，不用重启", "grey"),
            "",
            ui.c("模板里已经写好了三种用法的例子：面板 / 命令 / 钩子。", "plum"),
            ui.c("详细说明看插件目录里的 README.txt。", "plum"),
        ], width=ui.term_width(), style=ctx.theme.primary))
        return 0

    ui.err(f"不认识的动作 {action}")
    return 1


STATE_ERROR_TEXT = "error"


def _save_disabled(ctx, names: list[str]) -> None:
    """停用列表存在配置文件的额外字段里（Config 的 DEFAULTS 不认识它也无妨）。"""
    import json

    path = ctx.cfg.config_path
    payload: dict = {}
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            payload = {}
    payload["plugins_disabled"] = names
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    except OSError as exc:
        ui.err(f"写配置失败：{exc}")


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    from ._testutil import temp_home
    from .config import Config
    from .db import Store

    ui.use_color(False)
    with temp_home(".selftest-features") as home:
        _selftest_inner(Store(":memory:"), Config(home=home))
    print("features selftest: 全部断言通过 ✓")


def _selftest_inner(store, cfg) -> None:
    class _Ctx:
        pass

    ctx = _Ctx()
    ctx.store = store
    ctx.cfg = cfg
    ctx.theme = gem.theme_from_birthday("2005-06-01")
    ctx.name = "测试"
    ctx.today = lambda: date(2026, 6, 1)
    ctx.plugins = None
    ctx.hooks = None
    registry = PanelRegistry()
    panels.register_builtin_panels(registry, ctx)
    ctx.panels = registry

    # 面板开关
    class _Args:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    # 下面用"动态算出的初始顺序"做基准，而不是写死列表——
    # 这样以后再新增内置面板，这个自测不用跟着改。
    base = list(DEFAULT_PANELS)

    assert cmd_panels(_Args(action="list", name=None, extra=None), ctx) == 0
    assert cmd_panels(_Args(action="disable", name="notes", extra=None), ctx) == 0
    # 注意：panel_order() 会把"本该有但配置里没有的面板"自动补回来（升级友好），
    # 所以这里不能用 "notes" not in panel_order() 判断，
    # 要看配置里真正存下来的那份（cfg.panels）。
    assert "notes" not in [p.strip() for p in cfg.panels.split(",") if p.strip()]
    assert cmd_panels(_Args(action="enable", name="notes", extra=None), ctx) == 0
    assert cfg.panel_order() == base, cfg.panel_order()

    # move 是 1-based：把第 1 个挪到第 2 位
    assert cmd_panels(_Args(action="move", name="1", extra="2"), ctx) == 0
    moved = [base[1], base[0]] + base[2:]
    assert cfg.panel_order() == moved, cfg.panel_order()

    # 把最后一个挪到最前
    last = len(base)
    assert cmd_panels(_Args(action="move", name=str(last), extra="1"), ctx) == 0
    assert cfg.panel_order() == [base[-1]] + moved[:-1], cfg.panel_order()

    # down 把第一个往后挪一位
    assert cmd_panels(_Args(action="down", name=base[-1], extra=None), ctx) == 0
    assert cfg.panel_order()[1] == base[-1], cfg.panel_order()

    # up 撤回
    assert cmd_panels(_Args(action="up", name=base[-1], extra=None), ctx) == 0
    assert cfg.panel_order()[0] == base[-1], cfg.panel_order()

    # 边界的 up 应该安静地什么都不做
    assert cmd_panels(_Args(action="up", name=base[-1], extra=None), ctx) == 0
    assert cfg.panel_order()[0] == base[-1], "已经在第一位，不该动"
    # 序号超范围要报错
    assert cmd_panels(_Args(action="move", name="99", extra="1"), ctx) == 1
    assert cmd_panels(_Args(action="reset", name=None, extra=None), ctx) == 0
    assert cfg.panel_order() == base, cfg.panel_order()
    # 不存在的面板要报错而不是崩
    assert cmd_panels(_Args(action="enable", name="不存在", extra=None), ctx) == 1

    # 便签
    assert cmd_note(_Args(action="add", text="测试便签", color=None, pin=True, all=False,
                          yes=True), ctx) == 0
    assert len(store.notes()) == 1
    assert cmd_note(_Args(action="list", text=None, color=None, pin=False, all=False,
                          yes=True), ctx) == 0
    assert cmd_note(_Args(action="pin", text="测试", color=None, pin=False, all=False,
                          yes=True), ctx) == 0
    assert cmd_note(_Args(action="archive", text="测试", color=None, pin=False, all=False,
                          yes=True), ctx) == 0
    assert not store.notes()
    assert cmd_note(_Args(action="list", text=None, color=None, pin=False, all=True, yes=True),
                    ctx) == 0

    # 倒数日
    assert cmd_days(_Args(action="add", title="期末机试", date="2026-06-11", kind="exam",
                          note="", yearly=False), ctx) == 0
    assert cmd_days(_Args(action="list", title=None, date=None, kind=None, note=None,
                          yearly=False, yes=True), ctx) == 0
    assert cmd_days(_Args(action="rm", title="期末机试", date=None, kind=None, note=None,
                          yearly=False, yes=True), ctx) == 0
    assert not store.countdowns()

    # 提醒
    assert cmd_remind(_Args(action="add", text="喝水", pattern="daily", weekday=None,
                            date=None, at=None, important=False), ctx) == 0
    assert cmd_remind(_Args(action="add", text="交报告", pattern="date",
                            weekday=None, date="2026-06-01", at="20:00", important=True),
                      ctx) == 0
    assert cmd_remind(_Args(action="list", text=None, pattern=None, weekday=None,
                            date=None, at=None, important=False), ctx) == 0
    assert announce_reminders(ctx) == 2
    assert cmd_remind(_Args(action="off", text="1", pattern=None, weekday=None, date=None,
                            at=None, important=False), ctx) == 0
    assert cmd_remind(_Args(action="list", text=None, pattern=None, weekday=None, date=None,
                            at=None, important=False), ctx) == 0

    # 每日任务页面不炸即可
    assert cmd_day(_Args(), ctx) == 0

    store.close()


if __name__ == "__main__":
    _selftest()
