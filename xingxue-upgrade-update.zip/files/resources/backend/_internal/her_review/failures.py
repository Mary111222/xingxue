"""失败台账：把"静默失败"变成"可查、可重试"。

借自 VeoStudyHub 的"失败安全（Fail-safe）"原则：
    模型调用失败、输出格式非法、来源变化等情况，
    都不得写入半成品或覆盖用户已有内容，而是**保留可重试的失败记录**。

对应到 her 这个程序，真实存在的问题是：
    我为了让程序"不崩"，到处写了 except + 降级。
    程序确实不崩了，但**她永远不知道刚才那次失败过**：
    - B 站搜索没拿到结果，静默退回"打开搜索页"
    - 视频总结只有转写没有笔记，看起来像成功了
    - 插件加载失败，只在 plugins list 里标个红
    - 导入解析出 0 道题，只说一句"没解析出来"

这个模块把这些都记下来，并且给出**具体的重试命令**，
这样"失败"就从"她感觉不对劲但说不清"变成"她看到一行字，照着敲一下"。

设计要点：
    1. 只记"她可能需要知道"的失败，不记"程序内部自己消化了"的正常分支
    2. 同一种失败（kind + summary 相同）重复出现时只累加次数，不刷屏
    3. 成功的重试要能把它标记为已解决
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from . import ui

KIND_LABELS = {
    "search": "B 站搜索",
    "summarize": "视频总结",
    "plugin": "插件",
    "import": "导入",
    "notify": "提醒推送",
    "other": "其他",
}


@dataclass
class Failure:
    id: int
    kind: str
    summary: str
    detail: str = ""
    retry: str = ""
    attempts: int = 1
    state: str = "open"          # open / resolved / given_up
    created_at: str = ""
    updated_at: str = ""

    @property
    def kind_label(self) -> str:
        return KIND_LABELS.get(self.kind, self.kind)

    def is_open(self) -> bool:
        return self.state == "open"


# --------------------------------------------------------------------------
# 记录与查询（都挂在 Store 上，和程序其他数据同一个库）
# --------------------------------------------------------------------------

def record(store, kind: str, summary: str, *, detail: str = "",
           retry: str = "") -> int:
    """记一条失败。同 kind + summary 的未解决记录只累加次数。

    返回记录 id。
    """
    summary = (summary or "").strip()[:200]
    if not summary:
        summary = "（未说明原因）"
    detail = (detail or "").strip()[:4000]
    retry = (retry or "").strip()[:300]
    now = datetime.now().isoformat(timespec="seconds")

    existing = store.conn.execute(
        "SELECT id, attempts FROM failures WHERE kind = ? AND summary = ? AND state = 'open'"
        " ORDER BY id DESC LIMIT 1",
        (kind, summary),
    ).fetchone()
    if existing:
        store.conn.execute(
            "UPDATE failures SET attempts = attempts + 1, detail = ?, updated_at = ?"
            " WHERE id = ?",
            (detail or None or "", now, existing["id"]),
        )
        store.conn.commit()
        return int(existing["id"])

    cur = store.conn.execute(
        """INSERT INTO failures(kind, summary, detail, retry, attempts, state,
                                created_at, updated_at)
           VALUES(?,?,?,?,1,'open',?,?)""",
        (kind, summary, detail, retry, now, now),
    )
    store.conn.commit()
    return int(cur.lastrowid)


def _row_to_failure(row) -> Failure:
    return Failure(
        id=int(row["id"]), kind=row["kind"], summary=row["summary"],
        detail=row["detail"] or "", retry=row["retry"] or "",
        attempts=int(row["attempts"] or 1), state=row["state"],
        created_at=row["created_at"] or "", updated_at=row["updated_at"] or "",
    )


def open_failures(store, *, limit: int = 50) -> list[Failure]:
    rows = store.conn.execute(
        "SELECT * FROM failures WHERE state = 'open' ORDER BY updated_at DESC LIMIT ?",
        (limit,),
    )
    return [_row_to_failure(r) for r in rows]


def all_failures(store, *, limit: int = 100) -> list[Failure]:
    rows = store.conn.execute(
        "SELECT * FROM failures ORDER BY updated_at DESC LIMIT ?", (limit,)
    )
    return [_row_to_failure(r) for r in rows]


def resolve(store, failure_id: int) -> bool:
    now = datetime.now().isoformat(timespec="seconds")
    cur = store.conn.execute(
        "UPDATE failures SET state = 'resolved', updated_at = ? WHERE id = ?",
        (now, failure_id),
    )
    store.conn.commit()
    return cur.rowcount > 0


def resolve_kind(store, kind: str) -> int:
    """某类失败全部标记为已解决（比如这次搜索成功了）。返回处理了几条。"""
    now = datetime.now().isoformat(timespec="seconds")
    cur = store.conn.execute(
        "UPDATE failures SET state = 'resolved', updated_at = ?"
        " WHERE kind = ? AND state = 'open'",
        (now, kind),
    )
    store.conn.commit()
    return cur.rowcount


def clear(store) -> int:
    cur = store.conn.execute("DELETE FROM failures")
    store.conn.commit()
    return cur.rowcount


def count_open(store) -> int:
    row = store.conn.execute(
        "SELECT COUNT(*) AS n FROM failures WHERE state = 'open'"
    ).fetchone()
    return int(row["n"]) if row else 0


# --------------------------------------------------------------------------
# 展示
# --------------------------------------------------------------------------

def render_list(store, *, include_resolved: bool = False) -> list[str]:
    items = all_failures(store) if include_resolved else open_failures(store)
    if not items:
        return [ui.c("没有未解决的问题。", "brightgreen")]

    lines: list[str] = []
    for item in items:
        if item.state == "resolved":
            mark = ui.c("✓", "brightgreen")
        elif item.attempts >= 3:
            mark = ui.c("‼", "red")
        else:
            mark = ui.c("!", "gold")
        head = (f"{mark} " + ui.c(ui.pad(f"#{item.id}", 5), "grey")
                + ui.c(ui.pad(item.kind_label, 10), "plum")
                + item.summary)
        lines.append(head)
        if item.attempts > 1:
            lines.append("    " + ui.c(f"出现过 {item.attempts} 次", "grey")
                         + ui.c(f"    最近 {item.updated_at[:16].replace('T', ' ')}", "grey"))
        if item.detail:
            for piece in item.detail.splitlines()[:3]:
                lines.append("    " + ui.c(piece[:100], "grey"))
        if item.retry and item.state == "open":
            lines.append("    " + ui.c("重试：", "grey") + ui.c(item.retry, "hotpink"))
        lines.append("")
    while lines and not lines[-1]:
        lines.pop()
    return lines


def _selftest() -> None:
    from ._testutil import temp_home
    from .db import Store
    from .config import Config

    ui.use_color(False)
    with temp_home(".selftest-failures") as home:
        store = Store(":memory:")
        _ = Config(home=home)

        # 记录
        fid = record(store, "search", "B 站搜索没拿到结果", retry="her search dp")
        assert fid > 0
        assert count_open(store) == 1

        # 同 kind+summary 只累加次数
        again = record(store, "search", "B 站搜索没拿到结果")
        assert again == fid, "同一种失败应该合并"
        assert open_failures(store)[0].attempts == 2

        # 不同 kind 算两条
        record(store, "summarize", "总结只有转写没有笔记",
               detail="llm_enabled=false", retry="her video status")
        assert count_open(store) == 2

        # 分类筛选
        assert resolve_kind(store, "search") == 1
        assert count_open(store) == 1, count_open(store)
        assert len(open_failures(store)) == 1

        # 单条解决
        assert resolve(store, open_failures(store)[0].id)
        assert count_open(store) == 0
        assert "没有未解决" in ui._strip_ansi(render_list(store)[0])

        # resolved 也要能查出来
        assert len(all_failures(store)) == 2
        lines = render_list(store, include_resolved=True)
        assert any("✓" in ui._strip_ansi(l) for l in lines)

        # detail 的展示
        record(store, "import", "解析不出题目", detail="第 3 行格式不认识\n第 7 行也是")
        lines = render_list(store)
        joined = ui._strip_ansi("\n".join(lines))
        assert "第 3 行" in joined and "第 7 行" in joined

        # 重复多次要有"‼"提示
        for _ in range(3):
            record(store, "plugin", "坏插件加载失败")
        lines = ui._strip_ansi("\n".join(render_list(store)))
        assert "‼" in lines or "出现过 4 次" in lines, lines

        # 清空
        assert clear(store) >= 1
        assert count_open(store) == 0
        store.close()

    print("failures selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
