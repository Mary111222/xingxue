"""头像处理：校验、压缩成 data URL、安全渲染。

**为什么需要专门一个模块做校验**，而不是直接存前端传来的字符串：

    头像会被塞进 <img src="...">，也会被写进 config.json。
    如果照单全收，有两个真实风险：

    1. **SVG 能执行脚本**。`<svg onload="fetch('/api/...')">` 作为图片是合法 SVG，
       浏览器打开它就会跑脚本——这是存储型 XSS。所以 SVG 一律拒收。
    2. **前端说的 content-type 不算数**。真正的格式要看文件头那几个字节
       （magic bytes）。只看 MIME 的话，改个扩展名或者伪造一下就能塞任意数据进来。

    另外还要防"用一张 50MB 的图把 config.json 撑爆"。

所以这里的做法：
    - 用**文件头**判断真实格式，只放行 PNG / JPEG / GIF / WebP / BMP
    - 明确拒绝 SVG（并说明原因，不是一句"格式不对"）
    - 体积上限 2 MB，超了明确报错
    - 只在确认是图片之后才拼 data URL
"""

from __future__ import annotations

import base64
import binascii
import re

# 2 MB。够放一张清晰的证件照或头像，又不会把 config.json 撑得没法看。
# （data URL 是 base64，实际占 config 里约 2.7 MB）
MAX_BYTES = 2 * 1024 * 1024

# 文件头 → 格式名。顺序无关，每个都是"开头这几个字节就确定"的。
_SIGNATURES: list[tuple[bytes, str, str]] = [
    (b"\x89PNG\r\n\x1a\n", "image/png", "PNG"),
    (b"\xff\xd8\xff", "image/jpeg", "JPEG"),
    (b"GIF87a", "image/gif", "GIF"),
    (b"GIF89a", "image/gif", "GIF"),
    (b"BM", "image/bmp", "BMP"),
]

_DATA_URL_RE = re.compile(r"^data:([\w.+-]+/[\w.+-]+);base64,(.+)$", re.S | re.I)


class AvatarError(ValueError):
    """头像有问题（格式不对、太大、SVG 被拒…）。消息直接给她看，要写清楚。"""


def sniff(data: bytes) -> str:
    """按文件头判断真实图片格式。认不出来返回空串。"""
    for magic, mime, _name in _SIGNATURES:
        if data.startswith(magic):
            return mime
    # WebP: RIFF....WEBP
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return ""


def looks_like_svg(data: bytes) -> bool:
    """判断是不是 SVG。

    SVG 是唯一能执行脚本的图片格式，必须单独识别出来给一个明确的拒绝理由——
    只说"格式不支持"她会以为是我们没做这个功能。
    """
    head = data[:1024].lstrip(b"\xef\xbb\xbf").lstrip()
    low = head.lower()
    return low.startswith(b"<svg") or (low.startswith(b"<?xml") and b"<svg" in low[:1024])


def _decode_payload(payload: str) -> bytes:
    """把 base64 部分解码成字节。"""
    raw = (payload or "").strip()
    if not raw:
        raise AvatarError("图片内容是空的")
    # 有些导出工具会带换行
    raw = re.sub(r"\s+", "", raw)
    # 补上省略的 padding（有些实现会去掉 = ）
    pad = len(raw) % 4
    if pad:
        raw += "=" * (4 - pad)
    try:
        return base64.b64decode(raw, validate=False)
    except (binascii.Error, ValueError) as exc:
        raise AvatarError("图片数据坏了（base64 解不开）") from exc


def normalize(data_url: str) -> str:
    """校验并规整成可以安全使用的 data URL。

    接受 data URL 字符串；返回规整后的 data URL。
    任何不合格的情况抛 AvatarError，消息可以直接展示给她。
    """
    text = (data_url or "").strip()
    if not text:
        raise AvatarError("没有收到图片")

    # 允许直接传纯 base64（某些前端实现会这样）
    if not text.startswith("data:"):
        text = "data:image/png;base64," + text

    match = _DATA_URL_RE.match(text)
    if not match:
        raise AvatarError("图片格式不认识（要 data:image/...;base64,... 这种）")
    declared, payload = match.group(1).lower(), match.group(2)

    blob = _decode_payload(payload)

    if looks_like_svg(blob):
        raise AvatarError(
            "SVG 头像不能用：SVG 里可以藏脚本，会有安全问题。"
            "换成 PNG 或 JPG 吧（截图、微信保存的图片都是）。"
        )

    real = sniff(blob)
    if not real:
        raise AvatarError(
            "这不是一张能识别的图片。支持 PNG / JPG / GIF / WebP / BMP。"
        )

    if len(blob) > MAX_BYTES:
        mb = len(blob) / 1024 / 1024
        raise AvatarError(
            f"图片太大了（{mb:.1f} MB），上限是 {MAX_BYTES // 1024 // 1024} MB。"
            "先用画图或手机相册裁小一点再传。"
        )

    # 用**嗅探出来的**类型，不用她声明的类型
    encoded = base64.b64encode(blob).decode("ascii")
    return f"data:{real};base64,{encoded}"


def is_safe(data_url: str) -> bool:
    """判断一个已存的 data URL 能不能安全地放进 <img src>。

    渲染时用这个再过滤一遍：老配置里可能存着别的版本写进去的东西，
    不能假设"存的就一定干净"。
    """
    text = (data_url or "").strip()
    if not text.startswith("data:image/"):
        return False
    match = _DATA_URL_RE.match(text)
    if not match:
        return False
    mime = match.group(1).lower()
    # 明确挡掉 svg+xml 和任何 xml 类型
    if "svg" in mime or "xml" in mime:
        return False
    if mime not in ("image/png", "image/jpeg", "image/gif",
                    "image/webp", "image/bmp"):
        return False
    try:
        blob = _decode_payload(match.group(2))
    except AvatarError:
        return False
    if looks_like_svg(blob):
        return False
    return len(blob) <= MAX_BYTES


def describe(data_url: str) -> dict:
    """给界面用的信息：有没有头像、什么格式、多大。"""
    if not is_safe(data_url):
        return {"has_avatar": False, "format": "", "bytes": 0, "kb": 0}
    match = _DATA_URL_RE.match(data_url.strip())
    blob = _decode_payload(match.group(2)) if match else b""
    return {
        "has_avatar": True,
        "format": sniff(blob).replace("image/", "").upper() or "?",
        "bytes": len(blob),
        "kb": round(len(blob) / 1024, 1),
    }


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    import base64 as b64

    # 造一张最小的合法 PNG（1x1）
    png = b64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
    )

    # ---- 正常放行 ----
    out = normalize("data:image/png;base64," + b64.b64encode(png).decode())
    assert out.startswith("data:image/png;base64,"), out[:40]
    assert describe(out)["has_avatar"] is True
    assert describe(out)["format"] == "PNG"
    assert describe(out)["bytes"] == len(png)

    # 纯 base64（不带 data: 前缀）也要能处理
    assert normalize(b64.b64encode(png).decode()).startswith("data:image/png;")

    # 带换行的 base64
    b64wrapped = b64.b64encode(png).decode()
    wrapped = "\n".join(b64wrapped[i:i + 40] for i in range(0, len(b64wrapped), 40))
    assert normalize("data:image/png;base64," + wrapped).startswith("data:image/png;")

    # ---- 声明的类型不算数，按文件头来 ----
    # 她声明成 jpeg，实际是 png → 要按 png 存（否则浏览器可能不认）
    sneaky = normalize("data:image/jpeg;base64," + b64.b64encode(png).decode())
    assert sneaky.startswith("data:image/png;"), "应该按真实文件头判定"

    # ---- SVG 必须拒绝，而且理由要说清 ----
    svg = b'<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"></svg>'
    try:
        normalize("data:image/svg+xml;base64," + b64.b64encode(svg).decode())
        raise AssertionError("SVG 应该被拒绝")
    except AvatarError as exc:
        assert "SVG" in str(exc), f"拒绝理由应该提到 SVG：{exc}"

    # 伪装成 png 的 SVG 也要挡住
    try:
        normalize("data:image/png;base64," + b64.b64encode(svg).decode())
        raise AssertionError("伪装成 png 的 SVG 应该被拒绝")
    except AvatarError as exc:
        assert "SVG" in str(exc), exc
    # <?xml 开头的 svg
    xmlsvg = b'<?xml version="1.0"?>\n<svg xmlns="http://www.w3.org/2000/svg"></svg>'
    assert looks_like_svg(xmlsvg), "<?xml 开头的 svg 要能识别"

    # ---- 不是图片的二进制要拒绝 ----
    for junk, label in [(b"hello world this is not an image", "纯文本"),
                        (b"PK\x03\x04zipfile", "zip"),
                        (b"\x7fELF\x02\x01\x01", "ELF")]:
        try:
            normalize("data:image/png;base64," + b64.b64encode(junk).decode())
            raise AssertionError(f"{label} 应该被拒绝")
        except AvatarError:
            pass

    # ---- 空 / 坏 base64 ----
    for bad, label in [("", "空串"), ("   ", "空白"), ("data:image/png;base64,", "只有前缀"),
                       ("data:image/png;base64,!!!!", "坏 base64"),
                       ("随便一段中文", "瞎写")]:
        try:
            normalize(bad)
            raise AssertionError(f"{label} 应该被拒绝")
        except AvatarError:
            pass

    # ---- 超过体积上限 ----
    big = png + b"\x00" * (MAX_BYTES + 1024)
    # 注意：加零之后文件头还是 PNG，所以要能靠体积挡下来
    try:
        normalize("data:image/png;base64," + b64.b64encode(big).decode())
        raise AssertionError("超大图片应该被拒绝")
    except AvatarError as exc:
        assert "太大" in str(exc), exc

    # ---- is_safe 作为渲染前的第二道关 ----
    assert is_safe(out) is True
    assert is_safe("") is False
    assert is_safe("data:image/svg+xml;base64," + b64.b64encode(svg).decode()) is False
    assert is_safe("javascript:alert(1)") is False
    assert is_safe("http://example.com/x.png") is False
    assert is_safe("data:text/html;base64," + b64.b64encode(b"<b>x</b>").decode()) is False
    # 声明成 png 但内容是 SVG → is_safe 也要挡住
    assert is_safe("data:image/png;base64," + b64.b64encode(svg).decode()) is False

    # ---- describe 对空头像不炸 ----
    d = describe("")
    assert d["has_avatar"] is False and d["kb"] == 0

    # ---- WebP / GIF / BMP 的文件头识别 ----
    assert sniff(b"RIFF\x00\x00\x00\x00WEBPVP8 ") == "image/webp"
    assert sniff(b"GIF89a....") == "image/gif"
    assert sniff(b"BM......") == "image/bmp"
    assert sniff(b"\xff\xd8\xff\xe0....") == "image/jpeg"
    assert sniff(b"nonsense") == ""

    print("avatar selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
