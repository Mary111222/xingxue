"""鼓励语与心情文案。

设计上刻意避开两类话：
    1. **空洞打气**（"加油！你最棒！"）——看两次就免疫了，甚至有点烦
    2. **贩卖焦虑**（"今天不学明天就落后"）——她已经被课程和考试压着了，
       程序不该再推一把

留下来的是这三类：
    - 承认"记不住是正常的"（这是间隔重复的心理学前提，说破了她才不焦虑）
    - 具体的、可执行的一句话（"讲给空气听一遍"比"好好学习"有用）
    - 一点点属于她自己的东西（生日、认识的日期、名字）

用法：
    pick("praise", seed)      同一天同一类拿到同一句（不会一刷新就跳）
    random_one("home")        真随机（她主动点"再来一句"时用）
    for_context("review")     按场景取一类的随机一句
"""

from __future__ import annotations

import hashlib
import random as _random
from datetime import date

# --------------------------------------------------------------------------
# 语料
# --------------------------------------------------------------------------

MESSAGES: dict[str, list[str]] = {
    # 首页顶部：每天固定一句
    "home": [
        "今天也一起把不会的题变会吧。",
        "不求多，今天弄懂一道就够本了。",
        "刷题不是比谁快，是比谁还在。",
        "你上次卡住的那道题，今天可能就通了。",
        "先做最容易的那道，热起来再说。",
        "忘了不丢人，忘了不复盘才可惜。",
        "一天一道，一学期就是一百多道。",
        "慢慢来，比较快。",
        "今天的你只需要比昨天多记住一点。",
        "把不会的挑出来，就是今天最大的收获。",
        "别急着刷量，先把错的那些吃透。",
        "状态不好就少做两道，别断。",
    ],

    # 评分为 3-5：答对了
    "praise": [
        "这题你拿下了。",
        "记住的感觉很好，对吧。",
        "又多一道以后不用怕的题。",
        "看，昨天觉得难的，今天会了。",
        "稳。下一道。",
        "这道题以后是你的了。",
        "写出来的才算真的会——你刚刚写出来了。",
        "这种题再来十道也不慌了吧。",
        "进步就是这么一点点攒的。",
        "答题的手感在回来。",
    ],

    # 评分为 0-2：忘了
    "comfort": [
        "忘了很正常，大脑就是这么设计的。",
        "这次忘，是为了第三次记住。",
        "间隔重复本来就要错几次，别自责。",
        "没关系，它明天还会来找你。",
        "第一次见面的题，忘了不亏。",
        "错了说明它值得多来几遍，不是你的问题。",
        "现在补上，比考场上想起来强。",
        "卡住的地方，往往就是最该学的地方。",
        "再来一次就好，真的。",
        "记不住不是笨，是还没见够面。",
    ],

    # 做完一整轮
    "done": [
        "这一轮清完了，去喝口水。",
        "今天的任务完成了，剩下的时间是你的。",
        "坚持这件事，你已经比很多人做得好了。",
        "收工。明天见。",
        "做得不错，别急着开下一轮。",
        "完成比完美重要，你今天完成了。",
    ],

    # 深夜（22 点后）
    "latenight": [
        "这么晚了还在看题，佩服。但也别熬太久。",
        "夜深了，记住一道就收吧，睡眠也影响记忆。",
        "熬夜背的东西，第二天容易还回去。差不多就睡。",
        "现在这一道，抵不上明天清醒时的三道。早点休息。",
    ],

    # 摸一摸符号喵喵
    "pet": [
        "喵～（蹭了蹭你的手）",
        "喵！（尾巴翘起来了）",
        "呼噜呼噜……（眯起眼睛）",
        "喵呜～今天也辛苦了。",
        "（翻了个身，露出肚皮）",
        "喵？还要摸吗？那就再摸一下。",
        "（用头蹭你的手腕）继续做题吧，我在这儿。",
        "喵～接猫花掉了我一个月工资，你可要对我好一点。",
        "（叼来一支笔放在你手边）",
        "喵喵！（好像是在说「你可以的」）",
    ],

    # 生日当天
    "birthday": [
        "生日快乐！今天的题可以少做两道。",
        "生日快乐呀，又长大一岁了。",
        "今天是你的日子，许个愿吧。",
        "生日快乐！符号喵喵给你唱一首（喵喵版）。",
    ],

    # B 站搜索页
    "search": [
        "看不懂就搜，搜完再回来看题，别硬扛。",
        "先看知识点讲解，再看题解——顺序反了容易抄答案。",
        "找个讲得清楚的 UP 主，比刷十道题有用。",
        "看完记得回来自己写一遍，不然等于没看。",
    ],

    # 题库页
    "bank": [
        "题目不用多，覆盖到知识点就行。",
        "标签写对了，统计才准，才知道自己虚在哪。",
        "每道题至少写一句关键思路，复习时你会感谢现在的自己。",
    ],

    # 视频总结页
    "video": [
        "总结出来的东西要写回题里，否则看完就散了。",
        "可信度只是告诉你边界在哪，不代表失败。",
    ],

    # 成绩单
    "stats": [
        "间隔短的标签就是你的短板，优先补那几个。",
        "别只看总数，看「已掌握」有多少。",
        "热力图有断档没关系，今天接上就行。",
    ],

    # 空状态
    "empty": [
        "这里还是空的，慢慢来。",
        "先加点题，别的都会有的。",
    ],
}


CONTEXT_TO_KIND = {
    "home": "home",
    "review": "home",
    "praise": "praise",
    "comfort": "comfort",
    "done": "done",
    "latenight": "latenight",
    "pet": "pet",
    "birthday": "birthday",
    "search": "search",
    "bank": "bank",
    "video": "video",
    "stats": "stats",
    "empty": "empty",
}


# --------------------------------------------------------------------------
# 取用
# --------------------------------------------------------------------------

def _seed_of(*parts) -> int:
    text = "|".join(str(p) for p in parts)
    return int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:8], 16)


def pick(kind: str, *seed_parts) -> str:
    """按种子取一句：同一天同一类永远是同一句。

    为什么不用纯随机：
        首页每刷新一次就换一句话，看起来像在抽奖，反而不像"对我说的话"。
        固定下来她才会有"今天这句是给我的"这种感觉。
        真随机留给 pet / 主动点按钮那两种场景。
    """
    pool = MESSAGES.get(kind) or MESSAGES["home"]
    if not pool:
        return ""
    index = _seed_of(kind, *seed_parts) % len(pool)
    return pool[index]


def random_one(kind: str = "home") -> str:
    """真随机取一句（她主动要"再来一句"时用）。"""
    pool = MESSAGES.get(kind) or MESSAGES["home"]
    return _random.choice(pool) if pool else ""


def for_context(context: str, *seed_parts) -> str:
    return pick(CONTEXT_TO_KIND.get(context, "home"), *seed_parts)


def suitable_for_now(today: date, hour: int, *,
                     is_birthday: bool = False,
                     due_count: int = 0,
                     finished: bool = False) -> tuple[str, str]:
    """按当前处境挑一句最合适的。返回 (类型, 文案)。

    优先级是有道理的：生日 > 刚做完 > 深夜 > 有题待复习 > 默认。
    生日一年只有一天，任何情况下都该让它先说话。
    """
    if is_birthday:
        return "birthday", random_one("birthday")
    if finished:
        return "done", random_one("done")
    if hour >= 22 or hour < 5:
        return "latenight", random_one("latenight")
    if due_count == 0:
        return "done", random_one("done")
    return "home", pick("home", today.isoformat())


def all_kinds() -> list[str]:
    return sorted(MESSAGES)


def counts() -> dict[str, int]:
    return {k: len(v) for k, v in MESSAGES.items()}


# --------------------------------------------------------------------------
# 自测
# --------------------------------------------------------------------------

def _selftest() -> None:
    # 每一类都要有内容，不能有空列表（空列表会在界面上显示成空白）
    for kind, pool in MESSAGES.items():
        assert pool, f"{kind} 是空的"
        for line in pool:
            assert line.strip(), f"{kind} 里有空行"
            assert len(line) <= 60, f"{kind} 里这句太长（{len(line)} 字）：{line}"

    # 同类多次取，结果必须一致（否则首页一刷新就换话）
    a = pick("home", "2026-10-04")
    b = pick("home", "2026-10-04")
    assert a == b, "同一种子应该拿到同一句"
    # 不同天应该（大概率）不同
    seen = {pick("home", f"2026-10-{d:02d}") for d in range(1, 29)}
    assert len(seen) >= 6, f"28 天里只出现了 {len(seen)} 句，分布太集中"

    # 每句都要真的在语料里
    assert a in MESSAGES["home"]

    # 随机取也要在语料里
    for _ in range(30):
        assert random_one("pet") in MESSAGES["pet"]

    # 分类都要能取到
    for kind in all_kinds():
        assert pick(kind, "x") in MESSAGES[kind], kind
        assert for_context(kind, "x") in MESSAGES[kind], kind

    # 未知类要能兜底，不能抛异常
    assert pick("不存在的类", "x") in MESSAGES["home"]
    assert random_one("不存在的类") in MESSAGES["home"]

    # suitable_for_now 的优先级
    today = date(2026, 10, 18)
    kind, line = suitable_for_now(today, 14, is_birthday=True, due_count=5)
    assert kind == "birthday" and line in MESSAGES["birthday"]
    kind, line = suitable_for_now(today, 14, due_count=5)
    assert kind == "home" and line in MESSAGES["home"]
    kind, line = suitable_for_now(today, 14, due_count=0)
    assert kind == "done", kind
    kind, line = suitable_for_now(today, 23, due_count=5)
    assert kind == "latenight", kind
    kind, line = suitable_for_now(today, 3, due_count=5)
    assert kind == "latenight", kind
    kind, _ = suitable_for_now(today, 14, finished=True, due_count=5)
    assert kind == "done", kind

    # 生日优先级最高（即使在深夜、即使做完了）
    kind, _ = suitable_for_now(today, 23, is_birthday=True, finished=True)
    assert kind == "birthday", kind

    # 数量要够，不然很快重复
    assert counts()["praise"] >= 8
    assert counts()["comfort"] >= 8

    print(f"encouragement selftest: 全部断言通过 ✓（{sum(counts().values())} 句语料）")


if __name__ == "__main__":
    _selftest()
