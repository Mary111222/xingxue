"""备份与恢复。

## 为什么必须有

她的数据**只有一份**：`data.sqlite3`（题目、复习记录、便签、歌单…）
+ `config.json`（设置、头像）+ `cookies/`（B 站登录）。
磁盘坏了、误删了、迁移失败——任何一个都够她哭一次。

## 怎么做

    每天**首次启动**自动打一份 zip（`备份/形学-YYYYMMDD-HHMM.zip`）
    只留最近 KEEP 份，老的自己删
    `data.sqlite3` 用 **sqlite3 的 backup API** 导出
      —— 直接复制文件在 WAL 模式下可能拿到不一致的快照
    恢复之前**先把当前状态也打一份**（`恢复前-…zip`），
      万一恢复错了还能退回来

备份里**不放**：`.app-window`（WebView2 缓存，几百 MB）、`cache`、
`备份` 自己（不然越滚越大）、日志。
"""
from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

DIRNAME = "备份"
KEEP = 7                     # 只留最近 7 份
_SKIP_DIRS = {".app-window", "cache", DIRNAME}


def backup_root(home: Path) -> Path:
    return Path(home) / DIRNAME


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _zip_one(zf: zipfile.ZipFile, path: Path, arcname: str) -> None:
    """把一件东西写进 zip。sqlite 走 backup API，别的直接写。"""
    if path.suffix == ".sqlite3":
        # **不要直接 copy**：WAL 模式下拷到的可能是半个事务。
        # sqlite3 的 backup() 会拿到一致快照。
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td) / path.name
            src = sqlite3.connect(str(path))
            try:
                dst = sqlite3.connect(str(tmp))
                try:
                    src.backup(dst)
                finally:
                    dst.close()
            finally:
                src.close()
            zf.write(tmp, arcname)
        return
    zf.write(path, arcname)


def make_backup(home: Path, note: str = "", prefix: str = "形学") -> dict:
    """打一份备份。返回 {ok, name, bytes, files}。"""
    home = Path(home)
    root = backup_root(home)
    root.mkdir(parents=True, exist_ok=True)
    name = f"{prefix}-{_stamp()}.zip" if not note else f"{prefix}-{_stamp()}-{note}.zip"
    out = root / name
    count = 0
    try:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for item in sorted(home.iterdir()):
                if item.name in _SKIP_DIRS:
                    continue
                if item.is_file() and item.suffix in (".log", ".pid"):
                    continue
                if item.is_dir():
                    for sub in sorted(item.rglob("*")):
                        if sub.is_dir() or any(p in _SKIP_DIRS for p in sub.parts):
                            continue
                        _zip_one(zf, sub, str(sub.relative_to(home)).replace("\\", "/"))
                        count += 1
                elif item.is_file():
                    _zip_one(zf, item, item.name)
                    count += 1
    except Exception as exc:
        out.unlink(missing_ok=True)
        return {"ok": False, "error": f"备份没做成：{exc.__class__.__name__}: {exc}"}
    return {"ok": True, "name": name, "bytes": out.stat().st_size, "files": count,
            "at": datetime.now().isoformat(timespec="seconds")}


def list_backups(home: Path) -> list[dict]:
    root = backup_root(home)
    if not root.is_dir():
        return []
    items = []
    for p in sorted(root.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True):
        st = p.stat()
        items.append({
            "name": p.name,
            "bytes": st.st_size,
            "kb": round(st.st_size / 1024, 1),
            "at": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
            "before_restore": "恢复前" in p.name,
        })
    return items


def prune(home: Path, keep: int = KEEP) -> int:
    """只留最近 keep 份（"恢复前"的也一起算，它们是救命的）。"""
    root = backup_root(home)
    if not root.is_dir():
        return 0
    files = sorted(root.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)
    n = 0
    for p in files[keep:]:
        try:
            p.unlink()
            n += 1
        except OSError:
            pass
    return n


def maybe_daily(home: Path) -> dict | None:
    """今天还没备份就做一份。**每天首次启动**调它。

    返回 None 表示"今天已经有过了"。
    """
    home = Path(home)
    today = datetime.now().strftime("%Y%m%d")
    if backup_root(home).is_dir():
        if any(today in p.name for p in backup_root(home).glob("*.zip")):
            return None
    data = make_backup(home, prefix="每日")
    prune(home)
    return data


def restore(home: Path, name: str) -> dict:
    """从某份备份恢复。

    **先把当前状态也打一份**（`恢复前-…`）——恢复错了还能退回来。
    只覆盖备份里有的文件；备份里没有的（比如她后来新加的目录）不动。
    """
    home = Path(home)
    src = backup_root(home) / name
    if not src.is_file():
        return {"ok": False, "error": "找不到这份备份"}
    safety = make_backup(home, prefix="恢复前")
    try:
        with zipfile.ZipFile(src) as zf:
            bad = zf.testzip()
            if bad is not None:
                return {"ok": False, "error": f"这份备份坏了（{bad} 解不开）"}
            zf.extractall(home)
            names = zf.namelist()
    except Exception as exc:
        return {"ok": False, "error": f"恢复失败：{exc.__class__.__name__}: {exc}"}
    return {"ok": True, "restored": len(names), "from": name,
            "safety": safety.get("name", ""),
            "note": "已经恢复了。要退回刚才那一版，就用「恢复前」那份。"}


def _selftest() -> None:
    """自测：造一个假数据目录，备份 → 改坏 → 恢复 → 看有没有复原。"""
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        home = Path(td)
        (home / "config.json").write_text('{"name":"测试"}', encoding="utf-8")
        db = sqlite3.connect(str(home / "data.sqlite3"))
        db.execute("CREATE TABLE t (x TEXT)")
        db.execute("INSERT INTO t VALUES ('原来的')")
        db.commit()
        db.close()
        (home / "cookies").mkdir()
        (home / "cookies" / "bilibili.txt").write_text("cookie", encoding="utf-8")

        made = make_backup(home, prefix="测试")
        assert made["ok"], made
        assert made["files"] >= 3, made
        assert list_backups(home), "列不出备份"

        # 改坏：
        (home / "config.json").write_text('{"name":"被改了"}', encoding="utf-8")
        db = sqlite3.connect(str(home / "data.sqlite3"))
        db.execute("UPDATE t SET x = '被改了'")
        db.commit()
        db.close()
        (home / "cookies" / "bilibili.txt").unlink()

        got = restore(home, made["name"])
        assert got["ok"], got
        assert json.loads((home / "config.json").read_text(encoding="utf-8"))["name"] == "测试"
        db = sqlite3.connect(str(home / "data.sqlite3"))
        assert db.execute("SELECT x FROM t").fetchone()[0] == "原来的"
        db.close()
        assert (home / "cookies" / "bilibili.txt").is_file(), "cookies 没恢复"
        # 恢复前那份安全备份要存在
        assert any("恢复前" in b["name"] for b in list_backups(home)), "没有安全备份"
        print("backup selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
