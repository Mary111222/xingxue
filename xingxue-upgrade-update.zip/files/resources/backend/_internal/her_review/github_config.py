"""构建时自动生成（scripts/build_backend.py），不要手改。只存 GitHub 仓库信息，不存 token。"""
OWNER = 'Mary111222'
REPO = 'xingxue'
BRANCH = 'upgrade-channel'
ASSET_NAME = 'xingxue-upgrade-update.zip'
