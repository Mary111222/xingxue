"""可选依赖的探测与降级。

设计原则（这是整个升级里最重要的一条）：
    **每一个库都是可选增强，不是运行前提。**
    装上 rich → 视频笔记用真 Markdown 渲染、搜索结果变表格、总结时有进度条；
    没装 → 退回自带渲染，功能一个不少，只是朴素一点。

为什么坚持这个原则：
    1. 她换台电脑、或者环境没配好，程序不能就打不开了
    2. 送礼物的程序「第一次双击就报 ModuleNotFoundError」是最糟的体验
    3. 顺带保住了「零依赖也能跑」这个基本盘

用法：
    from .deps import RICH, console, md_render
    if RICH: ...   # 增强路径
"""

from __future__ import annotations

import importlib
import importlib.util
import os
import sys
import time
from pathlib import Path
from typing import Any

# --------------------------------------------------------------------------
# 本地库目录（bootstrap.py 装到这里，程序启动时自动加进 sys.path）
# --------------------------------------------------------------------------

LOCAL_LIBS_DIR = ".pylibs"
LOCAL_LIBS_FILE = "pylibs.local.json"  # 记录装了什么、什么版本


def local_libs_path() -> Path:
    """.pylibs 放在程序目录下（和 her_review 同级）。"""
    return Path(__file__).resolve().parent.parent / LOCAL_LIBS_DIR


def activate_local_libs() -> bool:
    """把 .pylibs 加进 sys.path。返回是否真的加了。"""
    target = local_libs_path()
    if not target.is_dir():
        return False
    entry = str(target)
    if entry not in sys.path:
        sys.path.insert(0, entry)
    return True


def installed_versions() -> dict[str, str]:
    """读 pylibs.local.json，看 bootstrap 装过什么。"""
    import json

    marker = Path(__file__).resolve().parent.parent / LOCAL_LIBS_FILE
    if not marker.exists():
        return {}
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    libs = payload.get("libs")
    return libs if isinstance(libs, dict) else {}


# --------------------------------------------------------------------------
# 探测
# --------------------------------------------------------------------------

def available(module: str) -> bool:
    """模块能不能 import（找到 spec 就算）。"""
    try:
        return importlib.util.find_spec(module) is not None
    except (ImportError, ValueError):
        return False


def _try_import(module: str) -> Any:
    try:
        return importlib.import_module(module)
    except Exception:  # 装了但坏了也不能崩
        return None


# --------------------------------------------------------------------------
# rich：终端渲染增强
# --------------------------------------------------------------------------

def _enable_windows_ansi_early() -> None:
    """rich 自己会处理，但我们在它之前也可能画东西，先开一次。"""
    if os.name != "nt":
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


RICH = available("rich")
_CONSOLE: Any = None


def console():
    """拿一个共享的 rich Console（拿不到就返回 None）。"""
    global _CONSOLE
    if _CONSOLE is not None:
        return _CONSOLE
    if not RICH:
        return None
    _enable_windows_ansi_early()
    module = _try_import("rich.console")
    if module is None:
        return None
    try:
        # force_terminal=None 让 rich 自己判断；软换行关掉，避免破坏我们的布局
        _CONSOLE = module.Console(soft_wrap=False, highlight=False, emoji=True)
    except Exception:
        return None
    return _CONSOLE


def rich_ready() -> bool:
    return RICH and _try_import("rich.console") is not None


# --------------------------------------------------------------------------
# 渲染能力
# --------------------------------------------------------------------------

def md_render(text: str) -> bool:
    """用 rich 渲染 Markdown。成功返回 True，调用方据此决定要不要走降级路径。"""
    con = console()
    if con is None:
        return False
    module = _try_import("rich.markdown")
    if module is None:
        return False
    try:
        con.print(module.Markdown(text, hyperlinks=True))
        return True
    except Exception:
        return False


def table(columns: list[str], rows: list[list[str]], *, title: str = "",
          caption: str = "") -> bool:
    """用 rich 画表格。成功返回 True。"""
    con = console()
    if con is None:
        return False
    module = _try_import("rich.table")
    if module is None:
        return False
    try:
        tbl = module.Table(title=title or None, caption=caption or None,
                           header_style="bold magenta", box=module.box.ROUNDED,
                           show_lines=False, expand=False)
        for col in columns:
            tbl.add_column(col, overflow="fold")
        for row in rows:
            tbl.add_row(*row)
        con.print(tbl)
        return True
    except Exception:
        return False


def syntax(code: str, language: str = "python") -> bool:
    """语法高亮打印一段代码（她复习题解时会用得上）。"""
    con = console()
    if con is None:
        return False
    module = _try_import("rich.syntax")
    if module is None:
        return False
    try:
        con.print(module.Syntax(code, language, line_numbers=False,
                                theme="monokai", background_color="default"))
        return True
    except Exception:
        return False


def status(message: str):
    """进度指示器。rich 不可用时给一个空壳上下文管理器。"""
    con = console()
    if con is None:
        return _NullStatus()
    try:
        return con.status(message, spinner="dots")
    except Exception:
        return _NullStatus()


class _NullStatus:
    def __enter__(self):
        return self

    def __exit__(self, *exc) -> bool:
        return False

    def update(self, *args, **kwargs) -> None:
        return None


def rule(title: str = "") -> bool:
    con = console()
    if con is None:
        return False
    try:
        con.rule(title or "", style="bright_magenta")
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------
# httpx：更稳的网络层
# --------------------------------------------------------------------------

HTTPX = available("httpx")


def _is_connect_error(exc: BaseException) -> bool:
    """这是「连不上」类错误吗（而不是「服务端回了 5xx」或「读超时」）。

    ## 为什么要区分

    断网时重试**毫无意义**——只是让她多等几倍。实测
    （`scripts/verify_offline_speed.py`，出网代理指向死端口）：

        不区分：搜 B 站 **7961 ms**、音乐搜索 **5315 ms** 才回错
        区分后：一次连接失败就回错（约 1.8 秒）

    而 5xx / 读超时**值得重试**（服务端临时抖动，第二次可能就好）。

    urllib 会把真原因包在 `URLError.reason` 里，所以要往里看一眼。
    """
    names = {
        "ConnectError", "ConnectTimeout", "ConnectTimeoutError",
        "ProxyError", "NewConnectionError", "ConnectionRefusedError",
        "ConnectionError", "ConnectionResetError", "gaierror",
    }
    if exc.__class__.__name__ in names:
        return True
    reason = getattr(exc, "reason", None)
    if reason is None:
        return False
    if reason.__class__.__name__ in names:
        return True
    if isinstance(reason, TimeoutError):
        return False          # 超时算「可能抖一下」，允许重试
    return isinstance(reason, (ConnectionError, OSError))


def http_get_json(url: str, *, headers: dict | None = None, params: dict | None = None,
                  timeout: float = 8.0, retries: int = 2) -> tuple[bool, Any, str]:
    """GET 一个 JSON 接口。返回 (成功, 数据, 错误说明)。

    httpx 可用时带连接复用和自动重试；否则退回 urllib。
    两者对外行为一致，所以 search.py 不用关心用的哪个。

    **重试策略**（断网快慢全看这里）：

        · 连不上（ConnectError / 代理拒绝 / DNS 失败）→ **不重试**，立刻回错
        · HTTP 5xx → 重试
        · 读超时 → 重试
    """
    if HTTPX:
        module = _try_import("httpx")
        if module is not None:
            last = ""
            for attempt in range(retries + 1):
                try:
                    with module.Client(
                        headers=headers or {},
                        timeout=timeout,
                        follow_redirects=True,
                        http2=False,
                    ) as client:
                        resp = client.get(url, params=params)
                    if resp.status_code == 200:
                        return True, resp.json(), ""
                    last = f"HTTP {resp.status_code}"
                    if resp.status_code < 500:
                        break  # 4xx 重试没意义
                except Exception as exc:
                    last = f"{exc.__class__.__name__}: {exc}"
                    if _is_connect_error(exc):
                        # **连接类错误不重试**：断网/代理拒绝时，
                        # 第二次第三次只会让她多等（8 秒 → 1.8 秒）
                        break
            return False, None, last

    # ---- 降级：urllib ----
    import json as _json
    import urllib.error
    import urllib.parse
    import urllib.request

    if params:
        url = f"{url}?{urllib.parse.urlencode(params)}"
    last = ""
    for _ in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers or {})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status != 200:
                    last = f"HTTP {resp.status}"
                    continue
                return True, _json.loads(resp.read().decode("utf-8", errors="replace")), ""
        except urllib.error.HTTPError as exc:
            last = f"HTTP {exc.code}"
            if exc.code < 500:
                break
        except Exception as exc:
            last = f"{exc.__class__.__name__}"
            if _is_connect_error(exc):
                break
    return False, None, last


# --------------------------------------------------------------------------
# platformdirs：跨平台数据目录
# --------------------------------------------------------------------------

PLATFORMDIRS = available("platformdirs")


def platform_data_dir() -> Path | None:
    """系统推荐的用户数据目录。装了 platformdirs 才给得出。"""
    if not PLATFORMDIRS:
        return None
    module = _try_import("platformdirs")
    if module is None:
        return None
    try:
        return Path(module.user_data_dir("her-review", "her"))
    except Exception:
        return None


# --------------------------------------------------------------------------
# discache：搜索结果缓存（少打网络）
# --------------------------------------------------------------------------

DISKCACHE = available("diskcache")
# 缓存实例与它所在的目录。启动时会由 configure_cache() 指定到真实数据目录下。
_CACHE: Any = None
_CACHE_DIR: Path | None = None
# 缓存没生效时的原因（给 doctor 用：宁可说"没生效，因为 X"，也不要假装能用）
_CACHE_ERROR = ""


def configure_cache(directory: Path | str) -> bool:
    """把缓存目录指到**实际使用的数据目录**下。

    为什么必须有这一步：
        原来缓存固定在 default_home()（~/.her-review）。
        但程序真正的数据目录来自 her.local.json（她的是 `容齐芳的数据/`），
        两者不是一个地方；一旦默认目录不可写（只读家目录、沙箱、U 盘），
        _cache_store() 就返回 None，之后所有 cache_get/cache_set **静默变成空操作**——
        缓存看起来装好了，实际一次都没生效。
        所以在解析出数据目录之后立刻调这里，把缓存放到确定可写的位置。
    """
    global _CACHE, _CACHE_DIR
    try:
        target = Path(directory) / "cache"
        if _CACHE is not None and _CACHE_DIR == target:
            return True
        _CACHE = None
        _CACHE_DIR = target
        return _cache_store(target) is not None
    except Exception:
        return False


def cache_get(key: str, *, ttl: float = 3600.0) -> Any:
    """读缓存。ttl 秒内有效，过期当没读到。

    为什么自己存时间戳，而不是用 diskcache 自带的 expire：
        那个参数的语义在不同版本里不一样（有的是相对秒数、有的要绝对时间），
        实测传进去之后过期的条目照样能读出来。
        与其猜版本，不如自己在值里带一个写入时刻——
        这样在任何版本、甚至换成别的缓存后端，行为都是确定的。
    """
    store = _cache_store()
    if store is None:
        return None
    try:
        entry = store.get(key)
    except Exception:
        return None
    if not isinstance(entry, tuple) or len(entry) != 2:
        return None
    stamp, value = entry
    try:
        if ttl and ttl > 0 and (time.time() - float(stamp)) > ttl:
            return None   # 过期
    except (TypeError, ValueError):
        return None
    return value


def cache_set(key: str, value: Any) -> None:
    store = _cache_store()
    if store is None:
        return
    try:
        store.set(key, (time.time(), value))
    except Exception:
        pass


def cache_stats() -> dict:
    """缓存状态，给 doctor 看。装没装、在哪个目录、有多少条、没生效的原因。"""
    store = _cache_store()
    if store is None:
        return {"enabled": False, "dir": str(_CACHE_DIR) if _CACHE_DIR else "",
                "count": 0, "error": _CACHE_ERROR}
    try:
        return {"enabled": True, "dir": str(store.directory), "count": len(store),
                "error": ""}
    except Exception as exc:
        return {"enabled": True, "dir": str(_CACHE_DIR) if _CACHE_DIR else "",
                "count": 0, "error": f"{exc.__class__.__name__}: {exc}"}


def clear_cache() -> int:
    """清空缓存。返回清了几条。"""
    store = _cache_store()
    if store is None:
        return 0
    try:
        n = len(store)
        store.clear()
        return n
    except Exception:
        return 0


def _cache_store(cache_dir: Path | None = None):
    """缓存放在数据目录里，而不是额外再建一个目录。

    优先用 configure_cache() 指定的目录；没指定才退回 default_home()。
    退回那一步只在"没有明确数据目录"时发生（比如裸跑一个自测），
    正常启动都会先调 configure_cache()。

    失败时把原因记在 _CACHE_ERROR 里（不抛异常，缓存失败不该影响主流程），
    这样 doctor 能如实说"缓存没生效，原因是 X"，
    而不是显示成"已安装"却什么都不做——那种沉默最难查。
    """
    global _CACHE, _CACHE_DIR, _CACHE_ERROR
    if _CACHE is not None:
        return _CACHE
    # 这里**必须现查**，不能用模块级的 DISKCACHE 常量：
    # 那是个在 import 时刻求值的布尔值，而 .pylibs 往往在那之后才加进 sys.path，
    # 于是它会永远停在 False —— 缓存看起来装好了，实际一次都没生效。
    # 这个 bug 藏了很久，就是因为没有任何地方会报错。
    if not available("diskcache"):
        _CACHE_ERROR = "diskcache 未安装（或 .pylibs 还没加到 sys.path）"
        return None
    module = _try_import("diskcache")
    if module is None:
        _CACHE_ERROR = "diskcache 导入失败"
        return None
    try:
        base = cache_dir or _CACHE_DIR
        if base is None:
            from .config import default_home

            base = default_home() / "cache"
        base = Path(base)
        base.mkdir(parents=True, exist_ok=True)
        # 写探针：能建目录不代表能写（沙箱里经常是这种情况）
        probe = base / ".write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        _CACHE = module.Cache(str(base))
        _CACHE_DIR = base
        _CACHE_ERROR = ""
    except Exception as exc:
        _CACHE_ERROR = f"{exc.__class__.__name__}: {exc}"
        return None
    return _CACHE


# --------------------------------------------------------------------------
# pyperclip：复制到剪贴板
# --------------------------------------------------------------------------

PYPERCLIP = available("pyperclip")


def copy_to_clipboard(text: str) -> bool:
    """复制一段文本到剪贴板。没装库就试试系统命令。"""
    if PYPERCLIP:
        module = _try_import("pyperclip")
        if module is not None:
            try:
                module.copy(text)
                return True
            except Exception:
                pass
    # 降级：Windows clip / macOS pbcopy / Linux xclip
    import shutil
    import subprocess

    for cmd in (["clip"], ["pbcopy"], ["xclip", "-selection", "clipboard"]):
        exe = shutil.which(cmd[0])
        if not exe:
            continue
        try:
            proc = subprocess.run(cmd, input=text.encode("utf-8"),
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                  timeout=5)
            if proc.returncode == 0:
                return True
        except Exception:
            continue
    return False


# --------------------------------------------------------------------------
# 能力清单（her doctor / her libs 用）
# --------------------------------------------------------------------------

# 名字 -> (import 名, 用来干什么, 属于哪一层)
# (名称, import 名, 作用说明, 级别)
#
# 作用说明里要**如实写清在界面里能不能用上**，不能笼统说"增强效果"：
# 她是在图形界面里用的，如果一个库在界面这条线上根本没机会生效，
# 那把它显示成"已装"就是在给她一个好看但没用的数字。
# 实际使用点（改这些说明前先确认一遍）：
#   httpx        deps.http_get_json -> search.search_online（界面搜索走这条）
#   diskcache    deps.cache_get/set -> search.search_online（界面搜索的 10 分钟缓存）
#   pyperclip    deps.copy_to_clipboard（终端命令用；界面里浏览器自带剪贴板）
#   platformdirs deps.platform_data_dir（终端用；界面固定用 her.local.json 指定的目录）
#   rich         deps.md_render（**只在终端用**；界面的 Markdown 由浏览器渲染）
#   pytest       开发用，两个入口都用不到
LIBRARIES: list[tuple[str, str, str, str]] = [
    ("rich", "rich",
     "终端里的 Markdown 渲染、表格、进度条（界面不需要：浏览器自己会渲染）", "推荐"),
    ("httpx", "httpx",
     "网络请求带连接复用与自动重试，B 站搜索更稳（界面和终端都走这条）", "推荐"),
    ("platformdirs", "platformdirs",
     "按系统规范放数据目录（终端用；界面固定用 her.local.json 指定的目录）", "推荐"),
    ("diskcache", "diskcache",
     "搜索结果缓存 10 分钟，重复搜同一个知识点不再打网络（界面和终端都有效）", "可选"),
    ("pyperclip", "pyperclip",
     "命令行里一键复制链接（界面里浏览器自带复制，用不到）", "可选"),
    ("pytest", "pytest",
     "跑正经的测试套件（开发用，日常不需要）", "开发"),
]


def capability_report() -> list[dict]:
    """每个库的可用状态，给 doctor 用。"""
    versions = installed_versions()
    out: list[dict] = []
    for label, module, purpose, tier in LIBRARIES:
        ok = available(module)
        version = ""
        if ok:
            # 版本优先从 importlib.metadata 读（读 .pylibs 里的 dist-info）。
            # 为什么不只靠 getattr(mod, "__version__")：
            #   像 rich 这类库根本不导出 __version__，那样会显示 unknown。
            # 也不只靠标记文件：它是上次安装时的快照，可能已经过时。
            version = _metadata_version(label) or str(
                getattr(_try_import(module), "__version__", "") or ""
            ) or versions.get(label, "")
            if version == "unknown":
                version = _metadata_version(label) or ""
        out.append({
            "name": label,
            "module": module,
            "purpose": purpose,
            "tier": tier,
            "available": ok,
            "version": version,
        })
    return out


# 安装名和 import 名不一致的那些（和 bootstrap.py 保持同一份口径）
_IMPORT_NAMES = {"markdown-it-py": "markdown_it"}


def _metadata_version(label: str) -> str:
    """从 dist-info 读版本号。读不到就返回空串，不抛异常。

    找不到包是**正常情况**（没装），所以这里必须吞掉 PackageNotFoundError，
    否则环境自检这一页会因为一个没装的库直接崩掉。
    """
    try:
        from importlib.metadata import PackageNotFoundError, version
    except ImportError:
        return ""
    for name in (label, _IMPORT_NAMES.get(label, ""), label.replace("-", "_")):
        if not name:
            continue
        try:
            return version(name)
        except PackageNotFoundError:
            continue
        except Exception:
            continue
    return ""


def summary_line() -> str:
    """一行摘要，给首页/doctor 用。"""
    items = capability_report()
    on = [i["name"] for i in items if i["available"]]
    if not on:
        return "增强库：未安装（功能正常，只是朴素一点）"
    return f"增强库：{'、'.join(on)}"
