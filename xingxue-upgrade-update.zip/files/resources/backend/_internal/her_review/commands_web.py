"""命令实现（二）：B 站搜索栏 + 复习流程 + 视频总结器。

这个模块是「卡壳 → 看懂 → 沉淀」的闭环本体：
    review 里按 s 搜 B 站、按 b 丢给视频总结器、复习完写回笔记。
"""

from __future__ import annotations

import time
from datetime import datetime

from . import features, gem, report, search, ui
from .cli_support import (InputClosed, ask, ask_choice, input_is_exhausted,
                            interactive, pause, resolve)


def cmd_search(args, ctx) -> int:
    """B 站搜索栏。核心入口，也是「不会就搜」这个动作的最短路径。"""
    from . import failures

    problem = None
    if args.problem:
        problem = resolve(ctx.store, args.problem)
        if not problem:
            ui.warn(f"没找到题目「{args.problem}」，改成直接搜这个词")

    keyword = args.keyword
    # 有 --problem 就先从题目派生搜索词：这在脚本里是最常用的形态
    # （her search --problem 每日温度 --print-only）
    if not keyword and problem:
        derived = search.queries_for_problem(problem.title, problem.tags)
        keyword = derived[0][1] if derived else problem.title

    if not keyword:
        if not interactive():
            # 既没关键词也没 --problem，非交互环境下直接报错，
            # 而不是卡在 input() 上等一个永远不来的回车
            ui.err("没给搜索词")
            ui.info("用法：her search <关键词>    或    her search --problem <题目>")
            return 1
        suggestions = (search.queries_for_problem(problem.title, problem.tags)
                       if problem else [])
        if suggestions:
            print(ui.box("这道题该搜什么", [
                ui.c(f"{i}. ", "gold") + ui.c(label, "bold") + "  " + ui.c(kw, "grey")
                for i, (label, kw) in enumerate(suggestions, start=1)
            ] + ["", ui.c("直接回车 = 搜第 1 条；也可以自己输入关键词", "grey")],
                width=ui.term_width(), style=ctx.theme.primary))
            default = suggestions[0][1]
        else:
            default = problem.title if problem else ""
        keyword = ask("搜什么", default)
    if not keyword:
        ui.err("没给搜索词")
        return 1

    # 纯链接模式：不联网，永远可用
    if args.links_only:
        search.print_links(keyword)
        return 0

    if not args.offline:
        outcome = search.search_online(keyword, page=args.page)
        search.print_videos(outcome, keyword)
        videos = outcome.videos if outcome.ok else []
        # 搜索失败不再静默：记一条可重试的账，成功则把这一类标记为已解决
        if outcome.ok:
            failures.resolve_kind(ctx.store, "search")
        else:
            failures.record(
                ctx.store, "search", "B 站搜索没拿到在线结果",
                detail=outcome.error, retry=f'her search "{keyword}"',
            )
    else:
        videos = []
        search.print_links(keyword)

    chosen = None
    if videos and not args.print_only:
        if args.pick:
            index = int(args.pick)
            if 1 <= index <= len(videos):
                chosen = videos[index - 1]
        else:
            raw = ask(f"打开第几个（1-{len(videos)}，回车直接开搜索页，s 跳过）",
                      "1" if args.open else "")
            if raw.isdigit() and 1 <= int(raw) <= len(videos):
                chosen = videos[int(raw) - 1]

    url = chosen.url if chosen else search.search_url(keyword)

    if args.summarize and chosen:
        return do_summarize(ctx, chosen.url, problem=problem, save=args.save)

    if args.open or chosen:
        opened = search.open_url(url)
        ui.ok(("已打开浏览器：" if opened else "链接（请手动打开）：") + url)
    else:
        ui.info(f"链接：{url}")

    if problem:
        print()
        print(report.suggestions_block(problem, ctx.theme))
    return 0


def cmd_summarize(args, ctx) -> int:
    """调用 BiliSum 视频总结器。"""
    problem = resolve(ctx.store, args.problem) if args.problem else None
    return do_summarize(ctx, args.url, problem=problem, save=args.save, fmt=args.format)


def do_summarize(ctx, url: str, problem=None, save: bool = False,
                 fmt: str = "markdown") -> int:
    """总结一个视频。

    优先走内置托管（直接起 BiliSum 后端 + HTTP），不需要 Node，也不需要桌面端。
    只有在没装 BiliSum 时才提示怎么办。
    """
    import json

    from . import bilisum, deps, evidence, failures

    started = time.time()
    ok, detail = search.bilisum_available()
    if not ok:
        ui.err(f"视频总结器不可用：{detail}")
        ui.info("装过 BiliSum 的话，用环境变量 BILISUM_HOME 指一下它的安装目录")
        ui.info("没装也不影响复习：her search 照样能搜 B 站、打开视频")
        failures.record(ctx.store, "summarize", "视频总结器不可用",
                        detail=detail, retry="her video status")
        return 3

    def on_status(message: str) -> None:
        print(f"{ui.c('·', 'cyan')} {message}")

    print(f"{ui.c('·', 'cyan')} 正在准备视频总结器…")
    if fmt == "json":
        # JSON 模式仍然走 CLI，因为要的就是它的原始任务对象
        ok2, output = search.summarize_video(url, fmt=fmt)
        if not ok2:
            clean = evidence.redact(output)[0]
            ui.err(clean)
            failures.record(ctx.store, "summarize", "总结任务失败（json 模式）",
                            detail=clean[:1500], retry=f'her summarize "{url}"')
            return 3
        print(output.strip())
        return 0

    success, body, error, summary = search.summarize_via_service(
        url, ctx.cfg.home, on_progress=on_status
    )
    if not success:
        # 失败也要留痕：下次她想重试，得知道上次是因为什么
        clean_error = evidence.redact(error)[0]
        ui.err(f"总结失败：{clean_error}")
        ui.info(f"后端日志：{ctx.cfg.home / 'bilisum-backend.log'}")
        failures.record(ctx.store, "summarize", "视频总结失败",
                        detail=clean_error[:1500], retry=f'her summarize "{url}"')
        return 3

    # ---- 脱敏 → 预算 → 质量记录 ----
    # 这三步对着三个真实风险：密钥跟着笔记进数据库、note 字段无限膨胀、
    # AI 产出的东西看起来完整其实没依据。
    safe_body, redacted_count = evidence.redact(body)
    if redacted_count:
        ui.warn(f"内容里有 {redacted_count} 处疑似密钥，已替换成 {evidence.REDACTED}")

    note_budget = evidence.budget(safe_body, "problem_note")
    text = note_budget.text

    warnings: list[str] = []
    if note_budget.truncated:
        warnings.append(f"内容超出笔记预算（{note_budget.original_chars} → "
                        f"{note_budget.kept_chars} 字），已裁剪")
    if redacted_count:
        warnings.append(f"已脱敏 {redacted_count} 处密钥片段")

    report = evidence.build_report(
        summary,
        elapsed=time.time() - started,
        llm_used=_llm_enabled(ctx),
        transcript_source=_guess_transcript_source(summary),
        warnings=warnings,
    )
    ctx.store.conn.execute(
        "INSERT INTO quality_log(task_id, title, problem_id, payload, created_at)"
        " VALUES(?,?,?,?,?)",
        (report.task_id, report.title, problem.id if problem else None,
         json.dumps(report.to_dict(), ensure_ascii=False), report.generated_at),
    )
    ctx.store.conn.commit()

    print()
    # rich 可用就渲染真 Markdown（标题、列表、代码块都好看），否则原样打印
    if not (deps.rich_ready() and deps.md_render(text)):
        print(ui.c(text, "white"))

    # 当场告诉她"这份东西能信到什么程度"，而不是让她自己猜
    print()
    print(ui.box("这次生成的质量", report.lines(), width=ui.term_width(),
                 style=ctx.theme.primary))

    if save and problem:
        return _save_into_problem(ctx, problem, text, report)
    if save and not problem:
        out_dir = ctx.cfg.home / "notes"
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"video-{datetime.now().strftime('%Y%m%d-%H%M%S')}.md"
        path.write_text(text, encoding="utf-8")
        ui.ok(f"已保存到 {path}")
    return 0


def _llm_enabled(ctx) -> bool:
    """她的 BiliSum 到底有没有配大模型。

    读不到就返回 False —— 宁可把可信度说低，也不要给她一个乐观的错结论。
    """
    try:
        from . import bilisum

        client = bilisum.Client(ctx.cfg.home)
        client.prepare()
        settings = (client.data_root or Path()) / "data" / "settings.json"
        if settings.exists():
            payload = json.loads(settings.read_text(encoding="utf-8"))
            return bool(payload.get("llm_enabled"))
    except Exception:
        pass
    return False


def _guess_transcript_source(summary) -> str:
    """判断转写来自 B 站字幕还是语音识别。

    判据：字幕通常是完整句子、标点多；ASR 结果里口语语气词密集。
    拿不准就返回 unknown —— 宁可说"不确定"，也不要编一个结论出来。
    """
    text = " ".join(filter(None, [
        getattr(summary, "overview", "") or "",
        getattr(summary, "transcript", "") or "",
    ]))
    if not text:
        return "unknown"
    fillers = sum(text.count(w) for w in ("呃", "啊", "呢", "哦", "嗯"))
    periods = text.count("。") + text.count("，")
    if periods >= 5 and fillers / max(1, periods) < 0.08:
        return "subtitle"
    if fillers >= 8:
        return "asr"
    return "unknown"


def _save_into_problem(ctx, problem, text: str, report) -> int:
    """把总结写进题目的 note。

    三条保护（对应"失败安全：不写半成品、不覆盖她的内容"）：
        1. 先比指纹：同一道题已经存过同一份内容就不重复追加
        2. 不覆盖：她自己写的 note 永远保留，新内容追加在后
        3. 留痕：写进去的内容带头信息（来源/指纹/可信度），以后能对上
    """
    from . import evidence

    stamp = datetime.now().strftime("%Y-%m-%d")
    header = (f"【视频笔记 {stamp}】{report.title or ''}\n"
              f"来源指纹 {report.source_fingerprint}　"
              f"转写来源：{report.source_label()}　"
              f"可信度：{report.confidence()[0]}\n")

    existing = problem.note or ""
    # 幂等：同一份内容不重复写
    if existing and report.source_fingerprint and report.source_fingerprint in existing:
        ui.info("这道题的笔记里已经有同一份内容了（来源指纹相同），跳过写入")
        return 0

    if not existing:
        ctx.store.update(problem.id, note=header + text)
        ui.ok(f"已写回 #{problem.id} {problem.title} 的笔记")
        return 0

    limit = evidence.BUDGETS["problem_note"]
    merged = existing + "\n\n" + header + text
    if len(merged) <= limit:
        ctx.store.update(problem.id, note=merged)
        ui.ok(f"已追加到 #{problem.id} {problem.title} 的笔记（她原来写的内容保留）")
        return 0

    # 超预算时优先保住她自己写的那部分，新内容单独存文件
    room = limit - len(existing) - len(header) - 80
    if room >= 500:
        ctx.store.update(problem.id,
                         note=existing + "\n\n" + header + text[:room] + "\n…（已裁剪）")
        ui.ok(f"已追加到 #{problem.id} 的笔记（新内容较长，做了裁剪）")
        return 0

    out_dir = ctx.cfg.home / "notes"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{problem.id}-{stamp}.md"
    path.write_text(header + text, encoding="utf-8")
    ui.warn("她原来写的内容已经接近 note 上限，这次总结没有覆盖它")
    ui.ok(f"已单独保存到 {path}")
    return 0


# --------------------------------------------------------------------------
# 视频服务管理
# --------------------------------------------------------------------------

def cmd_video(args, ctx) -> int:
    """管理内置的 BiliSum 后端服务。"""
    from . import bilisum, deps

    action = args.action or "status"

    if action == "status":
        lines: list[str] = []
        if not bilisum.installed():
            lines.append(ui.c("没找到 BiliSum 的后端", "gold"))
            lines.append("")
            lines.append(ui.c("装过 BiliSum 的话，用环境变量指一下安装目录：", "grey"))
            lines.append("  " + ui.c('set BILISUM_HOME=C:\\Users\\你\\AppData\\Local\\Programs\\BiliSum',
                                    "hotpink"))
            lines.append(ui.c("没装也不影响复习，只是不能用视频总结。", "grey"))
            return _video_box("视频总结器", lines, ctx)

        client = bilisum.Client(ctx.cfg.home)
        try:
            client.prepare()
        except bilisum.ServiceError as exc:
            lines.append(ui.c(str(exc), "red"))
            return _video_box("视频总结器", lines, ctx)

        lines.append(ui.c("后端      ", "grey") + ui.c(str(client.backend), "plum"))
        lines.append(ui.c("数据目录  ", "grey") + ui.c(str(client.data_root), "plum"))
        if client.note:
            lines.append("          " + ui.c(client.note, "grey"))
        lines.append(ui.c("端口      ", "grey") + ui.c(str(client.port), "plum"))
        lines.append("")
        running = client.service_running()
        if running:
            ok, state = client.health()
            lines.append(ui.c("服务状态  ", "grey")
                         + ui.c(f"运行中（{state}）", "brightgreen")
                         + ui.c("  不需要桌面端", "grey"))
            pid = bilisum._read_pid(ctx.cfg.home)
            if pid:
                lines.append("          " + ui.c(f"是我们拉起来的（PID {pid}），her video stop 可以停",
                                                "grey"))
            else:
                lines.append("          " + ui.c("由别处启动（桌面端或她自己开的）", "grey"))
        else:
            lines.append(ui.c("服务状态  ", "grey") + ui.c("未运行", "gold"))
            lines.append("          " + ui.c("总结视频时会自动拉起来，不用管", "grey"))
        lines.append("")
        lines.append(ui.c("增强库    ", "grey") + ui.c(deps.summary_line(), "plum"))
        lines.append("")
        lines.append(ui.c("总结一个视频：", "grey")
                     + ui.c("her summarize <视频链接>", "hotpink"))
        return _video_box("视频总结器", lines, ctx)

    if action == "start":
        client = bilisum.Client(ctx.cfg.home)
        try:
            ok, message = client.ensure_service(on_status=lambda m: print(f"  · {m}"))
        except bilisum.ServiceError as exc:
            ui.err(str(exc))
            return 1
        if ok:
            ui.ok(message)
            return 0
        ui.err(message)
        return 1

    if action == "stop":
        client = bilisum.Client(ctx.cfg.home)
        try:
            client.prepare()
        except bilisum.ServiceError as exc:
            ui.err(str(exc))
            return 1
        if client.stop_service():
            ui.ok("已停止我们拉起来的后端服务")
            return 0
        ui.info("没有我们启动的服务在跑（桌面端自己起的不受影响）")
        return 0

    ui.err(f"不认识的动作 {action}")
    return 1


def _video_box(title: str, lines: list[str], ctx) -> int:
    print(ui.box(title, lines, width=ui.term_width(), style=ctx.theme.primary))
    return 0


# --------------------------------------------------------------------------
# 复习流程
# --------------------------------------------------------------------------

def search_and_maybe_summarize(ctx, problem, keyword: str, auto_open: bool = True) -> None:
    """复习中途的搜索：给结果 → 打开 → 可选丢给总结器 → 可选写回笔记。"""
    outcome = search.search_online(keyword, page=1)
    search.print_videos(outcome, keyword)
    if not outcome.ok or not outcome.videos:
        if auto_open:
            url = search.search_url(keyword)
            if search.open_url(url):
                ui.ok(f"已打开浏览器：{url}")
        return

    raw = ask(f"打开第几个（1-{len(outcome.videos)}，回车=搜索页，b=总结第1个）", "1")
    if raw == "b":
        do_summarize(ctx, outcome.videos[0].url, problem=problem, save=False)
        if ask_choice("把总结写回这道题的笔记？(y/n)", {"y", "n"}, "y") == "y":
            merged = (problem.note + "\n\n" if problem.note else "") + (
                f"【视频笔记 {datetime.now():%Y-%m-%d}】{outcome.videos[0].title}\n"
            )
            ctx.store.update(problem.id, note=merged)
            ui.ok("已追加到笔记（正文用 her edit 补，或加 --save 自动写全文）")
        return

    if raw.isdigit() and 1 <= int(raw) <= len(outcome.videos):
        video = outcome.videos[int(raw) - 1]
        if search.open_url(video.url):
            ui.ok(f"已打开：{video.title}")
        else:
            ui.info(video.url)
        if ask_choice("要顺便让视频总结器出摘要吗？(y/n)", {"y", "n"}, "n") == "y":
            do_summarize(ctx, video.url, problem=problem, save=False)
    elif auto_open:
        url = search.search_url(keyword)
        if search.open_url(url):
            ui.ok(f"已打开浏览器：{url}")


def review_one(ctx, problem, index: int, total: int,
               auto_open_search: bool, show_solution_first: bool) -> str:
    """复习一道题。返回 'done' / 'quit'。

    要区分三种收尾：'done' 做完了 / 'quit' 她按 q 主动退出 / 'eof' 输入断了。
    主动退出是正常结束（退出码 0）；输入断掉是"操作没做完"（退出码 1）——
    不能把没干成报成成功。
    """
    show_solution = show_solution_first
    while True:
        ui.clear_screen()
        print(report.review_card(problem, index, total, ctx.theme, show_solution))
        print()
        print(report.rating_block(ctx.theme))
        print()
        try:
            raw = ask("评分 / 操作", "n" if not show_solution else "").lower().strip()
        except InputClosed:
            print()
            ui.info("输入结束了，先退出复习")
            return "eof"

        if raw == "q":
            return "quit"

        if raw == "n":
            show_solution = True
            continue

        if raw == "s":
            suggestions = search.queries_for_problem(problem.title, problem.tags)
            print()
            for i, (label, kw) in enumerate(suggestions, start=1):
                print(f"  {ui.c(str(i), 'gold')}. {ui.c(label, 'bold')}  {ui.c(kw, 'grey')}")
            default = suggestions[0][1] if suggestions else problem.title
            keyword = ask("搜什么（直接回车用第 1 条）", default)
            if keyword:
                search_and_maybe_summarize(ctx, problem, keyword, auto_open=auto_open_search)
                pause()
            continue

        if raw == "b":
            if not problem.url:
                ui.warn("这道题没链接，直接搜一个视频来总结")
            keyword = ask("搜什么视频",
                          search.build_query(problem.tags[0]) if problem.tags else problem.title)
            outcome = search.search_online(keyword)
            if outcome.ok and outcome.videos:
                search.print_videos(outcome, keyword)
                pick = ask("总结第几个", "1")
                if pick.isdigit() and 1 <= int(pick) <= len(outcome.videos):
                    do_summarize(ctx, outcome.videos[int(pick) - 1].url,
                                 problem=problem, save=False)
            else:
                ui.warn("没搜到视频")
            pause()
            continue

        if raw == "o":
            if problem.url:
                if search.open_url(problem.url):
                    ui.ok(f"已打开 {problem.url}")
                else:
                    ui.info(problem.url)
            else:
                ui.warn("这道题没存链接，用 her edit 补一个")
            pause()
            continue

        if raw.isdigit() and 0 <= int(raw) <= 5:
            quality = int(raw)
            before = len(ctx.store.due(ctx.today()))
            result = ctx.store.submit_review(problem, quality)
            left = max(0, before - 1)
            # 通知插件：又复习完一道（钩子出错也不会影响这里）
            features.fire_hooks(ctx, "review", problem=problem, quality=quality, result=result)
            ui.clear_screen()
            print(report.review_summary(problem, result, ctx.theme, left))
            print()
            if not result.passed and problem.tags:
                print(report.suggestions_block(problem, ctx.theme))
                print()
            pause()
            return "done"

        ui.warn("看不懂这个输入，输入 0-5 评分，或 n/s/b/o/q")


def cmd_review(args, ctx) -> int:
    """开始复习。

    队列不再是"due <= today 直接拿来用"，而是走 queue.build_queue 的四层过滤：
    资格 → 形状（信息够不够） → 去重 → 限额。
    过滤结果会如实报出来（"截掉 N 道""有 2 道没写思路"），
    这样她知道今天为什么是这几道，而不是觉得程序在随机给她出题。
    """
    from . import queue as queue_mod

    if not ctx.store.count():
        print(report.empty_state(ctx.theme))
        return 0

    selected, queue_report = queue_mod.build_queue(
        ctx.store, ctx.today(),
        limit=args.limit or 0,
        extra_keyword=args.extra or "",
    )
    queue = selected

    if not queue:
        ui.ok("今天没有到期的题了")
        upcoming = ctx.store.upcoming(7, ctx.today())
        if upcoming:
            print()
            print(report.problem_table(upcoming, ctx.theme, "接下来 7 天", ctx.today()))
        return 0

    total = len(queue)
    if not args.no_banner:
        print(report.opening(ctx.store, ctx.theme, ctx.name, ctx.birthday,
                             ctx.today(), compact=True))
        print()
        # 队列构成说明（只在"确实做了什么过滤"时显示，避免啰嗦）
        extra_lines = [l for l in queue_report.lines()
                       if "去重" in ui._strip_ansi(l) or "限额" in ui._strip_ansi(l)
                       or "信息不足" in ui._strip_ansi(l)]
        if extra_lines:
            print(ui.c("  今天的队列是这样筛出来的：", "grey"))
            for line in extra_lines:
                print("  " + line)
            print()
        ui.info(f"本次 {total} 道题。卡片上按 {ui.c('n', 'hotpink')} 看思路，"
                f"{ui.c('s', 'hotpink')} 搜 B 站，{ui.c('b', 'violet')} 丢给视频总结器，"
                f"{ui.c('q', 'grey')} 退出。")
        pause("准备好了就回车")
        # 输入已经没了（管道读完 / Ctrl+D）：干净收尾，别空转
        if input_is_exhausted():
            print(report.progress_line(0, total, ctx.theme))
            ui.info("输入结束了，本次复习先到这儿")
            return 1

    done = 0
    interrupted = False
    try:
        for index, problem in enumerate(queue, start=1):
            outcome = review_one(
                ctx, problem, index, total,
                auto_open_search=not args.no_auto_open,
                show_solution_first=args.show_solution,
            )
            if outcome == "eof":
                interrupted = True
                break
            if outcome == "quit":
                break
            done += 1
    except InputClosed:
        # 输入在进循环之前就断了（banner 阶段），也要走正常收尾：
        # 打完成绩单再退出，而不是把异常甩到顶层
        interrupted = True

    ui.clear_screen()
    print(ui.box("本次复习结束", [
        ui.c("完成  ", "grey") + ui.c(f"{done} / {total}", ctx.theme.accent, "bold"),
        ui.c("连续打卡  ", "grey") + ui.c(f"{ctx.store.streak(ctx.today())} 天", "gold", "bold"),
        ui.c("剩余待复习  ", "grey") + ui.c(f"{len(ctx.store.due(ctx.today()))} 道", "grey"),
        "",
        ui.c(gem.daily_quote(ctx.today()), ctx.theme.extra),
    ], width=ui.term_width(), style=ctx.theme.primary))
    # 输入断了 = 这次没做完，退出码给 1；她主动按 q 则是正常结束
    return 1 if interrupted else 0
