"""终端渲染层：零依赖、宽字符对齐、无 colorama 也能在 Windows 上变色。

设计目标：
1. 只依赖标准库（她电脑上不用 pip install 任何东西）
2. 中文/emoji 占两个字符宽，框线必须对齐（自己实现 char_width）
3. 不支持颜色时自动降级成纯文本，不乱码
"""

from __future__ import annotations

import os
import shutil
import sys
import unicodedata

# --------------------------------------------------------------------------
# 颜色
# --------------------------------------------------------------------------

_CODES = {
    "reset": "\033[0m",
    "bold": "\033[1m",
    "dim": "\033[2m",
    "italic": "\033[3m",
    "underline": "\033[4m",
    "black": "\033[30m",
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
    "white": "\033[37m",
    "grey": "\033[90m",
    "pink": "\033[95m",
    "brightgreen": "\033[92m",
    "brightyellow": "\033[93m",
    "brightcyan": "\033[96m",
    "gold": "\033[38;5;220m",
    "violet": "\033[38;5;141m",
    "orange": "\033[38;5;215m",
    # 粉色系（符号喵喵专用）：256 色，比基础色好看得多
    "pink": "\033[38;5;218m",        # 浅粉：猫的身体描边
    "pinklight": "\033[38;5;224m",   # 更浅的粉：内耳、腮红
    "hotpink": "\033[38;5;211m",     # 亮粉：强调、眼泪
    "rose": "\033[38;5;204m",        # 玫粉：标题
    "plum": "\033[38;5;182m",        # 藕粉：次要文字
}


def _enable_windows_ansi() -> bool:
    """在 Windows 上打开 VT 处理，否则颜色会变成一串乱码转义符。"""
    if os.name != "nt":
        return True
    try:
        import ctypes  # 仅在 Windows 上导入

        kernel32 = ctypes.windll.kernel32
        # -11 = STD_OUTPUT_HANDLE；0x0004 = ENABLE_VIRTUAL_TERMINAL_PROCESSING
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        return bool(kernel32.SetConsoleMode(handle, mode.value | 0x0004))
    except Exception:
        return False


_COLOR_OK = _enable_windows_ansi() and sys.stdout.isatty()


def use_color(flag: bool) -> None:
    """允许外部（--no-color / 非交互）强制关闭颜色。"""
    global _COLOR_OK
    _COLOR_OK = _COLOR_OK and flag


def has_color() -> bool:
    return _COLOR_OK


def c(text: str, *styles: str) -> str:
    """给文本上色。无颜色支持时原样返回。"""
    if not _COLOR_OK or not styles:
        return text
    prefix = "".join(_CODES.get(s, "") for s in styles)
    if not prefix:
        return text
    return f"{prefix}{text}{_CODES['reset']}"


# --------------------------------------------------------------------------
# 宽字符
# --------------------------------------------------------------------------

_WIDE_RANGES = (
    (0x1100, 0x115F),
    (0x2E80, 0x303E),
    (0x3041, 0x33FF),
    (0x3400, 0x4DBF),
    (0x4E00, 0x9FFF),
    (0xA000, 0xA4CF),
    (0xAC00, 0xD7A3),
    (0xF900, 0xFAFF),
    (0xFE30, 0xFE6F),
    (0xFF00, 0xFF60),
    (0xFFE0, 0xFFE6),
    (0x1F300, 0x1F64F),
    (0x1F900, 0x1F9FF),
    (0x1FA70, 0x1FAFF),
    (0x20000, 0x2FFFD),
)


def char_width(ch: str) -> int:
    """单个字符在等宽终端里占几列。"""
    if ch in ("\u200b", "\ufe0f", "\u200d"):
        return 0
    code = ord(ch)
    for low, high in _WIDE_RANGES:
        if low <= code <= high:
            return 2
    if unicodedata.combining(ch):
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    return 1


def dwidth(text: str) -> int:
    """整串文本的显示宽度。"""
    return sum(char_width(ch) for ch in text)


def truncate(text: str, width: int, ellipsis: str = "…") -> str:
    """按显示宽度截断，不切坏宽字符。"""
    if width <= 0:
        return ""
    if dwidth(text) <= width:
        return text
    limit = width - dwidth(ellipsis)
    out: list[str] = []
    used = 0
    for ch in text:
        w = char_width(ch)
        if used + w > limit:
            break
        out.append(ch)
        used += w
    return "".join(out) + ellipsis


def pad(text: str, width: int, align: str = "left") -> str:
    """按显示宽度补空格对齐。"""
    text = truncate(text, width)
    space = max(0, width - dwidth(text))
    if align == "right":
        return " " * space + text
    if align == "center":
        left = space // 2
        return " " * left + text + " " * (space - left)
    return text + " " * space


def wrap(text: str, width: int) -> list[str]:
    """中英混排折行：英文按空格断，中文按字符断。"""
    if width <= 2:
        return [text]
    lines: list[str] = []
    for raw_line in text.split("\n"):
        if not raw_line:
            lines.append("")
            continue
        current = ""
        used = 0
        for ch in raw_line:
            w = char_width(ch)
            if used + w > width:
                # 英文单词尽量不切断
                if ch.isalnum() and " " in current:
                    head, _, tail = current.rpartition(" ")
                    if head:
                        lines.append(head)
                        current = tail + ch
                        used = dwidth(current)
                        continue
                lines.append(current)
                current = ch
                used = w
            else:
                current += ch
                used += w
        lines.append(current)
    return lines


# --------------------------------------------------------------------------
# 终端尺寸
# --------------------------------------------------------------------------

def term_width(default: int = 100, minimum: int = 34) -> int:
    try:
        size = shutil.get_terminal_size(fallback=(default, 24))
        return max(minimum, min(size.columns, 120))
    except Exception:
        return default


def term_height(default: int = 30) -> int:
    try:
        return max(10, shutil.get_terminal_size(fallback=(100, default)).lines)
    except Exception:
        return default


# --------------------------------------------------------------------------
# 组件
# --------------------------------------------------------------------------

def clear_screen() -> None:
    if sys.stdout.isatty():
        print("\033[2J\033[H", end="")


def rule(char: str = "─", width: int | None = None, style: str = "grey") -> str:
    width = width or term_width()
    return c(char * width, style)


def _strip_ansi(text: str) -> str:
    out: list[str] = []
    i = 0
    while i < len(text):
        if text[i] == "\033":
            j = text.find("m", i)
            if j == -1:
                break
            i = j + 1
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def box(
    title: str = "",
    lines: list[str] | None = None,
    width: int | None = None,
    style: str = "cyan",
    colored_title: str | None = None,
    border: bool = True,
    wrap_lines: bool = False,
) -> str:
    """画一个带标题的框。lines 里允许已经带颜色的内容。

    两个开关是给"长文本"用的（踩过坑）：

        border=False   不画边框，只用标题分节。
                       框线**不会自动换行**——一行超过宽度就会把右边框顶出去，
                       整个框看起来是破的。内容里有长句子时，别用边框。

        wrap_lines=True  自动把超长行折成多行再放进框里。
                       折行按显示宽度算（中日韩字符占 2 列），
                       不能按字符数算，否则中文行会超宽。
    """
    lines = lines or []
    width = width or term_width()
    inner = width - 4

    if wrap_lines:
        wrapped: list[str] = []
        for line in lines:
            wrapped.extend(_wrap_ansi(line, inner))
        lines = wrapped

    if not border:
        out: list[str] = []
        if title:
            out.append("")
            out.append(c(f"── {title} ", style) + c("─" * max(0, width - dwidth(title) - 5), style))
        out.extend(lines)
        return "\n".join(out)

    out: list[str] = []
    if title:
        head = f" {colored_title or title} "
        fill = max(0, width - 2 - dwidth(head))
        left = fill // 2
        out.append(
            c("┌", style) + c("─" * left, style) + head + c("─" * (fill - left), style) + c("┐", style)
        )
    else:
        out.append(c("┌" + "─" * (width - 2) + "┐", style))
    for line in lines:
        visible = _strip_ansi(line)
        pad_n = max(0, inner - dwidth(visible))
        out.append(c("│", style) + " " + line + " " * pad_n + " " + c("│", style))
    out.append(c("└" + "─" * (width - 2) + "┘", style))
    return "\n".join(out)


def _wrap_ansi(text: str, limit: int) -> list[str]:
    """按**显示宽度**折行，折的时候尽量不破坏已有的 ANSI 颜色。

    简化处理：颜色码在折行后会被复制到新行的开头，
    这样后半段的颜色不会丢（丢颜色比多几个字符难看）。
    """
    if limit <= 8:
        return [text]
    plain = _strip_ansi(text)
    if dwidth(plain) <= limit:
        return [text]

    # 找出开头所有的 ANSI 码，折行后要补回去
    prefix = ""
    i = 0
    while i < len(text) and text[i] == "\x1b":
        end = text.find("m", i)
        if end == -1:
            break
        prefix += text[i:end + 1]
        i = end + 1
    body = text[i:]

    out: list[str] = []
    current = ""
    current_w = 0
    for ch in body:
        w = dwidth(ch)
        if current_w + w > limit and current:
            out.append((prefix if out else "") + current)
            current = ""
            current_w = 0
        current += ch
        current_w += w
    if current:
        out.append((prefix if out else "") + current)
    return out or [text]


def bar(
    filled: int,
    total: int,
    width: int = 24,
    style: str = "brightgreen",
    empty_style: str = "grey",
) -> str:
    """进度条。"""
    if total <= 0:
        total = 1
    filled = max(0, min(filled, total))
    n = int(round(width * filled / total))
    return c("█" * n, style) + c("░" * (width - n), empty_style)


def configure_stdio() -> None:
    """把标准输出调成「永远不崩」的模式。

    为什么需要：Windows 上 Python 默认用 ANSI 代码页（cp936）编码输出，
    一旦输出被重定向到文件，程序里的框线字符（─│┌┐╭╮）就可能编不出来，
    直接 UnicodeEncodeError 崩掉。这里统一改成 UTF-8 + 替换模式，
    宁可少一个字符，也不能让程序挂掉。
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            continue


def emit(text: str = "") -> None:
    print(text)


def info(text: str) -> None:
    print(f"{c('·', 'cyan')} {text}")


def ok(text: str) -> None:
    print(f"{c('✓', 'brightgreen')} {text}")


def warn(text: str) -> None:
    print(f"{c('!', 'yellow')} {text}")


def err(text: str) -> None:
    print(f"{c('✗', 'red')} {text}", file=sys.stderr)
