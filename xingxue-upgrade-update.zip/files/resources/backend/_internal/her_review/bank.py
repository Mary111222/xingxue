"""内置题库：按**培养方案里的课程**组织，不是通用面试题清单。

## 这份数据是怎么定的

用户要求“按照实际用户情况来定”。这里的“实际情况”取自程序里的客观信息：

    · `curriculum.py` 里的 22 门课（她这个专业要学什么）
    · 六级考试日期（有截止日期的硬目标）
    · 原来那 33 道通用题里**只有 2 道复习过**（说明她没在用）

所以改成**按课程分组**：每组对应一门课，标题、标签、关键思路
都冲着那门课去。这样“今天该复习什么”和“我这门课学到哪了”是一回事。

## 两条硬约束（都是踩过坑才写下来的）

**① 每个 LeetCode slug 都必须真实存在。**
编造一个点不开的链接比没有链接更糟——点进去 404，
会让她觉得整个程序是拼凑的。
这一版里的 slug **逐个请求验证过**（75 个全部 HTTP 200）。

**② 课程类知识点用搜索页，不编题目链接。**
操作系统、计算机网络、数据库这几门，LeetCode 上**确实没有**
对应的编程题。与其编一个看着完整的题号（点进去 404），
不如给一个**真实可点、一定打得开**的站内搜索页。

## note 字段写什么

写“关键思路”和“当时为什么卡住”——这是复习时真正有用的那部分。
**不要写解法代码**：这个程序的复习界面默认不显示 note，
逼她先自己想，想不出来再按 N 看。
"""

from __future__ import annotations

from datetime import date

# 题型：关键思路写在 note 里，便于复习时一眼回想
def course_item(title: str, difficulty: str, tags: list[str], note: str,
                search: str, source: str = "nowcoder") -> dict:
    """课程知识点条目。

    **为什么这类条目不指向具体题目**：
    操作系统、计算机网络、数据库这几门，LeetCode 上确实没有对应的编程题。
    与其编一个看着完整的题号（点进去 404），不如给一个**真实可点、
    一定打得开**的牛客站内搜索页——点进去就是这些知识点的题库列表。

    这个取舍值得记住：**编造的链接比没有链接更糟**。
    她点进去看到 404，会以为整个程序是拼凑出来的。
    """
    from urllib.parse import quote

    return {
        "title": title,
        "source": source,
        "difficulty": difficulty,
        "tags": tags,
        "url": f"https://www.nowcoder.com/search?query={quote(search)}",
        "note": note,
    }


BANK: list[dict] = [
    # ==================================================================
    #  C 语言程序设计（专业第一门语言课）
    #  重点：数组与字符串、递归、指针。指针是这门课挂科率最高的地方。
    # ==================================================================
    {
        "title": "两数之和",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["C语言", "数组", "哈希表"],
        "url": "https://leetcode.cn/problems/two-sum/",
        "note": "关键：不要双重循环（O(n²)）。用哈希表存「已经见过的值 → 下标」，"
                "遍历时先查 target - x 是否见过，边遍历边建表，O(n) 一次过。",
    },
    {
        "title": "最长公共前缀",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["C语言", "字符串"],
        "url": "https://leetcode.cn/problems/longest-common-prefix/",
        "note": "关键：以第一个串为基准逐列比较，不匹配就截断。"
                "字符串题在 C 里要特别小心结尾的 \\0 和越界——"
                "别用 strlen 循环里反复算长度，先存下来。",
    },
    {
        "title": "反转字符串中的单词",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["C语言", "字符串", "双指针"],
        "url": "https://leetcode.cn/problems/reverse-words-in-a-string/",
        "note": "关键：先整体反转，再逐个单词反转（两步反转）。"
                "或者从后往前扫、逐个单词搬。注意处理多余空格。",
    },
    {
        "title": "字符串转换整数 (atoi)",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["C语言", "字符串", "边界"],
        "url": "https://leetcode.cn/problems/string-to-integer-atoi/",
        "note": "关键：这题考的是**边界**不是算法——前导空格、正负号、"
                "非数字字符截断、int 溢出（用 long long 存再判范围）。"
                "面试官爱问这题就是因为它能看出你有没有边界意识。",
    },
    {
        "title": "爬楼梯",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["C语言", "递归", "动态规划"],
        "url": "https://leetcode.cn/problems/climbing-stairs/",
        "note": "关键：本质是斐波那契。dp[i] = dp[i-1] + dp[i-2]，"
                "空间可以压到 O(1)。**别写成朴素递归**，n=45 会超时——"
                "这是“递归要有出口、更要有记忆化”的第一个教训。",
    },
    {
        "title": "Pow(x, n)",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["C语言", "递归", "分治"],
        "url": "https://leetcode.cn/problems/powx-n/",
        "note": "关键：快速幂。x^n = (x^(n/2))^2，n 为奇数再乘一个 x。"
                "两个坑：n 可能是负数（取倒数）；n = INT_MIN 时 -n 会溢出。",
    },

    # ==================================================================
    #  数据结构（专业基础课，也是考研 408 和笔试的重头）
    # ==================================================================
    # ---- 线性表 / 链表 ----
    {
        "title": "设计链表",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "链表", "设计"],
        "url": "https://leetcode.cn/problems/design-linked-list/",
        "note": "关键：**哑结点（dummy）**是链表题的第一习惯。"
                "有了它，插入/删除头结点就不用特判。"
                "所有「操作链表」的题都先加哑结点，能省掉大半边界判断。",
    },
    {
        "title": "反转链表",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "链表"],
        "url": "https://leetcode.cn/problems/reverse-linked-list/",
        "note": "关键：三个指针 prev / cur / next，循环里先把 next 存下来再改指向。"
                "**这题要能闭眼写出来**——它是链表题的地基。",
    },
    {
        "title": "合并两个有序链表",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "链表", "递归"],
        "url": "https://leetcode.cn/problems/merge-two-sorted-lists/",
        "note": "关键：哑结点省掉大量判空。迭代就是「谁小接谁，剩下的整段挂上」，"
                "递归注意返回的是更小的那个头。",
    },
    {
        "title": "删除排序链表中的重复元素",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "链表"],
        "url": "https://leetcode.cn/problems/remove-duplicates-from-sorted-list/",
        "note": "关键：因为**已排序**，重复的一定相邻，一趟扫过去就行。"
                "对比「删除未排序链表的重复元素」——那个需要哈希表。"
                "排序这个前提能省多少事，值得体会一下。",
    },
    {
        "title": "环形链表",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "链表", "双指针"],
        "url": "https://leetcode.cn/problems/linked-list-cycle/",
        "note": "关键：快慢指针。快指针每次走两步、慢的一步，有环必相遇。"
                "为什么一定相遇：进入环之后，两者距离每轮缩短 1，迟早为 0。",
    },
    {
        "title": "环形链表 II",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "链表", "双指针", "数学"],
        "url": "https://leetcode.cn/problems/linked-list-cycle-ii/",
        "note": "关键：相遇之后，**一个新指针从头开始，和慢指针同速走**，"
                "再次相遇处就是环入口。这个结论要能自己推一遍——"
                "设头到环口 a、环口到相遇点 b、环长 c，推 a = c - b。",
    },
    {
        "title": "相交链表",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "链表", "双指针"],
        "url": "https://leetcode.cn/problems/intersection-of-two-linked-lists/",
        "note": "关键：两个指针各自走完自己的链后**换到对方的链头**继续走，"
                "走的总长度相同，必然在交点相遇（或同时到 null）。"
                "想不到这个技巧的话，用「长度差」的写法也行。",
    },
    {
        "title": "两两交换链表中的节点",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "链表", "递归"],
        "url": "https://leetcode.cn/problems/swap-nodes-in-pairs/",
        "note": "关键：还是哑结点 + 三个指针改指向。"
                "写的时候先在纸上画一遍指向变化——"
                "链表题的 bug 几乎都是「顺序写错，把还要用的节点覆盖掉了」。",
    },
    {
        "title": "删除链表的倒数第 N 个结点",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "链表", "双指针"],
        "url": "https://leetcode.cn/problems/remove-nth-node-from-end-of-list/",
        "note": "关键：快指针先走 n 步，然后快慢一起走到快指针到末尾，"
                "慢指针就停在待删节点的前一个。**一趟扫描**，不用先求长度。",
    },
    {
        "title": "K 个一组翻转链表",
        "source": "leetcode",
        "difficulty": "hard",
        "tags": ["数据结构", "链表", "递归"],
        "url": "https://leetcode.cn/problems/reverse-k-group/",
        "note": "关键：先数够不够 k 个（不够就保持原样），"
                "够就翻转这一段，再接上后面递归的结果。"
                "这题是链表题的“期中考试”——前面几道都熟了再来做它。",
    },

    # ---- 栈 / 队列 ----
    {
        "title": "有效的括号",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "栈", "字符串"],
        "url": "https://leetcode.cn/problems/valid-parentheses/",
        "note": "关键：遇左括号入栈，遇右括号必须和栈顶匹配。"
                "两个易错边界——遍历完栈必须为空；遇到右括号时栈不能已经空。",
    },
    {
        "title": "用栈实现队列",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "栈", "队列", "设计"],
        "url": "https://leetcode.cn/problems/implement-queue-using-stacks/",
        "note": "关键：两个栈，一个进一个出。出栈空了就把进栈全部倒过来。"
                "**均摊 O(1)**——每个元素最多被倒一次，这个摊还分析要能讲清。",
    },
    {
        "title": "用队列实现栈",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "栈", "队列", "设计"],
        "url": "https://leetcode.cn/problems/implement-stack-using-queues/",
        "note": "关键：一个队列就够——入队后把前面 n-1 个元素重新排到队尾。"
                "和上一题对照着做，能体会「栈和队列的本质差别在哪」。",
    },
    {
        "title": "最小栈",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "栈", "设计"],
        "url": "https://leetcode.cn/problems/min-stack/",
        "note": "关键：辅助栈存「到目前为止的最小值」。"
                "要点：push 时辅助栈存 min(当前值, 辅助栈顶)，"
                "这样 pop 时两边同步弹，不用回退查找，全 O(1)。",
    },
    {
        "title": "每日温度",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "栈", "单调栈"],
        "url": "https://leetcode.cn/problems/daily-temperatures/",
        "note": "关键：**单调栈**。栈里存下标，保持栈内温度递减。"
                "新元素比栈顶大时，栈顶的答案就是当前下标的差。"
                "单调栈解决的是「找右边第一个比它大的」这一类问题。",
    },
    {
        "title": "字符串解码",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "栈", "字符串", "递归"],
        "url": "https://leetcode.cn/problems/decode-string/",
        "note": "关键：两个栈——一个存重复次数，一个存进入括号前的字符串。"
                "遇到 '[' 压栈，遇到 ']' 弹出来拼接。"
                "括号匹配类的题，栈的用法都是这个套路。",
    },
    {
        "title": "设计循环队列",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "队列", "设计"],
        "url": "https://leetcode.cn/problems/design-circular-queue/",
        "note": "关键：判断队满/队空的两种写法——"
                "① 多开一个空间，head == tail 表示空，(tail+1)%n == head 表示满；"
                "② 额外维护一个 size。第一种不浪费变量但要想清楚，第二种直白。",
    },

    # ---- 树 ----
    {
        "title": "二叉树的前序遍历",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归", "DFS"],
        "url": "https://leetcode.cn/problems/binary-tree-preorder-traversal/",
        "note": "关键：递归三行。**重点是迭代写法**——用栈模拟，"
                "先压右孩子再压左孩子（这样弹出时才是先左）。"
                "前中后序的迭代写法是笔试常考。",
    },
    {
        "title": "二叉树的中序遍历",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归", "DFS"],
        "url": "https://leetcode.cn/problems/binary-tree-inorder-traversal/",
        "note": "关键：中序 = 左根右。**对二叉搜索树来说，中序遍历就是有序序列**——"
                "这一条是后面所有 BST 题的基础。迭代写法要「一路向左压栈」。",
    },
    {
        "title": "二叉树的后序遍历",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归", "DFS"],
        "url": "https://leetcode.cn/problems/binary-tree-postorder-traversal/",
        "note": "关键：后序 = 左右根。迭代写法有个技巧："
                "按「根右左」遍历然后反转结果，等价于后序。",
    },
    {
        "title": "二叉树的层序遍历",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二叉树", "BFS", "队列"],
        "url": "https://leetcode.cn/problems/binary-tree-level-order-traversal/",
        "note": "关键：队列 + **记录当前层的大小**（进循环前先取 size），"
                "这样才能分出「一层」。忘了取 size 就会把各层混在一起。",
    },
    {
        "title": "二叉树的锯齿形层序遍历",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二叉树", "BFS", "队列"],
        "url": "https://leetcode.cn/problems/binary-tree-zigzag-level-order-traversal/",
        "note": "关键：层序遍历 + 一个方向标志。奇数层正着放、偶数层反着放"
                "（或者用双端队列，按方向决定从哪头插入）。",
    },
    {
        "title": "二叉树的最大深度",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归", "DFS"],
        "url": "https://leetcode.cn/problems/maximum-depth-of-binary-tree/",
        "note": "关键：max(左, 右) + 1，递归两行。迭代版用层序遍历数层数。"
                "**这是所有树递归题的模板**，值得闭眼写出来。",
    },
    {
        "title": "翻转二叉树",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归"],
        "url": "https://leetcode.cn/problems/invert-binary-tree/",
        "note": "关键：交换左右孩子，然后递归两边。"
                "前序/后序都行，**但中序不行**——中序会把同一个子树翻转两次。"
                "这个细节面试常问。",
    },
    {
        "title": "对称二叉树",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归"],
        "url": "https://leetcode.cn/problems/symmetric-tree/",
        "note": "关键：判断的是「左子树的左」和「右子树的右」。"
                "递归时传两个节点（而不是一个），这是和普通树递归不同的地方。",
    },
    {
        "title": "相同的树",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归"],
        "url": "https://leetcode.cn/problems/same-tree/",
        "note": "关键：同时遍历两棵树。终止条件有三种——"
                "都空 ✓、一个空 ✗、值不等 ✗。"
                "「两棵树同时递归」是个固定套路，很多题都用。",
    },
    {
        "title": "平衡二叉树",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归"],
        "url": "https://leetcode.cn/problems/balanced-binary-tree/",
        "note": "关键：**自底向上**一次遍历（后序），返回高度顺便判平衡；"
                "不要自顶向下（那样每个节点都重算高度，O(n²)）。",
    },
    {
        "title": "二叉树的所有路径",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归", "回溯"],
        "url": "https://leetcode.cn/problems/binary-tree-all-paths/",
        "note": "关键：DFS + 回溯。**到叶子才收集结果**，"
                "返回上一层时要把路径里加的那个节点弹掉——"
                "这是“回溯”最直观的一个例子。",
    },
    {
        "title": "路径总和",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归"],
        "url": "https://leetcode.cn/problems/path-sum/",
        "note": "关键：向下递归时把 targetSum 减去当前值，"
                "到叶子时看剩的是不是 0。**判断叶子要两个子节点都为空**——"
                "只有一个子节点为空不算叶子，这里最容易错。",
    },
    {
        "title": "合并二叉树",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "递归"],
        "url": "https://leetcode.cn/problems/merge-two-binary-trees/",
        "note": "关键：同时递归两棵树，值相加，一个为空就返回另一个。"
                "和「相同的树」是同一个套路。",
    },
    {
        "title": "验证二叉搜索树",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二叉树", "BST"],
        "url": "https://leetcode.cn/problems/validate-binary-search-tree/",
        "note": "关键：**不能只比较父子节点**——必须保证整棵左子树都小于根。"
                "两种正确写法：① 中序遍历看是否递增；"
                "② 递归时传上下界 (lower, upper)。"
                "第一种最好写，也最难错。",
    },
    {
        "title": "二叉搜索树中第 K 小的元素",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二叉树", "BST"],
        "url": "https://leetcode.cn/problems/kth-smallest-element-in-a-bst/",
        "note": "关键：BST 中序遍历是升序，所以「第 k 个」就是中序第 k 个。"
                "可以遍历到第 k 个就提前返回，不用走完整棵树。",
    },
    {
        "title": "将有序数组转换为二叉搜索树",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二叉树", "BST", "分治"],
        "url": "https://leetcode.cn/problems/convert-sorted-array-to-binary-search-tree/",
        "note": "关键：取中间元素当根（这样左右高度差 ≤ 1，自然平衡），"
                "递归建左右子树。这就是「有序数组 ↔ 平衡 BST」的互相转换。",
    },
    {
        "title": "二叉树最近公共祖先",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二叉树", "递归", "DFS"],
        "url": "https://leetcode.cn/problems/lowest-common-ancestor-of-a-binary-tree/",
        "note": "关键：后序遍历。左子树找到一个、右子树找到一个，"
                "当前节点就是答案；只找到一边就往上返回那一边。"
                "「返回找到的节点本身」这个设计很巧，值得琢磨。",
    },

    # ---- 哈希 / 字符串 ----
    {
        "title": "字母异位词分组",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "哈希表", "字符串", "排序"],
        "url": "https://leetcode.cn/problems/group-anagrams/",
        "note": "关键：**把“异位词”变成一个可比较的 key**——"
                "要么把字符串排序，要么用 26 个字母的计数数组当 key。"
                "「设计一个好的哈希 key」是这类题的核心。",
    },
    {
        "title": "无重复字符的最长子串",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "哈希表", "字符串", "滑动窗口"],
        "url": "https://leetcode.cn/problems/longest-substring-without-repeating-characters/",
        "note": "关键：滑动窗口。右指针扩张，遇到重复就把左指针跳到"
                "「上次出现位置 + 1」（**不是简单加一**，要跳到位）。"
                "用哈希表记录每个字符最后出现的位置。",
    },
    {
        "title": "找到字符串中所有字母异位词",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "哈希表", "字符串", "滑动窗口"],
        "url": "https://leetcode.cn/problems/find-all-anagrams-in-a-string/",
        "note": "关键：固定长度滑动窗口 + 字符计数。"
                "进一个字符、出一个字符，用「不同的字符种类数」判断是否匹配，"
                "避免每次都比较整个计数数组。",
    },
    {
        "title": "最长回文子串",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "字符串", "动态规划"],
        "url": "https://leetcode.cn/problems/longest-palindromic-substring/",
        "note": "关键：**中心扩展**最好写——枚举每个中心（奇数长度 1 个、"
                "偶数长度 2 个），向两边扩。O(n²) 但常数小。"
                "Manacher 是 O(n)，但面试写中心扩展就够。",
    },

    # ---- 排序 / 查找 ----
    {
        "title": "排序数组",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "排序", "分治"],
        "url": "https://leetcode.cn/problems/sort-an-array/",
        "note": "关键：**手写快排和归并**。快排注意「基准选取」和「小区间优化」；"
                "归并注意合并时的临时数组。"
                "这题会卡常数，用最朴素的写法可能超时——正好体会一下复杂度常数。",
    },
    {
        "title": "颜色分类",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "排序", "双指针"],
        "url": "https://leetcode.cn/problems/sort-colors/",
        "note": "关键：**三指针一次遍历**（荷兰国旗问题）。"
                "0 区右边界、2 区左边界，当前指针扫中间。"
                "交换 2 的时候**不能前进**——换过来的还没看过。",
    },
    {
        "title": "合并区间",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "排序", "数组"],
        "url": "https://leetcode.cn/problems/merge-intervals/",
        "note": "关键：**先按左端点排序**，然后一趟扫描合并。"
                "排序之后「能不能合并」只需要看当前区间的左端点和上一个右端点的关系。",
    },
    {
        "title": "前 K 个高频元素",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "堆", "哈希表", "排序"],
        "url": "https://leetcode.cn/problems/top-k-frequent-elements/",
        "note": "关键：哈希表统计频次 → **小顶堆**维护前 k 个（堆大小保持 k）。"
                "时间复杂度 O(n log k)。用大顶堆把所有元素都放进去是 O(n log n)，"
                "面试官会追问这个差别。",
    },
    {
        "title": "数据流中的中位数",
        "source": "leetcode",
        "difficulty": "hard",
        "tags": ["数据结构", "堆", "设计"],
        "url": "https://leetcode.cn/problems/find-median-from-data-stream/",
        "note": "关键：**对顶堆**——大顶堆存较小的一半，小顶堆存较大的一半，"
                "保持两个堆大小差 ≤ 1。插入 O(log n)，取中位数 O(1)。"
                "「用两个堆维护一个有序结构」是很实用的技巧。",
    },
    {
        "title": "数组中的第 K 个最大元素",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "堆", "快速选择", "分治"],
        "url": "https://leetcode.cn/problems/kth-largest-element-in-an-array/",
        "note": "关键：两种解法——① 小顶堆 O(n log k)；"
                "② **快速选择**（快排的 partition，只递归一边）平均 O(n)。"
                "快速选择的最坏情况 O(n²) 和随机化基准要说得出。",
    },
    {
        "title": "二分查找",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二分查找", "数组"],
        "url": "https://leetcode.cn/problems/binary-search/",
        "note": "关键：**边界怎么写**比算法本身难。"
                "统一用「左闭右开」[lo, hi) 或者「闭区间」[lo, hi]，"
                "选一种就一直用，别混。混用是二分写错的头号原因。",
    },
    {
        "title": "搜索插入位置",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二分查找", "数组"],
        "url": "https://leetcode.cn/problems/search-insert-position/",
        "note": "关键：最基础的二分变形。返回 lo 就是插入位置——"
                "循环结束时 lo 正好是「第一个 ≥ target 的位置」。",
    },
    {
        "title": "在排序数组中查找元素的第一个和最后一个位置",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二分查找", "数组"],
        "url": "https://leetcode.cn/problems/find-first-and-last-position-of-element-in-sorted-array/",
        "note": "关键：**两次二分**，分别找「第一个 ≥ target」和「第一个 > target」。"
                "「找边界」这种需求，统一化成 lower_bound / upper_bound 就清爽了。",
    },
    {
        "title": "搜索旋转排序数组",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二分查找", "数组"],
        "url": "https://leetcode.cn/problems/search-in-rotated-sorted-array/",
        "note": "关键：旋转之后**至少有一半是有序的**。"
                "先判断 mid 在哪一半（比 nums[lo] 大就是左半有序），"
                "再看 target 在不在那一半里，决定往哪边走。",
    },
    {
        "title": "寻找峰值",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二分查找", "数组"],
        "url": "https://leetcode.cn/problems/find-peak-element/",
        "note": "关键：**二分不一定要有序**——只要有「单调性」就行。"
                "mid 比右边小就往右走，否则往左走。"
                "这题能帮你打破「二分只能用于有序数组」的误解。",
    },
    {
        "title": "寻找旋转排序数组中的最小值",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "二分查找", "数组"],
        "url": "https://leetcode.cn/problems/find-minimum-in-rotated-sorted-array/",
        "note": "关键：拿 mid 和最右端比——比最右大说明最小值在右半，"
                "否则在左半（含 mid）。和上一题对照着做。",
    },
    {
        "title": "x 的平方根",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二分查找", "数学"],
        "url": "https://leetcode.cn/problems/sqrtx/",
        "note": "关键：二分答案（找最大的 m 使 m² ≤ x）。"
                "**注意用 long long 或除法避免 m*m 溢出**——"
                "这是“二分答案”这个套路的入门题。",
    },

    # ---- 设计题 ----
    {
        "title": "LRU 缓存",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "设计", "哈希表", "双向链表"],
        "url": "https://leetcode.cn/problems/lru-cache/",
        "note": "关键：**哈希表 + 双向链表**。哈希表 O(1) 定位，"
                "双向链表 O(1) 移动/删除。"
                "为什么用双向：删除一个节点需要它的前驱，单向链表得从头找。"
                "这题是「数据结构组合」的经典，面试出现率极高。",
    },
    {
        "title": "扁平化嵌套列表迭代器",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "栈", "设计"],
        "url": "https://leetcode.cn/problems/flatten-nested-list-iterator/",
        "note": "关键：用栈保存「还没处理完的迭代器」。"
                "next() 时如果栈顶是列表就展开压栈，直到栈顶是整数。"
                "这其实是「手写递归」——把递归的调用栈显式管起来。",
    },
    {
        "title": "最近的请求次数",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "队列", "设计"],
        "url": "https://leetcode.cn/problems/number-of-recent-calls/",
        "note": "关键：队列存时间戳，每次把超出 3000ms 的从队头弹掉。"
                "**队列的典型用途**：维护一个滑动的时间窗口。",
    },
    {
        "title": "日志速率限制器",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "哈希表", "设计"],
        "url": "https://leetcode.cn/problems/logger-rate-limiter/",
        "note": "关键：哈希表存「消息 → 上次打印时间」。"
                "这就是**限流**最朴素的实现——真实系统里的令牌桶/漏桶都是它的进化版。",
    },

    # ==================================================================
    #  算法设计与分析（专业必修）
    #  四种基本策略：分治、贪心、回溯、动态规划
    # ==================================================================
    # ---- 分治 ----
    {
        "title": "最大子数组和",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "分治", "动态规划", "数组"],
        "url": "https://leetcode.cn/problems/maximum-subarray/",
        "note": "关键：**Kadane 算法**（动态规划）最好写——"
                "dp[i] = max(nums[i], dp[i-1] + nums[i])。"
                "分治写法是分三类：全在左、全在右、跨中点。两种都值得会。",
    },
    {
        "title": "多数元素",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["算法设计与分析", "分治", "哈希表"],
        "url": "https://leetcode.cn/problems/majority-element/",
        "note": "关键：**Boyer-Moore 投票算法**——候选人相同 +1、不同 -1，"
                "计数归零就换人。因为众数出现次数 > n/2，最后一定是它。"
                "分治写法是「左半众数 == 右半众数」那个递归。",
    },
    {
        "title": "寻找两个正序数组的中位数",
        "source": "leetcode",
        "difficulty": "hard",
        "tags": ["算法设计与分析", "分治", "二分查找"],
        "url": "https://leetcode.cn/problems/median-of-two-sorted-arrays/",
        "note": "关键：对**较短的数组**二分切分点，"
                "让左半部分元素个数 = (m+n+1)/2，且左半最大值 ≤ 右半最小值。"
                "O(log min(m,n))。这题是二分里最难的一档，别急。",
    },

    # ---- 贪心 ----
    {
        "title": "买卖股票的最佳时机",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["算法设计与分析", "贪心", "数组"],
        "url": "https://leetcode.cn/problems/best-time-to-buy-and-sell-stock/",
        "note": "关键：一次遍历，维护「到今天为止的历史最低价」和「最大利润」。"
                "容易想复杂成 DP，其实贪心就够。",
    },
    {
        "title": "跳跃游戏",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "贪心", "数组"],
        "url": "https://leetcode.cn/problems/jump-game/",
        "note": "关键：维护「能到达的最远位置」maxReach。"
                "遍历时如果 i > maxReach 就说明中间断了。"
                "**不用真的模拟每一步跳哪**——这是贪心的精髓。",
    },
    {
        "title": "盛最多水的容器",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "贪心", "双指针"],
        "url": "https://leetcode.cn/problems/container-with-most-water/",
        "note": "关键：双指针从两端往中间收，**每次移动较矮的那一边**。"
                "为什么这样不会漏解：移动高的那一边只会让面积更小（高度受矮的限制）。",
    },

    # ---- 双指针 ----
    {
        "title": "三数之和",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "双指针", "排序", "数组"],
        "url": "https://leetcode.cn/problems/3sum/",
        "note": "关键：**排序 + 固定一个数 + 双指针找另外两个**，O(n²)。"
                "最烦的是**去重**：固定数重复要跳、左右指针遇到相同值也要跳。"
                "去重写错是这题最常见的 bug。",
    },

    # ---- 回溯 ----
    {
        "title": "全排列",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "回溯", "递归"],
        "url": "https://leetcode.cn/problems/permutations/",
        "note": "关键：回溯模板——**做选择 → 递归 → 撤销选择**。"
                "用 used 数组标记已用元素。"
                "把「路径」和「选择列表」想清楚，所有回溯题都是这个骨架。",
    },
    {
        "title": "子集",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "回溯", "位运算"],
        "url": "https://leetcode.cn/problems/subsets/",
        "note": "关键：两种写法——① 回溯，每个元素「选或不选」；"
                "② **位掩码**枚举 0 ~ 2ⁿ-1，第 i 位为 1 就取第 i 个元素。"
                "第二种能一眼看出「子集总数 = 2ⁿ」。",
    },
    {
        "title": "组合总和",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "回溯", "递归"],
        "url": "https://leetcode.cn/problems/combination-sum/",
        "note": "关键：元素**可以重复选**，所以递归时传的起点是 i（不是 i+1）。"
                "排序之后还能提前剪枝——剩余目标小于当前元素就停。",
    },
    {
        "title": "电话号码的字母组合",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "回溯", "字符串"],
        "url": "https://leetcode.cn/problems/letter-combinations-of-a-phone-number/",
        "note": "关键：多叉树的遍历。每个数字对应一组字母，"
                "递归的每一层处理一个数字。回溯的入门题。",
    },
    {
        "title": "括号生成",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "回溯", "字符串", "递归"],
        "url": "https://leetcode.cn/problems/generate-parentheses/",
        "note": "关键：回溯时只看两个约束——**左括号还没用完**就可以放左；"
                "**右括号数 < 左括号数**才可以放右。"
                "把这两个条件想明白，比生成全部再筛选高效得多。",
    },
    {
        "title": "分割回文串",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "回溯", "字符串", "动态规划"],
        "url": "https://leetcode.cn/problems/palindrome-partitioning/",
        "note": "关键：回溯枚举**切分点**，每次切出来的那段要是回文才继续。"
                "回文判断可以用 DP 预处理（isPal[i][j]）避免重复计算。",
    },
    {
        "title": "单词搜索",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "回溯", "图", "DFS"],
        "url": "https://leetcode.cn/problems/word-search/",
        "note": "关键：网格 DFS + 回溯。**访问过要标记、回溯时撤销**。"
                "小技巧：访问时临时改成特殊字符，省掉 visited 数组。",
    },
    {
        "title": "N 皇后",
        "source": "leetcode",
        "difficulty": "hard",
        "tags": ["算法设计与分析", "回溯", "递归"],
        "url": "https://leetcode.cn/problems/n-queens/",
        "note": "关键：逐行放皇后，用三个集合记「列、主对角线、副对角线」是否被占。"
                "对角线编号：主对角线 i-j 相同，副对角线 i+j 相同。"
                "**回溯的经典中的经典**，剪枝的思路值得琢磨。",
    },

    # ---- 动态规划 ----
    {
        "title": "打家劫舍",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划"],
        "url": "https://leetcode.cn/problems/house-robber/",
        "note": "关键：dp[i] = max(dp[i-1], dp[i-2] + nums[i])。"
                "**状态转移的两种选择**：偷这家的（上一家不能偷）vs 不偷这家的。"
                "这是理解「状态 + 选择」最清楚的例子。",
    },
    {
        "title": "零钱兑换",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划"],
        "url": "https://leetcode.cn/problems/coin-change/",
        "note": "关键：**完全背包**。dp[i] = min(dp[i - coin] + 1)。"
                "注意初始化成无穷大表示「凑不出」，以及外层循环的顺序"
                "（完全背包物品在外、容量在内）。",
    },
    {
        "title": "最长递增子序列",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划", "二分查找"],
        "url": "https://leetcode.cn/problems/longest-increasing-subsequence/",
        "note": "关键：① DP O(n²)：dp[i] 表示以 i 结尾的 LIS 长度；"
                "② **贪心 + 二分** O(n log n)：维护一个「尽可能小的各长度结尾值」数组。"
                "第二种要能讲清为什么可以二分。",
    },
    {
        "title": "最长公共子序列",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划", "字符串"],
        "url": "https://leetcode.cn/problems/longest-common-subsequence/",
        "note": "关键：二维 DP，dp[i][j] 是前 i / 前 j 个字符的 LCS。"
                "字符相等就 dp[i-1][j-1] + 1，否则取 max(dp[i-1][j], dp[i][j-1])。"
                "**LCS 是所有双序列 DP 的模板**。",
    },
    {
        "title": "编辑距离",
        "source": "leetcode",
        "difficulty": "hard",
        "tags": ["算法设计与分析", "动态规划", "字符串"],
        "url": "https://leetcode.cn/problems/edit-distance/",
        "note": "关键：和 LCS 同一个骨架，三种操作对应三个方向："
                "增 = dp[i][j-1]、删 = dp[i-1][j]、改 = dp[i-1][j-1]。"
                "**边界初始化**（空串变成长度 n 的串要 n 步）最容易写错。",
    },
    {
        "title": "不同路径",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划"],
        "url": "https://leetcode.cn/problems/unique-paths/",
        "note": "关键：dp[i][j] = dp[i-1][j] + dp[i][j-1]。"
                "**空间可以压成一维**（滚动数组）——只依赖左边和上面。"
                "这个优化思路对二维 DP 通用。",
    },
    {
        "title": "最小路径和",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划"],
        "url": "https://leetcode.cn/problems/minimum-path-sum/",
        "note": "关键：和「不同路径」同一个网格，把求和换成求最小。"
                "第一行第一列要先累加初始化——这里不初始化直接算会出错。",
    },
    {
        "title": "单词拆分",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划", "字符串"],
        "url": "https://leetcode.cn/problems/word-break/",
        "note": "关键：dp[i] 表示「前 i 个字符能不能拆」。"
                "枚举 j < i，如果 dp[j] 且 s[j..i) 在字典里，那 dp[i] = true。"
                "**用哈希集合存字典**，别用列表查找。",
    },
    {
        "title": "乘积最大子数组",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划", "数组"],
        "url": "https://leetcode.cn/problems/maximum-product-subarray/",
        "note": "关键：乘法有**负负得正**，所以同时维护「最大」和「最小」。"
                "当前是负数时，最大值可能来自前面的最小值相乘。"
                "这题教会你：状态不一定只有一个。",
    },
    {
        "title": "完全平方数",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划", "数学"],
        "url": "https://leetcode.cn/problems/perfect-squares/",
        "note": "关键：和「零钱兑换」一模一样，硬币换成了平方数。"
                "做完这两题你应该能看出「完全背包」这一类题的共同形状。",
    },
    {
        "title": "01 矩阵",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "动态规划", "BFS"],
        "url": "https://leetcode.cn/problems/01-matrix/",
        "note": "关键：两种解法——① **多源 BFS**（所有 0 一起入队）；"
                "② DP 两趟扫描（左上→右下、右下→左上）。"
                "「多源 BFS」这个技巧很多网格题都用。",
    },

    # ---- 图 ----
    {
        "title": "岛屿数量",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "图", "DFS", "BFS", "并查集"],
        "url": "https://leetcode.cn/problems/number-of-islands/",
        "note": "关键：遍历每个格子，遇到 '1' 就计数 +1，然后**把它连通的一片全部淹掉**"
                "（DFS 或 BFS）。三种解法都值得会：DFS、BFS、并查集。"
                "这题是图遍历的入门，也是「连通分量」最直观的例子。",
    },
    {
        "title": "腐烂的橘子",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "图", "BFS", "队列"],
        "url": "https://leetcode.cn/problems/rotting-oranges/",
        "note": "关键：**多源 BFS + 按层计数**。所有腐烂橘子一起入队，"
                "每扩散一层就是「一分钟」。最后还要检查有没有没被感染的新鲜橘子。",
    },
    {
        "title": "课程表",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "图", "拓扑排序", "BFS"],
        "url": "https://leetcode.cn/problems/course-schedule/",
        "note": "关键：**拓扑排序**判有向图有没有环。"
                "BFS 版（Kahn 算法）：统计入度，入度为 0 的入队，"
                "最后看处理过的节点数是否等于总数。DFS 版用三色标记。",
    },
    {
        "title": "被围绕的区域",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "图", "DFS", "并查集"],
        "url": "https://leetcode.cn/problems/surrounded-regions/",
        "note": "关键：**反向思考**——不找「被围住的」，而是从四条边界的 O 出发，"
                "把连通的 O 标记成「安全」，剩下的 O 才翻转。"
                "正向做要判断「是否连通到边界」，很麻烦。",
    },
    {
        "title": "克隆图",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "图", "DFS", "哈希表"],
        "url": "https://leetcode.cn/problems/clone-graph/",
        "note": "关键：DFS/BFS + **哈希表记录「原节点 → 克隆节点」**。"
                "没有这张表，遇到环就会无限递归。"
                "「图的深拷贝」是理解「图和树的差别」的好例子。",
    },
    {
        "title": "网络延迟时间",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "图", "最短路径"],
        "url": "https://leetcode.cn/problems/network-delay-time/",
        "note": "关键：**Dijkstra**（边权非负）。用优先队列每次取当前距离最小的。"
                "为什么 Dijkstra 不能处理负权边？——因为它一旦确定就不再更新，"
                "负权边会打破这个前提。这个问题面试常问。",
    },
    {
        "title": "冗余连接",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "图", "并查集"],
        "url": "https://leetcode.cn/problems/redundant-connection/",
        "note": "关键：**并查集**。逐条加边，如果两个端点已经在同一个集合里，"
                "这条边就是多余的。并查集的两个优化：路径压缩 + 按秩合并。",
    },
    {
        "title": "实现 Trie（前缀树）",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["数据结构", "字典树", "设计", "字符串"],
        "url": "https://leetcode.cn/problems/implement-trie-prefix-tree/",
        "note": "关键：每个节点是个「字符 → 子节点」的映射 + 一个「是否单词结尾」标记。"
                "**为什么用 Trie 而不是哈希表**：Trie 支持「前缀查询」，"
                "哈希表做不到。搜索框的自动补全就是它。",
    },

    # ==================================================================
    #  计算机组成原理（专业必修）
    #  位运算、进制——这门课的题 LeetCode 上多是位运算类
    # ==================================================================
    {
        "title": "位 1 的个数",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["计算机组成原理", "位运算"],
        "url": "https://leetcode.cn/problems/number-of-1-bits/",
        "note": "关键：**n & (n-1) 能消掉最低位的 1**——"
                "所以循环次数等于 1 的个数，比逐位移位快。"
                "这个技巧在「判断 2 的幂」等题里也常用。",
    },
    {
        "title": "颠倒二进制位",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["计算机组成原理", "位运算"],
        "url": "https://leetcode.cn/problems/reverse-bits/",
        "note": "关键：结果左移一位、加上 n 的最低位，然后 n 右移。"
                "**注意是无符号右移**（逻辑右移，高位补 0）——"
                "有符号右移会补符号位，结果就错了。这正是补码要理解的地方。",
    },
    {
        "title": "两整数之和",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["计算机组成原理", "位运算"],
        "url": "https://leetcode.cn/problems/sum-of-two-integers/",
        "note": "关键：不能用 +，那就用**异或算无进位和、与运算左移一位算进位**，"
                "然后循环直到进位为 0。"
                "这就是**加法器在硬件里的实现方式**——正好对上组成原理那章。",
    },
    {
        "title": "只出现一次的数字",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["计算机组成原理", "位运算", "数组"],
        "url": "https://leetcode.cn/problems/single-number/",
        "note": "关键：**异或的性质**——a ^ a = 0，a ^ 0 = a，"
                "而且异或满足交换律结合律。所以全部异或起来，"
                "成对的都消掉了，剩的就是答案。O(n) 时间 O(1) 空间。",
    },
    {
        "title": "只出现一次的数字 II",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["计算机组成原理", "位运算", "数组"],
        "url": "https://leetcode.cn/problems/single-number-ii/",
        "note": "关键：每个数出现三次、只有一个一次。"
                "**按位统计**：每一位上 1 的总数对 3 取余，就是答案那一位。"
                "或者用一个状态机（两个变量表示 mod 3 的状态）。",
    },
    {
        "title": "计数质数",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "数学", "数组"],
        "url": "https://leetcode.cn/problems/count-primes/",
        "note": "关键：**埃氏筛**——从 2 开始，把每个质数的倍数全部划掉。"
                "优化到 O(n log log n)：只用筛到 √n；"
                "第二层从 i*i 开始（更小的倍数已经被更小的质数筛掉了）。",
    },
    {
        "title": "阶乘后的零",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "数学"],
        "url": "https://leetcode.cn/problems/factorial-trailing-zeroes/",
        "note": "关键：末尾的 0 来自因子 10 = 2 × 5，而 2 的个数远多于 5，"
                "所以**数 5 的个数**：n/5 + n/25 + n/125 + …。"
                "**别真的算阶乘**——n=10000 时那个数大得存不下。",
    },
    {
        "title": "用 Rand7() 实现 Rand10()",
        "source": "leetcode",
        "difficulty": "medium",
        "tags": ["算法设计与分析", "数学", "概率"],
        "url": "https://leetcode.cn/problems/implement-rand10-using-rand7/",
        "note": "关键：**拒绝采样**。(rand7()-1)*7 + rand7() 能均匀生成 1~49，"
                "落在 1~40 就映射成 1~10，41~49 丢弃重来。"
                "期望调用次数是 49/40 ≈ 1.225 次。",
    },
    {
        "title": "猜数字大小",
        "source": "leetcode",
        "difficulty": "easy",
        "tags": ["数据结构", "二分查找"],
        "url": "https://leetcode.cn/problems/guess-number-higher-or-lower/",
        "note": "关键：标准二分。**注意 mid 的算法要防溢出**——"
                "写 lo + (hi - lo) / 2，而不是 (lo + hi) / 2。"
                "这是二分里最经典的越界坑。",
    },

    # ==================================================================
    #  操作系统 / 计算机网络 / 数据库（专业必修）
    #
    #  说明：这三门课**在 LeetCode 上没有对应的编程题**。
    #  与其编造一个点进去 404 的题目链接，不如给一个**真实可点**的
    #  牛客搜索页——点进去是这些知识点的题库/面经列表。
    #  这样“链接一定打得开”，而且内容确实对口。
    # ==================================================================
    course_item(
        "操作系统 · 进程与线程的区别", "medium",
        ["操作系统"],
        "关键：① 进程是资源分配的单位，线程是调度的单位；"
        "② 同一进程的线程共享地址空间，进程之间互相隔离；"
        "③ 所以线程切换比进程切换便宜得多（不用换页表）。"
        "面试几乎必问，要能答到「共享了什么、没共享什么」这一层。",
        "操作系统 进程 线程 区别",
    ),
    course_item(
        "操作系统 · 死锁的四个必要条件", "medium",
        ["操作系统", "死锁"],
        "关键：互斥、持有并等待、不可剥夺、循环等待——**四个同时成立才会死锁**，"
        "所以破坏任意一个就能预防。"
        "银行家算法是「避免」而不是「预防」，区别要分清。",
        "操作系统 死锁 四个必要条件",
    ),
    course_item(
        "操作系统 · 虚拟内存与页面置换算法", "medium",
        ["操作系统", "内存管理"],
        "关键：FIFO（有 Belady 异常）、LRU（理论最好但实现贵）、"
        "Clock（LRU 的近似实现，实际系统用的就是这个）。"
        "**要会手算页面置换过程**——期末和考研都爱考这个。",
        "操作系统 虚拟内存 页面置换算法",
    ),
    course_item(
        "操作系统 · 进程调度算法", "easy",
        ["操作系统", "调度"],
        "关键：FCFS（护航效应）、SJF（平均等待时间最短，但需要预知运行时间）、"
        "时间片轮转、优先级调度、多级反馈队列（综合了前几种，实际系统用）。"
        "会算平均周转时间和平均等待时间。",
        "操作系统 进程调度算法 周转时间",
    ),
    course_item(
        "计算机网络 · TCP 三次握手与四次挥手", "medium",
        ["计算机网络", "TCP"],
        "关键：三次握手是为了**双方都确认对方的收发能力**；"
        "四次挥手是因为 TCP 全双工，一方关完另一方可能还有数据要发。"
        "TIME_WAIT 要等 2MSL——为什么要等，是经典追问。",
        "计算机网络 TCP 三次握手 四次挥手",
    ),
    course_item(
        "计算机网络 · TCP 与 UDP 的区别", "easy",
        ["计算机网络", "TCP", "UDP"],
        "关键：TCP 面向连接、可靠、有序、有流量控制和拥塞控制，开销大；"
        "UDP 无连接、不保证可靠、开销小。"
        "**要能说出各自适合什么场景**：TCP 适合文件传输/网页，UDP 适合直播/游戏/DNS。",
        "计算机网络 TCP UDP 区别",
    ),
    course_item(
        "计算机网络 · 从输入网址到页面显示发生了什么", "hard",
        ["计算机网络", "HTTP", "DNS"],
        "关键：DNS 解析 → TCP 三次握手 → TLS 握手（https）→ 发 HTTP 请求 → "
        "服务器响应 → 浏览器渲染 → 四次挥手。"
        "**这一题串起了整本书**，能把每一层讲清楚就说明网络学明白了。",
        "计算机网络 输入网址 发生了什么",
    ),
    course_item(
        "计算机网络 · HTTP 状态码与缓存", "easy",
        ["计算机网络", "HTTP"],
        "关键：2xx 成功、3xx 重定向、4xx 客户端错、5xx 服务端错。"
        "缓存看 Cache-Control / ETag / Last-Modified；"
        "**304 是「内容没变，用你本地的」**，不是错误。",
        "计算机网络 HTTP 状态码 缓存",
    ),
    course_item(
        "数据库 · 事务的 ACID 与隔离级别", "medium",
        ["数据库", "事务"],
        "关键：ACID = 原子性/一致性/隔离性/持久性。"
        "四种隔离级别解决的三个问题：脏读、不可重复读、幻读。"
        "**MySQL 默认是可重复读**，而且用间隙锁部分解决了幻读——这个细节常被追问。",
        "数据库 事务 ACID 隔离级别",
    ),
    course_item(
        "数据库 · 索引为什么用 B+ 树", "medium",
        ["数据库", "索引"],
        "关键：B+ 树**矮胖**（一个节点存很多 key），所以磁盘 IO 次数少；"
        "叶子节点连成链表，**范围查询**很高效。"
        "对比：B 树数据分散在各层；哈希索引不支持范围查询；"
        "红黑树是二叉的，树高太大。",
        "数据库 索引 B+树 为什么",
    ),
    course_item(
        "数据库 · SQL 手写题（连表、分组、窗口函数）", "medium",
        ["数据库", "SQL"],
        "关键：**一定要能手写**，不能只看懂。"
        "顺序：JOIN → WHERE → GROUP BY → HAVING → ORDER BY → LIMIT，"
        "以及 LEFT JOIN 里 ON 和 WHERE 的区别（这个坑最多人踩）。",
        "SQL 面试题 连表 分组",
    ),
    course_item(
        "数据库 · 慢查询与索引优化", "hard",
        ["数据库", "索引", "优化"],
        "关键：EXPLAIN 看 type（要避免 ALL 全表扫）、key（实际用了哪个索引）、"
        "rows（扫描行数）。"
        "**最左前缀原则**：联合索引 (a,b,c) 能支持 a、a+b、a+b+c，"
        "但不支持 b 或 b+c。",
        "数据库 慢查询 索引优化 EXPLAIN",
    ),

    # ==================================================================
    #  离散数学（专业基础）
    # ==================================================================
    course_item(
        "离散数学 · 图的连通性与欧拉/哈密顿路径", "medium",
        ["离散数学", "图"],
        "关键：欧拉路径存在的条件——**奇度顶点个数是 0 或 2**（一笔画问题）；"
        "哈密顿路径没有简单的充要条件（NP 完全）。"
        "这个对比本身就是重要知识点。",
        "离散数学 欧拉图 哈密顿图",
    ),
    course_item(
        "离散数学 · 关系的性质与等价关系", "medium",
        ["离散数学", "关系"],
        "关键：自反、对称、传递——**等价关系就是这三个都满足**，"
        "它把集合划分成等价类。"
        "偏序关系是自反 + 反对称 + 传递，对应哈斯图。",
        "离散数学 等价关系 偏序关系",
    ),
    course_item(
        "离散数学 · 命题逻辑与范式", "easy",
        ["离散数学", "逻辑"],
        "关键：主析取范式（小项之或）和主合取范式（大项之与）。"
        "**真值表法**最稳，但要会化简。"
        "这一章是后面「逻辑推理」和「布尔代数」的基础——"
        "而布尔代数就是数字电路的数学。",
        "离散数学 主析取范式 主合取范式",
    ),

    # ==================================================================
    #  数字电子技术 / 计算机组成原理（专业基础 + 必修）
    # ==================================================================
    course_item(
        "数字电子 · 卡诺图化简与组合逻辑", "medium",
        ["数字电子", "逻辑"],
        "关键：卡诺图**圈相邻的 1**（可以跨边界、可以重叠），圈越大项越简。"
        "约束项（don't care）既可以当 1 也可以当 0——用它能让圈更大。"
        "这是从真值表到最简电路的标准流程。",
        "数字电子 卡诺图 化简",
    ),
    course_item(
        "数字电子 · 触发器与时序逻辑", "medium",
        ["数字电子", "时序逻辑"],
        "关键：组合逻辑 = 输出只和当前输入有关；"
        "时序逻辑 = 输出还和**当前状态**有关（有记忆）。"
        "D 触发器、JK 触发器、T 触发器的特性方程要记清，"
        "状态转换图会画。",
        "数字电子 触发器 时序逻辑",
    ),
    course_item(
        "计算机组成原理 · 补码与溢出判断", "medium",
        ["计算机组成原理", "位运算"],
        "关键：**补码 = 反码 + 1**，好处是「减法变加法」，"
        "而且 0 只有一种表示。"
        "溢出判断：两个同号数相加、结果变号 → 溢出。"
        "或者看最高位进位和次高位进位是否相同。",
        "计算机组成原理 补码 溢出判断",
    ),
    course_item(
        "计算机组成原理 · Cache 映射方式与命中率", "hard",
        ["计算机组成原理", "缓存"],
        "关键：直接映射（简单但冲突多）、全相联（灵活但贵）、"
        "组相联（折中，实际用的）。"
        "**要会算地址划分**：标记 / 组号 / 块内偏移各多少位。"
        "命中率计算是期末大题。",
        "计算机组成原理 Cache 映射 命中率",
    ),

    # ==================================================================
    #  软件工程（专业必修）
    # ==================================================================
    course_item(
        "软件工程 · 常见设计模式与适用场景", "medium",
        ["软件工程", "设计模式"],
        "关键：单例、工厂、观察者、策略、装饰器——**要知道“解决什么问题”**，"
        "不是背 UML。"
        "面试常问：「你项目里用过哪个模式，为什么用它」。",
        "软件工程 设计模式 面试",
    ),
    course_item(
        "软件工程 · 单元测试与 Git 工作流", "easy",
        ["软件工程", "测试", "Git"],
        "关键：单元测试测**最小可测单元**，好的测试是「快、独立、可重复」。"
        "Git：feature 分支开发 → PR → review → merge；"
        "rebase 和 merge 的区别、冲突怎么解，要动手练过。",
        "软件工程 单元测试 Git 工作流",
    ),

    # ==================================================================
    #  程序设计竞赛基础（专业选修）
    # ==================================================================
    course_item(
        "竞赛 · 常用算法的模板与复杂度", "hard",
        ["竞赛", "算法", "模板"],
        "关键：二分、前缀和、差分、单调队列、并查集、最短路、"
        "最小生成树、树状数组、线段树。"
        "**每个都要能默写模板**——比赛时现推来不及。"
        "复杂度算错是超时的头号原因。",
        "算法竞赛 模板 复杂度",
    ),
]


# --------------------------------------------------------------------------
#  统计与摊派
# --------------------------------------------------------------------------

def count_by_difficulty() -> dict[str, int]:
    """按难度统计。"""
    out = {"easy": 0, "medium": 0, "hard": 0}
    for item in BANK:
        key = item.get("difficulty", "medium")
        out[key] = out.get(key, 0) + 1
    return out


def tag_cloud() -> list[tuple[str, int]]:
    """标签云：按出现次数从多到少。"""
    counts: dict[str, int] = {}
    for item in BANK:
        for tag in item.get("tags") or []:
            counts[tag] = counts.get(tag, 0) + 1
    return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))


def course_groups() -> list[tuple[str, int]]:
    """按"课程"分组统计，看每门课有多少道题。

    课程标签和知识点标签混在同一个 tags 列表里
    （比如 ["数据结构", "链表", "递归"]），这里只挑出课程那一层。
    """
    COURSES = [
        "C语言", "数据结构", "算法设计与分析", "计算机组成原理",
        "操作系统", "计算机网络", "数据库", "离散数学",
        "数字电子", "软件工程", "竞赛",
    ]
    counts = dict.fromkeys(COURSES, 0)
    for item in BANK:
        for tag in item.get("tags") or []:
            if tag in counts:
                counts[tag] += 1
    return [(k, v) for k, v in counts.items() if v]


def as_seed_items(spread_days: int = 7, first_day: date | None = None
                  ) -> list[dict]:
    """把题库摊成"前若干天每天几道"，避免第一天就被一百多道题淹没。

    **为什么改成按比例摊**：原来写死 6 道 + 每 4 道一天，
    那是按 33 道题库定的。现在题库有 126 道，
    照原来的算法会变成"第一天 6 道、之后每天 4 道"，
    要一个多月才轮完一遍——而复习本来就该先过一轮再回头。

    现在的规则：
        · 第一批按天摊，`spread_days` 天摊完（默认 7 天）
        · 每天的数量 = ceil(总数 / spread_days)
        · 同一天里的题按难度交错（easy 和 medium 混着来，
          不要一天全是 hard——那会直接劝退）

    这样她打开程序是"今天 18 道"，而不是"今天 126 道"。
    """
    from datetime import timedelta

    start = first_day or date.today()
    items: list[dict] = []
    total = len(BANK)
    if total == 0:
        return items

    # 每天多少道。
    #
    # 上限刻意压在 8 道：原来那 33 道题库，她**只复习了 2 道**——
    # 说明一天十几道这种量对她来说是不现实的，
    # 排得再满也只会变成打开看一眼就关掉。
    #
    # 宁可排得慢一点、让她真的开始做：
    # 126 道按每天 8 道摊，三周走完第一轮，然后进入 SM-2 的正常节奏。
    per_day = min(8, max(1, -(-total // max(1, spread_days))))

    # ---- 投放顺序：由易到难递增 ----
    #
    # 为什么不用"简单轮流"：那样第一天的 8 道里会有 2 道 hard
    # （K 个一组翻转链表、数据流中的中位数），**开头就劝退**。
    # 而她原来的 33 道题库只复习了 2 道，本来就没建立起习惯，
    # 第一印象尤其重要。
    #
    # 做法：按"目标难度曲线"铺开——前段以 easy 为主，
    # 中段以 medium 为主，hard 集中在后段。
    buckets: dict[str, list[dict]] = {"easy": [], "medium": [], "hard": []}
    for raw in BANK:
        buckets[raw.get("difficulty", "medium")].append(dict(raw))

    interleaved: list[dict] = []
    # 每一轮往结果里放一批，比例随进度变化
    total_n = len(BANK)
    keys = ("easy", "medium", "hard")
    counts = {k: len(buckets[k]) for k in keys}
    cursor = {k: 0 for k in keys}
    while len(interleaved) < total_n:
        # 进度 0 → 1
        p = len(interleaved) / max(1, total_n)
        if p < 0.4:
            # 前 40%：easy 优先，偶尔 medium
            want = ("easy", "easy", "medium", "easy", "medium")
        elif p < 0.8:
            # 中段：medium 为主，掺 easy
            want = ("medium", "medium", "easy", "medium", "hard")
        else:
            # 后段：medium + hard
            want = ("medium", "hard", "hard", "medium")
        for k in want:
            if cursor[k] < counts[k]:
                interleaved.append(buckets[k][cursor[k]])
                cursor[k] += 1
                break
        else:
            # 想要的档位取完了，退而求其次，按 easy → medium → hard 找
            for k in keys:
                if cursor[k] < counts[k]:
                    interleaved.append(buckets[k][cursor[k]])
                    cursor[k] += 1
                    break
            else:
                break

    for index, raw in enumerate(interleaved):
        item = dict(raw)
        day_offset = index // per_day
        item["due"] = start + timedelta(days=day_offset)
        items.append(item)
    return items
