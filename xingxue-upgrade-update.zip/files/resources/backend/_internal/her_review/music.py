"""网易云音乐：搜索 + 取播放直链（纯标准库）。

## 数据源与依据

这份实现对着一份实测研究写的（`build/研究_音乐与cookie登录.md`，研究线产出），
结论都是**实测**出来的，这里只照做，不自己猜：

    搜索   GET https://music.163.com/api/cloudsearch/pc?s=<kw>&type=1&limit=N&offset=0
           —— 它是**唯一白送 `privilege` 的变体**（`/api/search/get` 的 v1 没有），
              而 `privilege` 是判断能不能播的关键。字段名和 v1 不一样：
              cloudsearch 用 `ar`（歌手）/`al`（专辑），v1 用 `artists`/`album`。
    直链   GET https://music.163.com/song/media/outer/url?id=<id>（**不跟随重定向**，只读 Location）
           免费歌 → 302 到 http://m801.music.126.net/.../xxx.mp3
           收费/无版权 → 302 到 http://music.163.com/404

## 四条硬规矩（照研究结论，别"顺手优化"）

1. **`fee` 不能当"能不能播"的判据。** 实测反例：周杰伦原版《晴天》id=186016
   `fee=0` 看着免费，`outer/url` 照样 302 到 `/404`。
   可靠预筛是 `privilege.pl > 0 且 plLevel != "none"`；**最终权威是 `outer/url` 的落点**。
2. **直链只有 25 分钟有效期**（302 目标路径第一段的时间戳 = 请求时刻 + 25:00，实测三次逐次推进）。
   所以**绝不缓存直链**，每次播放都重取（一次 302 很便宜）。
   缓存直链只会带来"点了没反应"这种最难查的 bug。
3. **302 给的是 `http://`，必须手动升级成 `https://`**（实测同一 URL 换 https 是 200）。
   桌面版页面是安全上下文，http 资源可能被拦（混合内容）。
4. **不做任何绕过**：不用 `weapi`/`eapi` 加密接口（实测 weapi 返回空体）、
   不解析登录态取链接口、不解密 VIP、不代理音频。
   放不了的就如实说"需要会员 / 要单独买专辑 / 已经没有版权"。

## 缓存策略（跟"不缓存直链"不冲突）

    · 搜索结果：短时缓存（默认 5 分钟）——避免反复打同一个接口被风控；
    · 直链：**不缓存**（25 分钟就过期）；
    · "放不了"的结论：只缓存 60 秒（进程内），免得她连点几次把同一个 404 打很多遍。
      这是个**否定结论**，60 秒内不可能变；而"能播"的链接一秒都不留。

## 失败面

所有网络失败都转成**中文说明**，返回 `ok=False` 而不是抛异常/500。
离线时搜索和播放都用不了，但**绝不影响其它接口**（路由层各自独立）。
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request

from . import deps

SEARCH_URL = "https://music.163.com/api/cloudsearch/pc"
OUTER_URL = "https://music.163.com/song/media/outer/url"

# 超时固定 8 秒（研究里的实测口径）。搜索接口通常 <1 秒。
TIMEOUT = 8.0

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
HEADERS = {
    "User-Agent": UA,
    # 实测不带 Referer 也能用；带上更稳（万一哪天开始校验）。
    "Referer": "https://music.163.com/",
}

# 搜索缓存时长（秒）。不要设太长：她搜同一个词可能是想看到最新结果。
SEARCH_CACHE_TTL = 300.0
# "放不了"这个结论的缓存时长（秒）。只缓存否定结论。
NEGATIVE_CACHE_TTL = 60.0
# 直链有效期（秒）。研究实测：302 目标路径的时间戳 = 请求时刻 + 25:00。
LINK_TTL = 25 * 60

# 歌词接口（公开）。lv=1 原文、tv=-1 带翻译。
LYRIC_URL = "https://music.163.com/api/song/lyric"
# 歌词几乎不变，缓存久一点（和搜索的 5 分钟分开）
LYRIC_TTL = 6 * 3600.0
# LRC 时间标签：[mm:ss.xx] 或 [mm:ss:xx]（后者少见但要认）
_LRC_TAG = re.compile(r"\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]")

# 进程内缓存：只放**否定结论**，key 是歌曲 id。
_NEGATIVE: dict[str, tuple[float, str]] = {}


class MusicError(Exception):
    """带中文说明的错误。路由层把它转成 ok=False 的返回，不进 500。"""


# --------------------------------------------------------------------------
# 小工具
# --------------------------------------------------------------------------

def https_url(url: str) -> str:
    """把 http 换成 https。

    为什么必须做：`outer/url` 的 302 落点是 `http://m801...mp3`，
    而桌面版页面是安全上下文，http 资源会被当混合内容拦掉。
    实测同一个 URL 换 https 返回 200，所以升级是安全的。
    """
    text = (url or "").strip()
    if text.startswith("http://"):
        return "https://" + text[len("http://"):]
    return text


def _cover(raw: str) -> str:
    """封面：转 https + 要 200x200 的小图（实测 180KB → 13.5KB）。"""
    pic = https_url(str(raw or ""))
    if not pic:
        return ""
    if "?" in pic:
        return pic
    return pic + "?param=200y200"


def duration_text(seconds) -> str:
    """秒 → `m:ss`。负数/非数字一律当 0。"""
    try:
        total = int(seconds)
    except (TypeError, ValueError):
        total = 0
    if total < 0:
        total = 0
    return f"{total // 60}:{total % 60:02d}"


def _artists(raw: dict) -> str:
    """歌手。cloudsearch 是 `ar[].name`，v1 是 `artists[].name`，两种都认。"""
    rows = raw.get("ar") or raw.get("artists") or []
    names = []
    for row in rows:
        if isinstance(row, dict):
            name = str(row.get("name") or "").strip()
        else:
            name = str(row or "").strip()
        if name:
            names.append(name)
    return " / ".join(names)


def _album(raw: dict) -> tuple[str, str]:
    """专辑名 + 封面。cloudsearch 是 `al`，v1 是 `album`。"""
    album = raw.get("al") or raw.get("album") or {}
    if not isinstance(album, dict):
        return "", ""
    return str(album.get("name") or "").strip(), _cover(album.get("picUrl") or "")


def judge(raw: dict) -> tuple[bool, str, str]:
    """能不能播？返回 (可播, 给她的原因, 音质说明)。

    **只用 `privilege`，不用 `fee`**（理由见模块开头第 1 条）。
    返回 True 也只是**预筛过了**，真正播放前还会打一次 `outer/url` 看落点——
    那才是权威判据。
    """
    priv = raw.get("privilege")
    fee = raw.get("fee")
    if not isinstance(priv, dict):
        # 接口没给 privilege（换了变体/字段改名）。这时不能凭 fee 下结论，
        # 交给 outer/url 去判——**宁可让她点一下看到真实结果，也不要假装能/不能播**。
        return True, "", ""

    try:
        pl = int(priv.get("pl") or 0)
    except (TypeError, ValueError):
        pl = 0
    level = str(priv.get("plLevel") or "none")

    if pl > 0 and level != "none":
        return True, "", _quality_text(pl, level)

    # ---- 以下是"放不了"，按 fee 给不同的话术（研究 B6 的建议文案）----
    if fee == 1:
        why = "这首歌需要网易云会员，这里放不了。想听的话要去网易云客户端。"
    elif fee == 4:
        why = "这首歌要单独购买数字专辑，这里放不了。"
    else:
        why = "这首歌在网易云听不了（可能是会员曲目，也可能没有版权）。"
    return False, why, ""


def _quality_text(pl: int, level: str) -> str:
    if pl >= 900000:
        return "无损"
    if pl >= 320000:
        return "320k"
    if pl >= 192000:
        return "192k"
    if pl >= 128000:
        return "128k"
    return level


def parse_song(raw: dict) -> dict:
    """把云端的一条原始数据变成界面要的形状。

    时长单位**统一成秒**（接口给的是毫秒 `dt`）——单位混用是最容易出的错，
    所以这里连 `duration_text` 一起给出来，前端不用再算。
    """
    album, cover = _album(raw)
    ms = raw.get("dt")
    try:
        seconds = int(ms) // 1000 if ms is not None else 0
    except (TypeError, ValueError):
        seconds = 0
    playable, why, quality = judge(raw)
    return {
        "id": raw.get("id"),
        "name": str(raw.get("name") or "").strip() or "（没有名字）",
        "artists": _artists(raw) or "未知歌手",
        "album": album,
        "duration": seconds,
        "duration_text": duration_text(seconds),
        "cover": cover,
        "playable": playable,
        "why": why,
        "quality": quality,
    }


def friendly_network_error(detail: str) -> str:
    """把底层的英文报错翻成一句她能看懂的话。

    **不要把 `URLError`/`TimeoutError` 这种原文直接丢到界面上**——
    她会以为程序坏了。
    """
    text = str(detail or "")
    if "HTTP 4" in text or "HTTP 5" in text:
        return f"网易云没给正常回应（{text}），可能被限流了，过一会儿再试。"
    if "timeout" in text.lower() or "Timeout" in text:
        return "连网易云超时了（8 秒没回应）。检查一下网络，过一会儿再试。"
    return "连不上网易云（网络不通，或者它暂时不可用）。音乐功能现在用不了，别的功能不受影响。"


# --------------------------------------------------------------------------
# 搜索
# --------------------------------------------------------------------------

def _cache_key(keyword: str, limit: int) -> str:
    return f"music:search:{keyword.strip().lower()}:{int(limit)}"


def search(keyword: str, limit: int = 30) -> dict:
    """搜歌。返回 {ok, songs, keyword, count, cached} 或 {ok: False, error}。"""
    keyword = (keyword or "").strip()
    if not keyword:
        return {"ok": False, "error": "想听什么？先输入歌名或者歌手。", "songs": []}
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 30
    limit = max(1, min(50, limit))

    key = _cache_key(keyword, limit)
    cached = deps.cache_get(key, ttl=SEARCH_CACHE_TTL)
    if isinstance(cached, dict) and cached.get("songs"):
        return dict(cached, cached=True)

    ok, data, error = deps.http_get_json(
        SEARCH_URL,
        headers=HEADERS,
        params={"s": keyword, "type": 1, "limit": limit, "offset": 0},
        timeout=TIMEOUT,
        retries=1,
    )
    if not ok:
        return {"ok": False, "error": friendly_network_error(error), "songs": []}

    songs = _songs_from(data)
    if songs is None:
        return {"ok": False, "error": "网易云回的格式看不懂（接口可能改了）。", "songs": []}
    if not songs:
        return {"ok": True, "songs": [], "count": 0, "keyword": keyword,
                "note": f"没搜到「{keyword}」。换个歌名或者歌手名试试。"}

    out = {"ok": True, "songs": songs, "count": len(songs), "keyword": keyword,
           "cached": False}
    deps.cache_set(key, out)
    return out


def _songs_from(data) -> list[dict] | None:
    """从返回体里取歌曲数组。取不到就返回 None（跟"搜到 0 条"区分开）。"""
    if not isinstance(data, dict):
        return None
    result = data.get("result")
    if isinstance(result, dict):
        rows = result.get("songs")
    else:
        rows = data.get("songs")
    if rows is None:
        return None
    if not isinstance(rows, list):
        return None
    return [parse_song(row) for row in rows if isinstance(row, dict)]


# --------------------------------------------------------------------------
# 播放直链
# --------------------------------------------------------------------------

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """不自动跟随重定向。

    为什么必须这样：我们要的就是 302 的 `Location` 本身。
    跟着走只会把 mp3 整段拉进内存（5MB 起），而且分不清"落到 404"和"拿到音频"。
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _location(url: str) -> tuple[int, str]:
    """发一次请求，拿状态码和 Location。3xx 不作为异常抛出（我们要看它）。"""
    opener = urllib.request.build_opener(_NoRedirect)
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with opener.open(req, timeout=TIMEOUT) as resp:
            return int(resp.status), (resp.headers.get("Location") or "")
    except urllib.error.HTTPError as exc:
        location = ""
        try:
            location = exc.headers.get("Location") or ""
        except Exception:
            location = ""
        return int(exc.code), location


def stream_url(song_id) -> dict:
    """取一首歌的播放直链。返回 {ok, url, expires_in} 或 {ok: False, why}。

    **不缓存成功的直链**（25 分钟就过期）。只把"放不了"缓存 60 秒。
    """
    try:
        sid = int(song_id)
    except (TypeError, ValueError):
        return {"ok": False, "why": "歌曲 id 不对（要是数字）。"}
    if sid <= 0:
        return {"ok": False, "why": "歌曲 id 不对（要是数字）。"}

    key = str(sid)
    hit = _NEGATIVE.get(key)
    if hit and time.time() - hit[0] < NEGATIVE_CACHE_TTL:
        return {"ok": False, "why": hit[1], "cached": True}

    try:
        status, location = _location(f"{OUTER_URL}?id={sid}")
    except Exception:
        return {"ok": False, "why": friendly_network_error("URLError")}

    location = (location or "").strip()
    # 落点判据（研究实测）：302 → .../404 就是放不了；没有 Location 也不对。
    if not location or "/404" in location:
        why = "这首歌在网易云已经没有版权了（或者需要会员），这里放不了。"
        _NEGATIVE[key] = (time.time(), why)
        return {"ok": False, "why": why}
    if status not in (200, 301, 302, 303, 307, 308):
        why = friendly_network_error(f"HTTP {status}")
        return {"ok": False, "why": why}
    if not location.lower().startswith("http"):
        why = "网易云给的播放地址看不懂，换一首试试。"
        _NEGATIVE[key] = (time.time(), why)
        return {"ok": False, "why": why}

    return {"ok": True, "url": https_url(location), "expires_in": LINK_TTL}


# --------------------------------------------------------------------------
# 歌词
# --------------------------------------------------------------------------

def parse_lrc(raw: str) -> list[dict]:
    """把 LRC 文本解析成 [{t: 秒, text: 歌词}]，按时间排序。

    一行可能有多个时间标签（`[00:12.00][01:20.00] 副歌`），每个都要算一条。
    空行/纯标签行（`[00:00.000]`）丢掉——留着会在面板上撑出一堆空白。
    """
    out: list[dict] = []
    for line in (raw or "").splitlines():
        stamps = _LRC_TAG.findall(line)
        if not stamps:
            continue
        text = _LRC_TAG.sub("", line).strip()
        if not text:
            continue
        for mm, ss, frac in stamps:
            try:
                sec = int(mm) * 60 + int(ss)
            except ValueError:
                continue
            if frac:
                # 两位是百分秒，三位是毫秒
                sec += int(frac) / (1000.0 if len(frac) == 3 else 100.0)
            out.append({"t": round(sec, 2), "text": text})
    # 同一时间点重复的（原文+翻译各占一条时会出现）只留一条
    seen: set[tuple[float, str]] = set()
    uniq: list[dict] = []
    for item in sorted(out, key=lambda x: x["t"]):
        key = (item["t"], item["text"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(item)
    return uniq


def _merge_translation(lines: list[dict], trans: list[dict]) -> list[dict]:
    """把翻译按时间贴到原文上（对不上的就丢掉，不硬凑）。"""
    if not lines or not trans:
        return lines
    by_t = {round(x["t"], 1): x["text"] for x in trans}
    for item in lines:
        zh = by_t.get(round(item["t"], 1))
        if zh:
            item["zh"] = zh
    return lines


def lyric(song_id) -> dict:
    """取歌词。返回 {ok, lines, has_translation, cached} 或 {ok: False, error}。

    没有歌词的三种情况都当成"没有"，并且**如实说明**：
    `nolyric`（纯音乐）/ 接口 200 但内容为空 / 只有时间标签没有文字。
    """
    try:
        sid = int(song_id)
    except (TypeError, ValueError):
        return {"ok": False, "lines": [], "error": "歌曲 id 不对。"}
    if sid <= 0:
        return {"ok": False, "lines": [], "error": "歌曲 id 不对。"}

    key = f"music:lyric:{sid}"
    cached = deps.cache_get(key, ttl=LYRIC_TTL)
    if isinstance(cached, dict):
        return dict(cached, cached=True)

    try:
        ok, data, error = deps.http_get_json(
            LYRIC_URL,
            headers=HEADERS,
            params={"id": str(sid), "lv": "1", "kv": "1", "tv": "-1"},
            timeout=TIMEOUT,
        )
    except Exception as exc:
        return {"ok": False, "lines": [],
                "error": f"取歌词出问题了（{exc.__class__.__name__}）。"}

    if not ok or not isinstance(data, dict):
        detail = friendly_network_error(str(error or ""))
        return {"ok": False, "lines": [],
                "error": f"没取到歌词：{detail}"}

    if data.get("nolyric") is True:
        return {"ok": False, "lines": [], "error": "这首是纯音乐，没有歌词。"}

    raw = ((data.get("lrc") or {}).get("lyric") or "")
    lines = parse_lrc(raw)
    if not lines:
        return {"ok": False, "lines": [],
                "error": "这首歌没有歌词（或者歌词是空的）。"}
    trans = parse_lrc(((data.get("tlyric") or {}).get("lyric") or ""))
    if trans:
        lines = _merge_translation(lines, trans)

    out = {
        "ok": True,
        "id": sid,
        "lines": lines,
        "has_translation": bool(trans),
        "count": len(lines),
        "cached": False,
    }
    deps.cache_set(key, out)
    return out


def clear_caches() -> int:
    """清掉进程内的否定缓存（自测/诊断用）。返回清掉几条。"""
    count = len(_NEGATIVE)
    _NEGATIVE.clear()
    return count


# --------------------------------------------------------------------------
# 自测（**不联网**：只测纯函数和判据，联网的部分由 scripts 里的端到端脚本覆盖）
# --------------------------------------------------------------------------

def _selftest() -> None:
    # ---- 选歌字段解析：cloudsearch 的 ar/al 和 v1 的 artists/album 都要认 ----
    raw = {
        "id": 5257138,
        "name": "屋顶",
        "ar": [{"name": "周杰伦"}, {"name": "温岚"}],
        "al": {"name": "男女情歌对唱冠军全记录",
               "picUrl": "http://p2.music.126.net/x.jpg"},
        "dt": 319039,
        "fee": 8,
        "privilege": {"pl": 320000, "plLevel": "exhigh"},
    }
    song = parse_song(raw)
    assert song["id"] == 5257138
    assert song["name"] == "屋顶"
    assert song["artists"] == "周杰伦 / 温岚", song["artists"]
    assert song["album"] == "男女情歌对唱冠军全记录"
    # 毫秒 → 秒；319039ms = 319s = 5:19（研究里实测这个数字）
    assert song["duration"] == 319, song["duration"]
    assert song["duration_text"] == "5:19", song["duration_text"]
    assert song["cover"] == "https://p2.music.126.net/x.jpg?param=200y200", song["cover"]
    assert song["playable"] is True
    assert song["why"] == ""
    assert song["quality"] == "320k", song["quality"]

    # ---- v1 变体的字段名也要能解析 ----
    v1 = {"id": 1, "name": "x", "artists": [{"name": "A"}], "album": {"name": "B"},
          "dt": 1000, "privilege": {"pl": 128000, "plLevel": "standard"}}
    assert parse_song(v1)["artists"] == "A"
    assert parse_song(v1)["album"] == "B"
    assert parse_song(v1)["quality"] == "128k"

    # ---- 会员歌（fee=1, pl=0）→ 放不了，且文案说"需要会员" ----
    vip = {"id": 25730757, "name": "稳稳的幸福", "ar": [{"name": "陈奕迅"}],
           "al": {"name": "x"}, "dt": 261000, "fee": 1,
           "privilege": {"pl": 0, "plLevel": "none"}}
    s = parse_song(vip)
    assert s["playable"] is False
    assert "会员" in s["why"], s["why"]

    # ---- 数字专辑（fee=4）→ 文案是"要单独买" ----
    album = dict(vip, fee=4)
    assert "数字专辑" in parse_song(album)["why"]

    # ---- **最关键的一条**：fee=0 但 pl=0 也不能说可播（晴天 186016 的反例）----
    sunny = {"id": 186016, "name": "晴天", "ar": [{"name": "周杰伦"}], "al": {"name": "x"},
             "dt": 269000, "fee": 0, "privilege": {"pl": 0, "plLevel": "none"}}
    s = parse_song(sunny)
    assert s["playable"] is False, "fee=0 不能当作可播——晴天就是反例"
    assert s["why"], "放不了必须给原因"

    # ---- 没有 privilege 字段时不硬判（交给 outer/url 去判）----
    unknown = {"id": 2, "name": "y", "ar": [], "al": {}, "dt": 0, "fee": 1}
    assert parse_song(unknown)["playable"] is True, "没有 privilege 时不该凭 fee 下结论"

    # ---- 时长文案 ----
    assert duration_text(0) == "0:00"
    assert duration_text(59) == "0:59"
    assert duration_text(60) == "1:00"
    assert duration_text(319) == "5:19"
    assert duration_text(3600) == "60:00"
    assert duration_text(None) == "0:00"
    assert duration_text("坏值") == "0:00"
    assert duration_text(-5) == "0:00"

    # ---- https 升级（研究第 3 条硬规矩）----
    assert https_url("http://m801.music.126.net/a.mp3") == "https://m801.music.126.net/a.mp3"
    assert https_url("https://x/a.mp3") == "https://x/a.mp3"
    assert https_url("") == ""

    # ---- 封面小图 ----
    assert _cover("http://a/b.jpg") == "https://a/b.jpg?param=200y200"
    assert _cover("http://a/b.jpg?x=1") == "https://a/b.jpg?x=1"
    assert _cover("") == ""

    # ---- 返回体解析：格式不对要能区分出"看不懂"和"搜到 0 条" ----
    assert _songs_from({"result": {"songs": []}}) == []
    assert _songs_from({"result": {"songs": [raw]}})[0]["name"] == "屋顶"
    assert _songs_from({"songs": [raw]})[0]["name"] == "屋顶"
    assert _songs_from({"result": {}}) is None
    assert _songs_from("不是字典") is None

    # ---- 空关键词不该发请求 ----
    out = search("   ")
    assert out["ok"] is False and out["songs"] == []
    assert "想听什么" in out["error"]

    # ---- 网络错误要翻成中文，不能把 URLError 丢出去 ----
    text = friendly_network_error("URLError")
    assert "网易云" in text and "URLError" not in text, text
    assert "超时" in friendly_network_error("TimeoutError")
    assert "限流" in friendly_network_error("HTTP 403")

    # ---- 直链：坏 id 不进网络，直接给中文原因 ----
    assert stream_url("abc")["ok"] is False
    assert stream_url(None)["ok"] is False
    assert stream_url(0)["ok"] is False
    assert "id" in stream_url("abc")["why"]

    # ---- 否定缓存：清一下别影响别的自测 ----
    clear_caches()

    print("music selftest: 全部断言通过 ✓")


if __name__ == "__main__":
    _selftest()
