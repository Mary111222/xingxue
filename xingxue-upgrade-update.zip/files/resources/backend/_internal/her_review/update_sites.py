"""固定的发布通道（写死在构建配置里，界面按钮直接用，不用每次复制网址）。

升级版用的是 **GitHub 固定分支**（不是 Releases/latest）：
    https://github.com/<owner>/<repo>/tree/<branch>
固定分支里放两个文件：
    update.json                    ← 版本/大小/sha256/更新说明/三路下载地址
    xingxue-upgrade-update.zip     ← 更新包本体（files/<相对路径> + manifest.json）

为什么用固定分支而不是 Releases/latest：
    同一个仓库 `Mary111222/xingxue` 的 Releases/latest 已经被「集成电路版」占用，
    两版各自发版会互相覆盖。固定分支互不影响。

下载走三路（国内网络总有一路能通）：
    ① raw.githubusercontent.com（直链，最稳）
    ② cdn.jsdelivr.net（CDN，raw 被墙时常用）
    ③ github.com/.../raw/...（网页版 raw）

构建时 `scripts/build_backend.py` 读 `_tools/pack_upgrade/github_release.json`，
生成 `her_review/github_config.py`（只写 owner/repo/branch/资产名，**不写 token**）。
"""
from urllib.parse import quote

try:  # 构建时生成；开发态没生成时为空（回退到占位地址）
    from . import github_config
except ImportError:  # pragma: no cover
    github_config = None

GH_OWNER = str(getattr(github_config, "OWNER", "") or "").strip()
GH_REPO = str(getattr(github_config, "REPO", "") or "").strip()
GH_BRANCH = str(getattr(github_config, "BRANCH", "") or "upgrade-channel").strip()
GH_ASSET = str(getattr(github_config, "ASSET_NAME", "") or "xingxue-upgrade-update.zip").strip()
GITHUB_READY = bool(GH_OWNER and GH_REPO)

# update.json 的固定文件名（和 build_pack.py 里一致）
META_NAME = "update.json"

if GITHUB_READY:
    SITE_NAME = "GitHub 固定分支"
    _raw = f"https://raw.githubusercontent.com/{GH_OWNER}/{GH_REPO}/{GH_BRANCH}"
    _jsd = f"https://cdn.jsdelivr.net/gh/{GH_OWNER}/{GH_REPO}@{GH_BRANCH}"
    _gh = f"https://github.com/{GH_OWNER}/{GH_REPO}/raw/{GH_BRANCH}"

    # 更新包的三路下载地址（第一路当"主地址"，后两路当 fallback）。
    # 顺序：raw（最快、缓存最短）→ github.com/raw（跟着分支走）→ jsDelivr 放最后。
    # 为什么 jsDelivr 最后：它按 @分支 缓存，同一个资产名覆盖后可能几小时都是旧的，
    # 而前两路几分钟内就能拿到新文件；等它刷新后三路才完全一致。
    DOWNLOAD_URL = f"{_raw}/{quote(GH_ASSET)}"
    DOWNLOAD_FALLBACKS = [
        f"{_gh}/{quote(GH_ASSET)}",
        f"{_jsd}/{quote(GH_ASSET)}",
    ]
    # 更新信息（update.json）也走同样三路
    META_URLS = [
        f"{_raw}/{quote(META_NAME)}",
        f"{_gh}/{quote(META_NAME)}",
        f"{_jsd}/{quote(META_NAME)}",
    ]
    # 「打开下载页」= 分支文件列表页（能看到 update.json / zip，也能手动下载）
    DOWNLOAD_PAGE_URL = f"https://github.com/{GH_OWNER}/{GH_REPO}/tree/{GH_BRANCH}"
    # 「上传更新包（作者用）」= GitHub 网页版直接上传到该分支的页面
    UPLOAD_URL = f"https://github.com/{GH_OWNER}/{GH_REPO}/upload/{GH_BRANCH}"
    SITE_HINT = (f"GitHub · {GH_OWNER}/{GH_REPO}@{GH_BRANCH}："
                 "一键更新直接从固定分支下载最新更新包并校验")
else:  # 还没配置仓库：给空占位，界面按钮会提示"网址还没配置"
    SITE_NAME = "还没配置"
    DOWNLOAD_URL = ""
    DOWNLOAD_FALLBACKS = []
    META_URLS = []
    DOWNLOAD_PAGE_URL = ""
    UPLOAD_URL = ""
    SITE_HINT = "还没配置 GitHub 发布通道（构建时生成 her_review/github_config.py）"

DOWNLOAD_IS_PLACEHOLDER = not GITHUB_READY
